function [A,id_gauge,gname,zone] = read_attr_US(dirD,bas)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%READ_ATTR_US Read catchment attributes of CAMELS-US dataset.
%
% SYNOPSIS:
%   [A,id_gauge,gname,zone] = read_attr_US(dirD,bas)
%
% INPUT:
%   dirD        Directory with CAMELS-US catchment-attribute files
%   bas         OPTIONAL: structure with basin and attribute information
%    .id_attr    rx1 vector of integer attribute IDs
%    .pr_attr    OPTIONAL: print attribute table [1/0]
%
% OUTPUT:
%   A           r x K matrix of standardized selected attributes
%   id_gauge    K x 1 vector with USGS gauge identifiers
%   gname       K x 1 vector/string array with standardized gauge names
%   zone        structure with CAMELS-US hydroclimatic classification
%    .id          K x 1 string array with zone labels per basin
%    .num         K x 1 numeric vector with integer zone identifiers
%    .names       m x 1 string array with unique zone names
%    .aridity     K x 1 vector with aridity-index values
%    .frac_snow   K x 1 vector with snow-fraction values
%
% DESCRIPTION:
%   This function reads and joins CAMELS-US climate, geology, hydrology,
%   soil, topography, and vegetation attributes by gauge_id. The attribute
%   order mirrors the internal concatenation:
%   climate -> geology -> hydrology -> soil -> topography -> vegetation.
%
% NOTES:
%   If bas is omitted, a small default attribute set is used. Default
%   attributes should include only basic watershed and climate information,
%   not discharge-derived hydrologic signatures.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% © Written by Jasper A. Vrugt, Dec. 2025 / updated Apr. 2026             %
% University of California, Irvine                                        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    if nargin < 1 ...
            || isempty(dirD)
        error('read_attr_US:missingDir', ...
            ['      Error:read_attr_US: ' ...
            'dirD must be provided.']);
    end
    
    if ~isfolder(dirD)
        error('read_attr_US:missingDir', ...
            ['      Error:read_attr_US: Attribute ' ...
            'directory does not exist: %s'],dirD);
    end
    
    if nargin < 2 ...
            || isempty(bas)
        bas = struct();
    end
    
    if ~isstruct(bas)
        error('read_attr_US:badBas', ...
            ['      Error:read_attr_US: ' ...
            'bas must be a structure.']);
    end
    % =========================================
    % ZONE CONTROL PARAMETERS (GLOBAL DEFAULTS)
    % =========================================
    if ~isfield(bas,'min_per_zone') ...
            || isempty(bas.min_per_zone)
        min_per_zone = 5;
    else
        min_per_zone = bas.min_per_zone;
    end
    if ~isfield(bas,'max_zones') ...
            || isempty(bas.max_zones)
        max_zones = 8;
    else
        max_zones = bas.max_zones;
    end
    
    pr_table = 1;
    if isfield(bas,'pr_attr') ...
            && ~isempty(bas.pr_attr)
        pr_table = bas.pr_attr;
    end
    
    if ~isfield(bas,'id_attr') ...
            || isempty(bas.id_attr)
        error('read_attr_US:missingIdAttr', ...
            ['      Error:read_attr_US: ' ...
            'bas.id_attr must be provided ' ...
            'by the GUI/config.']);
    end
    
    % File paths
    f_clim = fullfile(dirD,'camels_clim.txt');
    f_geol = fullfile(dirD,'camels_geol.txt');
    f_hydro = fullfile(dirD,'camels_hydro.txt');
    f_soil = fullfile(dirD,'camels_soil.txt');
    f_topo = fullfile(dirD,'camels_topo.txt');
    f_vege = fullfile(dirD,'camels_vege.txt');
    f_name = fullfile(dirD,'camels_name.txt');
    f_namec = fullfile(dirD,'camels_name_clean.txt');
    
    % -------------------------
    % Optional: read attributes
    % -------------------------
    fprintf('... Reading basin attributes');
    
    caller = mfilename;
    must_exist(f_clim,'camels_clim.txt',caller);
    must_exist(f_geol,'camels_geol.txt',caller);
    must_exist(f_hydro,'camels_hydro.txt',caller);
    must_exist(f_soil,'camels_soil.txt',caller);
    must_exist(f_topo,'camels_topo.txt',caller);
    must_exist(f_vege,'camels_vege.txt',caller);
    
    climate = readtable(f_clim);
    col_c = 2:12;
    C_id = climate{:,1};
    C = climate(:,col_c);
    
    geology = readtable(f_geol);
    col_g = 2:8;
    G_id = geology{:,1};
    G = geology(:,col_g);
    
    hydro = readtable(f_hydro);
    col_h = 2:14;
    H_id = hydro{:,1};
    H = hydro(:,col_h);
    
    soil = readtable(f_soil);
    col_s = 2:12;
    S_id = soil{:,1};
    S = soil(:,col_s);
    
    topo = readtable(f_topo);
    col_t = 2:7;
    T_id = topo{:,1};
    T = topo(:,col_t);
    
    vege = readtable(f_vege);
    col_v = 2:10;
    V_id = vege{:,1};
    V = vege(:,col_v);
    
    % Check row counts before concatenation
    nrow = height(climate);
    if any([height(geology), ...
            height(hydro), ...
            height(soil), ...
            height(topo), ...
            height(vege)] ~= nrow)
        error('read_attr_US:tableSizeMismatch', ...
            ['      Error:read_attr_US: ' ...
            'Attribute tables have different ' ...
            'numbers of basins/rows.']);
    end
    
    % Check gauge ID consistency across tables
    id_gauge_all = [double(C_id), ...
        double(G_id),double(H_id), ...
        double(S_id),double(T_id), ...
        double(V_id)];
    
    if any(any(id_gauge_all ~= id_gauge_all(:,1)))
        error('read_attr_US:idMismatch', ...
            ['      Error:read_attr_US: ' ...
            'Catchment gauge ID mismatch ' ...
            'across attribute tables.']);
    end
    id_gauge = id_gauge_all(:,1);             % 2nd return argument
    
    AA = [C G H S T V];                     % attributes, all basins
    region = erase(mfilename,'read_attr_');
    zone = classify_camels_all_zones(region,AA, ...
        min_per_zone,max_zones);
    
    % ------------------
    % Generic attributes
    % ------------------
    [A,labels] = build_attr_matrix(AA,bas, ...
        mfilename,pr_table);
    
    if pr_table == 1
        assignin('base', ...
            'SAGE_US_attribute_labels',labels);
    end
    
    fprintf(' ... Done\n');
    
    % -----------------------
    % Always read gauge names
    % -----------------------
    must_exist(f_name,'camels_name.txt',caller);
    
    local_standardize_camels_name_file(f_name, ...
        f_namec);
    if isfile(f_namec)
        fname_to_read = f_namec;
    else
        warning('read_attr_US:noCleanNameFile', ...
            ['      Warning:read_attr_US: ' ...
            'local_standardize_camels_name_file ' ...
            'did not create %s. ' ...
            'Using raw camels_name.txt instead.'], ...
            f_namec);
        fname_to_read = f_name;
    end
    
    fprintf('... Reading basin ID''s and names');
    
    names = readtable(fname_to_read);
    
    if width(names) < 3
        error('read_attr_US:badNameFile', ...
            ['      Error:read_attr_US: ' ...
            'Name file %s has fewer ' ...
            'than 3 columns.'], ...
            fname_to_read);
    end
    
    id_names = names{:,1};
    [tf,loc] = ismember(id_gauge,id_names);
    
    if ~all(tf)
        missing = id_gauge(~tf);
        error('read_attr_US:missingGaugeNames', ...
            ['      Error:read_attr_US: ' ...
            'Missing gauge names for %d basin IDs ' ...
            '(e.g., %s).'], ...
            numel(missing), local_id_str(missing(1)));
    end
    
    gname = standardize_camels_gauge_names(names{loc,3}, ...
        'CAMELS_US',id_gauge);

    fprintf(' ... Done\n');

end

% =============
% Local helpers
% =============
function s = local_id_str(x)
    if isnumeric(x) ...
            && isfinite(x)
        s = sprintf('%08d',x);
    else
        s = char(string(x));
    end
end

% =========================================================
function local_standardize_camels_name_file(infile,outfile)
% =========================================================
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%LOCAL_STANDARDIZE_CAMELS_NAME_FILE Enforce consistent CAMELS gauge-names
%
% SYNOPSIS:
%   local_standardize_camels_name_file(infile)
%   local_standardize_camels_name_file(infile,outfile)
%
% INPUT:
%   infile      string/char with semicolon-delimited CAMELS name file
%               with header:
%                 gauge_id;huc_02;gauge_name
%
%   outfile     OPTIONAL string/char with output file name
%               [] or omitted -> overwrite infile
%
% OUTPUT:
%   The standardized CAMELS name file is written to outfile. The function
%   also prints a short summary of the number of modified gauge names.
%
% DESCRIPTION:
%   This function standardizes CAMELS gauge names by enforcing consistent
%   abbreviations and capitalization. It is used by read_attr to create a
%   cleaned name file before gauge names are matched to USGS basin IDs.
%
% STANDARDIZATION RULES:
%   nr / near              -> near
%   above                  -> abv
%   below                  -> blw
%   R / Riv / Rv / River   -> River
%   C / Cr / Ck / Creek    -> Creek
%   Br / Branch            -> Branch
%   Bk / Brk / Brook       -> Brook
%   F / Fk / Fork          -> Fork
%   N F / Nf / North Fork  -> North Fork
%   S F / Sf / South Fork  -> South Fork
%   E F / Ef / East Fork   -> East Fork
%   W F / Wf / West Fork   -> West Fork
%   M F / Mf / Middle Fork -> Middle Fork
%
% NOTES:
%   - Standard output uses near, abv, and blw consistently.
%   - US state abbreviations are preserved in uppercase, for example CA,
%     NY, TX, and WA.
%   - The input file is overwritten safely through a temporary file when
%     infile and outfile are the same.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% © Written by Jasper A. Vrugt, Apr. 2026                                 %
% University of California, Irvine                                        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    if nargin < 1 ...
            || isempty(infile)
        error(['read_attr:local_standardize_' ...
            'camels_name_file:missingInput'], ...
            ['      Error:read_attr:local_' ...
            'standardize_camels_name_file: ' ...
            'Input file must be provided.']);
    end
    
    if nargin < 2 ...
            || isempty(outfile)
        outfile = infile;
    end
    
    infile = char(string(infile));
    outfile = char(string(outfile));
    
    if ~isfile(infile)
        error(['read_attr:local_standardize_' ...
            'camels_name_file:missingFile'], ...
            ['      Error:read_attr:local_' ...
            'standardize_camels_name_file: ' ...
            'Input file does not exist: %s'],infile);
    end
    
    L = readlines(infile);
    if isempty(L)
        error(['read_attr:local_standardize_' ...
            'camels_name_file:emptyFile'], ...
            ['      Error:read_attr:local_' ...
            'standardize_camels_name_file: ' ...
            'Empty file: %s'],infile);
    end
    
    H = string(L(1));
    D = string(L(2:end));
    D(D == "") = [];
    
    if isempty(D)
        warning(['read_attr:local_standardize_' ...
            'camels_name_file:noDataRows'], ...
            ['      Warning:read_attr:local_' ...
            'standardize_camels_name_file: ' ...
            'No data rows found in: %s'],infile);
    
        local_safe_write_lines(H,infile,outfile);
        return
    end
    
    parts = split(D,';');
    if size(parts,2) < 3
        error(['read_attr:local_standardize_' ...
            'camels_name_file:badColumns'], ...
            ['      Error:read_attr:local_' ...
            'standardize_camels_name_file: ' ...
            'Expected >= 3 semicolon-' ...
            'delimited columns in %s'], ...
            infile);
    end
    
    name0 = string(parts(:,3));
    name  = name0;
    
    for i = 1:numel(name)
        name(i) = local_standardize_name(name(i));
    end
    
    parts(:,3) = name;
    Lout = [H; join(parts,';')];
    
    local_safe_write_lines(Lout,infile,outfile);
    
    nChanged = nnz(name ~= name0);
    
    fprintf(['      read_attr:local_' ...
        'standardize_camels_name_file: ' ...
        'Wrote standardized file to: %s\n'], ...
        outfile);
    fprintf(['      read_attr:local_' ...
        'standardize_camels_name_file: ' ...
        '%d of %d gauge names modified\n'], ...
        nChanged,numel(name));
    
    % quick residual check
    bad = false(size(name));
    name_cell = cellstr(name);
    
    pat = {'(?i)\bC\b','(?i)\bCr\b','(?i)\bCk\b', ...
        '(?i)\bR\b','(?i)\bRv\b','(?i)\bRiv\b', ...
        '(?i)\bBr\b','(?i)\bBk\b','(?i)\bBrk\b', ...
        '(?i)\bF\b','(?i)\bFk\b', ...
        '(?i)\bNf\b','(?i)\bSf\b','(?i)\bEf\b', ...
        '(?i)\bWf\b','(?i)\bMf\b', ...
        '(?i)\bab\b','(?i)\bbl\b', ...
        '(?i)\babove\b','(?i)\bbelow\b'};
    
    for k = 1:numel(pat)
        bad = bad | ~cellfun(@isempty, ...
            regexp(name_cell,pat{k},'once'));
    end
    
    if any(bad)
        fprintf(['      read_attr:local_' ...
            'standardize_camels_name_file: ' ...
            'Warning: %d names still ' ...
            'contain short tokens\n'], ...
            nnz(bad));
    
        ibad = find(bad);
        nshow = min(20,numel(ibad));
        for k = 1:nshow
            ii = ibad(k);
            fprintf('         %s  -->  %s\n', ...
                char(name0(ii)), ...
                char(name(ii)));
        end
    end

end

% ==================================================
function local_safe_write_lines(Lout,infile,outfile)
% ==================================================
%LOCAL_SAFE_WRITE_LINES Write safely, especially when overwriting infile.

    same_file = strcmp(local_canonical_path(infile), ...
        local_canonical_path(outfile));
    
    if same_file
        tmpfile = [outfile '.tmp'];
        cleanupObj = onCleanup(@() ...
            local_delete_if_exists(tmpfile));
    
        writelines(Lout,tmpfile);
    
        % Replace original only after successful write
        movefile(tmpfile,outfile,'f');
        clear cleanupObj
    else
        writelines(Lout,outfile);
    end
end

% ====================================
function p = local_canonical_path(pth)
% ====================================
%LOCAL_CANONICAL_PATH Normalize path representation for comparison.

    p = char(string(pth));
    if ispc
        p = lower(p);
    end
end

% ================================
function local_delete_if_exists(f)
% ================================
%LOCAL_DELETE_IF_EXISTS Delete file if it exists.

    try
        if isfile(f)
            delete(f);
        end
    catch
    end
end

function s = local_standardize_name(s)
    
    s = char(string(s));
    s = strtrim(s);
    
    % basic whitespace normalization
    s = regexprep(s,'\s+',' ');
    s = regexprep(s,'@\s*','@ ');
    s = strtrim(s);
    
    % split into tokens by spaces
    tok = regexp(s,'\s+','split');
    
    out = {};
    i = 1;
    
    while i <= numel(tok)
    
        t0 = tok{i};
    
        % separate trailing punctuation
        [core,suf] = local_strip_trailing_punct(t0);
        lc = lower(core);
    
        % ---- multi-token directional fork handling ----
        if i < numel(tok)
            [core2,suf2] = ...
                local_strip_trailing_punct(tok{i+1});
            lc2 = lower(core2);
        else
            suf2 = '';
            lc2 = '';
        end
    
        % full word directional fork
        if any(strcmp(lc,{'north','south', ...
                'east','west','middle'})) ...
                && strcmp(lc2,'fork')
            out{end+1} = [local_proper_direction(lc) suf];          %#ok
            out{end+1} = ['Fork' suf2];                             %#ok
            i = i + 2;
            continue
        end
    
        % abbreviated directional fork: N F, S F, ...
        if any(strcmp(lc,{'n','s','e','w','m'})) ...
                && strcmp(lc2,'f')
            out{end+1} = [local_expand_direction_letter(lc) suf];   %#ok
            out{end+1} = ['Fork' suf2];                             %#ok
            i = i + 2;
            continue
        end
    
        % condensed directional fork: Nf, Sf, Ef, Wf, Mf
        switch lc
            case 'nf'
                out{end+1} = ['North' suf];     %#ok
                out{end+1} = 'Fork';            %#ok
                i = i + 1;
                continue
            case 'sf'
                out{end+1} = ['South' suf];     %#ok
                out{end+1} = 'Fork';            %#ok
                i = i + 1;
                continue
            case 'ef'
                out{end+1} = ['East' suf];      %#ok
                out{end+1} = 'Fork';            %#ok
                i = i + 1;
                continue
            case 'wf'
                out{end+1} = ['West' suf];      %#ok
                out{end+1} = 'Fork';            %#ok
                i = i + 1;
                continue
            case 'mf'
                out{end+1} = ['Middle' suf];    %#ok
                out{end+1} = 'Fork';            %#ok
                i = i + 1;
                continue
        end
    
        % ---- single-token normalization ----
        switch lc
            case {'near','nr'}
                core = 'near';
    
            case {'above','abv','ab'}
                core = 'abv';
    
            case {'below','blw','bl'}
                core = 'blw';
    
            case {'river','riv','rv','r'}
                core = 'River';
    
            case {'creek','ck','cr','c'}
                core = 'Creek';
    
            case {'branch','br'}
                core = 'Branch';
    
            case {'brook','bk','brk'}
                core = 'Brook';
    
            case {'fork','fk','f'}
                core = 'Fork';
    
            case 'us'
                core = 'US';
    
            case 'ynp'
                core = 'YNP';
    
            otherwise
                core = local_fix_case(core);
        end
    
        out{end+1} = [core suf];                %#ok
        i = i + 1;
    end
    
    s = strjoin(out,' ');
    
    % display/name cleanup
    s = regexprep(s,'\s*@\s*',' at ');
    s = regexprep(s,'(?i)\bnr\b','near');
    
    % cleanup duplicate fork artifacts
    s = regexprep(s,['(?i)\b(North|South|East|West|Middle)' ...
        '\s+Fork\s+Fork\b'],'$1 Fork');
    
    % cleanup spacing before punctuation
    s = regexprep(s,'\s+,',',');
    s = regexprep(s,'\s+',' ');
    s = strtrim(s);

end

% =================================================
function [core,suf] = local_strip_trailing_punct(t)
% =================================================
%LOCAL_STRIP_TRAILING_PUNCT

    m = regexp(t,'^(.*?)([.,;:]*)$','tokens','once');
    
    if isempty(m)
        core = t;
        suf = '';
    else
        core = m{1};
        suf  = m{2};
    end
end

% =====================================
function s = local_proper_direction(lc)
% =====================================
%LOCAL_PROPER_DIRECTION

    switch lc
        case 'north'
            s = 'North';
        case 'south'
            s = 'South';
        case 'east'
            s = 'East';
        case 'west'
            s = 'West';
        case 'middle'
            s = 'Middle';
        otherwise
            s = lc;
    end
end

% ============================================
function s = local_expand_direction_letter(lc)
% ============================================
%LOCAL_EXPAND_DIRECTION_LETTER

    switch lc
        case 'n'
            s = 'North';
        case 's'
            s = 'South';
        case 'e'
            s = 'East';
        case 'w'
            s = 'West';
        case 'm'
            s = 'Middle';
        otherwise
            s = lc;
    end
end

% ============================
function s = local_fix_case(s)
% ============================
%LOCAL_FIX_CASE Light case cleanup for ordinary tokens.

    if isempty(s)
        return
    end
    
    % keep fully numeric tokens unchanged
    if all(isstrprop(s,'digit'))
        return
    end
    
    % keep US state abbreviations uppercase
    states = {'AL','AK','AZ','AR', ...
        'CA','CO','CT','DE','FL', ...
        'GA','HI','ID','IL','IN', ...
        'IA','KS','KY','LA','ME', ...
        'MD','MA','MI','MN','MS', ...
        'MO','MT','NE','NV','NH', ...
        'NJ','NM','NY','NC','ND', ...
        'OH','OK','OR','PA','RI', ...
        'SC','SD','TN','TX','UT', ...
        'VT','VA','WA','WV','WI', ...
        'WY','DC'};
    
    if any(strcmpi(s,states))
        s = upper(s);
        return
    end
    
    if strcmpi(s,'us')
        s = 'US';
        return
    end
    
    if strcmpi(s,'ynp')
        s = 'YNP';
        return
    end
    
    % capitalize ordinary word
    s = lower(s);
    s(1) = upper(s(1));
end