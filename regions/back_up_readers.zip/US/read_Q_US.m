function dat = read_Q_US(dirQ,mdl,dat,bas,split,aux)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%READ_Q Read USGS discharge data for each CONUS watershed
%
% SYNOPSIS: [dat,aux] = read_Q_US(dirQ,mdl,dat,bas,split,aux)
%   dirQ        string with main directory of USGS discharge data
%   mdl         model state/parameter info
%   dat         cell structure with meteorological/model information
%   bas         structure basin information
%   split       structure with training/evaluation time split
%   aux         Kx3 matrix with basin metadata
%   dat         OUTPUT: cell structure with discharge information added
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% © Written by Jasper A. Vrugt, Apr. 2026                                 %
% University of California Irvine                                         %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

split = prepare_split(split);

K = bas.K;
K_t = bas.K_t;
id_GAUGE = bas.id_gauge;

dt = double(split.dt);

mode = mdl.mode;
hasEval = ismember(mode,[2 4]);

id_train = expand_index(mdl.id_train);

if hasEval ...
        && isfield(mdl,'id_eval') ...
        && ~isempty(mdl.id_eval)
    id_eval = expand_index(mdl.id_eval);
else
    id_eval = [];
end

dt_name = dt2str(dt);

static_name = fullfile(dirQ, ...
    sprintf('USGS_discharge_summary_%s.csv', ...
    dt_name));

run_stamp = char(datetime('now', ...
    'Format','yyyyMMdd_HHmmss'));

run_name = fullfile(dirQ, ...
    sprintf('USGS_discharge_run_%s_%s.csv', ...
    dt_name,run_stamp));

need_static = ~isfile(static_name);

if hasEval
    Qrun = table('Size',[K 10], ...
        'VariableTypes',{'double', ...
        'string','string', ...
        'string','double','double', ...
        'string', ...
        'string','double','double'}, ...
        'VariableNames',{'gauge', ...
        'use','start_train', ...
        'end_train','n_train', ...
        'n_bad_train', ...
        'start_eval','end_eval', ...
        'n_eval', ...
        'n_bad_eval'});
else
    Qrun = table('Size',[K 6], ...
        'VariableTypes',{'double', ...
        'string','string', ...
        'string','double','double'}, ...
        'VariableNames',{'gauge','use', ...
        'start_train', ...
        'end_train','n_train', ...
        'n_bad_train'});
end

req = build_requested_window(split,false);

switch dt

    %======================================================================
    case 1 % daily
    %======================================================================

        mult = 86400/3.28084^3;     % cubic feet/s --> m3/d
        data_name = '*_streamflow_qc*.txt';
        tref = datetime(1950,10,1);

        LUTQd = build_Q_time_LUT_daily( ...
            dirQ,data_name, ...
            "HeaderLines",0, ...
            "RefDT",tref);

        dir_T = fullfile(fileparts(dirQ), ...
            'metadata');
        Tmeta = readtable(fullfile(dir_T, ...
            'gauge_information.txt'), ...
            'Delimiter','\t');

        id_meta_all = normalize_usgs(Tmeta{:,2});
        area_all = 1e6 * Tmeta{:,6};   % km^2 -> m^2

        if need_static
            Kstat = height(LUTQd);
            Qstat = table('Size',[Kstat 5], ...
                'VariableTypes',{'double', ...
                'string','string', ...
                'double','double'}, ...
                'VariableNames',{'gauge', ...
                'start_record', ...
                'end_record','n_all','n_bad'});

            fprintf(['      Building static ' ...
                'daily discharge summary ... ']);

            for kq = 1:Kstat
                fname_stat = LUTQd.FullPath(kq);
                gauge_stat = normalize_usgs( ...
                    LUTQd.BasinID8(kq));
                jj = find(strcmp(id_meta_all, ...
                    gauge_stat),1,'first');

                if isempty(jj)
                    [~,~,area_fb_km2,found_fb] = ...
                        fallback_usgs_metadata( ...
                        gauge_stat);

                    if ~found_fb
                        fprintf('\n');
                        error(['      Error:read_Q_US: ' ...
                            'Missing metadata for ' ...
                            'daily basin %s while ' ...
                            'building static summary.'], ...
                            char(gauge_stat));
                    end

                    fprintf('\n');
                    fprintf(['      Warning:read_Q_US: ' ...
                        'Missing metadata row in ' ...
                        'gauge_information.txt ' ...
                        'for basin %s; using ' ...
                        'hard-coded fallback ' ...
                        'metadata.\n'],char(gauge_stat));
                    fprintf(['      Building static ' ...
                        'daily discharge summary ... ']);

                    area_stat = 1e6 * area_fb_km2;
                else
                    area_stat = area_all(jj);
                end

                [n_all,n_bad] = ...
                    daily_full_record_badcount( ...
                    fname_stat,area_stat);

                Qstat.gauge(kq) = str2double(gauge_stat);
                Qstat.start_record(kq) = ...
                    string(datetime(LUTQd.StartDT(kq), ...
                    'Format','dd/MM/yyyy'));
                Qstat.end_record(kq) = ...
                    string(datetime(LUTQd.EndDT(kq), ...
                    'Format','dd/MM/yyyy'));
                Qstat.n_all(kq) = n_all;
                Qstat.n_bad(kq) = n_bad;
            end

            fprintf('Done \n');
        else
            fprintf(['      Static daily discharge ' ...
                'summary exists\n']);
            Qstat = table();
        end

        fprintf(['... Reading daily USGS discharge ' ...
            'data files %3d%%'],0);

        id_gauge = normalize_usgs(LUTQd.BasinID8);
        id_req = normalize_usgs(id_GAUGE);
        [tf,l] = ismember(id_req,id_gauge);
        id_row = l(tf);

        if ~all(tf)
            missing = id_GAUGE(~tf);
            fprintf('\n');
            error(['      Error:read_Q_US: ' ...
                'Missing DAILY USGS ' ...
                'streamflow files for %d ' ...
                'basins (e.g., %d).'], ...
                numel(missing),missing(1));
        end

        Rows = LUTQd(id_row,:);

        fmt = '%f %f %f %f %f%*[^\n]';

        for k = 1:K
            fname = Rows.FullPath(k);

            fid = fopen(char(fname),'r');
            if fid < 0
                fprintf('\n');
                error(['      Error:read_Q_US: ' ...
                    'Cannot open file: %s'],fname);
            end
            fclose(fid);

            fileStartN = Rows.StartN(k);
            fileEndN = Rows.EndN(k);
            hdr = double(Rows.HeaderLines(k));

            if req.read_start_N < fileStartN ...
                    || req.read_end_N > fileEndN
                fprintf('\n');
                error(['      Error:read_Q_US: ' ...
                    'requested period outside ' ...
                    'DAILY file for basin %d.\n' ...
                    'File covers %s to %s.'], ...
                    id_GAUGE(k), ...
                    string(Rows.StartDT(k)), ...
                    string(Rows.EndDT(k)));
            end

            id_read0 = int64(req.read_start_N ...
                - fileStartN) + 1;
            id_read1 = int64(req.read_end_N ...
                - fileStartN) + 1;
            nr = double(id_read1 - id_read0 + 1);

            skip = hdr + double(id_read0 - 1);

            fid = fopen(char(fname),'r');
            if fid < 0
                fprintf('\n');
                error(['      Error:read_Q_US: ' ...
                    'Cannot open file: %s'], ...
                    fname);
            end

            C = textscan(fid,fmt,nr, ...
                'HeaderLines',skip, ...
                'Delimiter',{' ','\t'}, ...
                'MultipleDelimsAsOne',true, ...
                'CollectOutput',true);
            fclose(fid);

            D = C{1};
            if size(D,1) ~= nr
                fprintf('\n');
                error(['      Error:read_Q_US: ' ...
                    'daily file ended ' ...
                    'early for basin %d (%s).'], ...
                    id_GAUGE(k),fname);
            end

            Q = D(:,5);
            area = aux(k,3);
            Qmm = 1e3 * Q * mult/area;

            dat{k}.y_n = single(Qmm);

            if k <= K_t
                dat{k}.use = 'training';
            else
                dat{k}.use = 'evaluation';
            end

            dat{k}.fname{2} = fname;

            badmask = isnan(Qmm) ...
                | isinf(Qmm);
            dat{k}.bad = badmask(:)';

            n_train = numel(id_train);
            n_bad_train = sum(badmask(id_train));

            if hasEval
                n_eval = numel(id_eval);
                n_bad_eval = sum(badmask(id_eval));
            else
                n_eval = 0;
                n_bad_eval = 0;
            end

            Qrun.gauge(k) = id_GAUGE(k);

            if k <= K_t
                Qrun.use(k) = "training";
            else
                Qrun.use(k) = "evaluation";
            end

            Qrun.start_train(k) = ...
                string(datetime(split.dt_train0, ...
                'Format','dd/MM/yyyy'));
            Qrun.end_train(k) = ...
                string(datetime(split.dt_train1, ...
                'Format','dd/MM/yyyy'));
            Qrun.n_train(k) = n_train;
            Qrun.n_bad_train(k) = n_bad_train;

            if hasEval
                Qrun.start_eval(k) = ...
                    string(datetime( ...
                    split.dt_eval0, ...
                    'Format','dd/MM/yyyy'));
                Qrun.end_eval(k) = ...
                    string(datetime( ...
                    split.dt_eval1, ...
                    'Format','dd/MM/yyyy'));
                Qrun.n_eval(k) = n_eval;
                Qrun.n_bad_eval(k) = n_bad_eval;
            end

            if mod(k,20) == 0 ...
                    || k == K
                pct = floor(100*k/K);
                fprintf('\b\b\b\b%3d%%',pct);
            end
            % Graphical User Interface
            if isfield(bas,'progressFcn') ...
                    && ~isempty(bas.progressFcn)
                try
                    bas.progressFcn(k,K);
                catch
                    try
                        bas.progressFcn(k);
                    catch
                    end
                end
            end
        end

    %======================================================================
    case 24 % hourly
    %======================================================================

        data_name = '*-usgs-hourly*.csv';
        tref = datetime(1950,10,1,0,0,0);

        cache_root = fullfile(dirQ, ...
            'cache_hourly_usgs');
        ensure_folder(cache_root);
        lut_file = fullfile(cache_root, ...
            'LUTQh_hourly.mat');

        if isfile(lut_file)
            S = load(lut_file,'LUTQh', ...
                'dirQ','data_name');
            if isfield(S,'LUTQh')
                LUTQh = S.LUTQh;
            else
                LUTQh = build_Q_time_LUT_hourly_csv( ...
                    dirQ,data_name, ...
                    "HeaderLines",1, ...
                    "RefDT",tref, ...
                    "TimeFormat", ...
                    "yyyy-MM-dd HH:mm:ss");
                save(lut_file,'LUTQh','dirQ', ...
                    'data_name','-v7.3');
            end
        else
            LUTQh = build_Q_time_LUT_hourly_csv( ...
                dirQ,data_name, ...
                "HeaderLines",1, ...
                "RefDT",tref, ...
                "TimeFormat","yyyy-MM-dd HH:mm:ss");
            save(lut_file,'LUTQh','dirQ', ...
                'data_name','-v7.3');
        end

        if need_static
            Kstat = height(LUTQh);
            Qstat = table('Size',[Kstat 5], ...
                'VariableTypes',{'double', ...
                'string','string', ...
                'double','double'}, ...
                'VariableNames',{'gauge', ...
                'start_record', ...
                'end_record','n_all','n_bad'});

            fprintf(['      Building static ' ...
                'hourly discharge summary ... ']);

            for kq = 1:Kstat
                fname_stat = LUTQh.FullPath(kq);
                gauge_stat = normalize_usgs( ...
                    LUTQh.BasinID8(kq));
                cache_file_stat = ...
                    hourly_q_cache_file(cache_root, ...
                    gauge_stat);

                if isfile(cache_file_stat)
                    Tstat = load(cache_file_stat, ...
                        'Qmm_h');
                    Qmm_h_stat = Tstat.Qmm_h;
                    n_all = numel(Qmm_h_stat);
                    n_bad = sum(isnan(Qmm_h_stat) ...
                        | isinf(Qmm_h_stat));
                else
                    [Qmm_h,~] = ...
                        read_hourly_usgs_full_with_fallback( ...
                        fname_stat,1,gauge_stat);
                    n_all = numel(Qmm_h);
                    n_bad = sum(isnan(Qmm_h) ...
                        | isinf(Qmm_h));
                    save(cache_file_stat, ...
                        'Qmm_h','-v7.3');
                end

                Qstat.gauge(kq) = str2double(gauge_stat);
                Qstat.start_record(kq) = ...
                    string(datetime(LUTQh.StartDT(kq), ...
                    'Format','dd/MM/yyyy HH:mm'));
                Qstat.end_record(kq) = ...
                    string(datetime(LUTQh.EndDT(kq), ...
                    'Format','dd/MM/yyyy HH:mm'));
                Qstat.n_all(kq) = n_all;
                Qstat.n_bad(kq) = n_bad;
            end

            fprintf('Done \n');
        else
            fprintf(['      Static ' ...
                'hourly discharge ' ...
                'summary exists\n']);
            Qstat = table();
        end

        fprintf(['... Reading hourly ' ...
            'USGS discharge ' ...
            'data files %3d%%'],0);

        id_gauge = normalize_usgs(LUTQh.BasinID8);
        id_req = normalize_usgs(id_GAUGE);
        [tf,l] = ismember(id_req,id_gauge);
        id_row = l(tf);

        if ~all(tf)
            missing = id_GAUGE(~tf);
            fprintf('\n');
            error(['      Error:read_Q_US: ' ...
                'Missing HOURLY USGS ' ...
                'streamflow files for ' ...
                '%d basins (e.g., %d).'], ...
                numel(missing),missing(1));
        end

        Rows = LUTQh(id_row,:);

        for k = 1:K
            fname = Rows.FullPath(k);
            usgs_k = normalize_usgs(id_GAUGE(k));
            cache_file = hourly_q_cache_file( ...
                cache_root,usgs_k);

            fileStartN = Rows.StartN(k);
            fileEndN = Rows.EndN(k);
            dth = double(Rows.dtHours(k));

            if req.read_start_N < fileStartN ...
                    || req.read_end_N > fileEndN
                fprintf('\n');
                error(['      Error:read_Q_US: ' ...
                    'requested period ' ...
                    'outside hourly file ' ...
                    'for basin %d.\n' ...
                    'File covers %s to %s.'], ...
                    id_GAUGE(k), ...
                    string(Rows.StartDT(k)), ...
                    string(Rows.EndDT(k)));
            end

            if mod(double(req.read_start_N ...
                    - fileStartN),dth) ~= 0 || ...
               mod(double(req.read_end_N ...
                - fileStartN),dth) ~= 0
                fprintf('\n');
                error(['      Error:read_Q_US: ' ...
                    'hourly offsets are ' ...
                    'not integer. Check ' ...
                    'time parsing.']);
            end

            id_read0 = int64((req.read_start_N ...
                - fileStartN)/dth) + 1;
            id_read1 = int64((req.read_end_N ...
                - fileStartN)/dth) + 1;

            need_rebuild = true;
            Qfull = [];

            if isfile(cache_file)
                S = load(cache_file,'Qmm_h');
                if isfield(S,'Qmm_h')
                    Qfull = double(S.Qmm_h(:));
                    if double(id_read1) <= numel(Qfull)
                        need_rebuild = false;
                    end
                elseif isfield(S,'Qmm_h_stat')
                    Qfull = double(S.Qmm_h_stat(:));
                    if double(id_read1) <= numel(Qfull)
                        need_rebuild = false;
                    end
                end
            end

            if need_rebuild
                [Qfull,~] = ...
                    read_hourly_usgs_full_with_fallback( ...
                    fname,1,usgs_k);
                Qfull = double(Qfull(:));

                if double(id_read1) > numel(Qfull)
                    fprintf('\n');
                    error(['      Error:read_Q_US: ' ...
                        'hourly record ' ...
                        'too short after rebuild ' ...
                        'for basin %d (%s).'], ...
                        id_GAUGE(k),fname);
                end

                Qmm_h = single(Qfull);
                save(cache_file,'Qmm_h','-v7.3');
            end

            Qmm = Qfull(double(id_read0):double(id_read1));
            dat{k}.y_n = single(Qmm);

            if k <= K_t
                dat{k}.use = 'training';
            else
                dat{k}.use = 'evaluation';
            end

            dat{k}.fname{2} = fname;

            badmask = isnan(Qmm) ...
                | isinf(Qmm);
            dat{k}.bad = badmask(:)';

            n_train = numel(id_train);
            n_bad_train = sum(badmask(id_train));

            if hasEval
                n_eval = numel(id_eval);
                n_bad_eval = sum(badmask(id_eval));
            else
                n_eval = 0;
                n_bad_eval = 0;
            end

            Qrun.gauge(k) = id_GAUGE(k);

            if k <= K_t
                Qrun.use(k) = "training";
            else
                Qrun.use(k) = "evaluation";
            end

            Qrun.start_train(k) = ...
                string(datetime(split.dt_train0, ...
                'Format','dd/MM/yyyy HH:mm'));
            Qrun.end_train(k) = ...
                string(datetime(split.dt_train1 + hours(23), ...
                'Format','dd/MM/yyyy HH:mm'));
            Qrun.n_train(k) = n_train;
            Qrun.n_bad_train(k) = n_bad_train;

            if hasEval
                Qrun.start_eval(k) = ...
                    string(datetime(split.dt_eval0, ...
                    'Format','dd/MM/yyyy HH:mm'));
                Qrun.end_eval(k) = ...
                    string(datetime(split.dt_eval1 + hours(23), ...
                    'Format','dd/MM/yyyy HH:mm'));
                Qrun.n_eval(k) = n_eval;
                Qrun.n_bad_eval(k) = n_bad_eval;
            end

            if mod(k,20)==0 || k==K
                pct = floor(100*k/K);
                fprintf('\b\b\b\b%3d%%',pct);
            end
            % Graphical User Interface
            if isfield(bas,'progressFcn') ...
                    && ~isempty(bas.progressFcn)
                bas.progressFcn(k);
            end
        end

    %======================================================================
    otherwise
    %======================================================================
        fprintf('\n');
        fprintf(['      Warning:read_Q_US: ' ...
            'Unknown dt = %d ' ...
            'temporal resolution of ' ...
            'USGS data: set dt = 1 ' ...
            '[daily] or dt = 24 [hourly]\n'],dt);
        error(['      Error:read_Q_US: ' ...
            'demo_CONUS stops']);
end

fprintf('\b\b\b\b... Done\n');

if need_static
    writetable(Qstat,static_name);
    fprintf(['      Read_Q: ' ...
        'Wrote static discharge ' ...
        'summary: %s\n'],static_name);
end

writetable(Qrun,run_name);
fprintf(['      Read_Q: ' ...
    'Wrote run-dependent discharge ' ...
    'summary: %s\n'],run_name);

end

% ----------------
% helper functions
% ----------------
function LUT = build_Q_time_LUT_daily(dir_root,pattern,varargin)
p = inputParser;
p.addRequired("dir_root",@(x)ischar(x)||isstring(x));
p.addRequired("pattern",@(x)ischar(x)||isstring(x));
p.addParameter("HeaderLines",0,@(x)isnumeric(x)&&isscalar(x)&&x>=0);
p.addParameter("RefDT",datetime(1950,10,1), ...
    @(x)isdatetime(x)&&isscalar(x));
p.addParameter("Recursive",true, ...
    @(x)islogical(x)&&isscalar(x));
p.parse(dir_root,pattern,varargin{:});

hdr = int16(p.Results.HeaderLines);
tref = p.Results.RefDT;
doRec = p.Results.Recursive;

dir_root = string(dir_root);
pattern = string(pattern);

if doRec
    D = dir(fullfile(dir_root,"**",pattern));
else
    D = dir(fullfile(dir_root,pattern));
end

names = string({D.name})';
paths = string(fullfile({D.folder}',{D.name}'));

tok = regexp(names,'^(\d{8})','tokens','once');
basin = strings(numel(names),1);
for i = 1:numel(tok)
    if ~isempty(tok{i})
        basin(i) = string(tok{i}{1});
    end
end

StartDT = NaT(numel(names),1);
EndDT = NaT(numel(names),1);
StartN = zeros(numel(names),1,"int64");
EndN = zeros(numel(names),1,"int64");

for i = 1:numel(names)
    fname = paths(i);
    fid = fopen(char(fname),'r');
    if fid < 0
        error("Cannot open %s",fname);
    end

    c = onCleanup(@() fclose(fid));
    for k = 1:double(hdr)
        fgetl(fid);
    end

    line1 = fgetl(fid);
    v1 = sscanf(line1,'%f');

    if numel(v1) < 4
        error("First data line lacks " + ...
            "USGS_ID YYYY MM DD in %s",fname);
    end

    StartDT(i) = datetime(v1(2),v1(3),v1(4));
    clear c;

    EndDT(i) = last_daily_date_with_usgs(fname);

    StartN(i) = int64(round(days(StartDT(i) - tref)));
    EndN(i) = int64(round(days(EndDT(i) - tref)));
end

LUT = table(basin,StartDT,EndDT,StartN,EndN, ...
    repmat(int16(1),numel(names),1), ...
    repmat(hdr,numel(names),1), ...
    paths,names, ...
    'VariableNames',{'BasinID8','StartDT','EndDT', ...
    'StartN','EndN','dtDays','HeaderLines', ...
    'FullPath','Filename'});

LUT = LUT(LUT.BasinID8 ~= "",:);
end

function s = dt2str(dt)
switch dt
    case 1
        s = 'daily';
    case 24
        s = 'hourly';
    otherwise
        error(['      Error:dt2str: ' ...
            'Unknown dt = %g. ' ...
            'Expected dt = 1 or dt = 24.'],dt);
end
end

function dt = last_daily_date_with_usgs(fname)
fid = fopen(char(fname),'r');
if fid < 0
    error("Cannot open %s",fname);
end

c = onCleanup(@() fclose(fid));

fseek(fid,0,'eof');
pos = ftell(fid);
block = 65536;

while pos > 0
    pos = max(0,pos - block);
    fseek(fid,pos,'bof');
    txt = fread(fid,block,'*char')';
    lines = regexp(txt,'\r\n|\n|\r','split');

    for j = numel(lines):-1:1
        cand = strtrim(lines{j});
        if isempty(cand)
            continue
        end

        if ~isempty(regexp(cand,'^\d','once'))
            v = sscanf(cand,'%f');
            if numel(v) >= 4
                dt = datetime(v(2),v(3),v(4));
                return
            end
        end
    end
end

error("      Error: read_Q_US: Could not " + ...
    "find last data line in %s",fname);
end

function LUT = build_Q_time_LUT_hourly_csv( ...
    dir_root,pattern,varargin)
p = inputParser;
p.addRequired("dir_root",@(x)ischar(x)||isstring(x));
p.addRequired("pattern",@(x)ischar(x)||isstring(x));
p.addParameter("HeaderLines",1, ...
    @(x)isnumeric(x)&&isscalar(x)&&x>=0);
p.addParameter("RefDT",datetime(1950,10,1,0,0,0), ...
    @(x)isdatetime(x)&&isscalar(x));
p.addParameter("TimeFormat","yyyy-MM-dd HH:mm:ss", ...
    @(x)isstring(x)||ischar(x));
p.addParameter("Recursive",true, ...
    @(x)islogical(x)&&isscalar(x));
p.parse(dir_root,pattern,varargin{:});

hdr = int16(p.Results.HeaderLines);
tref = p.Results.RefDT;
tfmt = string(p.Results.TimeFormat);
doRec = p.Results.Recursive;

dir_root = string(dir_root);
pattern = string(pattern);

if doRec
    D = dir(fullfile(dir_root,"**",pattern));
else
    D = dir(fullfile(dir_root,pattern));
end

names = string({D.name})';
paths = string(fullfile({D.folder}',{D.name}'));

tok = regexp(names,'^(\d{8})','tokens','once');
basin = strings(numel(names),1);
for i = 1:numel(tok)
    if ~isempty(tok{i})
        basin(i) = string(tok{i}{1});
    end
end

StartDT = NaT(numel(names),1);
EndDT = NaT(numel(names),1);
StartN = zeros(numel(names),1,"int64");
EndN = zeros(numel(names),1,"int64");

for i = 1:numel(names)
    fname = paths(i);
    fid = fopen(char(fname),'r');
    if fid < 0
        error("Cannot open %s",fname);
    end

    c = onCleanup(@() fclose(fid));
    for k = 1:double(hdr)
        fgetl(fid);
    end

    line1 = fgetl(fid);
    tstr1 = extractBefore(string(line1),",");
    StartDT(i) = datetime(strtrim(tstr1), ...
        "InputFormat",tfmt);
    clear c;

    EndDT(i) = last_hourly_timestamp_csv(fname,tfmt);

    StartN(i) = int64(round(hours(StartDT(i) - tref)));
    EndN(i) = int64(round(hours(EndDT(i) - tref)));
end

LUT = table(basin,StartDT,EndDT,StartN,EndN, ...
    repmat(int16(1),numel(names),1), ...
    repmat(hdr,numel(names),1), ...
    paths,names, ...
    'VariableNames',{'BasinID8','StartDT','EndDT', ...
    'StartN','EndN','dtHours','HeaderLines', ...
    'FullPath','Filename'});

LUT = LUT(LUT.BasinID8 ~= "",:);
end

function dt = last_hourly_timestamp_csv(fname,tfmt)
fid = fopen(char(fname),'r');
if fid < 0
    error("Cannot open %s",fname);
end

c = onCleanup(@() fclose(fid));

fseek(fid,0,'eof');
pos = ftell(fid);
block = 65536;

while pos > 0
    pos = max(0,pos - block);
    fseek(fid,pos,'bof');
    txt = fread(fid,block,'*char')';
    lines = regexp(txt,'\r\n|\n|\r','split');

    for j = numel(lines):-1:1
        cand = strtrim(lines{j});
        if isempty(cand)
            continue
        end

        if ~isempty(regexp(cand, ...
                '^\d{4}-\d{2}-\d{2}','once'))
            tstr = extractBefore(string(cand),",");
            dt = datetime(strtrim(tstr), ...
                "InputFormat",tfmt);
            return
        end
    end
end

error("      Error: read_Q_US: " + ...
    "Could not find last timestamp row in %s",fname);
end

function [n_all,n_bad] = daily_full_record_badcount(fname,area)
mult = 86400/3.28084^3;
fmt = '%f %f %f %f %f%*[^\n]';

fid = fopen(char(fname),'r');
if fid < 0
    error(['      Error: read_Q_US: ' ...
        'Cannot open file: %s'],fname);
end

C = textscan(fid,fmt, ...
    'Delimiter',{' ','\t'}, ...
    'MultipleDelimsAsOne',true, ...
    'CollectOutput',true);
fclose(fid);

D = C{1};
Q = D(:,5);
Qmm_d = 1e3 * Q * mult / area;

badmask = isnan(Qmm_d) | isinf(Qmm_d);
n_all = numel(Qmm_d);
n_bad = sum(badmask);
end

function [Qmm_h,badmask] = ...
    read_hourly_usgs_full_with_fallback(fname,hdr,usgs_id)
try
    [Qmm_h,badmask] = read_hourly_usgs_full_fast(fname,hdr);
catch ME
    fprintf('\n');
    fprintf(['      Warning:read_Q_US: ' ...
        'fast hourly reader failed ' ...
        'for basin %s; switching to ' ...
        'robust fallback.\n'], ...
        char(normalize_usgs(usgs_id)));
    fprintf('      Cause: %s\n', ...
        ME.message);
    [Qmm_h,badmask] = ...
        read_hourly_usgs_full_slow(fname,hdr);
end
end

function [Qmm_h,badmask] = read_hourly_usgs_full_fast(fname,hdr)
%READ_HOURLY_USGS_FULL_FAST Fast full-file reader for hourly USGS CSV.
% Expected CSV layout:
%   col 1 = timestamp text
%   col 2 = QObs(mm/h)
%   col 7 = QObs_CAMELS(mm/h)

opts = detectImportOptions(char(fname), ...
    "Delimiter",",", ...
    "NumHeaderLines",double(hdr));
opts.VariableNamingRule = "preserve";

vn = opts.VariableNames;
if numel(vn) < 7
    error(['      Error:read_Q_US: ' ...
        'Hourly CSV has fewer than 7 columns: %s'], ...
        fname);
end

opts = setvartype(opts,vn{1},"char");
opts.SelectedVariableNames = vn([1 2 7]);

Tbl = readtable(char(fname),opts);

if width(Tbl) < 3
    error(['      Error:read_Q_US: ' ...
        'Could not read hourly ' ...
        'discharge columns from %s.'], ...
        fname);
end

Q1 = local_to_double(Tbl{:,2});
Q7 = local_to_double(Tbl{:,3});

Qmm_h = Q1;
miss = isnan(Qmm_h) | isinf(Qmm_h);
Qmm_h(miss) = Q7(miss);

badmask = isnan(Qmm_h) | isinf(Qmm_h);
end

function [Qmm_h,badmask] = read_hourly_usgs_full_slow(fname,hdr)
%READ_HOURLY_USGS_FULL_SLOW Robust fallback for files with sparse trailing
% columns in early rows. Reads line-by-line and preserves empty trailing
% fields so column 7 can stay empty for part of the record.

fid = fopen(char(fname),'r');
if fid < 0
    error(['      Error:read_Q_US: ' ...
        'Cannot open file: %s'],fname);
end
c = onCleanup(@() fclose(fid));

for k = 1:double(hdr)
    fgetl(fid);
end

chunk = 100000;
Q1 = nan(chunk,1);
Q7 = nan(chunk,1);
n = 0;

while true
    line = fgetl(fid);
    if ~ischar(line)
        break
    end

    n = n + 1;
    if n > numel(Q1)
        Q1 = [Q1; nan(chunk,1)]; %#ok
        Q7 = [Q7; nan(chunk,1)]; %#ok
    end

    parts = split_csv_preserve_trailing(line);

    if numel(parts) >= 2
        Q1(n) = str2double( ...
            strtrim(string(parts{2})));
    end

    if numel(parts) >= 7
        Q7(n) = str2double( ...
            strtrim(string(parts{7})));
    end
end

Q1 = Q1(1:n);
Q7 = Q7(1:n);

Qmm_h = Q1;
miss = isnan(Qmm_h) ...
    | isinf(Qmm_h);
Qmm_h(miss) = Q7(miss);

badmask = isnan(Qmm_h) ...
    | isinf(Qmm_h);
end

function parts = split_csv_preserve_trailing(line)
% Simple split that preserves trailing empty columns for lines like
%   a,b,c,,,,
parts = regexp(line,',','split');
if ~isempty(line) && line(end) == ','
    ntrail = 0;
    idx = numel(line);
    while idx >= 1 && line(idx) == ','
        ntrail = ntrail + 1;
        idx = idx - 1;
    end
    nmissing = ntrail - 1;
    for i = 1:nmissing
        parts{end+1} = ''; %#ok<AGROW>
    end
end
end

function x = local_to_double(x)
if isnumeric(x)
    x = double(x(:));
    return
end

if iscell(x)
    x = string(x);
end

if ischar(x)
    x = string(cellstr(x));
end

if isstring(x) || iscategorical(x)
    x = str2double(string(x(:)));
    return
end

error(['      Error:read_Q_US: ' ...
    'Unable to convert hourly ' ...
    'discharge column to double.']);
end

function id = normalize_usgs(x)
x = string(x);
x = strtrim(x);
x = regexprep(x,'\.0+$','');
id = compose('%08d',str2double(x));
id = string(id(:));
end

function [lat,lon,area_km2,found] = ...
    fallback_usgs_metadata(usgs_id)
usgs_id = char(normalize_usgs(usgs_id));
found = true;

switch usgs_id
    case '06775500'
        lat = 41.8311028;
        lon = -100.1008667;
        area_km2 = 1830.0 * 2.58999;

    case '06846500'
        lat = 39 + 59/60 + 6/3600;
        lon = -(100 + 33/60 + 35/3600);
        area_km2 = 1680.0 * 2.58999;

    case '09535100'
        lat = 32.04424;
        lon = -112.37097;
        area_km2 = 569.0 * 2.58999;

    otherwise
        lat = NaN;
        lon = NaN;
        area_km2 = NaN;
        found = false;
end
end

function ensure_folder(pth)
if ~isfolder(pth)
    mkdir(pth);
end
end

function fname = hourly_q_cache_file(cache_root,usgs_id)
uid = char(normalize_usgs(usgs_id));
fname = fullfile(cache_root, ...
    sprintf('%s_Q_hourly.mat',uid));
end