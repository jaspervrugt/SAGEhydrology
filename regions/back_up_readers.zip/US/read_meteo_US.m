function [dat,aux] = read_meteo_US(dirM,bas,split,meteo)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%READ_METEO Read CONUS meteorological data for each watershed
%
% SYNOPSIS: [dat,aux] = read_meteo_US(dirM,bas,split,meteo)
%   dirM        string with main directory of meteorological data
%   bas         structure basin information
%   split       structure with training/evaluation time split
%   meteo       structure basin average meteorological data
%   dat         OUTPUT: cell structure model and meteorological information
%   aux         OUTPUT: Kx3 matrix: lat. (°), elev. (m) and basin area (m²)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% © Written by Jasper A. Vrugt, Dec. 2025 / Mar. 2026                     %
% University of California, Irvine                                        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    split = prepare_split(split);   % validate time split
    dt = double(split.dt);          % unpack time split  
    K = bas.K;                      % # training + evaluation watersheds
    id_GAUGE = bas.id_gauge;        % gauge basin codes in final order
    dmeteo = meteo.data;            % choice of meteo data: [1,2,3]
    pet = meteo.pet;                % choice of pet data [1,2,3]

    % ----------------------------
    % Main switch: daily vs hourly
    % ----------------------------
    switch dt
        
        case 1 % daily
        
            switch dmeteo
                case 1
                    dname = 'cida';
                    dirData = fullfile(dirM,'daymet');
                case 2
                    dname = 'maurer';
                    dirData = fullfile(dirM,dname);
                case 3
                    dname = 'nldas';
                    dirData = fullfile(dirM,dname);
                otherwise
                    fprintf('\n');
                    error(['      Error:read_meteo_US: ' ...
                        'Improper ' ...
                        'option daily meteo data.']);
            end
    
            data_name = strcat('*_lump_', ...
                dname,'_forcing_leap.txt');
    
            dat = cell(K,1);
            aux = nan(K,3);
    
            build_summary = true;
    
            lut_file = fullfile(dirData, ...
                sprintf('meteo_time_LUT_%s_daily.mat', ...
                dname));
            summary_file = fullfile(dirData, ...
                sprintf('meteo_summary_%s_daily.csv', ...
                dname));
    
            if isfile(lut_file)
                fprintf(['      Daily meteo lookup ' ...
                    'table already exists: %s\n'], ...
                    lut_file);
            
                S = load(lut_file,'LUTd');
                % LUTd = S.LUTd;
            
                % Make cached LUT port across Dropbox locs/drive letters.
                LUTd = rebase_meteo_LUT_paths(S.LUTd,dirData);
            
                % If rebasing fixed stale paths, save updated portable LUT.
                try
                    if all(isfile(string(LUTd.FullPath)))
                        save(lut_file,'LUTd','-v7.3');
                    end
                catch
                end
                try
                    badAll = ~isfile(string(LUTd.FullPath));
                catch
                    badAll = true;
                end
                
                if any(badAll)
                    fprintf(['      Daily meteo LUT ' ...
                        'contains stale paths.\n' ...
                        '      Rebuilding lookup table ' ...
                        'from current directory:\n' ...
                        '      %s\n'],dirData);
                
                    LUTd = build_meteo_time_LUT( ...
                        dirData,data_name, ...
                        "HeaderLines",4, ...
                        "dtHours",24, ...
                        "RefDT",datetime(1950,10,1,0,0,0));
                
                    save(lut_file,'LUTd','-v7.3');
                end
            else
                fprintf(['      Daily meteo lookup ' ...
                    'table does not yet exist.\n' ...
                    '      Building this file requires ' ...
                    'scanning all daily forcing\n' ...
                    '      files once to determine ' ...
                    'their time coverage.\n' ...
                    '      This can take a while the ' ...
                    'first time only.\n']);
                drawnow;
    
                LUTd = build_meteo_time_LUT( ...
                    dirData,data_name, ...
                    "HeaderLines",4, ...
                    "dtHours",24, ...
                    "RefDT",datetime(1950,10,1,0,0,0));
    
                save(lut_file,'LUTd','-v7.3');
    
                fprintf(['      Built daily meteo ' ...
                    'lookup table: %s\n'], ...
                    lut_file);
                fprintf(['      Future runs will ' ...
                    'reuse this file.\n']);
            end
    
            % if build_summary
            %     need_summary = ~isfile(summary_file);
            %     if need_summary
            %         fprintf(['      Building daily meteo ' ...
            %             'summary %3d%%'],0);
            % 
            %         Qsum = build_daily_meteo_summary(LUTd,pet);
            % 
            %         fprintf('\b\b\b\b%3d%%\n',100);
            % 
            %         writetable(Qsum,summary_file);
            %         fprintf(['      Wrote daily meteo ' ...
            %             'summary: %s\n'], ...
            %             summary_file);
            %     else
            %         fprintf(['      Daily meteo summary ' ...
            %             'already exists: %s\n'], ...
            %             summary_file);
            %     end
            % end
    
            fprintf(['... Reading daily meteorological ' ...
                '%s data files %3d%%'],dname,0);
    
            flag_progress = true;
    
            % Match requested basins to LUT rows
            id_gauge = normalize_usgs(LUTd.GAUGE_ID8);
            id_req = normalize_usgs(id_GAUGE);
            [tf,loc] = ismember(id_req,id_gauge);
            %[tf,loc] = ismember(id_GAUGE,id_gauge);
            if ~all(tf)
                missing = id_GAUGE(~tf);
                if flag_progress
                    fprintf('\n');
                end
                error(['      Error:read_meteo_US: Missing ' ...
                    'daily meteo files for %d basins ' ...
                    '(e.g., %d).'],numel(missing), ...
                    missing(1));
            end
            Rows = LUTd(loc,:);
            badRows = ~isfile(string(Rows.FullPath));
            if any(badRows)
                fprintf(['      Daily meteo LUT paths are stale ' ...
                    'and could not be fully rebased.\n' ...
                    '      Rebuilding lookup table from ' ...
                    'current directory:\n' ...
                    '      %s\n'],dirData);
            
                LUTd = build_meteo_time_LUT( ...
                    dirData,data_name, ...
                    "HeaderLines",4, ...
                    "dtHours",24, ...
                    "RefDT",datetime(1950,10,1,0,0,0));
            
                save(lut_file,'LUTd','-v7.3');
            
                id_gauge = normalize_usgs(LUTd.GAUGE_ID8);
                id_req = normalize_usgs(id_GAUGE);
                [tf,loc] = ismember(id_req,id_gauge);
            
                if ~all(tf)
                    missing = id_GAUGE(~tf);
                    if flag_progress
                        fprintf('\n');
                    end
                    error(['      Error:read_meteo_US: Missing ' ...
                        'daily meteo files for %d basins ' ...
                        '(e.g., %d).'],numel(missing), ...
                        missing(1));
                end
                Rows = LUTd(loc,:);
            end

            if build_summary
                need_summary = ~isfile(summary_file);
                if need_summary
                    fprintf(['      Building daily meteo ' ...
                        'summary %3d%%'],0);
    
                    Qsum = build_daily_meteo_summary(LUTd,pet);
    
                    fprintf('\b\b\b\b%3d%%\n',100);
    
                    writetable(Qsum,summary_file);
                    fprintf(['      Wrote daily meteo ' ...
                        'summary: %s\n'], ...
                        summary_file);
                else
                    fprintf(['      Daily meteo summary ' ...
                        'already exists: %s\n'], ...
                        summary_file);
                end
            end

            % Global requested daily window from split
            req = build_requested_window(split,true);
    
            for k = 1:K
                fname = Rows.FullPath(k);
    
                fileStartN = Rows.StartN(k);
                fileEndN = Rows.EndN(k);
    
                if req.read_start_N < fileStartN ...
                        || req.read_end_N > fileEndN
                    if flag_progress
                        fprintf('\n');
                    end
                    error(['      Error:read_meteo_US: ' ...
                        'requested period outside ' ...
                        'daily file for basin %d.\n' ...
                        'File covers %s to %s.'], ...
                        id_GAUGE(k), ...
                        string(Rows.StartDT(k)), ...
                        string(Rows.EndDT(k)));
                end
    
                id_read0 = int64(req.read_start_N ...
                    - fileStartN) + 1;
                id_read1 = int64(req.read_end_N ...
                    - fileStartN) + 1;
    
                [aux1,aux2,aux3,Dm] = ...
                    read_daily_meteo_slice( ...
                    fname,double(id_read0), ...
                    double(id_read1));
    
                aux(k,1:3) = [aux1; aux2; aux3];
    
                t_d = datetime(Dm(:,1),Dm(:,2),Dm(:,3));
    
                Tmax = Dm(:,9);
                Tmin = Dm(:,10);
                Rs = Dm(:,7);
                Vp = Dm(:,11);
                doy = day(t_d,'dayofyear');
                lat_deg = aux1;
                z = aux2;
                u2 = 2;
    
                ET0 = et0_fao56_daily(Tmax,Tmin, ...
                    Rs,Vp,doy,lat_deg,z,u2,pet);
    
                dat{k}.meteo.P = single(Dm(:,6));
                dat{k}.meteo.Ep = single(ET0);
                dat{k}.meteo.T = single(0.5*(Tmax+Tmin));
                dat{k}.gauge = id_GAUGE(k);
                dat{k}.fname{1} = fname;
    
                badmask = ~isfinite(Dm(:,6)) ...
                    | ~isfinite(ET0) ...
                    | ~isfinite(Tmax) ...
                    | ~isfinite(Tmin);
    
                badrows = find(badmask);
                dat{k}.meteo.bad = badrows(:)';
    
                if ~isempty(badrows)
                    if flag_progress
                        fprintf('\n');
                    end
                    fprintf(['      Warning:read_meteo_US: ' ...
                        'At least one row of %s daily meteo ' ...
                        'data of basin %d has invalid values\n'], ...
                        dname,id_GAUGE(k));
    
                    pct = floor(100*k/K);
                    fprintf(['... Reading daily meteorological ' ...
                        '%s data files %3d%%'],dname,pct);
                    flag_progress = true;
                end
    
                if mod(k,5)==0 ...
                        || k==K
                    pct = floor(100*k/K);
                    fprintf('\b\b\b\b%3d%%',pct);
                    drawnow;
                end
                % Graphical User Interface
                if isfield(meteo,'progressFcn') ...
                        && ~isempty(meteo.progressFcn)
                    meteo.progressFcn(k);
                end
            end
    
            if flag_progress
                fprintf('\b\b\b\b%s\n','... Done');
            end
    
        case 24 % hourly
        
            switch dmeteo
                case {1,2,3}
                    dname = 'nldas';
                    dirData = dirM;
                    data_name = strcat('*_hourly_', ...
                        dname,'.csv');
                otherwise
                    fprintf('\n');
                    error(['      Error:read_meteo_US: ' ...
                        'Improper option hourly ' ...
                        'meteo data.']);
            end
    
            dat = cell(K,1);
            aux = nan(K,3);
            comp_E0 = 0;
            build_summary = true;
    
            tref = datetime(1950,10,1,0,0,0);
            lut_file = fullfile(dirData, ...
                sprintf('meteo_time_LUT_%s_hourly.mat', ...
                dname));
            summary_file = fullfile(dirData, ...
                sprintf('meteo_summary_%s_hourly.csv', ...
                dname));

            if isfile(lut_file)
                S = load(lut_file,'LUTh');
                LUTh = S.LUTh;
                % Make cached hourly LUT portable across Dropbox locations.
                LUTh = rebase_meteo_LUT_paths(LUTh,dirData);
                try
                    if all(isfile(string(LUTh.FullPath)))
                        save(lut_file,'LUTh','-v7.3');
                    end
                catch
                end
                try
                    badAll = ~isfile(string(LUTh.FullPath));
                catch
                    badAll = true;
                end
                
                if any(badAll)
                    fprintf(['      Hourly meteo LUT ' ...
                        'contains stale paths.\n' ...
                        '      Rebuilding lookup table ' ...
                        'from current directory:\n' ...
                        '      %s\n'],dirData);
                
                    LUTh = build_meteo_time_LUT( ...
                        dirData,data_name, ...
                        "HeaderLines",1, ...
                        "dtHours",1, ...
                        "RefDT",tref, ...
                        "TimeFormat","yyyy-MM-dd HH:mm:ss");
                
                    save(lut_file,'LUTh','-v7.3');
                end
            else
                LUTh = build_meteo_time_LUT( ...
                    dirData,data_name, ...
                    "HeaderLines",1, ...
                    "dtHours",1, ...
                    "RefDT",tref, ...
                    "TimeFormat","yyyy-MM-dd HH:mm:ss");
                save(lut_file,'LUTh','-v7.3');
                fprintf(['      Built hourly meteo ' ...
                    'lookup table: %s\n'],lut_file);
            end
            
            if build_summary
                need_summary = ~isfile(summary_file);
                if need_summary
                    fprintf(['      Building ' ...
                        'hourly meteo ' ...
                        'summary %3d%%'],0);
    
                    Qsum = build_hourly_meteo_summary( ...
                        LUTh,dirData,dname,pet,comp_E0);
    
                    fprintf('\b\b\b\b%3d%%\n',100);
    
                    writetable(Qsum,summary_file);
                    fprintf(['      Wrote hourly ' ...
                        'meteo summary: %s\n'], ...
                        summary_file);
                else
                    fprintf(['      Hourly meteo ' ...
                        'summary already exists: %s\n'], ...
                        summary_file);
                end
            end
    
            fprintf(['... Reading hourly ' ...
                'meteorological %s data ' ...
                'files %3d%%'],dname,0);
    
            flag_progress = true;
    
            % Match requested basins to LUT rows
            id_gauge = normalize_usgs(LUTh.GAUGE_ID8);
            id_req = normalize_usgs(id_GAUGE);
            [tf,loc] = ismember(id_req,id_gauge);
    
            if ~all(tf)
                missing = id_GAUGE(~tf);
                if flag_progress
                    fprintf('\n');
                end
                error(['      Error:read_meteo_US: ' ...
                    'Missing hourly meteo files ' ...
                    'for %d basins ' ...
                    '(e.g., %d).'], ...
                    numel(missing),missing(1));
            end
    
            Rows = LUTh(loc,:);
            badRows = ~isfile(string(Rows.FullPath));

            if any(badRows)
                fprintf(['      Hourly meteo LUT paths are stale ' ...
                    'and could not be fully rebased.\n' ...
                    '      Rebuilding lookup table ' ...
                    'from current directory:\n' ...
                    '      %s\n'],dirData);
            
                LUTh = build_meteo_time_LUT( ...
                    dirData,data_name, ...
                    "HeaderLines",1, ...
                    "dtHours",1, ...
                    "RefDT",tref, ...
                    "TimeFormat","yyyy-MM-dd HH:mm:ss");
            
                save(lut_file,'LUTh','-v7.3');
            
                id_gauge = normalize_usgs(LUTh.GAUGE_ID8);
                id_req = normalize_usgs(id_GAUGE);
                [tf,loc] = ismember(id_req,id_gauge);
            
                if ~all(tf)
                    missing = id_GAUGE(~tf);
                    if flag_progress
                        fprintf('\n');
                    end
                    error(['      Error:read_meteo_US: ' ...
                        'Missing hourly ' ...
                        'meteo files for %d basins (e.g., %d).'], ...
                        numel(missing),missing(1));
                end
                Rows = LUTh(loc,:);
            end

            req = build_requested_window( ...
                split,true);
    
            cache_dir = fullfile(dirData, ...
                sprintf('_cache_%s_hourly', ...
                dname));
            if ~isfolder(cache_dir)
                mkdir(cache_dir);
            end
    
            for k = 1:K
                fname = Rows.FullPath(k);
    
                fileStartN = Rows.StartN(k);
                fileEndN = Rows.EndN(k);
                dth = double(Rows.dtHours(k));
    
                if req.read_start_N < fileStartN ...
                        || req.read_end_N > fileEndN
                    if flag_progress
                        fprintf('\n');
                    end
                    error(['      Error:read_meteo_US: ' ...
                        'requested period outside ' ...
                        'hourly file for basin %d.\n' ...
                        'File covers %s to %s.'], ...
                        id_GAUGE(k), ...
                        string(Rows.StartDT(k)), ...
                        string(Rows.EndDT(k)));
                end
    
                if mod(double(req.read_start_N ...
                        - fileStartN),dth) ~= 0 ...
                        || mod(double(req.read_end_N ...
                        - fileStartN),dth) ~= 0
                    if flag_progress
                        fprintf('\n');
                    end
                    error(['      Error:read_meteo_US: ' ...
                        'requested times not aligned ' ...
                        'to dtHours grid for basin %d.'], ...
                        id_GAUGE(k));
                end
    
                id_read0 = int64((req.read_start_N ...
                    - fileStartN)/dth) + 1;
                id_read1 = int64((req.read_end_N ...
                    - fileStartN)/dth) + 1;
    
                usgs8 = char(Rows.GAUGE_ID8(k));
                cache_file = fullfile(cache_dir, ...
                    sprintf('%s_%s_hourly.mat', ...
                    usgs8,dname));
    
                [Pfull,Epfull,Tfull,ET0full,badrows_full] = ...
                    load_or_build_hourly_meteo_cache( ...
                    fname,cache_file,pet,comp_E0);
    
                id_r = double(id_read0:id_read1);
    
                P = Pfull(id_r);
                Ep = Epfull(id_r);
                T = Tfull(id_r);
    
                dat{k}.meteo.P = single(P);
                dat{k}.meteo.Ep = single(Ep);
                dat{k}.meteo.T = single(T);
    
                if comp_E0 == 1
                    ET0 = ET0full(id_r);
                    dat{k}.meteo.ET0 = single(ET0);
                end
    
                dat{k}.gauge = id_GAUGE(k);
                dat{k}.fname{1} = fname;
    
                badrows_full = double(badrows_full(:));
                id0d = double(id_read0);
                id1d = double(id_read1);
    
                bad_loc = badrows_full( ...
                    badrows_full >= id0d & ...
                    badrows_full <= id1d) - id0d + 1;
    
                dat{k}.meteo.bad = bad_loc(:)';
    
                if ~isempty(bad_loc)
                    if flag_progress
                        fprintf('\n');
                    end
                    fprintf(['      Warning:read_meteo_US: ' ...
                        'At least one row of %s hourly ' ...
                        'meteo data of basin %d has ' ...
                        'invalid values\n'], ...
                        dname,id_GAUGE(k));
    
                    pct = floor(100*k/K);
                    fprintf(['... Reading hourly ' ...
                        'meteorological %s ' ...
                        'data files %3d%%'], ...
                        dname,pct);
                    flag_progress = true;
                end
    
                if mod(k,5)==0 || k==K
                    pct = floor(100*k/K);
                    fprintf('\b\b\b\b%3d%%',pct);
                    drawnow;
                end
                % Graphical User Interface
                if isfield(meteo,'progressFcn') ...
                        && ~isempty(meteo.progressFcn)
                    meteo.progressFcn(k);
                end
            end
    
            if flag_progress
                fprintf('\b\b\b\b%s\n','... Done');
            end
    
        %======================================================================
        otherwise
        %======================================================================
            fprintf('\n');
            fprintf(['      Warning:read_meteo_US: ' ...
                'Unknown dt = %d temporal resolution ' ...
                'of meteo data: set dt = 1 ' ...
                '[daily] or dt = 24 [hourly]\n'],dt);
            error(['      Error:read_meteo_US: ' ...
                'demo_SAGE stops']);
    end
    
    % ----------------------------------------------------------
    % Local basin-specific split based on ranked annual rainfall
    % ----------------------------------------------------------
    if isfield(split,'local') ...
            && split.local ...
            && isfield(split,'rainfall_block') ...
            && split.rainfall_block
    
        dat = rainfall_rank_split(dat,split);
    end
    %fprintf('\n');

end
% ----------------
% helper functions
% ----------------
function LUT = build_meteo_time_LUT(dir_root, ...
    pattern,varargin)
%BUILD_METEO_TIME_LUT Build lookup table with time coverage meteo files
%
% LUT columns:
%   GAUGE_ID8   (string)  - 8-digit basin id parsed from filename
%   StartDT    (datetime)
%   EndDT      (datetime)
%   StartN     (int64)   - integer offset from reference
%   EndN       (int64)
%   dtHours    (int16)   - 1 for hourly, 24 for daily
%   HeaderLines(int16)   - number of header lines before data
%   FullPath   (string)
%   Filename   (string)

    p = inputParser;
    p.addRequired("dir_root", @(x)ischar(x)||isstring(x));
    p.addRequired("pattern",  @(x)ischar(x)||isstring(x));
    p.addParameter("TimeFormat","",@(x)isstring(x)||ischar(x));
    p.addParameter("HeaderLines",0, ...
        @(x)isnumeric(x)&&isscalar(x)&&x>=0);
    p.addParameter("dtHours",[], ...
        @(x)isnumeric(x)&&isscalar(x)&&x>0);
    p.addParameter("RefDT",datetime(1950,10,1,0,0,0), ...
        @(x)isdatetime(x)&&isscalar(x));
    p.addParameter("Recursive",true, ...
        @(x)islogical(x)&&isscalar(x));
    p.addParameter("MaxFiles",inf, ...
        @(x)isnumeric(x)&&isscalar(x)&&x>0);
    p.parse(dir_root,pattern,varargin{:});
    
    hdr = int16(p.Results.HeaderLines);
    dtHours = p.Results.dtHours;
    tref = p.Results.RefDT;
    doRec = p.Results.Recursive;
    maxF = p.Results.MaxFiles;
    tfmt = string(p.Results.TimeFormat);
    
    dir_root = string(dir_root);
    pattern = string(pattern);
    
    if doRec
        D = dir(fullfile(dir_root,"**",pattern));
    else
        D = dir(fullfile(dir_root,pattern));
    end
    
    if isempty(D)
        LUT = table();
        return;
    end
    
    if isfinite(maxF)
        D = D(1:min(numel(D),maxF));
    end
    
    names = string({D.name})';
    paths = string(fullfile({D.folder}',{D.name}'));
    relPaths = erase(paths,string(dir_root) + filesep);
    
    tok = regexp(names,'^(\d{8})','tokens','once');
    gauge = strings(numel(names),1);
    for i = 1:numel(tok)
        if ~isempty(tok{i})
            gauge(i) = string(tok{i}{1});
        end
    end
    
    if isempty(dtHours)
        if any(contains(lower(names),"hour"))
            dtHours = 1;
        else
            dtHours = 24;
        end
    end
    dtHours = int16(dtHours);
    
    StartDT = NaT(numel(names),1);
    EndDT = NaT(numel(names),1);
    StartN = zeros(numel(names),1,"int64");
    EndN = zeros(numel(names),1,"int64");
    
    for i = 1:numel(names)
        fname = paths(i);
    
        if mod(i,25) == 1 || i == numel(names)
            fprintf(['      build_meteo_time_LUT: ' ...
                'file %d of %d: %s\n'], ...
                i,numel(names),char(fname));
            drawnow;
        end
        
        if strlength(tfmt) > 0
            StartDT(i) = ...
                read_first_timestamp_csv(fname,hdr,tfmt);
            EndDT(i) = ...
                read_last_timestamp_csv(fname,tfmt);
        else
            first = read_first_data_row(fname,hdr);
            last = read_last_data_row(fname);
            StartDT(i) = parts_to_datetime(first);
            EndDT(i) = parts_to_datetime(last);
        end
    
        if dtHours == 1
            StartN(i) = int64(hours(StartDT(i) - tref));
            EndN(i) = int64(hours(EndDT(i) - tref));
        elseif dtHours == 24
            StartN(i) = int64(days(dateshift(StartDT(i), ...
                'start','day') - dateshift(tref, ...
                'start','day')));
            EndN(i) = int64(days(dateshift(EndDT(i), ...
                'start','day') - dateshift(tref, ...
                'start','day')));
        else
            StartN(i) = int64(hours(StartDT(i) - tref) ...
                / double(dtHours));
            EndN(i) = int64(hours(EndDT(i) - tref) ...
                / double(dtHours));
        end
    end
    
    LUT = table(gauge,StartDT,EndDT,StartN,EndN, ...
                repmat(dtHours,numel(names),1), ...
                repmat(hdr,numel(names),1), ...
                paths,relPaths,names, ...
        'VariableNames',{'GAUGE_ID8','StartDT', ...
        'EndDT','StartN','EndN', ...
        'dtHours','HeaderLines', ...
        'FullPath','RelPath','Filename'});
    LUT = LUT(LUT.GAUGE_ID8 ~= "", :);
end

function dt = read_first_timestamp_csv( ...
    fname,hdr,tfmt)
    fid = fopen(char(fname),'r');
    if fid < 0
        error("Cannot open %s",fname);
    end
    cleanup = onCleanup(@() fclose(fid));
    
    for k = 1:double(hdr)
        fgetl(fid);
    end
    
    while true
        line = fgetl(fid);
        if ~ischar(line)
            break;
        end
        line = strtrim(line);
        if ~isempty(line)
            break;
        end
    end
    
    if ~ischar(line)
        error("No data lines found in %s",fname);
    end
    
    tstr = extractBefore(line,",");
    dt = datetime(strtrim(tstr),"InputFormat",tfmt);
end

function dt = read_last_timestamp_csv(fname,tfmt)
    fid = fopen(char(fname),'r');
    if fid < 0
        error("Cannot open %s",fname);
    end
    cleanup = onCleanup(@() fclose(fid));
    
    fseek(fid,0,'eof');
    pos = ftell(fid);
    block = 65536;
    
    line = "";
    while pos > 0
        pos = max(0,pos - block);
        fseek(fid,pos,'bof');
        txt = fread(fid,block,'*char')';
        lines = regexp(txt,'\r\n|\n|\r','split');
    
        for j = numel(lines):-1:1
            cand = strtrim(lines{j});
            if isempty(cand)
                continue;
            end
            if ~isempty(regexp(cand, ...
                    '^\d{4}-\d{2}-\d{2}','once'))
                line = cand;
                break
            end
        end
    
        if ~isempty(line)
            break
        end
    end
    
    if isempty(line)
        error("Could not locate last " + ...
            "timestamp row in %s",fname);
    end
    
    tstr = extractBefore(line,",");
    dt = datetime(strtrim(tstr), ...
        "InputFormat",tfmt);
end

function row = read_first_data_row(fname,hdr)
%READ_FIRST_DATA_ROW Read first non-empty daily data row after header

    fid = fopen(char(fname),'r');
    if fid < 0
        error(['      Error:read_meteo_US: ' ...
            'Cannot open file: %s'],fname);
    end
    cleanup = onCleanup(@() fclose(fid));
    
    for k = 1:double(hdr)
        line = fgetl(fid);
        if ~ischar(line)
            error(['      Error:read_meteo_US: ' ...
                'File ended inside header ' ...
                '(%d lines expected): %s'], ...
                double(hdr),fname);
        end
    end
    
    %line = '';
    while true
        line = fgetl(fid);
    
        if ~ischar(line)
            error(['      Error:read_meteo_US: ' ...
                'No first data row found ' ...
                'after header in file: %s'], ...
                fname);
        end
    
        line = strtrim(line);
        if ~isempty(line)
            break
        end
    end
    
    try
        row = parse_date_parts(line);
    catch ME
        error(['      Error:read_meteo_US: ' ...
            'Could not parse first data row ' ...
            'in file: %s\nLine = "%s"\nReason: %s'], ...
            fname,line,ME.message);
    end
end

function row = read_last_data_row(fname)
%READ_LAST_DATA_ROW Read last non-empty daily data row in file

    fid = fopen(char(fname),'r');
    if fid < 0
        error(['      Error:read_meteo_US: ' ...
            'Cannot open file: %s'],fname);
    end
    cleanup = onCleanup(@() fclose(fid));
    
    fseek(fid,0,'eof');
    pos = ftell(fid);
    block = 65536;
    
    line = "";
    found = false;
    
    while pos > 0
        pos = max(0,pos - block);
        fseek(fid,pos,'bof');
        txt = fread(fid,block,'*char')';
    
        if isempty(txt)
            continue
        end
    
        lines = regexp(txt,'\r\n|\n|\r','split');
    
        for j = numel(lines):-1:1
            cand = strtrim(lines{j});
            if isempty(cand)
                continue
            end
            if ~isempty(regexp(cand,'^\d','once'))
                line = cand;
                found = true;
                break
            end
        end
    
        if found
            break
        end
    end
    
    if ~found
        error(['      Error:read_meteo_US: ' ...
            'Could not locate last data row ' ...
            'in file: %s'],fname);
    end
    
    try
        row = parse_date_parts(line);
    catch ME
        error(['      Error:read_meteo_US: ' ...
            'Could not parse last data row ' ...
            'in file: %s\nLine = "%s"\nReason: %s'], ...
            fname,char(line),ME.message);
    end
end

function parts = parse_date_parts(line)
    nums = textscan(line,'%f', ...
        'Delimiter',{',',' ','\t'}, ...
        'MultipleDelimsAsOne',true);
    v = nums{1};
    
    if numel(v) < 3
        error("Line does not contain at least Y M D: %s",line);
    end
    
    if numel(v) >= 4
        parts = v(1:4);
    else
        parts = [v(1:3); 0];
    end
end

function dt = parts_to_datetime(parts)
    y = parts(1);
    m = parts(2);
    d = parts(3);
    h = parts(4);
    dt = datetime(y,m,d,h,0,0);
end

function [lat,elev,area,Dm] = ...
    read_daily_meteo_slice(fname,id_beg,id_end)
%READ_DAILY_METEO_SLICE Read only needed rows from daily forcing file

    fid = fopen(char(fname),'r');
    if fid < 0
        error(['      Error:read_meteo_US: ' ...
            'Cannot open: %s'],fname);
    end
    cleanup = onCleanup(@() fclose(fid));
    
    lat = str2double(strtrim(fgetl(fid)));     % Gauge lat. (°)
    elev = str2double(strtrim(fgetl(fid)));    % Gauge elev. (m)
    area = str2double(strtrim(fgetl(fid)));    % Basin area (m²)
    fgetl(fid);                                % skip line 4
    
    nr = double(id_end - id_beg + 1);
    fmt = repmat('%f',1,11);
    
    DmC = textscan(fid,fmt,nr, ...
        'HeaderLines',double(id_beg - 1), ...
        'Delimiter',{' ','\t'}, ...
        'MultipleDelimsAsOne',true, ...
        'CollectOutput',true);
    
    Dm = DmC{1};
    
    if size(Dm,1) ~= nr
        error(['      Error:read_meteo_US: ' ...
            'daily file ended early for %s.'], ...
            fname);
    end
end

function Qsum = build_daily_meteo_summary(LUTd,pet)
%BUILD_DAILY_METEO_SUMMARY Write one-time daily meteo summary

    K = height(LUTd);
    Qsum = table('Size',[K 5], ...
        'VariableTypes',{'double','string', ...
        'string','double','double'}, ...
        'VariableNames',{'gauge','start_record', ...
        'end_record','n_all','n_bad'});
    
    for k = 1:K
        fname = LUTd.FullPath(k);
        gauge = str2double(LUTd.GAUGE_ID8(k));
        [n_all,n_bad] = ...
            daily_meteo_full_record_badcount( ...
            fname,pet);
    
        Qsum.gauge(k) = gauge;
        Qsum.start_record(k) = ...
            string(datetime(LUTd.StartDT(k), ...
            'Format','dd/MM/yyyy'));
        Qsum.end_record(k) = ...
            string(datetime(LUTd.EndDT(k), ...
            'Format','dd/MM/yyyy'));
        Qsum.n_all(k) = n_all;
        Qsum.n_bad(k) = n_bad;
    
        if mod(k,5)==0 ...
                || k==K
            pct = floor(100*k/K);
            fprintf('\b\b\b\b%3d%%',pct);
            drawnow;
        end
    end
end

function [n_all,n_bad] = ...
    daily_meteo_full_record_badcount( ...
    fname,pet)
%DAILY_METEO_FULL_RECORD_BADCOUNT Count invalid daily forcing rows

    fid = fopen(char(fname),'r');
    if fid < 0
        error(['      Error:read_meteo_US: ' ...
            'Cannot open: %s'],fname);
    end
    cleanup = onCleanup(@() fclose(fid));
    
    lat = str2double(strtrim(fgetl(fid)));
    elev = str2double(strtrim(fgetl(fid)));
    fgetl(fid);      % area
    fgetl(fid);      % skip line 4
    
    fmt = repmat('%f',1,11);
    C = textscan(fid,fmt, ...
        'Delimiter',{' ','\t'}, ...
        'MultipleDelimsAsOne',true, ...
        'CollectOutput',true);
    
    D = C{1};
    t_d = datetime(D(:,1),D(:,2),D(:,3));
    Tmax = D(:,9);
    Tmin = D(:,10);
    Rs = D(:,7);
    Vp = D(:,11);
    doy = day(t_d,'dayofyear');
    u2 = 2;
    
    ET0 = et0_fao56_daily(Tmax,Tmin, ...
        Rs,Vp,doy,lat,elev,u2,pet);
    
    badmask = ~isfinite(D(:,6)) ...
        | ~isfinite(ET0) ...
        | ~isfinite(Tmax) ...
        | ~isfinite(Tmin);
    
    n_all = size(D,1);
    n_bad = sum(badmask);
end

function Qsum = build_hourly_meteo_summary(LUTh, ...
    dirData,dname,pet,comp_E0)
%BUILD_HOURLY_METEO_SUMMARY Write one-time hourly meteo summary

    K = height(LUTh);
    Qsum = table('Size',[K 5], ...
        'VariableTypes',{'double','string', ...
        'string','double','double'}, ...
        'VariableNames',{'gauge','start_record', ...
        'end_record','n_all','n_bad'});
    
    cache_dir = fullfile(dirData, ...
        sprintf('_cache_%s_hourly',dname));
    if ~isfolder(cache_dir)
        mkdir(cache_dir);
    end
    
    for k = 1:K
        fname = LUTh.FullPath(k);
        usgs8 = char(LUTh.GAUGE_ID8(k));
        cache_file = fullfile(cache_dir, ...
            sprintf('%s_%s_hourly.mat', ...
            usgs8,dname));
    
        [P,~,~,~,badrows] = ...
            load_or_build_hourly_meteo_cache( ...
            fname,cache_file,pet,comp_E0);
    
        Qsum.gauge(k) = str2double(usgs8);
        Qsum.start_record(k) = ...
            string(datetime(LUTh.StartDT(k), ...
            'Format','dd/MM/yyyy HH:mm'));
        Qsum.end_record(k) = ...
            string(datetime(LUTh.EndDT(k), ...
            'Format','dd/MM/yyyy HH:mm'));
        Qsum.n_all(k) = numel(P);
        Qsum.n_bad(k) = numel(badrows);
    
        if mod(k,5)==0 || k==K
            pct = floor(100*k/K);
            fprintf('\b\b\b\b%3d%%',pct);
            drawnow;
        end
    end
end

function [P,Ep,T,ET0,badrows] = ...
    load_or_build_hourly_meteo_cache(fname, ...
    cache_file,pet,comp_E0)
%LOAD_OR_BUILD_HOURLY_METEO_CACHE Load cached hourly meteo arrays
%
% Cache fields:
%   P, Ep, T, ET0, badrows

    use_cache = ~isempty(cache_file);
    rebuild = true;
    
    if use_cache && isfile(cache_file)
        info_src = dir(fname);
        info_cch = dir(cache_file);
        if info_cch.datenum >= info_src.datenum
            rebuild = false;
        end
    end
    
    if rebuild
        [P,Ep,T,ET0,badrows] = ...
            read_hourly_meteo_full_fast(fname, ...
            pet,comp_E0);
    
        if use_cache
            save(cache_file,'P','Ep','T', ...
                'ET0','badrows','-v7.3');
        end
    else
        S = load(cache_file,'P','Ep','T', ...
            'ET0','badrows');
        P = S.P;
        Ep = S.Ep;
        T = S.T;
        ET0 = S.ET0;
        badrows = S.badrows;
    end
end

function [P,Ep,T,ET0,badrows] = ...
    read_hourly_meteo_full_fast(fname,pet,comp_E0)
%READ_HOURLY_METEO_FULL_FAST Fast full-file reader for hourly csv
%
% Col mapping after csv split:
%   1  time
%   2  Rg
%   3  Ep
%   4  p
%   5  Rs
%   6  q
%   7  T
%   8  P
%   9  u10
%   10 v10

    opts = detectImportOptions(fname,"Delimiter",",");
    opts = setvartype(opts,opts.VariableNames{1},"char");
    opts.VariableNamingRule = "preserve";
    keep = opts.VariableNames([1 3 5 6 7 8 9 10 11 12]);
    opts.SelectedVariableNames = keep;
    
    Tbl = readtable(char(fname),opts);
    
    Rg = local_to_double(Tbl{:,2});
    Ep = max(local_to_double(Tbl{:,3}),0);
    p = local_to_double(Tbl{:,4});
    Rs = local_to_double(Tbl{:,5});
    q = local_to_double(Tbl{:,6});
    T = local_to_double(Tbl{:,7});
    P = local_to_double(Tbl{:,8});
    u10 = local_to_double(Tbl{:,9});
    v10 = local_to_double(Tbl{:,10});
    
    if comp_E0 == 1
        ET0 = et0_fao56_hourly(Rg,p,Rs,q,T,u10,v10,pet);
        badmask = ~isfinite(P) ...
            | ~isfinite(Ep) ...
            | ~isfinite(T) ...
            | ~isfinite(ET0);
    else
        ET0 = [];
        badmask = ~isfinite(P) ...
            | ~isfinite(Ep) ...
            | ~isfinite(T);
    end
    
    badrows = int64(find(badmask));
end

function x = local_to_double(x)
%LOCAL_TO_DOUBLE Convert table output to double column vector

    if isnumeric(x)
        x = double(x(:));
        return
    end
    
    if iscell(x)
        x = string(x);
    end
    
    if ischar(x)
        x = string(cellstr(x));
    end
    
    if isstring(x) || iscategorical(x)
        x = str2double(string(x(:)));
        return
    end
    
    error(['      Error:read_meteo_US: ' ...
        'Unable to convert hourly meteo ' ...
        'column to double.']);
end

function LUT = rebase_meteo_LUT_paths(LUT,dirData)
%REBASE_METEO_LUT_PATHS Make cached LUT paths portable across machines.

    if isempty(LUT) ...
            || ~istable(LUT)
        return
    end

    dirData = char(string(dirData));

    % Best case: LUT has relative paths.
    if ismember('RelPath',LUT.Properties.VariableNames)
        LUT.FullPath = string(fullfile(dirData, ...
            string(LUT.RelPath)));
    end

    % If FullPath exists and all files are valid, done.
    if ismember('FullPath', ...
            LUT.Properties.VariableNames)
        try
            if all(isfile(string(LUT.FullPath)))
                return
            end
        catch
        end
    else
        return
    end

    % Fallback for old LUTs without RelPath:
    % search by Filename under the current dirData.
    if ismember('Filename',LUT.Properties.VariableNames)
        newFullPath = strings(height(LUT),1);

        D = dir(fullfile(dirData,'**','*'));
        D = D(~[D.isdir]);

        allNames = string({D.name})';
        allPaths = string(fullfile({D.folder}',{D.name}'));

        for i = 1:height(LUT)
            fname = string(LUT.Filename(i));
            hit = find(allNames == fname,1,'first');

            if ~isempty(hit)
                newFullPath(i) = allPaths(hit);
            else
                newFullPath(i) = string(LUT.FullPath(i));
            end
        end

        LUT.FullPath = newFullPath;
    end
end
