function R = region_config_US()
%REGION_CONFIG_US Regional defaults for CAMELS-US.
%
% All X.paths fields are relative to Data/<R.data_root>.
% Dates use dd/MM/yyyy and water-year boundaries.

    R = struct();
    R.code = 'CAMELS_US';
    R.acronym = 'US';
    R.name = 'United States';
    R.dataset = 'CAMELS-US';
    R.data_root = 'CAMELS_US';
    R.resolutions = {'Daily','Hourly'};
    R.default_resolution = 'Daily';
    R.basin_file_pattern = 'US_%d_basins.txt';

    X = struct();
    X.label = 'Daily';
    X.dt = 1;
    X.basins.universe = [531 671];
    X.basins.training = 400;
    X.basins.evaluation = 131;
    X.period.spinup_days = 365;
    X.period.manual.train_start = '01/10/1999';
    X.period.manual.train_end = '30/09/2008';
    X.period.manual.eval_start = '01/10/1989';
    X.period.manual.eval_end = '30/09/1999';
    X.period.common_start = '01/10/1989';
    X.period.common_end = '30/09/2008';
    X.paths.run_root = '';
    X.paths.meteo = fullfile('daily','v1p2','forcing');
    X.paths.discharge = fullfile('daily','v1p2','streamflow');
    % Meteorological/PET controls shown by SAGE-GUI.
    X.meteo.product.items = { ...
        '1 Daymet', ...
        '2 Maurer', ...
        '3 NLDAS' ...
        };
    X.meteo.product.default = '1 Daymet';
    X.meteo.product.enabled = true;
    X.meteo.precipitation.items = {'Controlled by meteo product'};
    X.meteo.precipitation.default = 'Controlled by meteo product';
    X.meteo.precipitation.enabled = false;
    X.meteo.temperature.items = {'Controlled by meteo product'};
    X.meteo.temperature.default = 'Controlled by meteo product';
    X.meteo.temperature.enabled = false;
    X.meteo.pet.items = { ...
        '1 Penman-Monteith', ...
        '2 Priestley-Taylor', ...
        '3 Makkink' ...
        };
    X.meteo.pet.default = '1 Penman-Monteith';
    X.meteo.pet.enabled = true;
    C = repmat(struct('name','','type','','path','','pattern','', ...
        'minimum_count',1,'required',true),0,1);
    C(1).name = 'Meteorological data';
    C(1).type = 'folder';
    C(1).path = fullfile('daily','v1p2','forcing');
    C(1).pattern = '*';
    C(1).minimum_count = 1;
    C(2).name = 'Discharge data';
    C(2).type = 'folder';
    C(2).path = fullfile('daily','v1p2','streamflow');
    C(2).pattern = '*';
    C(2).minimum_count = 1;
    X.checks = C;
    R.by_resolution.Daily = X;

    X = struct();
    X.label = 'Hourly';
    X.dt = 24;
    X.basins.universe = 499;
    X.basins.training = 400;
    X.basins.evaluation = 99;
    X.period.spinup_days = 365;
    X.period.manual.train_start = '01/10/2008';
    X.period.manual.train_end = '30/09/2015';
    X.period.manual.eval_start = '01/10/2000';
    X.period.manual.eval_end = '30/09/2008';
    X.period.common_start = '01/10/2000';
    X.period.common_end = '30/09/2015';
    X.paths.run_root = '';
    X.paths.meteo = fullfile('hourly','forcing');
    X.paths.discharge = fullfile('hourly','streamflow');
    % Meteorological/PET controls shown by SAGE-GUI.
    X.meteo.product.items = {'3 NLDAS'};
    X.meteo.product.default = '3 NLDAS';
    X.meteo.product.enabled = false;
    X.meteo.precipitation.items = {'Controlled by meteo product'};
    X.meteo.precipitation.default = 'Controlled by meteo product';
    X.meteo.precipitation.enabled = false;
    X.meteo.temperature.items = {'Controlled by meteo product'};
    X.meteo.temperature.default = 'Controlled by meteo product';
    X.meteo.temperature.enabled = false;
    X.meteo.pet.items = { ...
        '1 Penman-Monteith', ...
        '2 Priestley-Taylor', ...
        '3 Makkink' ...
        };
    X.meteo.pet.default = '1 Penman-Monteith';
    X.meteo.pet.enabled = true;
    C = repmat(struct('name','','type','','path','','pattern','', ...
        'minimum_count',1,'required',true),0,1);
    C(1).name = 'Meteorological data';
    C(1).type = 'folder';
    C(1).path = fullfile('hourly','forcing');
    C(1).pattern = '*';
    C(1).minimum_count = 1;
    C(2).name = 'Discharge data';
    C(2).type = 'folder';
    C(2).path = fullfile('hourly','streamflow');
    C(2).pattern = '*';
    C(2).minimum_count = 1;
    X.checks = C;
    R.by_resolution.Hourly = X;

end