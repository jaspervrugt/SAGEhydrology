function dat=read_Q_JM(~,~,dat,~,~,~)
%READ_Q_JM No-op: GRDC-Caravan streamflow is read with meteorology.
end
