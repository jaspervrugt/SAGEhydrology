function [A,id_gauge,gname,zone]=read_attr_JM(dirD,bas)
%READ_ATTR_JM Read filtered Jamaica GRDC-Caravan attributes.
    [A,id_gauge,gname,zone]=read_attr_NA(dirD,bas,'CAMELS_JM','JM');
end
