function [dat,aux]=read_meteo_JM(dirM,bas,split,meteo)
%READ_METEO_JM Read daily Jamaica GRDC-Caravan forcing and discharge.
    [dat,aux]=read_meteo_NA(dirM,bas,split,meteo,'Jamaica');
end
