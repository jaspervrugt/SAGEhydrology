function dat = read_Q_CH(dirQ,mdl,dat,bas,split,aux)            %#ok
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%READ_Q_CH Read discharge data for each watershed in Switzerland
%
% SYNOPSIS: [dat,aux] = read_Q_CH(dirQ,mdl,dat,bas,split,aux)
%   dirQ        string with main directory of discharge data
%   mdl         model state/parameter info
%   dat         cell structure with meteorological/model information
%   bas         structure basin information
%   split       structure with training/evaluation time split
%   aux         Kx3 matrix with basin metadata
%   dat         OUTPUT: cell structure with discharge information added
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% © Written by Jasper A. Vrugt, Apr. 2026                                 %
% University of California Irvine                                         %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

fprintf(['... Reading daily CH discharge ' ...
    'data files %3d%%'],0);
fprintf('\b\b\b\b... Done\n');

end