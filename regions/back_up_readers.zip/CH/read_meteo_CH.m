function [dat,aux] = read_meteo_CH(dirM,bas,split,meteo)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%READ_METEO_CH Read CAMELS-CH daily meteorological/discharge data for SAGE.
%
% SYNOPSIS:
%   [dat,aux] = read_meteo_CH(dirM,bas,split,meteo)
%
% INPUT:
%   dirM        CAMELS-CH data directory. Either .../Data/CAMELS_CH or
%               .../Data/CAMELS_CH/daily/timeseries is accepted.
%   bas         basin structure with fields
%    .K          number of selected basins
%    .id_gauge   Kx1 basin/gauge identifiers, e.g. 5021
%   split       SAGE split structure. Supports daily dt = 1 only.
%               Uses spinup-aware requested window from ds/de, dts/dte,
%               or d1/d2.
%   meteo       options structure
%    .data       precipitation source:
%                  1 = observation-based precipitation(mm/d) [default]
%                  2 = simulation-based precipitation_sim(mm/d)
%    .temp       temperature source, observation-based:
%                  1 = temperature_mean(degC) [default]
%                  2 = mean(temperature_min,temperature_max)
%    .pet        PET source:
%                  1 = simulation-based pet_sim(mm/d) [default]
%    .progressFcn OPTIONAL function handle called progressFcn(k)
%
% OUTPUT:
%   dat         Kx1 cell array.
%    {k}.meteo.P    nx1 precipitation vector [mm/day]
%    {k}.meteo.Ep   nx1 potential evapotranspiration vector [mm/day]
%    {k}.meteo.T    nx1 mean air temperature vector [deg C]
%    {k}.meteo.bad  row vector of local indices with invalid meteo values
%    {k}.y_n        scored-period observed discharge, spin-up removed [mm/d]
%    {k}.bad        logical mask for invalid discharge, same length as y_n
%    {k}.gauge      basin/gauge identifier
%    {k}.fname      source/cache file names
%   aux         Kx3 matrix [lat,elev,area_m2] if gauge_information.txt is
%               available; otherwise NaNs.
%
% FILES:
%   observation_based/CAMELS_CH_obs_based_<ID>.csv
%   simulation_based/CAMELS_CH_sim_based_<ID>.csv
%
%   Observation-based columns used:
%     date, discharge_spec(mm/d), precipitation(mm/d),
%     temperature_min(degC), temperature_mean(degC), temperature_max(degC)
%
%   Simulation-based columns used:
%     date, precipitation_sim(mm/d), pet_sim(mm/d)
%
% NOTES:
%   The simulation-based file also contains radiation, wind, humidity and
%   other modeled fluxes. This reader intentionally starts with pet_sim as
%   the only PET option. Penman-Monteith, Priestley-Taylor and Makkink can
%   be added later if those variables are to be recomputed consistently.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% © Written by Jasper A. Vrugt / CAMELS-CH support, Jun. 2026             %
% University of California, Irvine                                        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    if nargin < 1 ...
            || isempty(dirM)
        error('read_meteo_CH:missingDir', ...
            ['      Error:read_meteo_CH: ' ...
            'dirM must be provided.']);
    end
    if ~isfolder(dirM)
        error('read_meteo_CH:missingDir', ...
            ['      Error:read_meteo_CH: ' ...
            'Directory does not exist: %s'],dirM);
    end
    if nargin < 2 ...
            || ~isstruct(bas) ...
            || ~isfield(bas,'id_gauge')
        error('read_meteo_CH:missingBasins', ...
            ['      Error:read_meteo_CH: ' ...
            'bas.id_gauge must be provided.']);
    end
    if nargin < 3 ...
            || isempty(split)
        error('read_meteo_CH:missingSplit', ...
            ['      Error:read_meteo_CH: ' ...
            'split must be provided.']);
    end
    if nargin < 4 ...
            || isempty(meteo)
        meteo = struct();
    end
    
    split = prepare_split_CH(split);
    dt = double(split.dt);
    if dt ~= 1
        error('read_meteo_CH:dailyOnly', ...
            ['      Error:read_meteo_CH: ' ...
            'CAMELS-CH currently ' ...
            'supports daily data only.']);
    end
    
    id_gauge = normalize_ch_id(bas.id_gauge(:));
    K = numel(id_gauge);
    if isfield(bas,'K') && ~isempty(bas.K)
        K = min(double(bas.K),K);
        id_gauge = id_gauge(1:K);
    end
    
    [p_id,p_label] = precipitation_source_CH(meteo);
    [t_id,t_label] = temperature_source_CH(meteo);
    [pet_id,pet_label] = pet_source_CH(meteo);
    
    rootCH = resolve_ch_root(dirM);
    tsDir = fullfile(rootCH,'daily','timeseries');
    if strcmpi(get_last_folder_CH(rootCH), ...
            'timeseries')
        tsDir = rootCH;
        rootCH = fileparts(rootCH);
        [pDaily,nmDaily] = fileparts(rootCH);
        if strcmpi(nmDaily,'daily')
            rootCH = pDaily;
        end
    end
    obsDir = fullfile(tsDir,'observation_based');
    simDir = fullfile(tsDir,'simulation_based');
    
    if ~isfolder(obsDir)
        error('read_meteo_CH:missingObsDir', ...
            ['      Error:read_meteo_CH: ' ...
            'Missing observation_based folder: %s'], ...
            obsDir);
    end
    if ~isfolder(simDir)
        error('read_meteo_CH:missingSimDir', ...
            ['      Error:read_meteo_CH: ' ...
            'Missing simulation_based folder: %s'], ...
            simDir);
    end
    
    cacheDir = fullfile(tsDir,'_cache_CH_daily');
    if ~isfolder(cacheDir)
        mkdir(cacheDir);
    end
    
    req = build_requested_window_CH(split,true);
    aux = read_aux_CH(rootCH,id_gauge);
    dat = cell(K,1);
    
    fprintf(['... Reading CAMELS-CH daily data ' ...
        'P=%s, PET=%s, T=%s ... %3d%%'], ...
        p_label,pet_label,t_label,0);
    flag_progress = true;
    
    for k = 1:K
        gid = char(id_gauge(k));
    
        fObs = find_ch_timeseries_file(obsDir,'obs',gid);
        fSim = find_ch_timeseries_file(simDir,'sim',gid);
    
        cacheFile = fullfile(cacheDir, ...
            sprintf('%s_CH_daily_p%d_pet%d_t%d.mat', ...
            gid,p_id,pet_id,t_id));
    
        [Pfull,Epfull,Tfull,Qfull,bad_meteo_full,bad_q_full, ...
            fileStartN,fileEndN,fileStartDT,fileEndDT,cacheUsed] = ...
            load_or_build_ch_cache(fObs, ...
            fSim,cacheFile,p_id,t_id,pet_id,gid); %#ok
    
        if req.read_start_N < fileStartN || req.read_end_N > fileEndN
            if flag_progress
                fprintf('\n');
            end
            error('read_meteo_CH:periodOutsideFile', ...
                ['      Error:read_meteo_CH: ' ...
                'requested period outside ' ...
                'CAMELS-CH files for basin %s.\n' ...
                'File overlap covers %s to %s.'], ...
                gid,string(fileStartDT),string(fileEndDT));
        end
    
        id0 = double(req.read_start_N - fileStartN) + 1;
        id1 = double(req.read_end_N   - fileStartN) + 1;
        idxRead = id0:id1;
    
        P = double(Pfull(idxRead));
        Ep = double(Epfull(idxRead));
        Tair = double(Tfull(idxRead));
        Qall = double(Qfull(idxRead));
    
        dat{k}.meteo.P = single(P(:));
        dat{k}.meteo.Ep = single(Ep(:));
        dat{k}.meteo.T = single(Tair(:));
    
        idx_score = double(split.idx(:));
        idx_score = idx_score(idx_score >= 1 ...
            & idx_score <= numel(Qall));
        if isempty(idx_score)
            idx_score = (1:numel(Qall)).';
        end
    
        dat{k}.y_n = single(Qall(idx_score));
        dat{k}.gauge = gid;
        dat{k}.fname = {fObs,fSim,cacheFile};
    
        bad_meteo_full = double(bad_meteo_full(:));
        bad_q_full = double(bad_q_full(:));
    
        bad_meteo = bad_meteo_full( ...
            bad_meteo_full >= id0 ...
            & bad_meteo_full <= id1) - id0 + 1;
        dat{k}.meteo.bad = bad_meteo(:).';
    
        bad_q_all = bad_q_full( ...
            bad_q_full >= id0 & bad_q_full <= id1) - id0 + 1;
        badmask_all = false(1,numel(Qall));
        bad_q_all = bad_q_all(isfinite(bad_q_all) ...
            & bad_q_all >= 1 ...
            & bad_q_all <= numel(Qall));
        badmask_all(round(bad_q_all)) = true;
        dat{k}.bad = badmask_all(idx_score);
    
        if mod(k,5) == 0 || k == K
            pct = floor(100*k/K);
            fprintf('\b\b\b\b%3d%%',pct);
            drawnow;
        end
    
        if isfield(meteo,'progressFcn') ...
                && ~isempty(meteo.progressFcn)
            try
                meteo.progressFcn(k);
            catch
            end
        end
    end
    
    if flag_progress
        fprintf('\b\b\b\bDone\n');
    end
    
    if isfield(split,'local') ...
            && split.local ...
            && isfield(split,'rainfall_block') ...
            && split.rainfall_block
        dat = rainfall_rank_split(dat,split);
    end

end

% ==================================================================
function [P,Ep,Tair,Q,bad_meteo,bad_q, ...
    fileStartN,fileEndN,fileStartDT,fileEndDT,cacheUsed] = ...
    load_or_build_ch_cache(fObs,fSim,cacheFile,p_id,t_id,pet_id,gid)
% ==================================================================

    cacheUsed = false;
    if isfile(cacheFile)
        try
            infoObs = dir(fObs);
            infoSim = dir(fSim);
            S = load(cacheFile, ...
                'P','Ep','Tair','Q','bad_meteo','bad_q', ...
                'fileStartN','fileEndN', ...
                'fileStartDT','fileEndDT', ...
                'obsBytes','simBytes', ...
                'obsDatenum','simDatenum');
            if isfield(S,'obsBytes') ...
                    && isfield(S,'simBytes') ...
                    && S.obsBytes == infoObs.bytes ...
                    && S.simBytes == infoSim.bytes ...
                    && abs(S.obsDatenum - infoObs.datenum) < 1e-8 ...
                    && abs(S.simDatenum - infoSim.datenum) < 1e-8
                P = S.P;
                Ep = S.Ep;
                Tair = S.Tair;
                Q = S.Q;
                bad_meteo = S.bad_meteo;
                bad_q = S.bad_q;
                fileStartN = S.fileStartN;
                fileEndN = S.fileEndN;
                fileStartDT = S.fileStartDT;
                fileEndDT = S.fileEndDT;
                cacheUsed = true;
                return
            end
        catch
            cacheUsed = false;
        end
    end
    
    [Obs,tObs] = read_ch_table(fObs);
    [Sim,tSim] = read_ch_table(fSim);
    
    fileStartDT = max([min(tObs),min(tSim)]);
    fileEndDT = min([max(tObs),max(tSim)]);
    if fileEndDT < fileStartDT
        error('read_meteo_CH:noOverlap', ...
            ['      Error:read_meteo_CH: ' ...
            'observation and simulation ' ...
            'files do not overlap ' ...
            'for basin %s.'],gid);
    end
    
    t = (fileStartDT:days(1):fileEndDT).';
    
    Q = single(column_by_date_CH(Obs,tObs,t, ...
        'discharge_spec(mm/d)',fObs));
    
    switch p_id
        case 1
            P = single(column_by_date_CH(Obs,tObs,t, ...
                'precipitation(mm/d)',fObs));
        case 2
            P = single(column_by_date_CH(Sim,tSim,t, ...
                'precipitation_sim(mm/d)',fSim));
        otherwise
            error('read_meteo_CH:badPrecipChoice', ...
                'Internal bad precipitation choice.');
    end
    
    switch t_id
        case 1
            Tair = single(column_by_date_CH(Obs,tObs,t, ...
                'temperature_mean(degC)',fObs));
        case 2
            Tmin = column_by_date_CH(Obs,tObs,t, ...
                'temperature_min(degC)',fObs);
            Tmax = column_by_date_CH(Obs,tObs,t, ...
                'temperature_max(degC)',fObs);
            Tair = single(0.5*(Tmin + Tmax));
        otherwise
            error('read_meteo_CH:badTempChoice', ...
                'Internal bad temperature choice.');
    end
    
    switch pet_id
        case 1
            Ep = single(column_by_date_CH(Sim,tSim,t, ...
                'pet_sim(mm/d)',fSim));
        otherwise
            error('read_meteo_CH:badPETChoice', ...
                'Internal bad PET choice.');
    end
    
    P = single(max(double(P),0));
    Ep = single(max(double(Ep),0));
    
    bad_meteo = int64(find(~isfinite(double(P)) ...
        | ~isfinite(double(Ep)) ...
        | ~isfinite(double(Tair)) ...
        | double(P) < 0 ...
        | double(Ep) < 0));
    
    bad_q = int64(find(~isfinite(double(Q))));
    
    fileStartN = int64(datenum(fileStartDT)); %#ok<DATNM>
    fileEndN = int64(datenum(fileEndDT));     %#ok<DATNM>
    
    obsInfo = dir(fObs);
    simInfo = dir(fSim);
    obsBytes = obsInfo.bytes;
    simBytes = simInfo.bytes;
    obsDatenum = obsInfo.datenum;
    simDatenum = simInfo.datenum;
    sourceObs = fObs;
    sourceSim = fSim;
    
    save(cacheFile,'P','Ep', ...
        'Tair','Q','bad_meteo','bad_q', ...
        'fileStartN','fileEndN', ...
        'fileStartDT','fileEndDT', ...
        'sourceObs','sourceSim', ...
        'obsBytes','simBytes', ...
        'obsDatenum','simDatenum', ...
        'p_id','t_id','pet_id','gid','-v7.3');

end

% ===================================
function [T,t] = read_ch_table(fname)
% ===================================

    opts = detectImportOptions(fname, ...
        'FileType','text', ...
        'VariableNamingRule','preserve');
    T = readtable(fname,opts);
    if ~ismember('date', ...
            T.Properties.VariableNames)
        error('read_meteo_CH:missingDate', ...
            ['      Error:read_meteo_CH: ' ...
            '%s lacks date column.'],fname);
    end
    
    t = datetime(string(T.date), ...
        'InputFormat','yyyy-MM-dd');

end

% ========================================================
function x = column_by_date_CH(T,tFile,tReq,varName,fname)
% ========================================================

    if ~ismember(varName, ...
            T.Properties.VariableNames)
        % Try robust matching if MATLAB altered parentheses in rare releases.
        hit = find(strcmpi(clean_name_CH( ...
            T.Properties.VariableNames), ...
            clean_name_CH({varName})),1,'first');
        if isempty(hit)
            error('read_meteo_CH:missingVariable', ...
                ['      Error:read_meteo_CH: ' ...
                '%s lacks column %s.'],fname,varName);
        end
        varName = T.Properties.VariableNames{hit};
    end
    
    [tf,loc] = ismember(tReq,tFile);
    if ~all(tf)
        error('read_meteo_CH:missingDates', ...
            ['      Error:read_meteo_CH: ' ...
            '%s lacks %d requested dates, e.g. %s.'], ...
            fname,sum(~tf),string(tReq(find(~tf,1))));
    end
    
    v = T.(varName);
    if isnumeric(v) ...
            || islogical(v)
        x = double(v(loc));
    else
        x = str2double(string(v(loc)));
    end
    
    % Common missing-value conventions.
    x(abs(x + 999) < 1e-8 ...
        | abs(x + 99) < 1e-8 ...
        | abs(x + 99.9) < 1e-8 ...
        | abs(x + 99.99) < 1e-8) = NaN;

end

% ==================================================
function fname = find_ch_timeseries_file(d,kind,gid)
% ==================================================

    switch lower(kind)
        case 'obs'
            patterns = { ...
                sprintf('CAMELS_CH_obs_based_%s.csv',gid), ...
                sprintf('*obs*%s.csv',gid), ...
                sprintf('*_%s.csv',gid)};
            errTag = 'observation-based';
        case 'sim'
            patterns = { ...
                sprintf('CAMELS_CH_sim_based_%s.csv',gid), ...
                sprintf('*sim*%s.csv',gid), ...
                sprintf('*_%s.csv',gid)};
            errTag = 'simulation-based';
        otherwise
            error('read_meteo_CH:badKind', ...
                'Unknown file kind.');
    end
    
    fname = '';
    for i = 1:numel(patterns)
        D = dir(fullfile(d,patterns{i}));
        D = D(~[D.isdir]);
        if ~isempty(D)
            fname = fullfile(D(1).folder,D(1).name);
            return
        end
    end
    
    error('read_meteo_CH:missingFile', ...
        ['      Error:read_meteo_CH: ' ...
        'Missing %s file ' ...
        'for basin %s in %s.'],errTag,gid,d);

end

% ==================================================
function [id,label] = precipitation_source_CH(meteo)
% ==================================================

    id = 1;
    if isfield(meteo,'data') ...
            && ~isempty(meteo.data)
        id = double(meteo.data(1));
    end
    
    switch id
        case 1
            label = 'OBS precipitation';
        case 2
            label = 'SIM precipitation';
        otherwise
            error('read_meteo_CH:badPrecipSource', ...
                ['      Error:read_meteo_CH: ' ...
                'meteo.data must be 1=OBS or 2=SIM.']);
    end

end

% ================================================
function [id,label] = temperature_source_CH(meteo)
% ================================================

    id = 1;
    if isfield(meteo,'temp') ...
            && ~isempty(meteo.temp)
        id = double(meteo.temp(1));
    end
    
    switch id
        case 1
            label = 'OBS Tmean';
        case 2
            label = 'OBS mean(Tmin,Tmax)';
        otherwise
            error('read_meteo_CH:badTempSource', ...
                ['      Error:read_meteo_CH: ' ...
                'meteo.temp must be 1=Tmean ' ...
                'or 2=mean(Tmin,Tmax).']);
    end

end

% ========================================
function [id,label] = pet_source_CH(meteo)
% ========================================

    id = 1;
    if isfield(meteo,'pet') ...
            && ~isempty(meteo.pet)
        id = double(meteo.pet(1));
    end
    
    switch id
        case 1
            label = 'SIM PET';
        otherwise
            error('read_meteo_CH:badPETSource', ...
                ['      Error:read_meteo_CH: ' ...
                'meteo.pet must be 1=pet_sim.']);
    end

end

% ======================================
function split = prepare_split_CH(split)
% ======================================

    if ~isfield(split,'dt') ...
            || isempty(split.dt)
        split.dt = 1;
    end
    if ~isfield(split,'spinup') ...
            || isempty(split.spinup)
        split.spinup = 0;
    end
    
    if ~isfield(split,'idx') ...
            || isempty(split.idx)
        % This is only a fallback. In the GUI/pipeline split.idx should be
        % scored period after spin-up.
        try
            req0 = build_requested_window_CH(split,false);
            req1 = build_requested_window_CH(split,true);
            n = double(req0.read_end_N - req0.read_start_N) + 1;
            spin = double(req0.read_start_N - req1.read_start_N);
            split.idx = (spin + 1):(spin + n);
        catch
            split.idx = [];
        end
    end

end

% ===========================================================
function req = build_requested_window_CH(split,includeSpinup)
% ===========================================================

    if nargin < 2
        includeSpinup = true;
    end
    spinup = max(0,round(double(split.spinup)));
    
    if isfield(split,'ds') ...
            && isfield(split,'de') ...
            && ~isempty(split.ds) ...
            && ~isempty(split.de)
        d0 = as_datetime_CH(split.ds);
        d1 = as_datetime_CH(split.de);
    
    elseif isfield(split,'dts') ...
            && isfield(split,'dte') ...
            && ~isempty(split.dts) ...
            && ~isempty(split.dte)
        d0 = as_datetime_CH(split.dts);
        d1 = as_datetime_CH(split.dte);
        if isfield(split,'des') ...
                && isfield(split,'dee') ...
                && ~isempty(split.des) ...
                && ~isempty(split.dee)
            d0 = min(d0,as_datetime_CH(split.des));
            d1 = max(d1,as_datetime_CH(split.dee));
        end
    
    elseif isfield(split,'d1') ...
            && isfield(split,'d2') ...
            && ~isempty(split.d1) ...
            && ~isempty(split.d2)
        d0 = as_datetime_CH(split.d1);
        d1 = as_datetime_CH(split.d2);
    
    else
        error('read_meteo_CH:badSplit', ...
            ['      Error:read_meteo_CH: ' ...
            'Could not determine ' ...
            'requested dates from split. ' ...
            'Expected ds/de, dts/dte, or d1/d2.']);
    end
    
    if includeSpinup
        d0 = d0 - days(spinup);
    end
    
    req.read_start_DT = d0;
    req.read_end_DT = d1;
    req.read_start_N = int64(datenum(d0)); %#ok<DATNM>
    req.read_end_N = int64(datenum(d1));   %#ok<DATNM>

end

% ============================
function d = as_datetime_CH(x)
% ============================

    if isdatetime(x)
        d = x(1);
    
    elseif isnumeric(x)
        x = double(x(:).');
        if numel(x) == 3
            if x(1) > 1800
                d = datetime(x(1),x(2),x(3));
            elseif x(3) > 1800
                d = datetime(x(3),x(2),x(1));
            else
                error('read_meteo_CH:badDate', ...
                    ['Cannot determine ' ...
                    'date-vector order.']);
            end
        elseif isscalar(x) ...
                && x > 1e7 ...
                && x < 1e8
            y = floor(x/10000);
            mo = floor((x - 10000*y)/100);
            da = x - 10000*y - 100*mo;
            d = datetime(y,mo,da);
        elseif isscalar(x)
            d = datetime(x, ...
                'ConvertFrom','datenum');
        else
            error('read_meteo_CH:badDate', ...
                'Unsupported numeric date format.');
        end
    
    elseif ischar(x) ...
            || isstring(x)
        s = strtrim(string(x));
        try
            d = datetime(s, ...
                'InputFormat','d/M/yyyy');
        catch
            try
                d = datetime(s, ...
                    'InputFormat','dd/MM/yyyy');
            catch
                try
                    d = datetime(s, ...
                        'InputFormat','yyyy-MM-dd');
                catch
                    d = datetime(s);
                end
            end
        end
        d = d(1);
    
    else
        error('read_meteo_CH:badDate', ...
            'Unsupported date input type.');
    end

end

% ==============================
function id = normalize_ch_id(x)
% ==============================

    if isnumeric(x) || islogical(x)
        id = string(compose('%.0f',double(x(:))));
    else
        id = string(x(:));
        id = strtrim(id);
        id = erase(id,'"');
        id(ismissing(id)) = "";
        id = regexprep(id,'\.0+$','');
    end
    
    % CAMELS-CH file IDs are four digits in the supplied files.
    for i = 1:numel(id)
        s = char(id(i));
        if ~isempty(regexp(s,'^\d+$','once'))
            id(i) = string( ...
                sprintf('%04d',str2double(s)));
        end
    end

end

% =========================================
function aux = read_aux_CH(rootCH,id_gauge)
% =========================================

    K = numel(id_gauge);
    aux = nan(K,3);
    
    candidates = { ...
        fullfile(rootCH, ...
        'gauge_information.txt'), ...
        fullfile(rootCH, ...
        'CAMELS_CH_topographic_attributes.csv'), ...
        fullfile(rootCH, ...
        'timeseries', ...
        'gauge_information.txt')};
    
    fname = '';
    for i = 1:numel(candidates)
        if isfile(candidates{i})
            fname = candidates{i};
            break
        end
    end
    if isempty(fname)
        return
    end
    
    try
        opts = detectImportOptions(fname, ...
            'FileType','text', ...
            'VariableNamingRule','preserve');
        T = readtable(fname,opts);
        vn = T.Properties.VariableNames;
        idVar = find_var_CH(vn, ...
            {'gauge_id','gaugeid','id'});
        latVar = find_var_CH(vn, ...
            {'gauge_lat','lat','latitude'});
        elevVar = find_var_CH(vn, ...
            {'elev_mean','gauge_elevation', ...
            'gauge_elev','elevation','elev'});
        areaVar = find_var_CH(vn, ...
            {'area','area_km2','catchment_area'});
        if isempty(idVar)
            return
        end
    
        ids = normalize_ch_id(T.(idVar));
        req = normalize_ch_id(id_gauge);
        [tf,loc] = ismember(req,ids);
    
        for k = 1:K
            if ~tf(k)
                continue
            end
            j = loc(k);
            if ~isempty(latVar)
                aux(k,1) = get_table_double_CH(T,latVar,j);
            end
            if ~isempty(elevVar)
                aux(k,2) = get_table_double_CH(T,elevVar,j);
            end
            if ~isempty(areaVar)
                a = get_table_double_CH(T,areaVar,j);
                if isfinite(a) && a < 1e7
                    a = a * 1e6;
                end
                aux(k,3) = a;
            end
        end
    catch
        aux = nan(K,3);
    end

end

% ===========================================
function x = get_table_double_CH(T,varName,j)
% ===========================================

    v = T.(varName);
    if isnumeric(v) || islogical(v)
        x = double(v(j));
    else
        x = str2double(string(v(j)));
    end

end

% =====================================
function v = find_var_CH(vn,candidates)
% =====================================

    v = '';
    vnn = clean_name_CH(vn);
    for i = 1:numel(candidates)
        c = clean_name_CH(candidates(i));
        j = find(strcmp(vnn,c),1,'first');
        if ~isempty(j)
            v = vn{j};
            return
        end
    end

end

% ===========================
function s = clean_name_CH(s)
% ===========================

    s = string(s);
    s = lower(regexprep(s,'[^a-zA-Z0-9]',''));

end

% =====================================
function rootCH = resolve_ch_root(dirM)
% =====================================

    rootCH = char(string(dirM));

end

% ================================
function s = get_last_folder_CH(p)
% ================================

    [~,s] = fileparts(char(p));

end
