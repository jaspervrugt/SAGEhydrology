function [A,id_gauge,gname,zone] = read_attr_CH(dirD,bas)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%READ_ATTR_CH Read catchment attributes of CAMELS-CH dataset.
%
% SYNOPSIS:
%   [A,id_gauge,gname,zone] = read_attr_CH(dirD,bas)
%
% INPUT:
%   dirD        Directory with CAMELS-CH CSV attribute files
%   bas         OPTIONAL structure
%    .id_gauge   requested CAMELS-CH gauge identifiers
%    .id_attr    rx1 vector of integer attribute IDs
%    .pr_attr    print attribute table [1/0]
%
% OUTPUT:
%   A           r x K matrix of standardized selected attributes
%   id_gauge    K x 1 string array with CAMELS-CH gauge identifiers
%   gname       K x 1 string array with gauge names
%   zone        structure with basin classification and metadata
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    if nargin < 1 ...
            || isempty(dirD)
        error('read_attr_CH:missingDir', ...
            ['      Error:read_attr_CH: ' ...
            'dirD must be provided.']);
    end
    
    if ~isfolder(dirD)
        error('read_attr_CH:missingDir', ...
            ['      Error:read_attr_CH: Attribute ' ...
            'directory does not exist: %s'],dirD);
    end
    
    if nargin < 2 ...
            || isempty(bas)
        bas = struct();
    end
    
    if ~isstruct(bas)
        error('read_attr_CH:badBas', ...
            ['      Error:read_attr_CH: ' ...
            'bas must be a structure.']);
    end
    % =========================================
    % ZONE CONTROL PARAMETERS (GLOBAL DEFAULTS)
    % =========================================
    if ~isfield(bas,'min_per_zone') ...
            || isempty(bas.min_per_zone)
        min_per_zone = 5;
    else
        min_per_zone = bas.min_per_zone;
    end    
    if ~isfield(bas,'max_zones') ...
            || isempty(bas.max_zones)
        max_zones = 8;
    else
        max_zones = bas.max_zones;
    end

    pr_table = 1;
    if isfield(bas,'pr_attr') ...
            && ~isempty(bas.pr_attr)
        pr_table = bas.pr_attr;
    end
    
    fprintf('... Reading CAMELS-CH basin attributes ');
    
    AA = read_camels_ch_attribute_tables(dirD);
    
    needVars = {'gauge_id','gauge_name', ...
        'gauge_lat','gauge_lon'};
    for j = 1:numel(needVars)
        if ~ismember(needVars{j}, ...
                AA.Properties.VariableNames)
            error('read_attr_CH:missingMetadata', ...
                ['      Error:read_attr_CH: ' ...
                'missing required variable: %s'], ...
                needVars{j});
        end
    end
    
    id_all = normalize_ch_gauge_id(AA.gauge_id);
    AA.gauge_id = id_all;
    
    [~,isrt] = sort(id_all);
    AA = AA(isrt,:);
    id_all = id_all(isrt);
    
    if isfield(bas,'id_gauge') ...
            && ~isempty(bas.id_gauge)
        id_req = normalize_ch_gauge_id(bas.id_gauge(:));
        [tf,locid] = ismember(id_req,id_all);
        if ~all(tf)
            missing = id_req(~tf);
            error('read_attr_CH:missingRequestedGauge', ...
                ['      Error:read_attr_CH: ' ...
                'Missing CAMELS-CH attributes ', ...
                 'for %d requested gauge IDs, e.g. %s.'], ...
                numel(missing),char(missing(1)));
        end
        AA = AA(locid,:);
        id_gauge = id_req(:);
    else
        id_gauge = id_all(:);
    end
    
    try
        gname = string(AA.gauge_name);
    catch
        gname = strings(height(AA),1);
    end
    gname = standardize_camels_gauge_names(gname, ...
        'CAMELS_CH',id_gauge);

    ensure_ch_gauge_information(dirD,AA);
    region = erase(mfilename,'read_attr_');
    zone = classify_camels_all_zones(region,AA, ...
        min_per_zone,max_zones);
    
    % ------------------
    % Generic attributes
    % ------------------
    [A,labels] = build_attr_matrix(AA,bas, ...
        mfilename,pr_table);

    if pr_table == 1
        assignin('base', ...
            'SAGE_CH_attribute_labels',labels);
    end
    
    fprintf(' ... Done\n');

end

% =================================================
function AA = read_camels_ch_attribute_tables(dirD)
% =================================================

    files = { ...
        'CAMELS_CH_topographic_attributes.csv','ISO-8859-1'; ...
        'CAMELS_CH_climate_attributes_obs.csv','UTF-8'; ...
        'CAMELS_CH_hydrology_attributes_obs.csv','UTF-8'; ...
        'CAMELS_CH_hydrogeology_attributes.csv','UTF-8'; ...
        'CAMELS_CH_soil_attributes.csv','UTF-8'; ...
        'CAMELS_CH_landcover_attributes.csv','UTF-8'; ...
        'CAMELS_CH_geology_attributes.csv','UTF-8'; ...
        'CAMELS_CH_glacier_attributes.csv','UTF-8'; ...
        'CAMELS_CH_humaninfluence_attributes.csv','UTF-8'};
    
    AA = table();
    caller = mfilename;
    for i = 1:size(files,1)
        fname = fullfile(dirD,files{i,1});
        must_exist(fname,files{i,1},caller);
        T = read_ch_csv(fname,files{i,2});
    
        if ~ismember('gauge_id',T.Properties.VariableNames)
            error('read_attr_CH:missingGaugeID', ...
                ['      Error:read_attr_CH: %s has ' ...
                'no gauge_id column.'],files{i,1});
        end
    
        T.gauge_id = normalize_ch_gauge_id(T.gauge_id);
    
        if isempty(AA)
            AA = T;
        else
            AA = outerjoin(AA,T, ...
                'Keys','gauge_id', ...
                'MergeKeys',true, ...
                'Type','full');
        end
    end

end

% =================================
function T = read_ch_csv(fname,enc)
% =================================

    try
        opts = detectImportOptions(fname, ...
            'FileType','text', ...
            'Delimiter',',', ...
            'Encoding',enc);
    catch
        opts = detectImportOptions(fname, ...
            'FileType','text', ...
            'Delimiter',',');
    end
    
    try
        opts.CommentStyle = '#';
    catch
    end
    
    try
        T = readtable(fname,opts, ...
            'Encoding',enc);
    catch
        T = readtable(fname,opts);
    end
    
    T.Properties.VariableNames = ...
        matlab.lang.makeValidName( ...
        T.Properties.VariableNames, ...
        'ReplacementStyle','delete');

end

% ===========================================
function ensure_ch_gauge_information(dirD,AA)
% ===========================================

    fout = fullfile(dirD, ...
        'gauge_information.txt');
    
    id = normalize_ch_gauge_id(AA.gauge_id);
    name = string(AA.gauge_name);
    lat = get_numeric_column(AA,"gauge_lat");
    lon = get_numeric_column(AA,"gauge_lon");
    
    fid = fopen(fout,'w');
    if fid < 0
        warning('read_attr_CH:gaugeInformationWriteFailed', ...
            ['      Warning:read_attr_CH: ' ...
            'Could not write ' ...
            'gauge_information.txt to %s'],dirD);
        return
    end
    cleanup = onCleanup(@() fclose(fid));
    
    fprintf(fid,['gauge_id;gauge_name;' ...
        'gauge_lat;gauge_lon\n']);
    for k = 1:numel(id)
        fprintf(fid,'%s;%s;%.8f;%.8f\n', ...
            char(id(k)),char(name(k)),lat(k),lon(k));
    end

end

% ====================================
function id = normalize_ch_gauge_id(x)
% ====================================

    if isnumeric(x) ...
            || islogical(x)
        id = string(compose('%.0f',double(x(:))));
    else
        id = string(x(:));
        id = strip(id);
        id = erase(id,'"');
        id(ismissing(id)) = "";
        id = regexprep(id,'\.0+$','');
    end

end
