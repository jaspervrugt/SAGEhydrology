function R = region_config_ZA()
%REGION_CONFIG_ZA Regional defaults for daily South Africa GRDC-Caravan.

    R = struct();
    R.code = 'CAMELS_ZA';
    R.acronym = 'ZA';
    R.name = 'South Africa';
    R.dataset = 'GRDC-Caravan';
    R.data_root = 'CAMELS_ZA';
    R.resolutions = {'Daily'};
    R.default_resolution = 'Daily';
    R.basin_file_pattern = 'ZA_%d_basins.txt';

    X = struct();
    X.label = 'Daily';
    X.dt = 1;
    % Of 434 installed stations, 352 have at least 5% observed discharge
    % in both default twenty-water-year periods.
    X.basins.universe = 352;
    X.basins.training = 293;
    X.basins.evaluation = 59;
    X.period.spinup_days = 365;
    X.period.manual.train_start = '01/10/1990';
    X.period.manual.train_end = '30/09/2010';
    X.period.manual.eval_start = '01/10/1970';
    X.period.manual.eval_end = '30/09/1990';
    X.period.common_start = '01/10/1970';
    X.period.common_end = '30/09/2010';
    X.paths.run_root = '';
    X.paths.meteo = fullfile('daily','timeseries');
    X.paths.discharge = fullfile('daily','timeseries');

    X.meteo.product.items = {'GRDC-Caravan ERA5-Land [daily]'};
    X.meteo.product.default = 'GRDC-Caravan ERA5-Land [daily]';
    X.meteo.product.enabled = false;
    X.meteo.precipitation.items = {'1 ERA5-Land precipitation'};
    X.meteo.precipitation.default = '1 ERA5-Land precipitation';
    X.meteo.precipitation.enabled = false;
    X.meteo.temperature.items = {'1 ERA5-Land temperature'};
    X.meteo.temperature.default = '1 ERA5-Land temperature';
    X.meteo.temperature.enabled = false;
    X.meteo.pet.items = {'1 FAO Penman-Monteith potential evaporation'};
    X.meteo.pet.default = '1 FAO Penman-Monteith potential evaporation';
    X.meteo.pet.enabled = false;

    C = repmat(struct('name','','type','','path','','pattern','', ...
        'minimum_count',1,'required',true),0,1);
    C(1).name = 'Daily forcing and streamflow';
    C(1).type = 'folder'; C(1).path = fullfile('daily','timeseries');
    C(1).pattern = '*.csv'; C(1).minimum_count = 434;
    C(2).name = 'Caravan attributes'; C(2).type = 'file';
    C(2).path = 'attributes_caravan_grdc.csv';
    C(3).name = 'HydroATLAS attributes'; C(3).type = 'file';
    C(3).path = 'attributes_hydroatlas_grdc.csv';
    C(4).name = 'Gauge metadata'; C(4).type = 'file';
    C(4).path = 'attributes_other_grdc.csv';
    C(5).name = 'Additional attributes'; C(5).type = 'file';
    C(5).path = 'attributes_additional_grdc.csv';
    X.checks = C;
    R.by_resolution.Daily = X;
end
