function dat = read_Q_ZA(~,~,dat,~,~,~)
%READ_Q_ZA No-op: GRDC-Caravan streamflow is read with meteorology.
end
