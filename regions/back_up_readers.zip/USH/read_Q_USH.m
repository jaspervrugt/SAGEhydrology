function dat = read_Q_USH(dirQ,mdl,dat,bas,split,aux) %#ok<INUSD>
%READ_Q_USH Read hourly CAMELSH-US discharge from NetCDF files.
%
% Streamflow is supplied in m3/s and converted to mm/hour using basin area.

    split = prepare_split(split);
    ids = local_ids(bas.id_gauge);
    K = numel(ids);

    dirT = local_timeseries_dir(dirQ);
    [~,start,count] = local_window(split,true);

    if isfield(split,'idx') ...
            && ~isempty(split.idx)
        % split.idx is expressed in state coordinates and includes the
        % terminal state. Q contains one value per forcing interval.
        idx = round(double(split.idx(:)));
        expectedCount = numel(idx) - 1;
        idx = idx(idx >= 1 ...
            & idx <= count);
    else
        ns = round(365*24);
        if isfield(split,'n_spin') ...
                && ~isempty(split.n_spin)
            ns = round(double(split.n_spin));
        end
        idx = (ns + 1:count)';
        expectedCount = numel(idx);
    end

    if numel(idx) ~= expectedCount
        error('read_Q_USH:indexWindow', ...
            ['Discharge scoring window ' ...
            'contains %d valid data indices; ' ...
            'expected %d from split.idx.'], ...
            numel(idx),expectedCount);
    end

    prt = reader_progress('start', ...
        '... Reading hourly CAMELSH-US discharge data',K);

    for k = 1:K
        f = fullfile(dirT,char(ids(k) + ".nc"));
        if ~isfile(f)
            fprintf('\n');
            error('read_Q_USH:missingFile', ...
                'Missing %s.',f);
        end

        q = local_slice(f,'Streamflow',start,count);
        q(q < 0) = NaN;

        area = double(aux(k,3));
        if ~isfinite(area) ...
                || area <= 0
            fprintf('\n');
            error('read_Q_USH:area', ...
                'Invalid area for basin %s.',ids(k));
        end

        qmm = q*3600*1000/area;
        qScore = qmm(idx);

        dat{k}.y_n = single(qScore);
        dat{k}.bad = (~isfinite(qScore))';
        dat{k}.Q_mm_USH = single(qmm);
        dat{k}.fname{2} = f;
        dat{k}.gauge = ids(k);

        prt = reader_progress('update',prt,k);
        % Graphical User Interface
        if isfield(bas,'progressFcn') ...
                && ~isempty(bas.progressFcn)
            try
                bas.progressFcn(k,K);
            catch
                try
                    bas.progressFcn(k);
                catch
                end
            end
        end
    end

    reader_progress('finish',prt,K);
end

function dirT = local_timeseries_dir(d)
    d = char(string(d));
    candidates = {d, ...
        fullfile(d,'timeseries'), ...
        fullfile(d,'hourly','timeseries')};

    for i = 1:numel(candidates)
        if isfolder(candidates{i}) ...
                && ~isempty(dir(fullfile(candidates{i},'*.nc')))
            dirT = candidates{i};
            return;
        end
    end

    error('read_Q_USH:missingDir', ...
        'Cannot locate CAMELSH-US NetCDF files.');
end

function [t,start,count] = local_window(split,spin)
    req = build_requested_window(split,spin);
    referenceDate = datetime(1950,10,1);
    t0 = referenceDate + hours(double(req.read_start_N));
    t1 = referenceDate + hours(double(req.read_end_N));

    fileEpoch = datetime(1980,1,1);
    start = round(hours(t0 - fileEpoch)) + 1;
    count = round(hours(t1 - t0)) + 1;
    t = (t0:hours(1):t1)';

    if start < 1 ...
            || start + count - 1 > 394488
        error('read_Q_USH:window', ...
            'Requested dates lie outside 1980-2024.');
    end
end

function x = local_slice(f,v,start,count)
    x = double(ncread(f,v,start,count));
    x = x(:);
    x(x <= -9990) = NaN;
end

function ids = local_ids(x)
    ids = strip(string(x(:)));
    ids = regexprep(ids,'\.0+$','');
    ids = arrayfun(@(s) pad(s,8,'left','0'),ids);
end
