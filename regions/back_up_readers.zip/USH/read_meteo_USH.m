function [dat,aux] = read_meteo_USH(dirM,bas,split,meteo)
%READ_METEO_USH Read hourly CAMELSH-US NLDAS-2 forcing from NetCDF.

    if nargin < 4 ...
            || isempty(meteo)
        meteo = struct();
    end

    split = prepare_split(split);
    if double(split.dt) ~= 24
        error('read_meteo_USH:badDt', ...
            'CAMELSH-US is hourly (dt = 24).');
    end

    ids = local_ids(bas.id_gauge);
    K = numel(ids);
    dirT = local_timeseries_dir(dirM);
    root = fileparts(fileparts(dirT));
    [aux,names] = local_metadata(root,ids,bas);
    [~,start,count] = local_window(split,true);
    dat = cell(K,1);

    prt = reader_progress('start', ...
        '... Reading hourly CAMELSH-US meteorological data',K);

    for k = 1:K
        f = fullfile(dirT,char(ids(k) + ".nc"));
        if ~isfile(f)
            fprintf('\n');
            error('read_meteo_USH:missingFile', ...
                'Missing %s.',f);
        end

        P = local_slice(f,'Rainf',start,count);
        Ep = local_slice(f,'PotEvap',start,count);
        T = local_slice(f,'Tair',start,count);

        P(P < 0) = NaN;
        Ep(isfinite(Ep) ...
            & Ep < 0) = 0;
        bad = find(~isfinite(P) ...
            | ~isfinite(Ep) ...
            | ~isfinite(T));

        dat{k}.meteo.P = single(P);
        dat{k}.meteo.Ep = single(Ep);
        dat{k}.meteo.T = single(T);
        dat{k}.meteo.Tmin = single(T);
        dat{k}.meteo.Tmax = single(T);
        dat{k}.meteo.bad = int64(bad(:)');
        dat{k}.meteo_source = 'CAMELSH-US NLDAS-2';
        dat{k}.gauge = ids(k);
        dat{k}.gname = names(k);
        dat{k}.fname{1} = f;

        prt = reader_progress('update',prt,k);
    
        if isfield(meteo,'progressFcn') ...
                && ~isempty(meteo.progressFcn)
            try
                meteo.progressFcn(k);
            catch MEprogress
                warning('read_meteo_USH:progressFcn', ...
                    'GUI progress callback failed: %s', ...
                    MEprogress.message);
            end
        end
    end

    reader_progress('finish',prt,K);

    if isfield(split,'local') ...
            && split.local ...
            && isfield(split,'rainfall_block') ...
            && split.rainfall_block
        dat = rainfall_rank_split(dat,split);
    end
end

function dirT = local_timeseries_dir(d)
    d = char(string(d));
    candidates = {d, ...
        fullfile(d,'timeseries'), ...
        fullfile(d,'hourly','timeseries')};

    for i = 1:numel(candidates)
        if isfolder(candidates{i}) ...
                && ~isempty(dir(fullfile(candidates{i},'*.nc')))
            dirT = candidates{i};
            return;
        end
    end

    error('read_meteo_USH:missingDir', ...
        'Cannot locate CAMELSH-US NetCDF files.');
end

function [aux,names] = local_metadata(root,ids,bas)
    f = fullfile(root,'attributes', ...
        'attributes_gageii_BasinID.csv');
    T = local_read_attribute_table(f);
    metadataIds = local_ids(T.STAID);
    [tf,loc] = ismember(ids,metadataIds);

    if ~all(tf)
        error('read_meteo_USH:metadata', ...
            'Missing basin metadata.');
    end

    aux = [double(T.LAT_GAGE(loc)), ...
        nan(numel(ids),1), ...
        double(T.DRAIN_SQKM(loc))*1e6];

    fTopo = fullfile(root,'attributes', ...
        'attributes_gageii_Topo.csv');
    if isfile(fTopo)
        U = local_read_attribute_table(fTopo);
        topoIds = local_ids(U.STAID);
        [tfTopo,locTopo] = ismember(ids,topoIds);
        aux(tfTopo,2) = double( ...
            U.ELEV_MEAN_M_BASIN(locTopo(tfTopo)));
    end

    names = string(T.STANAME(loc));
    names = standardize_camels_gauge_names(names, ...
        'CAMELSH_US',ids);

    if isfield(bas,'area') ...
            && numel(bas.area) >= numel(ids)
        missingArea = ~isfinite(aux(:,3));
        area = double(bas.area(missingArea));
        area(area < 1e7) = area(area < 1e7)*1e6;
        aux(missingArea,3) = area;
    end
end

function T = local_read_attribute_table(f)
% Preserve zero-prefixed and long CAMELSH station identifiers exactly.
    opts = detectImportOptions(f, ...
        'VariableNamingRule','preserve');
    if any(strcmp(opts.VariableNames,'STAID'))
        opts = setvartype(opts,'STAID','string');
    end
    T = readtable(f,opts);
end

function [t,start,count] = local_window(split,spin)
    req = build_requested_window(split,spin);
    referenceDate = datetime(1950,10,1);
    t0 = referenceDate + hours(double(req.read_start_N));
    t1 = referenceDate + hours(double(req.read_end_N));

    fileEpoch = datetime(1980,1,1);
    start = round(hours(t0 - fileEpoch)) + 1;
    count = round(hours(t1 - t0)) + 1;
    t = (t0:hours(1):t1)';

    if start < 1 ...
            || start + count - 1 > 394488
        error('read_meteo_USH:window', ...
            'Requested dates lie outside 1980-2024.');
    end
end

function x = local_slice(f,v,start,count)
    x = double(ncread(f,v,start,count));
    x = x(:);
    x(x <= -9990) = NaN;
end

function ids = local_ids(x)
    ids = strip(string(x(:)));
    ids = regexprep(ids,'\.0+$','');
    ids = arrayfun(@(s) pad(s,8,'left','0'),ids);
end
