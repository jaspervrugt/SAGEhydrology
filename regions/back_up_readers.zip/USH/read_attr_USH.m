function [A,id_gauge,gname,zone] = read_attr_USH(dirD,bas)
%READ_ATTR_USH Read curated CAMELSH-US GAGES-II/NLDAS-2 attributes.
% Native GAGES-II attributes are preferred. A small set of nonduplicate
% HydroATLAS hydrologic signatures is exposed as optional predictors.

    if nargin<2||isempty(bas), bas=struct(); end
    root=local_root(dirD); ad=fullfile(root,'attributes');
    files={ ...
        'attributes_gageii_BasinID.csv', ...
        'attributes_nldas2_climate.csv', ...
        'attributes_gageii_Climate.csv', ...
        'attributes_gageii_Bas_Morph.csv', ...
        'attributes_gageii_Topo.csv', ...
        'attributes_gageii_Soils.csv', ...
        'attributes_gageii_Geology.csv', ...
        'attributes_gageii_Hydro.csv', ...
        'attributes_gageii_Landscape_Pat.csv', ...
        'attributes_gageii_LC06_Basin.csv', ...
        'attributes_gageii_HydroMod_Dams.csv', ...
        'attributes_gageii_HydroMod_Other.csv', ...
        'attributes_gageii_Nutrient_App.csv', ...
        'attributes_gageii_Pest_App.csv', ...
        'attributes_gageii_Pop_Infrastr.csv', ...
        'attributes_gageii_Prot_Areas.csv', ...
        'attributes_hydroATLAS.csv'};
    T=cell(size(files));
    for j=1:numel(files)
        f=fullfile(ad,files{j}); if ~isfile(f), error('read_attr_USH:missingFile','Missing %s.',f); end
        % STAID must remain text. Besides zero-prefixed USGS IDs, CAMELSH
        % contains long synthetic identifiers that numeric import can
        % render in scientific notation or round before matching.
        opts=detectImportOptions(f,'VariableNamingRule','preserve');
        if any(strcmp(opts.VariableNames,'STAID'))
            opts=setvartype(opts,'STAID','string');
        end
        T{j}=readtable(f,opts);
        T{j}.STAID=local_ids(T{j}.STAID);
    end
    AA=T{1};
    for j=2:numel(T)
        dup=intersect(AA.Properties.VariableNames,T{j}.Properties.VariableNames); dup(strcmp(dup,'STAID'))=[]; T{j}(:,dup)=[];
        AA=outerjoin(AA,T{j},'Keys','STAID','MergeKeys',true,'Type','left');
    end
    AA.gauge_lat=double(AA.LAT_GAGE); AA.gauge_lon=double(AA.LNG_GAGE);
    AA.area=double(AA.DRAIN_SQKM); AA.elev_mean=double(AA.ELEV_MEAN_M_BASIN);
    AA.p_seasonality=double(AA.p_seasonality); AA.frac_snow=double(AA.frac_snow);
    AA.aridity=double(AA.aridity_index); AA.pet_mean=double(AA.pet_mean);
    [id_all,ix]=sort(local_ids(AA.STAID)); AA=AA(ix,:);
    names_all=standardize_camels_gauge_names(string(AA.STANAME),'CAMELSH_US',id_all);
    if isfield(bas,'id_gauge')&&~isempty(bas.id_gauge)
        req=local_ids(bas.id_gauge); [tf,loc]=ismember(req,id_all);
        if ~all(tf), error('read_attr_USH:missingGauge','Missing CAMELSH-US gauge %s.',req(find(~tf,1))); end
        AA=AA(loc,:); id_gauge=req; gname=names_all(loc);
    else, id_gauge=id_all; gname=names_all; end
    minz=local_field(bas,'min_per_zone',5); maxz=local_field(bas,'max_zones',8);
    zone=classify_camels_all_zones('USH',AA,minz,maxz);
    [A,labels]=build_attr_matrix(AA,bas,mfilename,local_field(bas,'pr_attr',1));
    assignin('base','SAGE_USH_attribute_labels',labels);
    local_gauge_info(root,AA,id_gauge,gname);
    fprintf('... Reading CAMELSH-US attributes ... Done\n');
end
function root=local_root(d)
    root=char(string(d));
    for i=1:5, if isfolder(fullfile(root,'attributes')), return; end; p=fileparts(root); if strcmp(p,root), break; end; root=p; end
    error('read_attr_USH:missingDir','Cannot locate the CAMELSH-US attributes folder.');
end
function ids=local_ids(x), ids=strip(string(x(:))); ids=regexprep(ids,'\.0+$',''); ids=arrayfun(@(s)pad(s,8,'left','0'),ids); end
function v=local_field(S,f,d), v=d; if isfield(S,f)&&~isempty(S.(f)), v=S.(f); end, end
function local_gauge_info(root,T,id,nm)
    f=fullfile(root,'gauge_information.txt'); fid=fopen(f,'w'); if fid<0, return; end; c=onCleanup(@()fclose(fid));
    fprintf(fid,'HUC_02\tGAGE_ID\tGAGE_NAME\tLAT\tLONG\tDRAINAGE AREA (KM^2)\n');
    for k=1:numel(id), fprintf(fid,'US\t%s\t%s\t%.7f\t%.7f\t%.6f\n',char(id(k)),char(nm(k)),double(T.gauge_lat(k)),double(T.gauge_lon(k)),double(T.area(k))); end
end
