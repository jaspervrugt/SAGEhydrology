function R = region_config_USH()
%REGION_CONFIG_USH Regional defaults for hourly CAMELSH-US.

    R = struct();
    R.code = 'CAMELSH_US';
    R.acronym = 'USH';
    R.name = 'United States (CAMELSH)';
    R.dataset = 'CAMELSH-US';
    R.data_root = 'CAMELSH_US';
    R.resolutions = {'Hourly'};
    R.default_resolution = 'Hourly';
    R.basin_file_pattern = 'USH_%d_basins.txt';

    X = struct();
    X.label = 'Hourly';
    X.dt = 24;
    % Basins have >=5% observed hourly discharge in both default periods.
    X.basins.universe = 2554;
    X.basins.training = 2000;
    X.basins.evaluation = 554;
    X.period.spinup_days = 365;
    X.period.manual.train_start = '01/01/2010';
    X.period.manual.train_end = '31/12/2019';
    X.period.manual.eval_start = '01/01/2000';
    X.period.manual.eval_end = '31/12/2009';
    X.period.common_start = '01/01/1999';
    X.period.common_end = '31/12/2019';
    X.paths.run_root = '';
    X.paths.meteo = fullfile('hourly','timeseries');
    X.paths.discharge = fullfile('hourly','timeseries');

    X.meteo.product.items = {'CAMELSH-US NLDAS-2 [hourly]'};
    X.meteo.product.default = 'CAMELSH-US NLDAS-2 [hourly]';
    X.meteo.product.enabled = false;
    X.meteo.precipitation.items = {'NLDAS-2 precipitation'};
    X.meteo.precipitation.default = 'NLDAS-2 precipitation';
    X.meteo.precipitation.enabled = false;
    X.meteo.temperature.items = {'NLDAS-2 air temperature'};
    X.meteo.temperature.default = 'NLDAS-2 air temperature';
    X.meteo.temperature.enabled = false;
    X.meteo.pet.items = {'NLDAS-2 potential evaporation'};
    X.meteo.pet.default = 'NLDAS-2 potential evaporation';
    X.meteo.pet.enabled = false;

    C = repmat(struct('name','','type','','path','','pattern','', ...
        'minimum_count',1,'required',true),0,1);
    C(1).name = 'Observed hourly forcing and streamflow';
    C(1).type = 'folder';
    C(1).path = fullfile('hourly','timeseries');
    C(1).pattern = '*.nc';
    C(1).minimum_count = 3166;
    C(2).name = 'NLDAS-2 climate attributes';
    C(2).type = 'file';
    C(2).path = fullfile('attributes','attributes_nldas2_climate.csv');
    C(3).name = 'GAGES-II basin identifiers';
    C(3).type = 'file';
    C(3).path = fullfile('attributes','attributes_gageii_BasinID.csv');
    C(4).name = 'GAGES-II topography attributes';
    C(4).type = 'file';
    C(4).path = fullfile('attributes','attributes_gageii_Topo.csv');
    C(5).name = 'CAMELSH streamflow availability';
    C(5).type = 'file';
    C(5).path = 'info.csv';
    X.checks = C;
    R.by_resolution.Hourly = X;
end
