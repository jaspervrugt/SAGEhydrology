function [A,id_gauge,gname,zone]=read_attr_IE(dirD,bas)
%READ_ATTR_IE Read filtered Ireland GRDC-Caravan attributes.
    [A,id_gauge,gname,zone]=read_attr_NA(dirD,bas,'CAMELS_IE','IE');
end
