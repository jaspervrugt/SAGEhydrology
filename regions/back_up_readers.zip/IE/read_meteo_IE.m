function [dat,aux]=read_meteo_IE(dirM,bas,split,meteo)
%READ_METEO_IE Read daily Ireland GRDC-Caravan forcing and discharge.
    [dat,aux]=read_meteo_NA(dirM,bas,split,meteo,'Ireland');
end
