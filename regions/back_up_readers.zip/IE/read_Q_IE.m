function dat=read_Q_IE(~,~,dat,~,~,~)
%READ_Q_IE No-op: GRDC-Caravan streamflow is read with meteorology.
end
