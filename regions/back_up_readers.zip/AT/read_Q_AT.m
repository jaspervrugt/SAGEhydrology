function dat = read_Q_AT(dirQ,mdl,dat,bas,split,aux)    %#ok
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%READ_Q_AT Read CAMELS-AT / LamaH-CE observed discharge.
%
% Supported installed structures:
%   Data/CAMELS_AT/daily/timeseries/streamflow/ID_<id>.csv
%   Data/CAMELS_AT/hourly/timeseries/streamflow/ID_<id>.csv
%
% Volumetric discharge [m3/s] is converted to basin-average runoff depth
% [mm/time step] using the catchment area. For daily data this gives
% mm/day; for hourly data this gives mm/hour.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    if nargin < 6
        aux = [];
    end
    if nargin < 5
        error(['      Error:read_Q_AT: ' ...
            'Expected input signature ' ...
            'dat = read_Q_AT(dirQ,dat,' ...
            'bas,split,aux).']);
    end
    if nargin < 1 ...
            || isempty(dirQ)
        error(['      Error:read_Q_AT: ' ...
            'dirQ must be provided.']);
    end

    split = local_prepare_split(split);

    dt = double(split.dt);
    if ~any(dt == [1 24])
        error(['      Error:read_Q_AT: ' ...
            'CAMELS-AT / LamaH-CE ' ...
            'supports dt = 1 (daily) ' ...
            'or dt = 24 (hourly).']);
    end
    stream = local_stream_from_dt(dt);
    stepSeconds = 86400/dt;

    K = bas.K;
    id_GAUGE = local_at_id_strings(bas.id_gauge(:));
    dirStream = local_at_streamflow_dir(dirQ,stream);

    req = local_requested_window(split,dt,false);
    tReq = local_snap_time(datetime(req.time(:)),dt);
    nReq = numel(tReq);

    cache_dir = fullfile(dirStream, ...
        sprintf('_cache_AT_%s_Q',stream));
    if ~isfolder(cache_dir)
        mkdir(cache_dir);
    end

    fprintf(['... Reading %s CAMELS-AT ' ...
        'discharge files %3d%%'],stream,0);
    flag_progress = true;

    for k = 1:K
        gid = id_GAUGE(k);
        fname = fullfile(dirStream,sprintf('ID_%s.csv',gid));
        if ~isfile(fname)
            fprintf('\n');
            error(['      Error:read_Q_AT: ' ...
                'Missing %s streamflow ' ...
                'file for basin %s: %s'],stream,gid,fname);
        end

        t0 = tReq(1);
        t1 = tReq(end);

        t0.Format = 'yyyyMMddHHmm';
        t1.Format = 'yyyyMMddHHmm';

        win_key = sprintf('%s_%s', char(t0), char(t1));
        cache_file = fullfile(cache_dir, ...
            sprintf('%s_AT_%s_Q_%s.mat',gid,stream,win_key));

        use_cache = false;
        if isfile(cache_file)
            try
                S = load(cache_file, ...
                    'Qmm_all','bad_q_all','src_datenum');
                info = dir(fname);
                if isfield(S,'src_datenum') ...
                        && S.src_datenum >= info.datenum
                    Qmm_all = S.Qmm_all;
                    bad_q_all = S.bad_q_all;
                    use_cache = true;
                end
            catch
                use_cache = false;
            end
        end

        if ~use_cache
            [tFile,Qraw,qUnits] = local_read_at_q_file(fname,dt);
            Qall = nan(nReq,1);
            [tf,loc] = ismember(tReq,tFile);
            Qall(tf) = Qraw(loc(tf));

            switch lower(qUnits)
                case {'mmstep','mmday','mmd', ...
                        'mm_d','runoffdepth'}
                    Qmm_all = Qall;
                case {'cms','m3s','m3_s','m3/s'}
                    area = local_area_m2(k,bas, ...
                        aux,dirStream,gid);
                    if ~isfinite(area) ...
                            || area <= 0
                        fprintf('\n');
                        error(['      Error:read_Q_AT: ' ...
                            'Missing/invalid ' ...
                            'basin area for basin %s. ' ...
                            'Cannot convert ' ...
                            'm3/s to mm/time step.'],gid);
                    end
                    Qmm_all = Qall * stepSeconds * 1000 / area;
                otherwise
                    area = local_area_m2(k,bas,aux,dirStream,gid);
                    if isfinite(area) ...
                            && area > 0
                        Qmm_all = Qall * stepSeconds * 1000 / area;
                    else
                        Qmm_all = Qall;
                    end
            end

            bad_q_all = ~isfinite(Qmm_all);

            try
                info = dir(fname);
                src_datenum = info.datenum;
                save(cache_file,'Qmm_all', ...
                    'bad_q_all','src_datenum','-v7.3');
            catch
            end
        end

        dat{k}.y_n = single(Qmm_all);
        dat{k}.bad = bad_q_all(:).';
        
        dat{k}.fname{2} = fname;
        dat{k}.gauge = gid;

        if any(dat{k}.bad)
            if flag_progress
                fprintf('\n');
            end
            fprintf(['      Warning:read_Q_AT: ' ...
                'basin %s has %d ' ...
                'invalid/missing %s discharge ' ...
                'rows in scored period.\n'], ...
                gid,nnz(dat{k}.bad),stream);
            pct = floor(100*k/K);
            fprintf(['... Reading %s CAMELS-AT ' ...
                'discharge files %3d%%'], ...
                stream,pct);
            flag_progress = true;
        end

        if mod(k,20)==0 ...
                || k==K
            pct = floor(100*k/K);
            fprintf('\b\b\b\b%3d%%',pct);
            drawnow;
        end

        if isfield(bas,'progressFcn') ...
                && ~isempty(bas.progressFcn)
            try
                bas.progressFcn(k);
            catch
            end
        end
    end

    if flag_progress
        fprintf('\b\b\b\b%s\n','... Done');
    end
end

% ====================================================
function [t,Q,qUnits] = local_read_at_q_file(fname,dt)
% ====================================================

    delim = local_detect_delimiter(fname);
    opts = detectImportOptions(char(fname), ...
        'FileType','text', ...
        'Delimiter',delim, ...
        'VariableNamingRule','preserve');
    T = readtable(char(fname),opts);
    T.Properties.VariableNames = ...
        matlab.lang.makeUniqueStrings( ...
        matlab.lang.makeValidName(strtrim( ...
        string(T.Properties.VariableNames))));

    vn0 = string(T.Properties.VariableNames);
    vnl = lower(regexprep(vn0,'[^a-zA-Z0-9]',''));

    if all(ismember({'YYYY','MM','DD'}, ...
        T.Properties.VariableNames))
        Y = local_col_to_double(T.YYYY);
        M = local_col_to_double(T.MM);
        D = local_col_to_double(T.DD);

        if double(dt) == 24
            jH = local_find_var_after(vnl, ...
                ["hh","hour","hod"],3,4);
            jMin = local_find_var_after(vnl, ...
                ["minute","min","mm"],jH,[]);
            H = local_col_to_double(T{:,jH});
            if isempty(jMin)
                MN = zeros(height(T),1);
            else
                MN = local_col_to_double(T{:,jMin});
            end
            t = datetime(Y,M,D,H,MN,zeros(height(T),1));
        else
            t = datetime(Y,M,D);
        end
    else
        jDate = local_find_var(vnl, ...
            ["date","time","datetime"],1);
        t = local_parse_at_date(T{:,jDate});
    end
    t = local_snap_time(t(:),dt);

    depthNames = ["qobsmm","qobsmmd", ...
        "qobsmmday","qobsmmh","qobsmmhour", ...
        "dischargespecobs","runoff","runoffmm", ...
        "runoffmmd","runoffmmh","qmm","qsimmm"];
    volNames = ["qobs","qobsm3s","qobsms", ...
        "qcms","discharge", ...
        "dischargevolobs","dischargevol", ...
        "flow","streamflow"];

    jQ = local_find_var_optional(vnl,depthNames);
    if ~isnan(jQ)
        qUnits = 'mmstep';
    else
        jQ = local_find_var_optional(vnl,volNames);
        if isnan(jQ)
            error(['      Error:read_Q_AT: ' ...
                'Could not identify observed ' ...
                'discharge column in %s.'],fname);
        end
        qUnits = 'cms';
    end

    Q = local_col_to_double(T{:,jQ});
    Q(Q <= -999) = NaN;

    bad = ~isnat(t);
    t = t(bad);
    Q = Q(bad);

    [t,isrt] = sort(t);
    Q = Q(isrt);
    [t,ia] = unique(t,'stable');
    Q = Q(ia);
end

% =========================================
function split = local_prepare_split(split)
% =========================================
    if exist('prepare_split','file') == 2
        split = prepare_split(split);
        return
    end
    flds = {'dt_spin0','dt_train0', ...
        'dt_train1','dt_eval0','dt_eval1'};
    for i = 1:numel(flds)
        f = flds{i};
        if isfield(split,f) ...
                && ~isempty(split.(f))
            split.(f) = local_to_datetime( ...
                split.(f),1,false);
        end
    end
end

% ========================================
function stream = local_stream_from_dt(dt)
% ========================================
    if double(dt) == 24
        stream = 'hourly';
    else
        stream = 'daily';
    end
end

% ================================
function t = local_snap_time(t,dt)
% ================================
    if double(dt) == 24
        t = dateshift(t,'start','hour');
    else
        t = dateshift(t,'start','day');
    end
end

% ===========================================================
function req = local_requested_window(split,dt,includeSpinup)
% ===========================================================

    if nargin < 3
        includeSpinup = false;
    end

    if exist('build_requested_window','file') == 2
        try
            req0 = build_requested_window(split,includeSpinup);
    
            if isfield(req0,'read_start_N') ...
                    && isfield(req0,'read_end_N')
    
                tRef = datetime(1950,10,1,0,0,0);
    
                if double(dt) == 24
                    t0 = tRef + hours(double(req0.read_start_N));
                    t1 = tRef + hours(double(req0.read_end_N));
                    req.time = (t0:hours(1):t1).';
                else
                    t0 = tRef + days(double(req0.read_start_N));
                    t1 = tRef + days(double(req0.read_end_N));
                    req.time = (dateshift(t0,'start','day'):days(1): ...
                        dateshift(t1,'start','day')).';
                end
    
                return
            end
    
            if isfield(req0,'time') ...
                    && ~isempty(req0.time)
                req.time = local_snap_time( ...
                    datetime(req0.time(:)),dt);
                return
            end
        catch
        end
    end

    stepHours = 24/double(dt);
    spinup = 0;
    if includeSpinup
        if isfield(split,'spinup') ...
                && ~isempty(split.spinup)
            spinup = max(0,round(double(split.spinup)));
        elseif isfield(split,'n_spin') ...
                && ~isempty(split.n_spin)
            spinup = max(0,round(double(split.n_spin)));
        end
    end

    starts = NaT(0,1);
    ends = NaT(0,1);
    fStart = {'ds','dts','des','d1', ...
        'dt_train0','dt_eval0','dt_spin0'};
    fEnd = {'de','dte','dee','d2', ...
        'dt_train1','dt_eval1'};
    for i = 1:numel(fStart)
        if isfield(split,fStart{i}) ...
                && ~isempty(split.(fStart{i}))
            starts(end+1,1) = ...
                local_to_datetime( ...
            split.(fStart{i}),dt,false); %#ok<AGROW>
        end
    end
    for i = 1:numel(fEnd)
        if isfield(split,fEnd{i}) ...
                && ~isempty(split.(fEnd{i}))
            ends(end+1,1) = ...
                local_to_datetime( ...
            split.(fEnd{i}),dt,true); %#ok<AGROW>
        end
    end
    starts = starts(~isnat(starts));
    ends = ends(~isnat(ends));
    if isempty(starts) ...
            || isempty(ends)
        error(['      Error:read_Q_AT: ' ...
            'could not determine ' ...
            'requested time window.']);
    end
    t0 = local_snap_time(min(starts),dt) ...
        - hours(spinup * stepHours);
    t1 = local_snap_time(max(ends),dt);
    if double(dt) == 24
        req.time = (t0:hours(1):t1).';
    else
        req.time = (t0:days(1):t1).';
    end
end

% =======================================================
function dirStream = local_at_streamflow_dir(dirQ,stream)
% =======================================================
    dirQ = char(string(dirQ));
    % Legacy layout, retained for existing installations.
    cands = { ...
        dirQ, ...
        fullfile(dirQ,'streamflow'), ...
        fullfile(dirQ,stream,'streamflow'), ...
        fullfile(dirQ,stream,'timeseries','streamflow'), ...
        fullfile(dirQ,'CAMELS_AT', ...
            stream,'timeseries','streamflow'), ...
        fullfile(dirQ,'Data','CAMELS_AT', ...
            stream,'timeseries','streamflow'), ...
        fullfile(dirQ,'timeseries', ...
            stream,'streamflow'), ...
        fullfile(dirQ,'CAMELS_AT', ...
            'timeseries',stream,'streamflow'), ...
        fullfile(dirQ,'Data','CAMELS_AT', ...
            'timeseries',stream,'streamflow')};
    for i = 1:numel(cands)
        d = cands{i};
        if isfolder(d) ...
                && ~isempty(dir(fullfile(d,'ID_*.csv')))
            dirStream = d;
            return
        end
    end
    error(['      Error:read_Q_AT: ' ...
        'Cannot resolve CAMELS_AT %s ' ...
        'streamflow directory from: %s'],stream,dirQ);
end

% ==================================
function id = local_at_id_strings(x)
% ==================================
    x = string(x(:));
    x = strtrim(x);
    x = regexprep(x,'^ID[_\s-]*','', 'ignorecase');
    x = regexprep(x,'\.0+$','');
    x = regexprep(x,'[^0-9]','');
    if any(x == "")
        error(['      Error:read_Q_AT: ' ...
            'Empty basin ID after normalization.']);
    end
    id = x;
end

% ====================================================
function area = local_area_m2(k,bas,aux,dirStream,gid)
% ====================================================

    area = NaN;

    if ~isempty(aux) ...
            && size(aux,1) >= k ...
            && size(aux,2) >= 3
        area = double(aux(k,3));
    end

    if (~isfinite(area) ...
            || area <= 0) ...
            && isfield(bas,'area')
        area = double(bas.area(k));
        if median(double(bas.area(:)),'omitnan') < 1e7
            area = area * 1e6;
        end
    end

    if (~isfinite(area) ...
            || area <= 0) ...
            && isfield(bas,'area_calc')
        area = 1e6 * double(bas.area_calc(k));
    end

    if (~isfinite(area) ...
            || area <= 0) ...
            && isfield(bas,'area_km2')
        area = 1e6 * double(bas.area_km2(k));
    end

    if ~isfinite(area) ...
            || area <= 0
        dirAT = local_at_root_from_streamflow(dirStream);
        fGI = fullfile(dirAT,'gauge_information.txt');

        if isfile(fGI)
            T = readtable(fGI, ...
                'FileType','text', ...
                'Delimiter','\t', ...
                'VariableNamingRule','preserve');

            idT = local_at_id_strings(T.gauge_id);
            [tf,loc] = ismember(string(gid),idT);

            if tf
                areaKm2 = double(T.area_km2(loc));
                if isfinite(areaKm2) ...
                        && areaKm2 > 0
                    area = areaKm2 * 1e6;
                end
            end
        end
    end
end

% =======================================================
function dirAT = local_at_root_from_streamflow(dirStream)
% =======================================================
    dirAT = char(string(dirStream));

    [~,nm] = fileparts(dirAT);
    if strcmpi(nm,'streamflow') ...
            || strcmpi(nm,'forcing')
        dirAT = fileparts(dirAT);
    end

    [~,nm] = fileparts(dirAT);
    if strcmpi(nm,'daily') ...
            || strcmpi(nm,'hourly')
        dirAT = fileparts(dirAT);
    end

    [~,nm] = fileparts(dirAT);
    if strcmpi(nm,'timeseries')
        dirAT = fileparts(dirAT);
    end
end

% ========================================
function t = local_to_datetime(x,dt,isEnd)
% ========================================
    if nargin < 2
        dt = 1;
    end
    if nargin < 3
        isEnd = false;
    end

    hasTime = false;
    if isdatetime(x)
        t = x(1);
        hasTime = hour(t) ~= 0 ...
            || minute(t) ~= 0 ...
            || second(t) ~= 0;
    elseif isnumeric(x)
        if numel(x) >= 5
            t = datetime(x(1),x(2),x(3),x(4),x(5),0);
            hasTime = true;
        elseif numel(x) >= 4
            t = datetime(x(1),x(2),x(3),x(4),0,0);
            hasTime = true;
        elseif numel(x) >= 3
            t = datetime(x(1),x(2),x(3));
        else
            t = datetime(x(1), ...
                'ConvertFrom','datenum');
            hasTime = hour(t) ~= 0 ...
                || minute(t) ~= 0 ...
                || second(t) ~= 0;
        end
    else
        xs = string(x(1));
        t = datetime(xs);
        hasTime = contains(xs,":");
    end

    if double(dt) == 24
        t = dateshift(t,'start','hour');
        if isEnd && ~hasTime
            t = t + hours(23);
        end
    else
        t = dateshift(t,'start','day');
    end
end

% =================================
function t = local_parse_at_date(x)
% =================================
    if isdatetime(x)
        t = x(:);
        return
    end
    x = string(x(:));
    x = strip(erase(x,'"'));
    fmts = {'yyyy-MM-dd HH:mm','yyyy/MM/dd HH:mm', ...
        'yyyy-MM-dd HH:mm:ss','yyyy/MM/dd HH:mm:ss', ...
        'yyyy-MM-dd','yyyy/MM/dd', ...
        'dd/MM/yyyy','d/MM/yyyy', ...
        'dd.MM.yyyy','yyyyMMdd'};
    for i = 1:numel(fmts)
        try
            t = datetime(x,'InputFormat',fmts{i});
            if ~any(isnat(t))
                return
            end
        catch
        end
    end
    t = datetime(x);
end

% ============================================
function delim = local_detect_delimiter(fname)
% ============================================
    fid = fopen(char(fname),'r');
    if fid < 0
        error('Could not open %s',fname);
    end
    c = onCleanup(@() fclose(fid));
    line = fgetl(fid);
    if ~ischar(line)
        error('Empty file: %s',fname);
    end
    if count(string(line),"\t") ...
            >= count(string(line),";") ...
            && count(string(line),"\t") ...
            >= count(string(line),",")
        delim = '\t';
    elseif count(string(line),";") ...
            >= count(string(line),",")
        delim = ';';
    else
        delim = ',';
    end
end

% =============================================
function j = local_find_var(vnl,cands,fallback)
% =============================================
    j = local_find_var_optional(vnl,cands);
    if isnan(j)
        if isnan(fallback)
            error('read_Q_AT:missingColumn', ...
                ['Could not identify ' ...
                'required column among: %s'], ...
                strjoin(cands,', '));
        else
            j = fallback;
        end
    end
end

% =============================================
function j = local_find_var_optional(vnl,cands)
% =============================================
    j = NaN;
    for i = 1:numel(cands)
        c = lower(regexprep(string(cands(i)), ...
            '[^a-zA-Z0-9]',''));
        jj = find(vnl == c,1,'first');
        if ~isempty(jj)
            j = jj;
            return
        end
    end
    for i = 1:numel(cands)
        c = lower(regexprep(string(cands(i)), ...
            '[^a-zA-Z0-9]',''));
        jj = find(contains(vnl,c),1,'first');
        if ~isempty(jj)
            j = jj;
            return
        end
    end
end

% ============================================================
function j = local_find_var_after(vnl,cands,afterIdx,fallback)
% ============================================================
    if nargin < 4
        fallback = [];
    end
    for i = 1:numel(cands)
        c = lower(regexprep(string(cands(i)), ...
            '[^a-zA-Z0-9]',''));
        idx = 1:numel(vnl);
        jj = find(vnl == c ...
            & idx > afterIdx,1,'first');
        if ~isempty(jj)
            j = jj;
            return
        end
    end
    for i = 1:numel(cands)
        c = lower(regexprep(string(cands(i)), ...
            '[^a-zA-Z0-9]',''));
        idx = 1:numel(vnl);
        jj = find(contains(vnl,c) ...
            & idx > afterIdx,1,'first');
        if ~isempty(jj)
            j = jj;
            return
        end
    end
    j = fallback;
end

% =================================
function x = local_col_to_double(x)
% =================================
    if isnumeric(x)
        x = double(x(:));
        x(x <= -999) = NaN;
        return
    end
    if iscell(x)
        x = string(x);
    elseif ischar(x)
        x = string(cellstr(x));
    elseif iscategorical(x)
        x = string(x);
    end
    if isstring(x)
        xs = strip(x(:));
        xs = erase(xs,'"');
        xs = strrep(xs,',','.');
        xs = regexprep(xs, ...
            '^(NA|NaN|null|NULL|nan|None|-9999|-999)$', ...
            'NaN','ignorecase');
        xs(xs == "") = "NaN";
        x = str2double(xs);
        x(x <= -999) = NaN;
        return
    end
    error('read_Q_AT:badColumn', ...
        'Unable to convert column to double.');
end
