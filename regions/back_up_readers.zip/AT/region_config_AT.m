function R = region_config_AT()
%REGION_CONFIG_AT Regional defaults for CAMELS-AT.
%
% All X.paths fields are relative to Data/<R.data_root>.
% Dates use dd/MM/yyyy and water-year boundaries.

    R = struct();
    R.code = 'CAMELS_AT';
    R.acronym = 'AT';
    R.name = 'Austria';
    R.dataset = 'CAMELS-AT';
    R.data_root = 'CAMELS_AT';
    R.resolutions = {'Daily','Hourly'};
    R.default_resolution = 'Daily';
    R.basin_file_pattern = 'AT_%d_basins.txt';

    X = struct();
    X.label = 'Daily';
    X.dt = 1;
    X.basins.universe = 859;
    X.basins.training = 700;
    X.basins.evaluation = 159;
    X.period.spinup_days = 365;
    X.period.manual.train_start = '01/10/2002';
    X.period.manual.train_end = '30/09/2017';
    X.period.manual.eval_start = '01/10/1987';
    X.period.manual.eval_end = '30/09/2002';
    X.period.common_start = '01/10/1987';
    X.period.common_end = '30/09/2017';
    X.paths.run_root = '';
    X.paths.meteo = fullfile('daily','timeseries','forcing');
    X.paths.discharge = fullfile('daily','timeseries','streamflow');
    % Meteorological/PET controls shown by SAGE-GUI.
    X.meteo.product.items = {'CAMELS-AT [daily]'};
    X.meteo.product.default = 'CAMELS-AT [daily]';
    X.meteo.product.enabled = false;
    X.meteo.precipitation.items = {'1 Precipitation'};
    X.meteo.precipitation.default = '1 Precipitation';
    X.meteo.precipitation.enabled = false;
    X.meteo.temperature.items = { ...
        '1 Mean', ...
        '2 (Tmin+Tmax)/2' ...
        };
    X.meteo.temperature.default = '1 Mean';
    X.meteo.temperature.enabled = true;
    X.meteo.pet.items = { ...
        '0 Zero PET', ...
        '1 Penman-Monteith', ...
        '2 Priestley-Taylor', ...
        '3 Makkink', ...
        '4 LamaH ΣET' ...
        };
    X.meteo.pet.default = '1 Penman-Monteith';
    X.meteo.pet.enabled = true;
    C = repmat(struct('name','','type','','path','','pattern','', ...
        'minimum_count',1,'required',true),0,1);
    C(1).name = 'Meteorological data';
    C(1).type = 'folder';
    C(1).path = fullfile('daily','timeseries','forcing');
    C(1).pattern = '*';
    C(1).minimum_count = 1;
    C(2).name = 'Discharge data';
    C(2).type = 'folder';
    C(2).path = fullfile('daily','timeseries','streamflow');
    C(2).pattern = '*';
    C(2).minimum_count = 1;
    X.checks = C;
    R.by_resolution.Daily = X;

    X = struct();
    X.label = 'Hourly';
    X.dt = 24;
    X.basins.universe = 859;
    X.basins.training = 700;
    X.basins.evaluation = 159;
    X.period.spinup_days = 365;
    X.period.manual.train_start = '01/10/2005';
    X.period.manual.train_end = '30/09/2017';
    X.period.manual.eval_start = '01/10/1993';
    X.period.manual.eval_end = '30/09/2005';
    X.period.common_start = '01/10/1993';
    X.period.common_end = '30/09/2017';
    X.paths.run_root = '';
    X.paths.meteo = fullfile('hourly','timeseries','forcing');
    X.paths.discharge = fullfile('hourly','timeseries','streamflow');
    % Meteorological/PET controls shown by SAGE-GUI.
    X.meteo.product.items = {'CAMELS-AT [hourly]'};
    X.meteo.product.default = 'CAMELS-AT [hourly]';
    X.meteo.product.enabled = false;
    X.meteo.precipitation.items = {'1 Precipitation'};
    X.meteo.precipitation.default = '1 Precipitation';
    X.meteo.precipitation.enabled = false;
    X.meteo.temperature.items = {'1 Mean'};
    X.meteo.temperature.default = '1 Mean';
    X.meteo.temperature.enabled = false;
    X.meteo.pet.items = { ...
        '0 Zero PET', ...
        '1 Penman-Monteith', ...
        '2 Priestley-Taylor', ...
        '3 Makkink', ...
        '4 LamaH ΣET' ...
        };
    X.meteo.pet.default = '1 Penman-Monteith';
    X.meteo.pet.enabled = true;
    C = repmat(struct('name','','type','','path','','pattern','', ...
        'minimum_count',1,'required',true),0,1);
    C(1).name = 'Meteorological data';
    C(1).type = 'folder';
    C(1).path = fullfile('hourly','timeseries','forcing');
    C(1).pattern = '*';
    C(1).minimum_count = 1;
    C(2).name = 'Discharge data';
    C(2).type = 'folder';
    C(2).path = fullfile('hourly','timeseries','streamflow');
    C(2).pattern = '*';
    C(2).minimum_count = 1;
    X.checks = C;
    R.by_resolution.Hourly = X;

end
