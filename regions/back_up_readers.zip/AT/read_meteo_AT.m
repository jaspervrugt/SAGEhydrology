function [dat,aux] = read_meteo_AT(dirM,bas,split,meteo)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%READ_METEO_AT Read CAMELS-AT / LamaH-CE meteorological forcing.
%
% Supported installed structures:
%   Data/CAMELS_AT/daily/timeseries/forcing/ID_<id>.csv
%   Data/CAMELS_AT/hourly/timeseries/forcing/ID_<id>.csv
%
% Daily forcing columns commonly include:
%   YYYY, MM, DD, DOY, precipitation, 2m_temp_mean, 2m_temp_min,
%   2m_temp_max, total_et
%
% Hourly forcing columns commonly include:
%   YYYY, MM, DD, hh, mm, DOY, HOD, 2m_temp, total_et, precipitation
%
% IMPORTANT
%   This reader reads meteorological forcing only.
%   Observed discharge for CAMELS-AT is read separately by read_Q_AT.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    if nargin < 4
        meteo = struct();
    end
    if nargin < 3
        error(['      Error:read_meteo_AT: ' ...
            'Expected input signature ' ...
            '[dat,aux] = read_meteo_AT(dirM,' ...
            'bas,split,meteo).']);
    end
    if nargin < 1 ...
            || isempty(dirM)
        error(['      Error:read_meteo_AT: ' ...
            'dirM must be provided.']);
    end

    split = local_prepare_split(split);

    dt = double(split.dt);
    if ~any(dt == [1 24])
        error(['      Error:read_meteo_AT: ' ...
            'CAMELS-AT / LamaH-CE supports dt = 1 ' ...
            '(daily) or dt = 24 (hourly).']);
    end
    stream = local_stream_from_dt(dt);
    temp = local_get_temp_option(meteo);
    % Temperature options:
    %   1 = mean Temperature
    %   2 = mean(Tmin,Tmax) 
    %   Hourly data: only option 1
    pet = local_get_pet_option(meteo);
    % PET options:
    %   0 = zero PET
    %   1 = Penman-Monteith
    %   2 = Priestley-Taylor
    %   3 = Makkink
    %   4 = LamaH total_et

    K = bas.K;
    id_GAUGE = local_at_id_strings( ...
        bas.id_gauge(:));

    dirTs = local_at_timeseries_dir(dirM,stream);
    dirAT = local_at_root_from_timeseries(dirTs);

    dat = cell(K,1);
    aux = nan(K,3);

    try
        aux = local_aux_from_bas(bas,aux);
    catch
    end
    try
        aux = local_aux_from_attributes(dirAT, ...
            bas,aux);
    catch MEaux
        fprintf('\n');
        fprintf(['      Warning:read_meteo_AT: ' ...
            'could not read ' ...
            'Austria catchment attributes ' ...
            'for aux fields.\n']);
        fprintf('      Cause: %s\n',MEaux.message);
    end

    % Final fallback from bas fields carried by GUI/export
    try
        if isfield(bas,'lat') ...
                && numel(bas.lat) >= K
            aux(:,1) = fillmissing(aux(:,1),'constant',NaN);
            bad = ~isfinite(aux(:,1));
            aux(bad,1) = double(bas.lat(bad));
        end

        if isfield(bas,'elev') ...
                && numel(bas.elev) >= K
            bad = ~isfinite(aux(:,2));
            aux(bad,2) = double(bas.elev(bad));
        elseif isfield(bas,'gauge_elev') ...
                && numel(bas.gauge_elev) >= K
            bad = ~isfinite(aux(:,2));
            aux(bad,2) = double(bas.gauge_elev(bad));
        end
    catch
    end

    req = local_requested_window(split,dt);
    tReq = local_snap_time(datetime( ...
        req.time(:)),dt);
    nReq = numel(tReq);

    if nReq == 0
        error(['      Error:read_meteo_AT: ' ...
            'requested %s time ' ...
            'window is empty. Check period ' ...
            'settings.'],stream);
    end

    if isfield(split,'idx') ...
            && ~isempty(split.idx)
        idx_score = double(split.idx(:));
    else
        idx_score = (1:nReq).';
    end
    idx_score = idx_score(isfinite(idx_score) ...
        & idx_score >= 1 ...
        & idx_score <= nReq);
    idx_score = round(idx_score(:));

    if isempty(idx_score)
        error(['      Error:read_meteo_AT: ' ...
            'scored-period index ' ...
            'split.idx is empty or outside ' ...
            'the requested window.']);
    end

    cache_dir = fullfile(dirTs, ...
        sprintf('_cache_AT_%s_meteo_temp%d_pet%d', ...
        stream,temp,pet));
    if ~isfolder(cache_dir)
        mkdir(cache_dir);
    end

    fprintf(['... Reading %s CAMELS-AT ' ...
        'meteorological data files %3d%%'], ...
        stream,0);
    flag_progress = true;

    for k = 1:K

        gid = id_GAUGE(k);
        fname = fullfile(dirTs,sprintf('ID_%s.csv',gid));

        if ~isfile(fname)
            fprintf('\n');
            error(['      Error:read_meteo_AT: ' ...
                'Missing %s ' ...
                'forcing file for basin %s: %s'], ...
                stream,gid,fname);
        end

        t0 = tReq(1);
        t1 = tReq(end);

        t0.Format = 'yyyyMMddHHmm';
        t1.Format = 'yyyyMMddHHmm';

        win_key = sprintf('%s_%s', char(t0), char(t1));
        cache_file = fullfile(cache_dir, ...
            sprintf('%s_AT_%s_meteo_pet%d_%s.mat', ...
            gid,stream,pet,win_key));

        use_cache = false;
        if isfile(cache_file)
            try
                S = load(cache_file, ...
                    'P','Ep','Tmean','Tmin','Tmax', ...
                    'badrows','src_datenum');
                info = dir(fname);
                if isfield(S,'src_datenum') ...
                        && S.src_datenum >= info.datenum
                    P = S.P;
                    Ep = S.Ep;
                    Tmean = S.Tmean;
                    Tmin = S.Tmin;
                    Tmax = S.Tmax;
                    badrows = S.badrows;
                    use_cache = true;
                end
            catch
                use_cache = false;
            end
        end
        
        if ~use_cache
            [tFile,Pfile,Epfile,TmeanFile,TminFile,TmaxFile] = ...
                local_read_at_forcing_file(fname,dt,pet,temp, ...
                aux(k,1),aux(k,2));

            P = nan(nReq,1);
            Ep = nan(nReq,1);
            Tmean = nan(nReq,1);
            Tmin = nan(nReq,1);
            Tmax = nan(nReq,1);

            [tf,loc] = ismember(tReq,tFile);
            P(tf) = Pfile(loc(tf));
            Ep(tf) = Epfile(loc(tf));
            Tmean(tf) = TmeanFile(loc(tf));
            Tmin(tf) = TminFile(loc(tf));
            Tmax(tf) = TmaxFile(loc(tf));

            badmask = ~isfinite(P) ...
                | ~isfinite(Ep) ...
                | ~isfinite(Tmean);
            badrows = int64(find(badmask));

            try
                info = dir(fname);
                src_datenum = info.datenum;
                save(cache_file,'P','Ep', ...
                    'Tmean','Tmin','Tmax', ...
                    'badrows','src_datenum','-v7.3');
            catch
            end
        end

        dat{k}.meteo.P = single(P);
        dat{k}.meteo.Ep = single(Ep);
        dat{k}.meteo.T = single(Tmean);
        dat{k}.meteo.Tmin = single(Tmin);
        dat{k}.meteo.Tmax = single(Tmax);
        dat{k}.meteo.bad = badrows(:)';

        dat{k}.gauge = gid;
        dat{k}.fname{1} = fname;
        dat{k}.fname{2} = fname;

        if ~isempty(badrows)
            if flag_progress
                fprintf('\n');
            end
            fprintf(['      Warning:read_meteo_AT: ' ...
                'basin %s has ' ...
                '%d invalid/missing %s meteo ' ...
                'rows in requested window.\n'], ...
                gid,numel(badrows),stream);
            pct = floor(100*k/K);
            fprintf(['... Reading %s CAMELS-AT ' ...
                'meteorological data files %3d%%'], ...
                stream,pct);
            flag_progress = true;
        end

        if mod(k,20)==0 ...
                || k==K
            pct = floor(100*k/K);
            fprintf('\b\b\b\b%3d%%',pct);
            drawnow;
        end

        if isfield(meteo,'progressFcn') ...
                && ~isempty(meteo.progressFcn)
            try
                meteo.progressFcn(k);
            catch
            end
        end
    end

    if flag_progress
        fprintf('\b\b\b\b%s\n','... Done');
    end

    if isfield(split,'local') ...
            && split.local ...
            && isfield(split, ...
            'rainfall_block') ...
            && split.rainfall_block
        dat = rainfall_rank_split(dat,split);
    end

end

% =========================================
function split = local_prepare_split(split)
% =========================================

    if exist('prepare_split','file') == 2
        split = prepare_split(split);
        return
    end

    flds = {'dt_spin0','dt_train0', ...
        'dt_train1','dt_eval0','dt_eval1'};
    for i = 1:numel(flds)
        f = flds{i};
        if isfield(split,f) ...
                && ~isempty(split.(f))
            split.(f) = local_to_datetime( ...
                split.(f),1,false);
        end
    end
end

% ========================================
function stream = local_stream_from_dt(dt)
% ========================================
    if double(dt) == 24
        stream = 'hourly';
    else
        stream = 'daily';
    end
end

% ================================
function t = local_snap_time(t,dt)
% ================================
    if double(dt) == 24
        t = dateshift(t, ...
            'start','hour');
    else
        t = dateshift(t, ...
            'start','day');
    end
end

% =============================================
function req = local_requested_window(split,dt)
% =============================================

    if exist('build_requested_window','file') == 2
        try
            req0 = build_requested_window(split,true);
    
            if isfield(req0,'read_start_N') ...
                    && isfield(req0,'read_end_N')
    
                tRef = datetime(1950,10,1,0,0,0);
    
                if double(dt) == 24
                    t0 = tRef + hours(double(req0.read_start_N));
                    t1 = tRef + hours(double(req0.read_end_N));
                    req.time = (t0:hours(1):t1).';
                else
                    t0 = tRef + days(double(req0.read_start_N));
                    t1 = tRef + days(double(req0.read_end_N));
                    req.time = (dateshift(t0,'start','day'):days(1): ...
                        dateshift(t1,'start','day')).';
                end
    
                return
            end
    
            if isfield(req0,'time') ...
                    && ~isempty(req0.time)
                req.time = local_snap_time( ...
                    datetime(req0.time(:)),dt);
                return
            end
        catch
        end
    end

    stepHours = 24/double(dt);
    spinup = 0;
    if isfield(split,'spinup') ...
            && ~isempty(split.spinup)
        spinup = max(0,round(double(split.spinup)));
    elseif isfield(split,'n_spin') ...
            && ~isempty(split.n_spin)
        spinup = max(0,round(double(split.n_spin)));
    end

    starts = NaT(0,1);
    ends = NaT(0,1);

    sf = {'ds','dts','des','d1', ...
        'dt_train0','dt_eval0','dt_spin0'};
    ef = {'de','dte','dee','d2', ...
        'dt_train1','dt_eval1'};

    for i = 1:numel(sf)
        if isfield(split,sf{i}) ...
                && ~isempty(split.(sf{i}))
            starts(end+1,1) = ...
                local_to_datetime(split.(sf{i}), ...
            dt,false);  %#ok<AGROW>
        end
    end
    for i = 1:numel(ef)
        if isfield(split,ef{i}) ...
                && ~isempty(split.(ef{i}))
            ends(end+1,1) = ...
                local_to_datetime(split.(ef{i}), ...
            dt,true);   %#ok<AGROW>
        end
    end

    starts = starts(~isnat(starts));
    ends = ends(~isnat(ends));

    if isempty(starts) ...
            || isempty(ends)
        error(['      Error:read_meteo_AT: ' ...
            'could not determine ' ...
            'requested time window from split.']);
    end

    t0 = local_snap_time(min(starts),dt) ...
        - hours(spinup * stepHours);
    t1 = local_snap_time(max(ends),dt);

    if t1 < t0
        error(['      Error:read_meteo_AT: ' ...
            'requested period is empty: ' ...
            '%s to %s.'],string(t0),string(t1));
    end

    if double(dt) == 24
        req.time = (t0:hours(1):t1).';
    else
        req.time = (t0:days(1):t1).';
    end
end

% ===================================================
function dirTs = local_at_timeseries_dir(dirM,stream)
% ===================================================

    dirM = char(string(dirM));
    % Legacy layout, retained for existing installations.
    cands = { ...
        dirM, ...
        fullfile(dirM,'forcing'), ...
        fullfile(dirM,stream,'forcing'), ...
        fullfile(dirM,stream,'timeseries','forcing'), ...
        fullfile(dirM,'CAMELS_AT', ...
            stream,'timeseries','forcing'), ...
        fullfile(dirM,'Data','CAMELS_AT', ...
            stream,'timeseries','forcing'), ...
        fullfile(dirM,'timeseries', ...
            stream,'forcing'), ...
        fullfile(dirM,'CAMELS_AT', ...
            'timeseries',stream,'forcing'), ...
        fullfile(dirM,'Data','CAMELS_AT', ...
            'timeseries',stream,'forcing')};

    for i = 1:numel(cands)
        d = cands{i};
        if isfolder(d) ...
                && ~isempty(dir(fullfile(d,'ID_*.csv')))
            dirTs = d;
            return
        end
    end

    error(['      Error:read_meteo_AT: ' ...
        'Cannot resolve CAMELS_AT ' ...
        '%s forcing directory from: %s'], ...
        stream,dirM);
end

% ===================================================
function dirAT = local_at_root_from_timeseries(dirTs)
% ===================================================

    dirAT = char(string(dirTs));

    [~,nm] = fileparts(dirAT);
    if strcmpi(nm,'forcing') ...
            || strcmpi(nm,'streamflow')
        dirAT = fileparts(dirAT);
    end

    for i = 1:2
        [~,nm] = fileparts(dirAT);
        if strcmpi(nm,'daily') ...
                || strcmpi(nm,'hourly') ...
                || strcmpi(nm,'timeseries')
            dirAT = fileparts(dirAT);
        end
    end
end

% ======================================================
function [t,P,Ep,Tmean,Tmin,Tmax] = ...
    local_read_at_forcing_file(fname,dt,pet,temp,lat_deg,z_m)
% ======================================================

    info = dir(fname);
    if isempty(info) ...
            || info.bytes == 0
        error(['      Error:read_meteo_AT: ' ...
            'Empty time-series file: %s'], ...
            fname);
    end

    delim = local_detect_delimiter(fname);
    opts = detectImportOptions(char(fname), ...
        'FileType','text', ...
        'Delimiter',delim, ...
        'VariableNamingRule','preserve');
    T = readtable(char(fname),opts);

    vn0 = string(T.Properties.VariableNames);
    vn = lower(regexprep(vn0,'[^a-zA-Z0-9]',''));

    jY = local_find_var(vn,["yyyy","year"],1);
    jM = local_find_var_month(vn0,vn);
    jD = local_find_var(vn,["dd","day"],3);

    Y = local_to_double(T{:,jY});
    M = local_to_double(T{:,jM});
    D = local_to_double(T{:,jD});

    if double(dt) == 24
        jH = local_find_var_after(vn, ...
            ["hh","hour","hod"],jD,4);
        jMin = local_find_var_after(vn, ...
            ["minute","min","mm"],jH,[]);
        H = local_to_double(T{:,jH});
        if isempty(jMin)
            MN = zeros(height(T),1);
        else
            MN = local_to_double(T{:,jMin});
        end
        t = datetime(Y,M,D,H,MN,zeros(height(T),1));
        t = dateshift(t(:),'start','hour');
    else
        t = datetime(Y,M,D);
        t = dateshift(t(:),'start','day');
    end

    jP = local_find_var(vn, ...
        ["prec","pre","pr","precipitation"],[]);

    jTm = local_find_var(vn, ...
        ["2mtempmean","2mtemp","tmean", ...
        "tempmean","temperaturemean","temperature", ...
        "2mtemp"],[]);
    jTn = local_find_var(vn, ...
        ["2mtempmin","tmin", ...
        "tempmin","temperaturemin"],[]);
    jTx = local_find_var(vn, ...
        ["2mtempmax","tmax", ...
        "tempmax","temperaturemax"],[]);

    jTd = local_find_var(vn, ...
        ["2mdptempmean","2mdptemp","dewpoint", ...
        "dewpointmean","2mdewpointtemperature", ...
        "2mdp"],[]);
    jTdn = local_find_var(vn, ...
        ["2mdptempmin","dewpointmin"],[]);
    jTdx = local_find_var(vn, ...
        ["2mdptempmax","dewpointmax"],[]);

    jU = local_find_var(vn, ...
        ["10mwindu","windu","u10"],[]);
    jV = local_find_var(vn, ...
        ["10mwindv","windv","v10"],[]);
    jRs = local_find_var(vn, ...
        ["surf_netsolar_rad", ...
        "surfnet_solar_rad", ...
        "surfnet_solar_radmean", ...
        "surfnet_solar_radmax", ...
        "surfnet_solarrad", ...
        "netsolarrad","solar"],[]);
    jRt = local_find_var(vn, ...
        ["surf_nettherm_rad", ...
        "surfnet_therm_rad", ...
        "surfnet_therm_radmean", ...
        "surfnet_therm_radmax", ...
        "surfnet_thermrad","netthermalrad", ...
        "thermal"],[]);
    jPress = local_find_var(vn, ...
        ["surfpress","surfacepressure", ...
        "press","pressure"],[]);
    jEp = local_find_var(vn, ...
        ["totalet","et0","pet", ...
        "potentialevapotranspiration", ...
        "eta","evapotranspiration"],[]);

    if isempty(jP)
        error(['      Error:read_meteo_AT: ' ...
            'No precipitation ' ...
            'column found in %s.'],fname);
    end
    if isempty(jTm) ...
            && (isempty(jTn) || isempty(jTx))
        error(['      Error:read_meteo_AT: ' ...
            'No usable temperature ' ...
            'columns found in %s.'],fname);
    end

    P = local_to_double(T{:,jP});

    if ~isempty(jTn)
        Tmin = local_to_double(T{:,jTn});
    else
        Tmin = nan(height(T),1);
    end

    if ~isempty(jTx)
        Tmax = local_to_double(T{:,jTx});
    else
        Tmax = nan(height(T),1);
    end

    if double(dt) == 24
        % Hourly: only 2m_temp is available/used
        Tmean = local_to_double(T{:,jTm});
    else
        % Daily: user can choose Tmean column or mean(Tmin,Tmax)
        switch temp
            case 1
                Tmean = local_to_double(T{:,jTm});
            case 2
                Tmean = 0.5*(Tmin + Tmax);
        end
    end

    % Safety fallback
    if all(~isfinite(Tmean)) ...
            && any(isfinite(Tmin)) ...
            && any(isfinite(Tmax))
        Tmean = 0.5*(Tmin + Tmax);
    end

    if double(dt) == 24
        if all(~isfinite(Tmin))
            Tmin = Tmean;
        end
        if all(~isfinite(Tmax))
            Tmax = Tmean;
        end
    end

    switch pet
        case 0
            Ep = zeros(height(T),1);

        case 4
            if isempty(jEp)
                error(['      Error:read_meteo_AT: ' ...
                    'PET option 4 requires ' ...
                    'total_et in %s.'],fname);
            end
            Ep = local_to_double(T{:,jEp});
            Ep = abs(Ep);

        case {1,2,3}
            if double(dt) == 24
                if isempty(jTd)
                    if ~isempty(jTdn) ...
                            && ~isempty(jTdx)
                        Td = 0.5*(local_to_double(T{:,jTdn}) + ...
                            local_to_double(T{:,jTdx}));
                    else
                        error(['      Error:read_meteo_AT: ' ...
                            'PET option %d requires dew-point ' ...
                            'temperature in %s.'],pet,fname);
                    end
                else
                    Td = local_to_double(T{:,jTd});
                end
                if isempty(jRs)
                    error(['      Error:read_meteo_AT: ' ...
                        'PET option %d requires net solar ' ...
                        'radiation in %s.'],pet,fname);
                end

                Rs = local_to_double(T{:,jRs});
                Vp = local_vapor_pressure_from_dewpoint(Td);
                doy = day(t,'dayofyear');

                if isempty(jU) ...
                        || isempty(jV)
                    u2 = 2;
                else
                    u10 = hypot(local_to_double(T{:,jU}), ...
                        local_to_double(T{:,jV}));
                    u2 = local_wind10_to_wind2(u10);
                end

                if ~isfinite(lat_deg) ...
                        || ~isfinite(z_m)
                    error(['      Error:read_meteo_AT: ' ...
                        'PET option %d ' ...
                        'requires finite latitude ' ...
                        'and elevation for %s.'],pet,fname);
                end

                Ep = et0_fao56_daily(Tmax,Tmin,Rs,Vp,doy, ...
                    lat_deg,z_m,u2,pet);

            else
                if isempty(jTd) ...
                        || isempty(jU) ...
                        || isempty(jV) ...
                        || isempty(jRs) ...
                        || isempty(jRt) ...
                        || isempty(jPress)
                    error(['      Error:read_meteo_AT: ' ...
                        'PET option %d requires hourly columns ' ...
                        '2m_dp_temp, 10m_wind_u, 10m_wind_v, ' ...
                        'surf_net_solar_rad, surf_net_therm_rad, ' ...
                        'and surf_press in %s.'],pet,fname);
                end

                Td = local_to_double(T{:,jTd});
                u10 = local_to_double(T{:,jU});
                v10 = local_to_double(T{:,jV});
                Rns = local_to_double(T{:,jRs});
                Rnt = local_to_double(T{:,jRt});
                press = local_to_double(T{:,jPress});

                Ep = et0_lamah_hourly(Tmean,Td,u10,v10, ...
                    Rns,Rnt,press,pet);
            end

        otherwise
            error(['      Error:read_meteo_AT: ' ...
                'Unknown PET option %d. ' ...
                'Use 0, 1, 2, 3, or 4.'],pet);
    end

    Ep(~isfinite(Ep) | Ep < 0) = NaN;

    good = ~isnat(t);
    t = t(good);
    P = P(good);
    Ep = Ep(good);
    Tmean = Tmean(good);
    Tmin = Tmin(good);
    Tmax = Tmax(good);

    [t,isrt] = sort(t);
    P = P(isrt);
    Ep = Ep(isrt);
    Tmean = Tmean(isrt);
    Tmin = Tmin(isrt);
    Tmax = Tmax(isrt);

    [t,ia] = unique(t,'stable');
    P = P(ia);
    Ep = Ep(ia);
    Tmean = Tmean(ia);
    Tmin = Tmin(ia);
    Tmax = Tmax(ia);
end

% ============================================
function delim = local_detect_delimiter(fname)
% ============================================

    fid = fopen(char(fname),'r');
    if fid < 0
        error('Could not open %s',fname);
    end
    c = onCleanup(@() fclose(fid));
    line = fgetl(fid);
    if ~ischar(line)
        error('Empty file: %s',fname);
    end
    if count(string(line),"\t") ...
            >= count(string(line),";") ...
            && count(string(line),"\t") ...
            >= count(string(line),",")
        delim = '\t';
    elseif count(string(line),";") ...
            >= count(string(line),",")
        delim = ';';
    else
        delim = ',';
    end
end

% ============================================
function j = local_find_var(vn,cands,fallback)
% ============================================

    if nargin < 3
        fallback = [];
    end

    for i = 1:numel(cands)
        c = lower(regexprep(string(cands(i)), ...
            '[^a-zA-Z0-9]',''));
        jj = find(vn == c,1,'first');
        if ~isempty(jj)
            j = jj;
            return
        end
    end
    for i = 1:numel(cands)
        c = lower(regexprep(string(cands(i)), ...
            '[^a-zA-Z0-9]',''));
        jj = find(contains(vn,c),1,'first');
        if ~isempty(jj)
            j = jj;
            return
        end
    end

    j = fallback;
end

% ===========================================================
function j = local_find_var_after(vn,cands,afterIdx,fallback)
% ===========================================================

    if nargin < 4
        fallback = [];
    end
    for i = 1:numel(cands)
        c = lower(regexprep(string(cands(i)), ...
            '[^a-zA-Z0-9]',''));
        idx = 1:numel(vn);
        jj = find(vn == c ...
            & idx > afterIdx,1,'first');
        if ~isempty(jj)
            j = jj;
            return
        end
    end
    for i = 1:numel(cands)
        c = lower(regexprep(string(cands(i)), ...
            '[^a-zA-Z0-9]',''));
        idx = 1:numel(vn);
        jj = find(contains(vn,c) ...
            & idx > afterIdx,1,'first');
        if ~isempty(jj)
            j = jj;
            return
        end
    end
    j = fallback;
end

% =======================================
function j = local_find_var_month(vn0,vn)
% =======================================
    j = find(strcmp(vn0,'MM'),1,'first');
    if isempty(j)
        j = local_find_var(vn,["month","mon"],[]);
    end
    if isempty(j)
        % In LamaH files, month is the second column.
        j = 2;
    end
end

% =============================
function x = local_to_double(x)
% =============================

    if isnumeric(x)
        x = double(x(:));
        x(x <= -999) = NaN;
        return
    end
    if iscell(x)
        x = string(x);
    end
    if ischar(x)
        x = string(cellstr(x));
    end
    if isstring(x) ...
            || iscategorical(x)
        xs = string(x(:));
        xs = strip(xs);
        xs = erase(xs,'"');
        xs = strrep(xs,',','.');
        xs = regexprep(xs, ...
            '^(NA|NaN|null|NULL|nan|None|-9999|-999)$', ...
            'NaN','ignorecase');
        xs(xs == "") = "NaN";
        x = str2double(xs);
        x(x <= -999) = NaN;
        return
    end
    error(['      Error:read_meteo_AT: ' ...
        'Unable to convert column to double.']);
end

% ==================================

% ========================================
function pet = local_get_pet_option(meteo)
% ========================================

    pet = 4; % default: LamaH total_et

    if isstruct(meteo)
        if isfield(meteo,'pet') ...
                && ~isempty(meteo.pet)
            pet = meteo.pet;
        elseif isfield(meteo,'id_pet') ...
                && ~isempty(meteo.id_pet)
            pet = meteo.id_pet;
        elseif isfield(meteo,'PET') ...
                && ~isempty(meteo.PET)
            pet = meteo.PET;
        end
    end

    if ischar(pet) ...
            || isstring(pet)
        s = lower(strtrim(string(pet)));
        tok = regexp(s,'^\s*(\d+)','tokens','once');
        if ~isempty(tok)
            pet = str2double(tok{1});
        elseif contains(s,'zero')
            pet = 0;
        elseif contains(s,'monteith')
            pet = 1;
        elseif contains(s,'priestley')
            pet = 2;
        elseif contains(s,'makkink')
            pet = 3;
        elseif contains(s,'total') ...
                || contains(s,'native') ...
                || contains(s,'lamah')
            pet = 4;
        else
            pet = 4;
        end
    end

    pet = double(pet);
    if ~isscalar(pet) ...
            || ~isfinite(pet)
        pet = 4;
    end
    pet = round(pet);

    if ~any(pet == [0 1 2 3 4])
        error(['      Error:read_meteo_AT: ' ...
            'Unknown PET option %d. ' ...
            'Use 0, 1, 2, 3, or 4.'],pet);
    end
end

% ======================================================
function ea_Pa = local_vapor_pressure_from_dewpoint(TdC)
% ======================================================
% Saturation vapor pressure at dew-point temperature gives actual vapor
% pressure. Output is Pa.

    ea_kPa = 0.6108 .* exp(17.27 .* TdC ./ (TdC + 237.3));
    ea_Pa = 1000 .* ea_kPa;
end

% ======================================
function u2 = local_wind10_to_wind2(u10)
% ======================================
% FAO-56 logarithmic wind-profile correction from 10 m to 2 m.

    u2 = u10 .* (4.87 ./ log(67.8*10 - 5.42));
end

function id = local_at_id_strings(x)
% ==================================

    x = string(x(:));
    x = strtrim(x);
    x = regexprep(x,'\.0+$','');
    x = regexprep(x,'^ID[_\-\s]*','', ...
        'ignorecase');
    x = regexprep(x,'[^0-9]','');

    if any(x == "")
        error(['      Error:read_meteo_AT: ' ...
            'Empty CAMELS-AT basin ID ' ...
            'after normalization.']);
    end
    id = x;
end

% ========================================
function t = local_to_datetime(x,dt,isEnd)
% ========================================

    if nargin < 2
        dt = 1;
    end
    if nargin < 3
        isEnd = false;
    end

    hasTime = false;
    if isdatetime(x)
        t = x(1);
        hasTime = hour(t) ~= 0 ...
            || minute(t) ~= 0 ...
            || second(t) ~= 0;
    elseif isnumeric(x)
        if numel(x) >= 5
            t = datetime(x(1),x(2),x(3),x(4),x(5),0);
            hasTime = true;
        elseif numel(x) >= 4
            t = datetime(x(1),x(2),x(3),x(4),0,0);
            hasTime = true;
        elseif numel(x) >= 3
            t = datetime(x(1),x(2),x(3));
        else
            t = datetime(x(1), ...
                'ConvertFrom','datenum');
            hasTime = hour(t) ~= 0 ...
                || minute(t) ~= 0 ...
                || second(t) ~= 0;
        end
    else
        xs = string(x(1));
        t = datetime(xs);
        hasTime = contains(xs,":");
    end

    if double(dt) == 24
        t = dateshift(t,'start','hour');
        if isEnd && ~hasTime
            t = t + hours(23);
        end
    else
        t = dateshift(t,'start','day');
    end
end

% ========================================
function aux = local_aux_from_bas(bas,aux)
% ========================================

    K = bas.K;
    if isfield(bas,'lat')
        aux(1:K,1) = double(bas.lat(1:K));
    elseif isfield(bas,'gauge_lat')
        aux(1:K,1) = double(bas.gauge_lat(1:K));
    elseif isfield(bas,'zone') ...
            && isfield(bas.zone,'lat')
        aux(1:K,1) = double(bas.zone.lat(1:K));        
    end

    if isfield(bas,'gauge_elev')
        aux(1:K,2) = double(bas.gauge_elev(1:K));
    elseif isfield(bas,'zone') ...
            && isfield(bas.zone,'elev')
        aux(1:K,2) = double(bas.zone.elev(1:K));
    elseif isfield(bas,'elev')
        aux(1:K,2) = double(bas.elev(1:K));
    elseif isfield(bas,'elev_mean')
        aux(1:K,2) = double(bas.elev_mean(1:K));
    end

    if isfield(bas,'area')
        a = double(bas.area(1:K));
        if median(a,'omitnan') < 1e7
            a = a * 1e6;
        end
        aux(1:K,3) = a;
    elseif isfield(bas,'area_km2')
        aux(1:K,3) = 1e6 * double(bas.area_km2(1:K));
    elseif isfield(bas,'area_calc')
        aux(1:K,3) = 1e6 * double(bas.area_calc(1:K));
    elseif isfield(bas,'zone') ...
            && isfield(bas.zone,'area')
        a = double(bas.zone.area(1:K));
        if median(a,'omitnan') < 1e7
            a = a * 1e6;
        end
        aux(1:K,3) = a;        
    end
end

% =====================================================
function aux = local_aux_from_attributes(dirAT,bas,aux)
% =====================================================

    f = fullfile(dirAT,'Catchment_attributes.csv');
    if ~isfile(f)
        return
    end

    delim = local_detect_delimiter(f);
    T = readtable(f,'FileType','text', ...
        'Delimiter',delim, ...
        'VariableNamingRule','preserve');
    T.Properties.VariableNames = ...
        matlab.lang.makeValidName( ...
        string(T.Properties.VariableNames));

    if ~ismember('ID', ...
            T.Properties.VariableNames)
        return
    end

    idT = local_at_id_strings(T.ID);
    idReq = local_at_id_strings(bas.id_gauge(:));
    [tf,loc] = ismember(idReq,idT);

    if ~any(tf)
        fprintf('\n');
        fprintf(['      Warning:read_meteo_AT: ' ...
            'no selected basin IDs ' ...
            'matched Catchment_attributes.csv.\n']);
        return
    end

    if ismember('elev_mean',T.Properties.VariableNames)
        aux(tf,2) = double(local_to_double( ...
            T{loc(tf),'elev_mean'}));
    end
    if ismember('area_calc',T.Properties.VariableNames)
        aux(tf,3) = 1e6 * double(local_to_double( ...
            T{loc(tf),'area_calc'}));
    end
end

function temp = local_get_temp_option(meteo)

    temp = 1;
    
    if isstruct(meteo) ...
            && isfield(meteo,'temp') ...
            && ~isempty(meteo.temp)
        temp = meteo.temp;
    end
    
    if ischar(temp) ...
            || isstring(temp)
        tok = regexp(string(temp), ...
            '^\s*(\d+)','tokens','once');
        if ~isempty(tok)
            temp = str2double(tok{1});
        else
            temp = 1;
        end
    end
    
    temp = round(double(temp));
    
    if ~any(temp == [1 2])
        temp = 1;
    end
end
