function [A,id_gauge,gname,zone] = read_attr_AT(dirD,bas)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%READ_ATTR_AT Read CAMELS-AT / LamaH-CE gauge and catchment attributes.
%
% Expected files in Data/CAMELS_AT:
%   Catchment_attributes.csv
%   Gauge_attributes.csv
%
% The reader combines Gauge_attributes and Catchment_attributes by ID.
% Gauge attributes are kept first, followed by catchment attributes. If a
% catchment variable has the same name as a gauge variable, the catchment
% variable is renamed with the suffix "_catch".
%
% Output follows the standard SAGE attribute-reader interface:
%   A          standardized selected attributes, nAttr x K
%   id_gauge   K x 1 string basin IDs
%   gname      K x 1 string display names
%   zone       structure with simple hydroclimatic zone labels
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    if nargin < 1 ...
            || isempty(dirD)
        error('read_attr_AT:missingDir', ...
            ['      Error:read_attr_AT: ' ...
            'dirD must be provided.']);
    end
    if ~isfolder(dirD)
        error('read_attr_AT:missingDir', ...
            ['      Error:read_attr_AT: ' ...
            'Attribute directory does ' ...
            'not exist: %s'],dirD);
    end
    if nargin < 2 ...
            || isempty(bas)
        bas = struct();
    end
    if ~isstruct(bas)
        error('read_attr_AT:badBas', ...
            ['      Error:read_attr_AT: ' ...
            'bas must be a structure.']);
    end
    % =========================================
    % ZONE CONTROL PARAMETERS (GLOBAL DEFAULTS)
    % =========================================
    if ~isfield(bas,'min_per_zone') ...
            || isempty(bas.min_per_zone)
        min_per_zone = 5;
    else
        min_per_zone = bas.min_per_zone;
    end    
    if ~isfield(bas,'max_zones') ...
            || isempty(bas.max_zones)
        max_zones = 8;
    else
        max_zones = bas.max_zones;
    end

    do_attr = ~isempty(bas);
    % If bas is omitted as input argument, use a small default 
    % climate-only attribute set.

    pr_table = 1;
    if do_attr ...
            && isstruct(bas) ...
            && isfield(bas,'pr_attr') ...
            && ~isempty(bas.pr_attr)
        pr_table = bas.pr_attr;
    end

    if do_attr
        if ~isstruct(bas) ...
                || ~isfield(bas,'id_attr') ...
                || isempty(bas.id_attr)
            error('read_attr_AT:missingIdAttr', ...
                ['      Error:read_attr_AT: ' ...
                'bas.id_attr must be provided ' ...
                'when attribute reading is requested.']);
        end
    end
    
    fprintf(['... Reading CAMELS-AT ' ...
        'basin attributes ']);

    fCatch = fullfile(dirD, ...
        'Catchment_attributes.csv');
    fGauge = fullfile(dirD, ...
        'Gauge_attributes.csv');

    caller = mfilename;
    must_exist(fCatch, ...
        'Catchment_attributes.csv',caller);
    must_exist(fGauge, ...
        'Gauge_attributes.csv',caller);

    C = local_read_at_csv(fCatch);
    G = local_read_at_csv(fGauge);

    if ~ismember('ID',C.Properties.VariableNames)
        error('read_attr_AT:missingIDCatchment', ...
            ['      Error:read_attr_AT: ' ...
            'Catchment_attributes.csv ' ...
            'has no ID column.']);
    end
    if ~ismember('ID',G.Properties.VariableNames)
        error('read_attr_AT:missingIDGauge', ...
            ['      Error:read_attr_AT: ' ...
            'Gauge_attributes.csv ' ...
            'has no ID column.']);
    end

    C.ID = normalize_at_gauge_id(C.ID);
    G.ID = normalize_at_gauge_id(G.ID);

    AA = local_merge_gauge_catchment_tables(G,C,dirD);

    % Convert LamaH projected coordinates to geographic lon/lat
    if ismember('lon',AA.Properties.VariableNames) ...
            && ismember('lat',AA.Properties.VariableNames)

        x = double(AA.lon(:));
        y = double(AA.lat(:));

        if any(abs(x) > 180 ...
                | abs(y) > 90)
            try
                p = projcrs(3035);  % ETRS89 / LAEA Europe
                [latDeg,lonDeg] = projinv(p,x,y);

                AA.gauge_lat = latDeg;
                AA.gauge_lon = lonDeg;
            catch ME
                error('read_attr_AT:coordTransformFailed', ...
                    ['      Error:read_attr_AT: ' ...
                    'Could not convert ' ...
                    'Austria projected coordinates ' ...
                    'to lon/lat: %s'], ...
                    ME.message);
            end
        else
            AA.gauge_lon = x;
            AA.gauge_lat = y;
        end
    end

    % Standardize catchment area field
    if ismember('area_gov', ...
            AA.Properties.VariableNames)
        AA.area = double(AA.area_gov(:));
    elseif ismember('area_calc', ...
            AA.Properties.VariableNames)
        AA.area = double(AA.area_calc(:));
    end

    id_all = string(AA.ID);
    id_num = str2double(id_all);
    if all(isfinite(id_num))
        [~,isrt] = sort(id_num);
    else
        [~,isrt] = sort(id_all);
    end
    AA = AA(isrt,:);
    id_all = id_all(isrt);

    if isfield(bas,'id_gauge') ...
            && ~isempty(bas.id_gauge)
        id_req = normalize_at_gauge_id( ...
            bas.id_gauge(:));
        [tf,locid] = ismember(id_req,id_all);
        if ~all(tf)
            missing = id_req(~tf);
            error('read_attr_AT:missingRequestedGauge', ...
                ['      Error:read_attr_AT: ' ...
                'Missing CAMELS-AT attributes ' ...
                'for %d requested ' ...
                'basin IDs, e.g. %s.'], ...
                numel(missing), ...
                char(missing(1)));
        end
        AA = AA(locid,:);
        id_gauge = id_req(:);
    else
        id_gauge = id_all(:);
    end
    % Leave this one 
    gname = local_at_gauge_names(AA,id_gauge);
    % has local call to 
    %  name = standardize_camels_gauge_names(name, ...
    %    'CAMELS_AT',id_gauge);
    
    ensure_at_gauge_information(dirD,AA,gname);
    region = erase(mfilename,'read_attr_');
    zone = classify_camels_all_zones(region,AA, ...
        min_per_zone,max_zones);

    % ------------------
    % Generic attributes
    % ------------------
    [A,labels] = build_attr_matrix(AA,bas, ...
        mfilename,pr_table);
    
    if pr_table == 1
        assignin('base', ...
            'SAGE_AT_attribute_labels',labels);
    end

    fprintf(' ... Done\n');

end

% ===================================
function T = local_read_at_csv(fname)
% ===================================

    delim = local_detect_delimiter(fname);
    opts = detectImportOptions(fname, ...
        'FileType','text', ...
        'Delimiter',delim, ...
        'VariableNamingRule','preserve');
    T = readtable(fname,opts);

    T.Properties.VariableNames = ...
        matlab.lang.makeUniqueStrings( ...
        matlab.lang.makeValidName(strtrim(string( ...
        T.Properties.VariableNames))));

    for j = 1:width(T)
        vn = T.Properties.VariableNames{j};
        if strcmp(vn,'ID')
            continue
        end
        T.(vn) = local_to_double_or_keep(T.(vn));
    end
end

% ========================================================
function AA = local_merge_gauge_catchment_tables(G,C,dirD)
% ========================================================

    G.ID = normalize_at_gauge_id(G.ID);
    C.ID = normalize_at_gauge_id(C.ID);
    
    idG = string(G.ID);
    idC = string(C.ID);
    
    idBoth = intersect(idG,idC,'stable');
    
    % Optional: also restrict to forcing files if available
    dirF = fullfile(dirD,'daily', ...
        'timeseries','forcing');
    if isfolder(dirF)
        D = dir(fullfile(dirF,'ID_*.csv'));
        idF = strings(numel(D),1);
        for i = 1:numel(D)
            tok = regexp(D(i).name, ...
                '^ID_(\d+)\.csv$', ...
                'tokens','once');
            if ~isempty(tok)
                idF(i) = string(tok{1});
            end
        end
        idF(idF == "") = [];
        idBoth = intersect(idBoth,idF,'stable');
    end
    
    % Sort numerically
    [~,ord] = sort(str2double(idBoth));
    idBoth = idBoth(ord);
    
    G = G(ismember(idG,idBoth),:);
    C = C(ismember(idC,idBoth),:);

    idG = string(G.ID);
    idC = string(C.ID);

    [~,iG] = ismember(idBoth,idG);
    [~,iC] = ismember(idBoth,idC);
   
    if any(iG == 0) ...
            || any(iC == 0)
        error('read_attr_AT:mergeFailed', ...
            ['      Error:read_attr_AT: ' ...
            'Could not align gauge ' ...
            'and catchment IDs.']);
    end

    G = G(iG,:);
    C = C(iC,:);

    % Start with gauge attributes, then append catchment attributes.
    AA = G;

    varsC = C.Properties.VariableNames;
    varsC(strcmp(varsC,'ID')) = [];

    for j = 1:numel(varsC)
        oldName = varsC{j};
        newName = oldName;
        if ismember(newName, ...
                AA.Properties.VariableNames)
            newName = [newName '_catch']; %#ok
        end
        newName = matlab.lang.makeUniqueStrings(newName, ...
            AA.Properties.VariableNames);
        AA.(newName) = C.(oldName);
    end

end

% ====================================
function id = normalize_at_gauge_id(x)
% ====================================

    x = string(x(:));
    x = strtrim(x);
    x = regexprep(x,'\.0+$','');
    x = regexprep(x,'^ID[_\-\s]*', ...
        '','ignorecase');
    x = regexprep(x,'[^0-9]','');

    if any(x == "")
        error('read_attr_AT:badGaugeID', ...
            ['      Error:read_attr_AT: ' ...
            'empty basin ID ' ...
            'after normalization.']);
    end
    id = x;
end

% ===============================================
function name = local_at_gauge_names(AA,id_gauge)
% ===============================================

    name = "AT_" + string(id_gauge(:));

    if ismember('name',AA.Properties.VariableNames) ...
            && ismember('river',AA.Properties.VariableNames)

        nm = strtrim(string(AA.name(:)));
        rv = strtrim(string(AA.river(:)));

        good = ~(ismissing(nm) | nm == "") ...
            & ~(ismissing(rv) | rv == "");

        name(good) = nm(good) + ": " + rv(good);

        goodNameOnly = ~(ismissing(nm) | nm == "") ...
            & (ismissing(rv) | rv == "");
        name(goodNameOnly) = nm(goodNameOnly);

        return
    end

    if ismember('name',AA.Properties.VariableNames)
        nm = strtrim(string(AA.name(:)));
        good = ~(ismissing(nm) | nm == "");
        name(good) = nm(good);
    end

    name = standardize_camels_gauge_names(name, ...
        'CAMELS_AT',id_gauge);
end

% =================================================
function ensure_at_gauge_information(dirD,AA,gname)
% =================================================

    fname = fullfile(dirD, ...
        'gauge_information.txt');
    if isfile(fname)
        return
    end

    T = table();
    T.gauge_id = normalize_at_gauge_id(AA.ID);
    T.gauge_name = string(gname(:));
    T.gauge_lat = get_numeric_column(AA, ...
        {'gauge_lat','lat', ...
        'latitude','lat_wgs84'});
    T.gauge_lon = get_numeric_column(AA, ...
        {'gauge_lon','lon', ...
        'longitude','lon_wgs84'});
    T.gauge_elev = get_numeric_column(AA, ...
        {'gauge_elev','elev', ...
        'elevation','elev_mean'});
    T.area_km2 = get_numeric_column(AA, ...
        {'area_calc','area_gov', ...
        'area','area_km2'});

    try
        writetable(T,fname, ...
            'Delimiter','\t','FileType','text');
    catch
    end
end

% ============================================
function delim = local_detect_delimiter(fname)
% ============================================

    fid = fopen(fname,'r');
    if fid < 0
        error('read_attr_AT:openFailed', ...
            'Could not open %s',fname);
    end
    c = onCleanup(@() fclose(fid));
    line = fgetl(fid);
    if ~ischar(line)
        error('read_attr_AT:emptyFile', ...
            'Empty file: %s',fname);
    end
    if count(string(line),";") ...
            >= count(string(line),",")
        delim = ';';
    else
        delim = ',';
    end
end

% =====================================
function x = local_to_double_or_keep(x)
% =====================================

    if isnumeric(x) ...
            || islogical(x)
        return
    end
    if iscell(x)
        xs = string(x);
    elseif ischar(x)
        xs = string(cellstr(x));
    elseif isstring(x) ...
            || iscategorical(x)
        xs = string(x);
    else
        return
    end

    xs = strtrim(xs);
    xs = erase(xs,'"');
    xs = strrep(xs,',','.');
    xs = regexprep(xs,'^(NA|NaN|null|NULL|nan|None|-9999)$', ...
        'NaN','ignorecase');
    y = str2double(xs);
    good = ~(ismissing(xs) | xs == "");

    isNum = isfinite(y);

    if any(good) ...
            && sum(isNum(good)) ...
            >= 0.9*sum(good)
        x = y;
    end
end
