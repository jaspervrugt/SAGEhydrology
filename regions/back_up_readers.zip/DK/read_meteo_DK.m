function [dat,aux] = read_meteo_DK(dirM,bas,split,meteo)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%READ_METEO_DK Read daily CAMELS-DK meteorological forcing.
%
% Expected file name:
%   CAMELS_DK_obs_based_<catch_id>.csv
%
% Expected columns:
%   time, catch_id, precipitation, temperature, pet, Qobs
%
% CAMELS-DK currently supports daily data only:
%   split.dt = 1
%
% PET options:
%   meteo.pet = 0   zero PET
%   otherwise       use supplied CAMELS-DK pet
%
% The source Qobs values are stored in m^3/s. They are converted to
% catchment-average runoff depth [mm/day] using catch_area [m^2]:
%
%   Q_mm_day = Qobs_m3_s * 86400 * 1000 / catch_area_m2
%
% Meteo retains the complete requested interval including spin-up.
% dat{k}.y_n contains only the scored period selected by split.idx.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    if nargin < 4 ...
            || isempty(meteo)
        meteo = struct();
    end
    if nargin < 3
        error('read_meteo_DK:badInput', ...
            ['      Error:read_meteo_DK: ' ...
            'Expected input signature ' ...
             '[dat,aux] = read_meteo_DK(dirM,bas,split,meteo).']);
    end

    split = local_prepare_split(split);
    dt = double(split.dt);
    if dt ~= 1
        error('read_meteo_DK:unsupportedDt', ...
            ['      Error:read_meteo_DK: ' ...
            'CAMELS-DK currently supports ' ...
             'dt = 1 (daily) only.']);
    end

    K = bas.K;
    ids = local_normalize_id(bas.id_gauge(:));
    dirTs = local_timeseries_dir(dirM);
    dirDK = local_dk_root(dirTs);

    dat = cell(K,1);
    aux = nan(K,3); % latitude [deg], elevation [m], area [m^2]

    try
        aux = local_aux_from_bas(bas,aux);
    catch
    end
    try
        aux = local_aux_from_attributes(dirDK,ids,aux);
    catch ME
        fprintf(['\n      Warning:read_meteo_DK: ' ...
            '%s\n'],ME.message);
    end

    req = local_requested_window(split);
    tReq = dateshift(datetime(req.time(:)),'start','day');
    nReq = numel(tReq);
    if nReq == 0
        error('read_meteo_DK:emptyWindow', ...
            ['      Error:read_meteo_DK: ' ...
            'Requested daily window is empty.']);
    end

    if isfield(split,'idx') ...
            && ~isempty(split.idx)
        idxScore = round(double(split.idx(:)));
        idxScore = idxScore(isfinite(idxScore) ...
            & idxScore >= 1 ...
            & idxScore <= nReq);
    else
        idxScore = (1:nReq).';
    end
    if isempty(idxScore)
        error('read_meteo_DK:badSplitIndex', ...
            ['      Error:read_meteo_DK: ' ...
            'split.idx is empty or outside ' ...
             'the requested time window.']);
    end

    petOption = 1;
    if isfield(meteo,'pet') ...
            && ~isempty(meteo.pet)
        petOption = double(meteo.pet);
    end

    cacheDir = fullfile(dirTs, ...
        sprintf('_cache_DK_daily_meteo_pet%d',petOption));
    if ~isfolder(cacheDir)
        mkdir(cacheDir);
    end

    fprintf(['... Reading daily CAMELS-DK ' ...
        'meteorological data files %3d%%'],0);

    for k = 1:K
        gid = ids(k);
        fname = fullfile(dirTs, ...
            sprintf('CAMELS_DK_obs_based_%s.csv',gid));

        if ~isfile(fname)
            fprintf('\n');
            error('read_meteo_DK:missingFile', ...
                ['      Error:read_meteo_DK: ' ...
                'Missing daily forcing file ' ...
                 'for basin %s: %s'],gid,fname);
        end

        t0 = tReq(1); t1 = tReq(end);
        t0.Format = 'yyyyMMdd'; t1.Format = 'yyyyMMdd';
        cacheFile = fullfile(cacheDir,sprintf( ...
            '%s_DK_daily_meteo_pet%d_%s_%s.mat', ...
            gid,petOption,char(t0),char(t1)));

        area_m2 = double(aux(k,3));

        % Defensive direct lookup in case auxiliary metadata supplied by
        % bas was incomplete or an earlier metadata operation failed.
        if ~isfinite(area_m2) || area_m2 <= 0
            area_m2 = local_lookup_area_m2(dirDK,gid);
            if isfinite(area_m2) && area_m2 > 0
                aux(k,3) = area_m2;
            end
        end

        if ~isfinite(area_m2) || area_m2 <= 0
            error('read_meteo_DK:badArea', ...
                ['      Error:read_meteo_DK: ' ...
                'Missing or invalid catchment area for basin %s. ' ...
                'A positive catch_area in m^2 is required to convert ' ...
                'Qobs from m^3/s to mm/day.'],gid);
        end

        useCache = false;
        if isfile(cacheFile)
            try
                S = load(cacheFile,'P','Ep','Tmean','Qall', ...
                    'bad_meteo','bad_q','src_datenum','area_m2_cache');
                inf0 = dir(fname);
                if isfield(S,'src_datenum') ...
                        && S.src_datenum >= inf0.datenum ...
                        && isfield(S,'area_m2_cache') ...
                        && abs(double(S.area_m2_cache) - area_m2) ...
                        <= max(1,1e-10*area_m2)
                    P = S.P;
                    Ep = S.Ep;
                    Tmean = S.Tmean;
                    Qall = S.Qall;
                    bad_meteo = S.bad_meteo;
                    bad_q = S.bad_q;
                    useCache = true;
                end
            catch
                useCache = false;
            end
        end

        if ~useCache
            [tFile,Pfile,Tfile,Epfile,QobsFile] = ...
                local_read_file(fname);

            P = nan(nReq,1);
            Ep = nan(nReq,1);
            Tmean = nan(nReq,1);
            Qall = nan(nReq,1);

            [tf,loc] = ismember(tReq,tFile);
            P(tf) = Pfile(loc(tf));
            Tmean(tf) = Tfile(loc(tf));
            Ep(tf) = Epfile(loc(tf));

            % Convert observed discharge from m^3/s to runoff depth mm/day.
            Qall(tf) = QobsFile(loc(tf)) .* 86400 .* 1000 ./ area_m2;

            if petOption == 0
                Ep(:) = 0;
            end

            bad_meteo = int64(find(~isfinite(P) ...
                | ~isfinite(Ep) ...
                | ~isfinite(Tmean)));
            bad_q = int64(find(~isfinite(Qall) | Qall < 0));
            Qall(Qall < 0) = NaN;

            try
                inf0 = dir(fname);
                src_datenum = inf0.datenum;
                area_m2_cache = area_m2;
                save(cacheFile,'P','Ep','Tmean','Qall', ...
                    'bad_meteo','bad_q','src_datenum', ...
                    'area_m2_cache','-v7.3');
            catch
            end
        end

        dat{k}.meteo.P = single(P);
        dat{k}.meteo.Ep = single(Ep);
        dat{k}.meteo.T = single(Tmean);
        dat{k}.meteo.Tmin = single(nan(size(Tmean)));
        dat{k}.meteo.Tmax = single(nan(size(Tmean)));
        dat{k}.meteo.bad = bad_meteo(:)';

        % Discharge contains the scored period only; spin-up is removed.
        Qscore = Qall(idxScore);
        dat{k}.y_n = single(Qscore);

        badmask_all = false(numel(Qall),1);
        iq = double(bad_q(:));
        iq = iq(isfinite(iq) & iq >= 1 & iq <= numel(Qall));
        badmask_all(round(iq)) = true;
        dat{k}.bad = badmask_all(idxScore).';

        dat{k}.gauge = gid;
        dat{k}.fname{1} = fname;
        dat{k}.fname{2} = fname;

        if ~isempty(bad_meteo)
            fprintf(['\n      Warning:read_meteo_DK: ' ...
                'basin %s ' ...
                'has %d invalid/missing daily meteo ' ...
                'rows in the requested window.\n'], ...
                gid,numel(bad_meteo));
            fprintf(['... Reading daily CAMELS-DK ' ...
                'meteorological data files %3d%%'], ...
                floor(100*k/K));
        end

        if mod(k,20) == 0 ...
                || k == K
            fprintf('\b\b\b\b%3d%%',floor(100*k/K));
            drawnow;
        end

        if isfield(meteo,'progressFcn') ...
                && ~isempty(meteo.progressFcn)
            try
                meteo.progressFcn(k);
            catch
            end
        end
    end

    fprintf('\b\b\b\b%s\n','... Done');

    if isfield(split,'local') ...
            && split.local ...
            && isfield(split,'rainfall_block') ...
            && split.rainfall_block
        dat = rainfall_rank_split(dat,split);
    end
end

% ==============================================
function [t,P,Tmean,Ep,Qobs] = local_read_file(fname)
% ==============================================
    opts = detectImportOptions(fname, ...
        'FileType','text', ...
        'Delimiter',',', ...
        'VariableNamingRule','preserve');
    T = readtable(fname,opts);
    T.Properties.VariableNames = ...
        matlab.lang.makeUniqueStrings( ...
        matlab.lang.makeValidName(strtrim(string( ...
        T.Properties.VariableNames))));

    required = {'time','precipitation', ...
        'temperature','pet','Qobs'};
    missing = required(~ismember(required, ...
        T.Properties.VariableNames));
    if ~isempty(missing)
        error('read_meteo_DK:missingColumns', ...
            ['      Error:read_meteo_DK: ' ...
            '%s is missing columns: %s'], ...
            fname,strjoin(missing,', '));
    end

    t = datetime(string(T.time), ...
        'InputFormat','yyyy-MM-dd');
    t = dateshift(t,'start','day');

    P = local_numeric(T.precipitation);
    Tmean = local_numeric(T.temperature);
    Ep = local_numeric(T.pet);
    Qobs = local_numeric(T.Qobs);

    [t,iu] = unique(t,'stable');
    P = P(iu);
    Tmean = Tmean(iu);
    Ep = Ep(iu);
    Qobs = Qobs(iu);

    [t,isrt] = sort(t);
    P = P(isrt);
    Tmean = Tmean(isrt);
    Ep = Ep(isrt);
    Qobs = Qobs(isrt);

    P(P < 0) = NaN;
    Ep(Ep < 0) = NaN;
    Qobs(Qobs < 0) = NaN;
end

% =========================================
function dirTs = local_timeseries_dir(dirM)
% =========================================
    root = char(string(dirM));
    candidates = {root, ...
        fullfile(root,'daily','timeseries'), ...
        fullfile(root,'timeseries'), ...
        fullfile(root,'Dynamics','Gauged_catchments'), ...
        fullfile(root,'Gauged_catchments'), ...
        fullfile(root,'CAMELS_DK','daily','timeseries'), ...
        fullfile(root,'CAMELS_DK','timeseries'), ...
        fullfile(root,'Data','CAMELS_DK','daily','timeseries'), ...
        fullfile(root,'Data','CAMELS_DK','timeseries')};

    for i = 1:numel(candidates)
        if isfolder(candidates{i}) ...
                && ~isempty(dir(fullfile(candidates{i}, ...
                'CAMELS_DK_obs_based_*.csv')))
            dirTs = candidates{i};
            return
        end
    end

    error('read_meteo_DK:missingTimeseriesDir', ...
        ['      Error:read_meteo_DK: ' ...
        'Cannot resolve CAMELS-DK observed ' ...
         'timeseries directory from %s.'],root);
end

% ===================================
function dirDK = local_dk_root(dirTs)
% ===================================
    dirDK = char(string(dirTs));
    [p,nm] = fileparts(dirDK);
    if strcmpi(nm,'timeseries') ...
            || strcmpi(nm,'Gauged_catchments')
        dirDK = p;
        [pDaily,nmDaily] = fileparts(dirDK);
        if strcmpi(nmDaily,'daily')
            dirDK = pDaily;
        end
    end
    [p,nm] = fileparts(dirDK);
    if strcmpi(nm,'Dynamics')
        dirDK = p;
    end
end

% =====================================================
function aux = local_aux_from_attributes(dirDK,ids,aux)
% =====================================================
    candidates = {dirDK,fullfile(dirDK,'Attributes')};
    f = '';
    for i = 1:numel(candidates)
        ff = fullfile(candidates{i},'CAMELS_DK_topography.csv');
        if isfile(ff)
            f = ff;
            break
        end
    end
    if isempty(f)
        return
    end

    T = readtable(f,'VariableNamingRule','preserve');
    T.Properties.VariableNames = ...
        matlab.lang.makeUniqueStrings( ...
        matlab.lang.makeValidName(strtrim(string( ...
        T.Properties.VariableNames))));
    idAll = local_normalize_id(T.catch_id);
    [tf,loc] = ismember(ids,idAll);

    % CAMELS-DK releases have used two naming conventions for these
    % topographic fields. Prefer the current names, while retaining support
    % for older local copies.
    xName = local_first_column(T, ...
        {'catch_outlet_lon','catch_outlet_x'});
    yName = local_first_column(T, ...
        {'catch_outlet_lat','catch_outlet_y'});
    zName = local_first_column(T, ...
        {'elev_mean','ele_mean'});

    required = {'catch_id','catch_area'};
    missing = required(~ismember(required,T.Properties.VariableNames));
    if ~isempty(missing)
        error('read_meteo_DK:missingTopoColumns', ...
            ['CAMELS_DK_topography.csv is missing required columns: %s'], ...
            strjoin(missing,', '));
    end

    % Load elevation and area independently of coordinate conversion.
    % A missing Mapping Toolbox or a projection error must not prevent
    % discharge conversion, which only requires catch_area.
    elevAll = local_numeric(T.(zName));
    areaAll = local_numeric(T.catch_area);

    aux(tf,2) = elevAll(loc(tf));
    aux(tf,3) = areaAll(loc(tf)); % source unit is m^2

    % Convert outlet coordinates when projection support is available.
    % The current CAMELS-DK names contain "lon" and "lat", but the values
    % are projected ETRS89 / UTM zone 32N coordinates rather than degrees.
    % Keep latitude as NaN if conversion cannot be performed.
    try
        x = local_numeric(T.(xName));
        y = local_numeric(T.(yName));

        if exist('projcrs','file') == 2 ...
                && exist('projinv','file') == 2
            p = projcrs(25832); % ETRS89 / UTM zone 32N
            [lat,~] = projinv(p,x,y);
            aux(tf,1) = lat(loc(tf));
        else
            warning('read_meteo_DK:noProjectionSupport', ...
                ['Mapping Toolbox projection functions are not ' ...
                'available. Latitude will remain NaN, but area, ' ...
                'elevation, meteorology, and discharge are retained.']);
        end
    catch ME
        warning('read_meteo_DK:coordTransformFailed', ...
            ['Could not convert CAMELS-DK outlet coordinates: %s. ' ...
            'Latitude will remain NaN; area and elevation are retained.'], ...
            ME.message);
    end
end

% ==============================================
function name = local_first_column(T,candidates)
% ==============================================
    names = string(T.Properties.VariableNames);
    name = '';

    for i = 1:numel(candidates)
        j = find(strcmpi(names,string(candidates{i})),1,'first');
        if ~isempty(j)
            name = char(names(j));
            return
        end
    end

    error('read_meteo_DK:missingTopoColumns', ...
        'CAMELS_DK_topography.csv is missing all aliases: %s', ...
        strjoin(candidates,', '));
end

% ============================================
function area_m2 = local_lookup_area_m2(dirDK,gid)
% ============================================
    area_m2 = NaN;

    candidates = {dirDK,fullfile(dirDK,'Attributes')};
    f = '';
    for i = 1:numel(candidates)
        ff = fullfile(candidates{i},'CAMELS_DK_topography.csv');
        if isfile(ff)
            f = ff;
            break
        end
    end
    if isempty(f)
        return
    end

    try
        opts = detectImportOptions(f, ...
            'FileType','text', ...
            'Delimiter',',', ...
            'VariableNamingRule','preserve');
        T = readtable(f,opts);
        T.Properties.VariableNames = ...
            matlab.lang.makeUniqueStrings( ...
            matlab.lang.makeValidName(strtrim(string( ...
            T.Properties.VariableNames))));

        if ~ismember('catch_id',T.Properties.VariableNames) ...
                || ~ismember('catch_area',T.Properties.VariableNames)
            return
        end

        idsAll = local_normalize_id(T.catch_id);
        j = find(idsAll == local_normalize_id(gid),1,'first');
        if isempty(j)
            return
        end

        a = local_numeric(T.catch_area(j));
        if ~isempty(a) && isfinite(a(1)) && a(1) > 0
            area_m2 = double(a(1));
        end
    catch
        area_m2 = NaN;
    end
end

% ========================================
function aux = local_aux_from_bas(bas,aux)
% ========================================
    K = size(aux,1);
    if isfield(bas,'lat') ...
            && numel(bas.lat) >= K
        aux(:,1) = double(bas.lat(1:K));
    elseif isfield(bas,'gauge_lat') ...
            && numel(bas.gauge_lat) >= K
        aux(:,1) = double(bas.gauge_lat(1:K));
    end
    if isfield(bas,'elev') ...
            && numel(bas.elev) >= K
        aux(:,2) = double(bas.elev(1:K));
    elseif isfield(bas,'gauge_elev') ...
            && numel(bas.gauge_elev) >= K
        aux(:,2) = double(bas.gauge_elev(1:K));
    end
    if isfield(bas,'area') ...
            && numel(bas.area) >= K
        a = double(bas.area(1:K));
        % SAGE convention is m^2. Convert only when values clearly look
        % like km^2 rather than m^2.
        finiteA = a(isfinite(a) & a > 0);
        if ~isempty(finiteA) && median(finiteA) < 1e5
            a = 1e6 .* a;
        end
        aux(:,3) = a;
    end
end

% =========================================
function split = local_prepare_split(split)
% =========================================
    if exist('prepare_split','file') == 2
        split = prepare_split(split);
    end
end

% ==========================================
function req = local_requested_window(split)
% ==========================================
    if exist('build_requested_window','file') == 2
        try
            req0 = build_requested_window(split,true);
            if isfield(req0,'read_start_N') ...
                    && isfield(req0,'read_end_N')
                tref = datetime(1950,10,1);
                t0 = tref + days(double(req0.read_start_N));
                t1 = tref + days(double(req0.read_end_N));
                req.time = (dateshift(t0,'start','day'):days(1): ...
                    dateshift(t1,'start','day')).';
                return
            elseif isfield(req0,'time') ...
                    && ~isempty(req0.time)
                req.time = dateshift(datetime(req0.time(:)),'start','day');
                return
            end
        catch
        end
    end

    starts = NaT(0,1);
    ends = NaT(0,1);
    sf = {'ds','dts','des','d1', ...
        'dt_train0','dt_eval0','dt_spin0'};
    ef = {'de','dte','dee','d2', ...
        'dt_train1','dt_eval1'};

    for i = 1:numel(sf)
        if isfield(split,sf{i}) ...
                && ~isempty(split.(sf{i}))
            starts(end+1,1) = local_datetime(split.(sf{i})); %#ok<AGROW>
        end
    end
    for i = 1:numel(ef)
        if isfield(split,ef{i}) ...
                && ~isempty(split.(ef{i}))
            ends(end+1,1) = local_datetime(split.(ef{i})); %#ok<AGROW>
        end
    end

    starts = starts(~isnat(starts));
    ends = ends(~isnat(ends));
    if isempty(starts) || isempty(ends)
        error('read_meteo_DK:unknownWindow', ...
            ['      Error:read_meteo_DK: ' ...
            'Could not determine requested ' ...
             'time window from split.']);
    end

    spinup = 0;
    if isfield(split,'spinup') ...
            && ~isempty(split.spinup)
        spinup = max(0,round(double(split.spinup)));
    elseif isfield(split,'n_spin') ...
            && ~isempty(split.n_spin)
        spinup = max(0,round(double(split.n_spin)));
    end

    t0 = dateshift(min(starts),'start','day') - days(spinup);
    t1 = dateshift(max(ends),'start','day');
    req.time = (t0:days(1):t1).';
end

% ============================
function t = local_datetime(x)
% ============================
    if isdatetime(x)
        t = x(1);
    elseif isnumeric(x)
        if x(1) > 5e5
            t = datetime(x(1),'ConvertFrom','datenum');
        else
            t = datetime(x(1),'ConvertFrom','posixtime');
        end
    else
        s = string(x(1));
        fmts = ["yyyy-MM-dd","dd-MMM-yyyy","dd/MM/yyyy","MM/dd/yyyy"];
        t = NaT;
        for i = 1:numel(fmts)
            try
                t = datetime(s,'InputFormat',fmts(i));
                if ~isnat(t), return; end
            catch
            end
        end
        t = datetime(s);
    end
end

% =================================
function id = local_normalize_id(x)
% =================================
    if isnumeric(x)
        id = compose('%.0f',double(x(:)));
    else
        id = strip(string(x(:)));
        n = str2double(id);
        ok = isfinite(n);
        id(ok) = compose('%.0f',n(ok));
    end
end

% ===========================
function x = local_numeric(v)
% ===========================
    if isnumeric(v) ...
            || islogical(v)
        x = double(v(:));
    else
        s = strip(string(v));
        s(ismissing(s) ...
            | s == "" ...
            | strcmpi(s,"NA") ...
            | strcmpi(s,"NAN") ...
            | strcmpi(s,"NULL")) = missing;
        x = str2double(s);
    end
end
