function [A,id_gauge,gname,zone] = read_attr_DK(dirD,bas)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%READ_ATTR_DK Read CAMELS-DK catchment attributes.
%
% Expected files in Data/CAMELS_DK (or Data/CAMELS_DK/Attributes):
%   CAMELS_DK_climate.csv
%   CAMELS_DK_geology.csv
%   CAMELS_DK_landuse.csv
%   CAMELS_DK_signature_obs_based.csv
%   CAMELS_DK_soil.csv
%   CAMELS_DK_topography.csv
%
% Only basins with an observed time-series file
% CAMELS_DK_obs_based_<catch_id>.csv are retained when a timeseries
% directory is present.
%
% OUTPUT:
%   A          standardized selected attributes, nAttr x K
%   id_gauge   K x 1 string basin identifiers
%   gname      K x 1 string display names
%   zone       hydroclimatic-zone structure
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    if nargin < 1 ...
            || isempty(dirD)
        error('read_attr_DK:missingDir', ...
            ['      Error:read_attr_DK: ' ...
            'dirD must be provided.']);
    end
    if nargin < 2 ...
            || isempty(bas)
        bas = struct();
    end
    if ~isstruct(bas)
        error('read_attr_DK:badBas', ...
            ['      Error:read_attr_DK: ' ...
            'bas must be a structure.']);
    end

    min_per_zone = local_bas_value(bas,'min_per_zone',5);
    max_zones = local_bas_value(bas,'max_zones',8);
    pr_table = local_bas_value(bas,'pr_attr',1);

    do_attr = ~isempty(fieldnames(bas));
    if do_attr && (~isfield(bas,'id_attr') ...
            || isempty(bas.id_attr))
        error('read_attr_DK:missingIdAttr', ...
            ['      Error:read_attr_DK: ' ...
            'bas.id_attr must be provided ' ...
             'when attribute reading is requested.']);
    end

    fprintf('... Reading CAMELS-DK basin attributes ');

    dirA = local_attribute_dir(dirD);
    files = { ...
        'CAMELS_DK_topography.csv', ...
        'CAMELS_DK_climate.csv', ...
        'CAMELS_DK_geology.csv', ...
        'CAMELS_DK_landuse.csv', ...
        'CAMELS_DK_soil.csv'};

    T = local_read_dk_csv(fullfile(dirA,files{1}));
    for i = 2:numel(files)
        Ti = local_read_dk_csv(fullfile(dirA,files{i}));
        T = outerjoin(T,Ti, ...
            'Keys','catch_id', ...
            'MergeKeys',true, ...
            'Type','left');
    end

    % Hydrologic signatures exist only for the observed/gauged subset.
    fSig = fullfile(dirA, ...
        'CAMELS_DK_signature_obs_based.csv');
    if isfile(fSig)
        Ts = local_read_dk_csv(fSig);
        T = outerjoin(T,Ts, ...
            'Keys','catch_id', ...
            'MergeKeys',true, ...
            'Type','left');
    end

    T.catch_id = local_normalize_id(T.catch_id);

    % Standard aliases used by SAGE zone classification and map plotting.
    if ismember('catch_outlet_lon', ...
            T.Properties.VariableNames) ...
            && ismember('catch_outlet_lat', ...
            T.Properties.VariableNames)
        x = double(T.catch_outlet_lon(:));
        y = double(T.catch_outlet_lat(:));

        if any(abs(x) > 180 ...
                | abs(y) > 90)
            try
                p = projcrs(25832); % ETRS89 / UTM zone 32N
                [latDeg,lonDeg] = projinv(p,x,y);
                T.gauge_lat = latDeg;
                T.gauge_lon = lonDeg;
            catch ME
                error('read_attr_DK:coordTransformFailed', ...
                    ['      Error:read_attr_DK: ' ...
                    'Could not convert Danish ' ...
                     'projected coordinates ' ...
                     'to longitude/latitude: %s'], ...
                     ME.message);
            end
        else
            T.gauge_lon = x;
            T.gauge_lat = y;
        end
    end

    if ismember('catch_area',T.Properties.VariableNames)
        % Source field is in m2.
        T.area = double(T.catch_area(:))/1e6;
    end
    if ismember('elev_mean',T.Properties.VariableNames)
        T.gauge_elev = double(T.elev_mean(:));
    end

    % Restrict the 3330 catchment attribute database to installed observed
    % time-series basins (304 in the published observed subset).
    idsInstalled = local_installed_timeseries_ids(dirD);
    if ~isempty(idsInstalled)
        keep = ismember(string(T.catch_id),idsInstalled);
        T = T(keep,:);
    end

    idAll = string(T.catch_id);
    idNum = str2double(idAll);
    if all(isfinite(idNum))
        [~,isrt] = sort(idNum);
    else
        [~,isrt] = sort(idAll);
    end
    T = T(isrt,:);
    idAll = idAll(isrt);

    if isfield(bas,'id_gauge') ...
            && ~isempty(bas.id_gauge)
        idReq = local_normalize_id(bas.id_gauge(:));
        [tf,loc] = ismember(idReq,idAll);
        if ~all(tf)
            miss = idReq(~tf);
            error('read_attr_DK:missingRequestedGauge', ...
                ['      Error:read_attr_DK: ' ...
                'Missing CAMELS-DK attributes ' ...
                 'for %d requested basin IDs, e.g. %s.'], ...
                 numel(miss),char(miss(1)));
        end
        T = T(loc,:);
        id_gauge = idReq(:);
    else
        id_gauge = idAll(:);
    end

    gname = "CAMELS-DK " + id_gauge;

    zone = classify_camels_all_zones('DK',T, ...
        min_per_zone,max_zones);

    if do_attr
        [A,labels] = build_attr_matrix(T, ...
            bas,mfilename,pr_table);
        if pr_table == 1
            assignin('base', ...
                'SAGE_DK_attribute_labels',labels);
        end
    else
        % Small default climate/topography set for calls without bas.
        bas0 = struct();
        C = attr_catalog('CAMELS_DK');
        bas0.id_attr = C.default_ids;
        [A,~] = build_attr_matrix(T,bas0,mfilename,0);
    end

    fprintf(' ... Done\n');
end

% =======================================
function dirA = local_attribute_dir(dirD)
% =======================================
    candidates = {char(string(dirD)), ...
        fullfile(char(string(dirD)),'Attributes'), ...
        fullfile(char(string(dirD)),'CAMELS_DK'), ...
        fullfile(char(string(dirD)),'CAMELS_DK','Attributes')};

    for i = 1:numel(candidates)
        if isfile(fullfile(candidates{i},'CAMELS_DK_topography.csv'))
            dirA = candidates{i};
            return
        end
    end

    error('read_attr_DK:missingAttributes', ...
        ['      Error:read_attr_DK: Cannot locate CAMELS-DK attribute ' ...
         'files from %s.'],char(string(dirD)));
end

% ===================================
function T = local_read_dk_csv(fname)
% ===================================
    if ~isfile(fname)
        error('read_attr_DK:missingFile', ...
            '      Error:read_attr_DK: Missing file: %s',fname);
    end

    opts = detectImportOptions(fname, ...
        'FileType','text', ...
        'Delimiter',',', ...
        'VariableNamingRule','preserve');
    T = readtable(fname,opts);

    T.Properties.VariableNames = matlab.lang.makeUniqueStrings( ...
        matlab.lang.makeValidName(strtrim(string( ...
        T.Properties.VariableNames))));

    if ~ismember('catch_id',T.Properties.VariableNames)
        error('read_attr_DK:missingCatchID', ...
            '      Error:read_attr_DK: %s has no catch_id column.',fname);
    end
    T.catch_id = local_normalize_id(T.catch_id);

    for j = 1:width(T)
        vn = T.Properties.VariableNames{j};
        if strcmp(vn,'catch_id')
            continue
        end
        T.(vn) = local_to_double_or_keep(T.(vn));
    end
end

% =================================================
function ids = local_installed_timeseries_ids(dirD)
% =================================================
    ids = strings(0,1);
    roots = {char(string(dirD)), ...
        fullfile(char(string(dirD)),'daily','timeseries'), ...
        fullfile(char(string(dirD)),'Dynamics'), ...
        fullfile(char(string(dirD)),'Dynamics','Gauged_catchments'), ...
        fullfile(char(string(dirD)),'Gauged_catchments')};

    for i = 1:numel(roots)
        if ~isfolder(roots{i})
            continue
        end
        D = dir(fullfile(roots{i},'CAMELS_DK_obs_based_*.csv'));
        if isempty(D)
            continue
        end
        nm = string({D.name});
        ids = extractBetween(nm, ...
            "CAMELS_DK_obs_based_",".csv");
        ids = local_normalize_id(ids(:));
        return
    end
end

% =================================
function id = local_normalize_id(x)
% =================================
    if isnumeric(x)
        id = compose('%.0f',double(x(:)));
    else
        id = strip(string(x(:)));
        n = str2double(id);
        ok = isfinite(n);
        id(ok) = compose('%.0f',n(ok));
    end
end

% =====================================
function v = local_to_double_or_keep(v)
% =====================================
    if isnumeric(v) ...
            || islogical(v)
        return
    end
    s = strip(string(v));
    s(ismissing(s) ...
        | s == "" ...
        | strcmpi(s,"NA") ...
        | strcmpi(s,"NAN") ...
        | strcmpi(s,"NULL")) = missing;
    x = str2double(s);
    if all(ismissing(s) ...
            | isfinite(x))
        v = x;
    else
        v = s;
    end
end

% =====================================================
function value = local_bas_value(bas,name,defaultValue)
% =====================================================
    if isfield(bas,name) ...
            && ~isempty(bas.(name))
        value = bas.(name);
    else
        value = defaultValue;
    end
end
