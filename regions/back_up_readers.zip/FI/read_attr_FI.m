function [A,id_gauge,gname,zone] = read_attr_FI(dirD,bas)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%READ_ATTR_FI Read catchment attributes of CAMELS-FI dataset.
%
% SYNOPSIS:
%   [A,id_gauge,gname,zone] = read_attr_FI(dirD,bas)
%
% INPUT:
%   dirD        Directory with CAMELS-FI attribute CSV files,
%               normally Data/CAMELS_FI
%   bas         OPTIONAL structure with fields
%    .id_gauge   requested CAMELS-FI basin IDs, e.g. "935", "1190-1191"
%    .id_attr    selected attribute IDs
%    .pr_attr    print attribute table [1/0]
%
% OUTPUT:
%   A           r x K matrix of standardized selected attributes
%   id_gauge    K x 1 string array with CAMELS-FI basin identifiers
%   gname       K x 1 string array with gauge names
%   zone        structure with simple CAMELS-FI hydroclimatic grouping
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% © Written by Jasper A. Vrugt, June 2026                                 %
% University of California, Irvine                                        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    if nargin < 1 ...
            || isempty(dirD)
        error('read_attr_FI:missingDir', ...
            ['      Error:read_attr_FI: ' ...
            'dirD must be provided.']);
    end

    if ~isfolder(dirD)
        error('read_attr_FI:missingDir', ...
            ['      Error:read_attr_FI: ' ...
            'Attribute directory ' ...
            'does not exist: %s'],dirD);
    end

    if nargin < 2 ...
            || isempty(bas)
        bas = struct();
    end

    if ~isstruct(bas)
        error('read_attr_FI:badBas', ...
            ['      Error:read_attr_FI: ' ...
            'bas must be a structure.']);
    end
    % =========================================
    % ZONE CONTROL PARAMETERS (GLOBAL DEFAULTS)
    % =========================================
    if ~isfield(bas,'min_per_zone') ...
            || isempty(bas.min_per_zone)
        min_per_zone = 5;
    else
        min_per_zone = bas.min_per_zone;
    end    
    if ~isfield(bas,'max_zones') ...
            || isempty(bas.max_zones)
        max_zones = 8;
    else
        max_zones = bas.max_zones;
    end
    
    pr_table = 1;
    if isfield(bas,'pr_attr') ...
            && ~isempty(bas.pr_attr)
        pr_table = bas.pr_attr;
    elseif ~isfield(bas,'id_attr') ...
            || isempty(bas.id_attr)
        pr_table = 0;
    end

    files = local_fi_attribute_files();
    caller = mfilename;
    for i = 1:numel(files)
        must_exist(fullfile(dirD, ...
            files{i}),files{i},caller);
    end

    fprintf('... Reading CAMELS-FI basin attributes ');

    meta  = read_fi_table(fullfile(dirD, ...
        'CAMELS_FI_meta_attributes.csv'));
    clim  = read_fi_table(fullfile(dirD, ...
        'CAMELS_FI_climatic_attributes.csv'));
    topo  = read_fi_table(fullfile(dirD, ...
        'CAMELS_FI_topographic_attributes.csv'));
    soil  = read_fi_table(fullfile(dirD, ...
        'CAMELS_FI_soil_attributes.csv'));
    geol  = read_fi_table(fullfile(dirD, ...
        'CAMELS_FI_geology_attributes.csv'));
    land  = read_fi_table(fullfile(dirD, ...
        'CAMELS_FI_landcover_attributes.csv'));
    hinf  = read_fi_table(fullfile(dirD, ...
        'CAMELS_FI_humaninfluence_attributes.csv'));
    hydro = read_fi_table(fullfile(dirD, ...
        'CAMELS_FI_hydrologic_attributes.csv'));

    % Metadata is the master table because it contains names, location,
    % area, and administrative metadata.
    AA = meta;
    AA = join_fi_attributes(AA,clim);
    AA = join_fi_attributes(AA,topo);
    AA = join_fi_attributes(AA,soil);
    AA = join_fi_attributes(AA,geol);
    AA = join_fi_attributes(AA,land);
    AA = join_fi_attributes(AA,hinf);
    AA = join_fi_attributes(AA,hydro);

    AA.gauge_id = normalize_fi_gauge_id(AA.gauge_id);
    [~,isrt] = sort(AA.gauge_id);
    AA = AA(isrt,:);
    id_all = string(AA.gauge_id(:));

    if isfield(bas,'id_gauge') ...
            && ~isempty(bas.id_gauge)
        id_req = ...
            normalize_fi_gauge_id(bas.id_gauge(:));
        [tf,loc] = ismember(id_req,id_all);
        if ~all(tf)
            missing = id_req(~tf);
            error('read_attr_FI:missingRequestedGauge', ...
                ['      Error:read_attr_FI: ' ...
                'Missing CAMELS-FI ' ...
                'attributes for %d requested ' ...
                'basin IDs, e.g. %s.'], ...
                numel(missing),char(missing(1)));
        end
        AA = AA(loc,:);
        id_gauge = id_req(:);
    else
        id_gauge = id_all(:);
    end

    if ismember('gauge_name', ...
            AA.Properties.VariableNames)
        gname = string(AA.gauge_name);
    elseif ismember('basin_name', ...
            AA.Properties.VariableNames)
        gname = string(AA.basin_name);
    else
        gname = "Gauge " + id_gauge;
    end
    % gname = local_standardize_fi_names(gname(:));
    gname = standardize_camels_gauge_names(gname, ...
        'CAMELS_FI',id_gauge);

    ensure_fi_gauge_information(dirD,AA);
    region = erase(mfilename,'read_attr_');
    zone = classify_camels_all_zones(region,AA, ...
        min_per_zone,max_zones);

    % ------------------
    % Generic attributes
    % ------------------
    [A,labels] = build_attr_matrix(AA,bas, ...
        mfilename,pr_table);

    if pr_table == 1
        assignin('base', ...
            'SAGE_FI_attribute_labels', ...
            labels);
    end

    fprintf(' ... Done\n');

end

% ===============================
function T = read_fi_table(fname)
% ===============================
    opts = detectImportOptions(fname, ...
        'FileType','text');
    opts.VariableNamingRule = ...
        'preserve';
    opts = detectImportOptions(fname, ...
        'FileType','text');
    opts.VariableNamingRule = 'preserve';
    
    if any(strcmp(opts.VariableNames, ...
            'gauge_id'))
        opts = setvartype(opts, ...
            'gauge_id','char');
    end

    T = readtable(fname,opts);

    T.Properties.VariableNames = ...
        matlab.lang.makeValidName( ...
        T.Properties.VariableNames, ...
        'ReplacementStyle','delete');
    T.Properties.VariableNames = ...
        matlab.lang.makeUniqueStrings( ...
        T.Properties.VariableNames);

    if ~ismember('gauge_id',T.Properties.VariableNames)
        error('read_attr_FI:missingGaugeID', ...
            ['      Error:read_attr_FI: ' ...
            'File %s does not contain gauge_id.'],fname);
    end

    T.gauge_id = normalize_fi_gauge_id(T.gauge_id);
    bad = ismissing(T.gauge_id) | T.gauge_id == "";
    T(bad,:) = [];
    
    [~,ia] = unique(T.gauge_id,'stable');
    T = T(ia,:);
    T = sortrows(T,'gauge_id');
end

% ==================================
function T = join_fi_attributes(T,U)
% ==================================
    U.gauge_id = normalize_fi_gauge_id(U.gauge_id);

    dup = intersect(T.Properties.VariableNames, ...
        U.Properties.VariableNames);
    dup(strcmp(dup,'gauge_id')) = [];
    if ~isempty(dup)
        U(:,dup) = [];
    end

    T = outerjoin(T,U, ...
        'Keys','gauge_id', ...
        'MergeKeys',true, ...
        'Type','left');
end

% ===========================================
function ensure_fi_gauge_information(dirD,AA)
% ===========================================
    f_info = fullfile(dirD, ...
        'gauge_information.txt');
    if isfile(f_info)
        return
    end

    id = normalize_fi_gauge_id(AA.gauge_id);
    if ismember('gauge_name', ...
            AA.Properties.VariableNames)
        nm = string(AA.gauge_name);
    else
        nm = "Gauge " + id;
    end

    lat = get_numeric_column(AA, ...
        {"gauge_lat"});
    lon = get_numeric_column(AA, ...
        {"gauge_lon"});
    area = get_numeric_column(AA, ...
        {"area"});

    try
        fid = fopen(f_info,'w');
        if fid < 0
            error('Could not open file for writing.');
        end
        cleanup = onCleanup(@() fclose(fid));

        fprintf(fid,['HUC_02\tGAGE_ID' ...
            '\tGAGE_NAME\tLAT\tLONG\t' ...
            'DRAINAGE AREA (KM^2)\n']);

        for k = 1:numel(id)
            gnm = string(nm(k));
            gnm = replace(gnm,char(9),' ');
            gnm = replace(gnm,newline,' ');
            fprintf(fid, ...
                'FI\t%s\t%s\t%.6f\t%.6f\t%.6f\n', ...
                char(id(k)), ...
                char(gnm),lat(k),lon(k),area(k));
        end

        fprintf(['\n      Wrote CAMELS-FI gauge ' ...
            'information file: %s'],f_info);
    catch ME
        warning('read_attr_FI:gaugeInfoWriteFailed', ...
            ['      Warning:read_attr_FI: ' ...
            'Could not write %s.\n%s'], ...
            f_info,ME.message);
    end
end

% ====================================
function id = normalize_fi_gauge_id(v)
% ====================================
    s = string(v);
    s = strip(s);
    s = erase(s,'"');
    s = erase(s,"'");
    s = regexprep(s,'\.0+$','');
    s(ismissing(s)) = "";
    id = s(:);
end

% % ========================================
% function s = local_standardize_fi_names(s)
% % ========================================
%     s = string(s);
%     s = strip(s);
%     s(ismissing(s)) = "";
%     s = regexprep(s,'[_]+',' ');
%     s = s(:);
% end

% =========================================
function files = local_fi_attribute_files()
% =========================================
    files = { ...
        'CAMELS_FI_climatic_attributes.csv', ...
        'CAMELS_FI_geology_attributes.csv', ...
        'CAMELS_FI_humaninfluence_attributes.csv', ...
        'CAMELS_FI_hydrologic_attributes.csv', ...
        'CAMELS_FI_landcover_attributes.csv', ...
        'CAMELS_FI_meta_attributes.csv', ...
        'CAMELS_FI_soil_attributes.csv', ...
        'CAMELS_FI_topographic_attributes.csv'};
end
