function [dat,aux] = read_meteo_FI(dirM,bas,split,meteo)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%READ_METEO_FI Read daily CAMELS-FI meteorological and discharge data.
%
% SYNOPSIS:
%   [dat,aux] = read_meteo_FI(dirM,bas,split,meteo)
%
% INPUT:
%   dirM        Directory with CAMELS-FI daily time-series files, normally
%               Data/CAMELS_FI/daily/timeseries
%   bas         Structure with selected basins
%    .K          number of selected basins
%    .id_gauge   Kx1 gauge identifiers, e.g. "935", "1190-1191"
%   split       Time-split structure; daily only, with split.idx used to
%               remove spin-up/burn-in from discharge
%   meteo       Meteorological choices
%    .pet        1 = pet [default], 2 = pet_fmi, 3 = pet_singer, 0 = zero
%    .temp       1 = temperature_mean [default], 2 = min, 3 = max, 4 = gmin
%    .progressFcn optional GUI progress callback
%
% OUTPUT:
%   dat{k}.meteo.P   precipitation [mm/day], including spin-up
%   dat{k}.meteo.Ep  PET [mm/day], including spin-up
%   dat{k}.meteo.T   air temperature [deg C], including spin-up
%   dat{k}.y_n       specific discharge [mm/day], spin-up removed
%   dat{k}.bad       bad discharge mask, same length as y_n; missing and
%                    nonpositive discharge values are flagged
%   aux              Kx3: latitude [deg], elevation [m], area [m^2]
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% © Written by Jasper A. Vrugt, June 2026                                 %
% University of California, Irvine                                        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    if nargin < 1 ...
            || isempty(dirM)
        error('read_meteo_FI:missingDir', ...
            ['      Error:read_meteo_FI: ' ...
            'dirM must be provided.']);
    end

    dirM = local_fi_timeseries_dir(dirM);

    if ~isfolder(dirM)
        error('read_meteo_FI:missingDir', ...
            ['      Error:read_meteo_FI: ' ...
            'Timeseries directory ' ...
            'does not exist: %s'],dirM);
    end

    if nargin < 2 || ~isstruct(bas) ...
            || ~isfield(bas,'id_gauge') ...
            || isempty(bas.id_gauge)
        error('read_meteo_FI:missingBasins', ...
            ['      Error:read_meteo_FI: ' ...
            'bas.id_gauge must be provided.']);
    end

    split = prepare_split(split);
    dt = double(split.dt);
    if dt ~= 1
        error('read_meteo_FI:unsupportedDt', ...
            ['      Error:read_meteo_FI: ' ...
            'CAMELS-FI reader ' ...
            'supports daily data ' ...
            'only [split.dt = 1].']);
    end

    if ~isfield(bas,'K') ...
            || isempty(bas.K)
        K = numel(bas.id_gauge);
    else
        K = double(bas.K);
    end

    id_GAUGE = normalize_fi_gauge_id( ...
        bas.id_gauge(:));

    petChoice = 1;
    tempChoice = 1;
    if nargin >= 4 ...
            && isstruct(meteo)
        if isfield(meteo,'pet') ...
                && ~isempty(meteo.pet)
            petChoice = double(meteo.pet(1));
        end
        if isfield(meteo,'temp') ...
                && ~isempty(meteo.temp)
            tempChoice = double(meteo.temp(1));
        end
    end

    dat = cell(K,1);
    aux = nan(K,3);

    cache_dir = fullfile(dirM, ...
        '_cache_FI_daily');
    if ~isfolder(cache_dir)
        mkdir(cache_dir);
    end

    rootFI = fileparts(dirM);
    [pDaily,nmDaily] = fileparts(rootFI);
    if strcmpi(nmDaily,'daily')
        rootFI = pDaily;
    end
    Tmeta = local_read_fi_table_optional( ...
        fullfile(rootFI, ...
        'CAMELS_FI_meta_attributes.csv'));
    Ttopo = local_read_fi_table_optional( ...
        fullfile(rootFI, ...
        'CAMELS_FI_topographic_attributes.csv'));

    fprintf(['... Reading daily CAMELS-FI ' ...
        'meteorological data files %3d%%'],0);
    flag_progress = true;

    req = build_requested_window(split,true);

    for k = 1:K
        gid = id_GAUGE(k);
        fname = ...
            local_find_fi_timeseries_file( ...
            dirM,gid);

        gidSafe = regexprep(char(gid), ...
            '[^A-Za-z0-9]','_');
        % qbad2 invalidates older caches that did not treat zero
        % discharge as missing/bad.
        cache_file = fullfile(cache_dir, ...
            sprintf(['%s_FI_daily_p%d_' ...
            't%d_pet%d_qbad2.mat'], ...
            gidSafe,1,tempChoice,petChoice));

        [Pfull,Epfull,Tfull,Qfull,bad_meteo_full, ...
            bad_q_full,fileStartN,fileEndN, ...
            fileStartDT,fileEndDT] = ...
            local_load_or_build_fi_cache( ...
            fname,cache_file, ...
            tempChoice,petChoice,gid);

        if req.read_start_N < fileStartN ...
                || req.read_end_N > fileEndN
            if flag_progress
                fprintf('\n');
            end
            error('read_meteo_FI:periodOutsideFile', ...
                ['      Error:read_meteo_FI: ' ...
                'requested period outside ' ...
                'CAMELS-FI file for basin %s.' ...
                '\nFile covers %s to %s.'], ...
                char(gid),string(fileStartDT), ...
                string(fileEndDT));
        end

        id_read0 = int64(req.read_start_N ...
            - fileStartN) + 1;
        id_read1 = int64(req.read_end_N ...
            - fileStartN) + 1;
        id_r = double(id_read0:id_read1);

        P = double(Pfull(id_r));
        Ep = double(Epfull(id_r));
        Temp = double(Tfull(id_r));
        Qall = double(Qfull(id_r));

        dat{k}.meteo.P = single(P);
        dat{k}.meteo.Ep = single(Ep);
        dat{k}.meteo.T = single(Temp);

        idx_score = double(split.idx(:));
        idx_score = idx_score(idx_score >= 1 ...
            & idx_score <= numel(Qall));
        if isempty(idx_score)
            idx_score = (1:numel(Qall)).';
        end

        Q = Qall(idx_score);
        dat{k}.y_n = single(Q);
        dat{k}.gauge = gid;
        dat{k}.fname{1} = fname;
        dat{k}.fname{2} = fname;

        id0d = double(id_read0);
        id1d = double(id_read1);

        bad_meteo_full = double(bad_meteo_full(:));
        bad_q_full = double(bad_q_full(:));

        bad_meteo = bad_meteo_full( ...
            bad_meteo_full >= id0d ...
            & bad_meteo_full <= id1d) ...
            - id0d + 1;
        dat{k}.meteo.bad = bad_meteo(:).';

        bad_q_all = bad_q_full( ...
            bad_q_full >= id0d ...
            & bad_q_full <= id1d) ...
            - id0d + 1;
        badmask_all = false(1,numel(Qall));
        bad_q_all = bad_q_all(isfinite(bad_q_all) ...
            & bad_q_all >= 1 ...
            & bad_q_all <= numel(Qall));
        badmask_all(round(bad_q_all)) = true;
        dat{k}.bad = badmask_all(idx_score);

        aux(k,:) = local_fi_aux(Tmeta,Ttopo,gid);

        if mod(k,5) == 0 ...
                || k == K
            pct = floor(100*k/K);
            fprintf('\b\b\b\b%3d%%',pct);
            drawnow;
        end

        if nargin >= 4 ...
                && isstruct(meteo) ...
                && isfield(meteo,'progressFcn') ...
                && ~isempty(meteo.progressFcn)
            meteo.progressFcn(k);
        end
    end

    if flag_progress
        fprintf('\b\b\b\b%s\n','... Done');
    end

    if isfield(split,'local') ...
            && split.local ...
            && isfield(split,'rainfall_block') ...
            && split.rainfall_block
        dat = rainfall_rank_split(dat,split);
    end
end

% ======================
% Local helper functions
% ======================
function dirM = local_fi_timeseries_dir(dirM)
    dirM = char(string(dirM));
    if isfolder(fullfile(dirM,'daily','timeseries'))
        dirM = fullfile(dirM,'daily','timeseries');
    elseif isfolder(fullfile(dirM, ...
            'timeseries'))
        dirM = fullfile(dirM, ...
            'timeseries');
    end
end

function fname = local_find_fi_timeseries_file(dirM,gid)
    gid = char(normalize_fi_gauge_id(gid));
    patterns = { ...
        sprintf(['CAMELS_FI_hydromet_' ...
        'timeseries_%s_*.csv'],gid), ...
        sprintf('*_%s_*.csv',gid), ...
        sprintf('*%s*.csv',gid)};

    D = [];
    for i = 1:numel(patterns)
        D = dir(fullfile(dirM,patterns{i}));
        if ~isempty(D)
            break
        end
    end

    if isempty(D)
        error('read_meteo_FI:missingFile', ...
            ['      Error:read_meteo_FI: ' ...
            'Missing CAMELS-FI ' ...
            'hydromet timeseries ' ...
            'file for basin %s.'],gid);
    end

    fname = fullfile(D(1).folder,D(1).name);
end

function [P,Ep,Tair,Q,bad_meteo,bad_q, ...
    fileStartN,fileEndN,fileStartDT,fileEndDT] = ...
    local_load_or_build_fi_cache(fname,cache_file, ...
    tempChoice,petChoice,gid)

    use_cache = false;
    if isfile(cache_file)
        try
            info_src = dir(fname);
            info_cch = dir(cache_file);
            use_cache = info_cch.datenum ...
                >= info_src.datenum;
        catch
            use_cache = false;
        end
    end

    if use_cache
        S = load(cache_file,'P','Ep','Tair','Q', ...
            'bad_meteo','bad_q', ...
            'fileStartN','fileEndN', ...
            'fileStartDT','fileEndDT');
        P = S.P;
        Ep = S.Ep;
        Tair = S.Tair;
        Q = S.Q;
        bad_meteo = S.bad_meteo;
        bad_q = S.bad_q;
        fileStartN = S.fileStartN;
        fileEndN = S.fileEndN;
        fileStartDT = S.fileStartDT;
        fileEndDT = S.fileEndDT;
        return
    end

    [P,Ep,Tair,Q,bad_meteo,bad_q, ...
        fileStartN,fileEndN,fileStartDT,fileEndDT] = ...
        local_read_fi_timeseries_full( ...
        fname,tempChoice,petChoice,gid);

    save(cache_file,'P','Ep','Tair','Q', ...
        'bad_meteo','bad_q', ...
        'fileStartN','fileEndN', ...
        'fileStartDT','fileEndDT', ...
        'tempChoice','petChoice', ...
        'gid','-v7.3');
end

function [P,Ep,Tair,Q,bad_meteo,bad_q, ...
    fileStartN,fileEndN,fileStartDT,fileEndDT] = ...
    local_read_fi_timeseries_full( ...
    fname,tempChoice,petChoice,gid)

    Traw = readtable(fname, ...
        'VariableNamingRule','preserve');
    Traw.Properties.VariableNames = ...
        matlab.lang.makeValidName( ...
        Traw.Properties.VariableNames, ...
        'ReplacementStyle','delete');

    need = {'date', ...
        'precipitation', ...
        'discharge_spec'};
    for i = 1:numel(need)
        if ~ismember(need{i}, ...
                Traw.Properties.VariableNames)
            error('read_meteo_FI:missingColumn', ...
                ['      Error:read_meteo_FI: ' ...
                'Required column "%s" ' ...
                'not found in %s.'], ...
                need{i},fname);
        end
    end

    t = datetime(string(Traw.date), ...
        'InputFormat','yyyy-MM-dd');
    if any(isnat(t))
        t = datetime(string(Traw.date));
    end
    if any(isnat(t))
        error('read_meteo_FI:badDate', ...
            ['      Error:read_meteo_FI: ' ...
            'Could not parse date ' ...
            'column in %s.'],fname);
    end

    fileStartDT = t(1);
    fileEndDT = t(end);
    fileStartN = int64(days(fileStartDT ...
        - datetime(1950,10,1)));
    fileEndN = int64(days(fileEndDT ...
        - datetime(1950,10,1)));

    P = single(max(local_to_double( ...
        Traw.precipitation),0));

    Tcol = local_fi_temp_column( ...
        Traw,tempChoice);
    Tair = single(local_to_double( ...
        Traw.(Tcol)));

    if petChoice == 0
        Ep = single(zeros(height(Traw),1));
    else
        Ecol = local_fi_pet_column( ...
            Traw,petChoice,gid);
        Ep = single(max(local_to_double( ...
            Traw.(Ecol)),0));
    end

    Q = single(local_to_double( ...
        Traw.discharge_spec));

    % CAMELS-FI zero/nonpositive discharge values are treated as
    % unavailable observations. Converting them to NaN ensures that they
    % cannot accidentally enter calculations that do not inspect bad_q,
    % while bad_q explicitly excludes them from the loss function.
    bad_q_mask = ~isfinite(double(Q)) ...
        | double(Q) <= 0;
    Q(bad_q_mask) = NaN;

    bad_meteo = int64(find(~isfinite(double(P)) ...
        | ~isfinite(double(Ep)) ...
        | ~isfinite(double(Tair))));
    bad_q = int64(find(bad_q_mask));
end

function col = local_fi_temp_column(T,tempChoice)

    switch tempChoice
        case 1
            prefs = {'temperature_mean', ...
                'temperature_gmin'};
        case 2
            prefs = {'temperature_min', ...
                'temperature_mean'};
        case 3
            prefs = {'temperature_max', ...
                'temperature_mean'};
        case 4
            prefs = {'temperature_gmin', ...
                'temperature_mean'};
        otherwise
            error('read_meteo_FI:badTempChoice', ...
                ['      Error:read_meteo_FI: ' ...
                'meteo.temp must be ' ...
                '1, 2, 3, or 4 for CAMELS-FI.']);
    end

    col = local_find_existing_var( ...
        T.Properties.VariableNames,prefs);

end

function col = local_fi_pet_column(T,petChoice,gid)
    switch petChoice
        case 1
            prefs = {'pet', ...
                'pet_fmi','pet_singer'};
        case 2
            prefs = {'pet_fmi', ...
                'pet','pet_singer'};
        case 3
            prefs = {'pet_singer', ...
                'pet','pet_fmi'};
        otherwise
            error('read_meteo_FI:badPetChoice', ...
                ['      Error:read_meteo_FI: ' ...
                'meteo.pet must be ' ...
                '0, 1, 2, or 3 for CAMELS-FI.']);
    end
    col = local_find_existing_var( ...
        T.Properties.VariableNames,prefs);
    if isempty(col)
        error('read_meteo_FI:missingPET', ...
            ['      Error:read_meteo_FI: ' ...
            'Requested PET column ' ...
            'not found for basin %s.'], ...
            char(gid));
    end
end

function T = local_read_fi_table_optional(fname)
    if isfile(fname)
        T = readtable(fname, ...
            'VariableNamingRule','preserve');
        T.Properties.VariableNames = ...
            matlab.lang.makeValidName( ...
            T.Properties.VariableNames, ...
            'ReplacementStyle','delete');
        if ismember('gauge_id', ...
                T.Properties.VariableNames)
            T.gauge_id = ...
                normalize_fi_gauge_id(T.gauge_id);
        end
    else
        T = table();
    end
end

function aux = local_fi_aux(Tmeta,Ttopo,gid)
    aux = [NaN NaN NaN];
    gid = normalize_fi_gauge_id(gid);

    if ~isempty(Tmeta) ...
            && height(Tmeta) > 0
        idcol = local_find_existing_var( ...
            Tmeta.Properties.VariableNames, ...
            {'gauge_id','gaugeid','id'});
        if ~isempty(idcol)
            ids = normalize_fi_gauge_id( ...
                Tmeta.(idcol));
            jj = find(ids == gid,1,'first');
            if ~isempty(jj)
                latcol = local_find_existing_var( ...
                    Tmeta.Properties.VariableNames, ...
                    {'gauge_lat','lat','latitude'});
                areacol = local_find_existing_var( ...
                    Tmeta.Properties.VariableNames, ...
                    {'area','area_km2', ...
                    'catchment_area'});
                if ~isempty(latcol)
                    v = Tmeta.(latcol);
                    aux(1) = local_to_double(v(jj));
                end
                if ~isempty(areacol)
                    a = local_to_double( ...
                        Tmeta.(areacol)(jj));
                    if isfinite(a) ...
                            && a < 1e7
                        a = a * 1e6;
                    end
                    aux(3) = a;
                end
            end
        end
    end

    if ~isempty(Ttopo) ...
            && height(Ttopo) > 0
        idcol = local_find_existing_var( ...
            Ttopo.Properties.VariableNames, ...
            {'gauge_id','gaugeid','id'});
        if ~isempty(idcol)
            ids = normalize_fi_gauge_id( ...
                Ttopo.(idcol));
            jj = find(ids == gid,1,'first');
            if ~isempty(jj)
                elevcol = local_find_existing_var( ...
                    Ttopo.Properties.VariableNames, ...
                    {'elev_mean','elevation', ...
                    'elev_gauge','elev'});
                if ~isempty(elevcol)
                    aux(2) = ...
                        local_to_double(Ttopo.(elevcol)(jj));
                end
            end
        end
    end
end

function col = local_find_existing_var(vn,cands)
    col = '';
    idx = local_find_var(vn,cands);
    if ~isempty(idx)
        col = vn{idx};
    end
end

function idx = local_find_var(vn,cands)
    normf = @(s) lower( ...
        regexprep(char(s),'[^a-z0-9]',''));
    vnn = cellfun(normf,vn, ...
        'UniformOutput',false);
    idx = [];
    for k = 1:numel(cands)
        hit = find(strcmp(vnn, ...
            normf(cands{k})),1,'first');
        if ~isempty(hit)
            idx = hit;
            return
        end
    end
end

function x = local_to_double(v)
    if isnumeric(v) ...
            || islogical(v)
        x = double(v(:));
        return
    end
    s = string(v);
    s = strip(s);
    s(ismissing(s) ...
        | strcmpi(s,'NA') ...
        | strcmpi(s,'NAN') ...
        | strcmpi(s,'NULL') ...
        | s == '') = missing;
    x = str2double(s);
    x = x(:);
end

function id = normalize_fi_gauge_id(v)
    s = string(v);
    s = strip(s);
    s = erase(s,'"');
    s = erase(s,"'");
    s = regexprep(s,'\.0+$','');
    s(ismissing(s)) = "";
    id = s(:);
end
