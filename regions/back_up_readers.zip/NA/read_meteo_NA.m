function [dat,aux] = read_meteo_NA(dirM,bas,split,meteo,regionName)
%READ_METEO_NA Read daily Namibia GRDC-Caravan forcing and Q.
% P, FAO Penman-Monteith PET, and streamflow are supplied in mm/day;
% temperature is supplied in degrees C.
    if nargin<4, meteo=struct(); end %#ok<NASGU>
    if nargin<5 || isempty(regionName), regionName='Namibia'; end
    split=prepare_split(split);
    if double(split.dt)~=1, error('read_meteo_NA:dailyOnly','Namibia GRDC-Caravan is daily.'); end
    if ~endsWith(dirM,fullfile('daily','timeseries'),'IgnoreCase',true), dirM=fullfile(dirM,'daily','timeseries'); end
    ids=local_id(bas.id_gauge(:)); K=numel(ids); dat=cell(K,1);
    aux=local_aux(dirM,ids);
    req=build_requested_window(split,true); tref=datetime(1950,10,1);
    tReq=(tref+days(double(req.read_start_N:req.read_end_N))).'; n=numel(tReq);
    idx=double(split.idx(:)); idx=round(idx(idx>=1&idx<=n));
    prt = reader_progress('start', ...
        sprintf('... Reading daily %s meteorological data',regionName),K);
    for k=1:K
        f=fullfile(dirM,['GRDC_' char(ids(k)) '.csv']);
        if ~isfile(f), error('read_meteo_NA:missingFile','Missing %s.',f); end
        T=readtable(f,'VariableNamingRule','preserve'); vn=T.Properties.VariableNames;
        dt=local_datetime(T,local_pick(vn,{'date','Date','datetime','time'}));
        P=local_num(T,local_pick(vn,{'total_precipitation_sum'}));
        Ta=local_num(T,local_pick(vn,{'temperature_2m_mean'}));
        Ep=local_num(T,local_pet(vn));
        Q=local_num(T,local_pick(vn,{'streamflow','streamflow_mm','discharge_spec'}));
        p=nan(n,1); e=p; tt=p; q=p; [tf,loc]=ismember(tReq,dt);
        p(tf)=P(loc(tf)); e(tf)=Ep(loc(tf)); tt(tf)=Ta(loc(tf)); q(tf)=Q(loc(tf));
        p=max(0,p); e=max(0,e);
        dat{k}.meteo.P=single(p); dat{k}.meteo.Ep=single(e); dat{k}.meteo.T=single(tt);
        dat{k}.meteo.bad=find(~isfinite(p)|~isfinite(e)|~isfinite(tt)).';
        dat{k}.y_n=single(q(idx)); dat{k}.bad=(~isfinite(q(idx))|q(idx)<0).';
        dat{k}.gauge=ids(k); dat{k}.fname={f};
        prt = reader_progress('update',prt,k);
        if isfield(meteo,'progressFcn')&&~isempty(meteo.progressFcn), try, meteo.progressFcn(k); catch, end, end
    end
    reader_progress('finish',prt,K);
    if isfield(split,'local')&&split.local&&isfield(split,'rainfall_block')&&split.rainfall_block, dat=rainfall_rank_split(dat,split); end
end
function n=local_pick(vn,c), n=''; for j=1:numel(c), q=find(strcmpi(vn,c{j}),1); if ~isempty(q), n=vn{q}; return; end, end, error('read_meteo_NA:missingColumn','Missing column: %s.',strjoin(c,', ')); end
function n=local_pet(vn)
    n=''; for j=1:numel(vn), s=lower(vn{j}); if contains(s,'potential_evaporation')&&contains(s,'penman'), n=vn{j}; return; end, end
    error('read_meteo_NA:missingPET','FAO Penman-Monteith PET column is missing.');
end
function x=local_num(T,n), x=double(T.(n)); x=x(:); end
function d=local_datetime(T,n)
    x=T.(n); if isdatetime(x), d=x; else, d=datetime(string(x)); end; d=dateshift(d(:),'start','day');
end
function aux=local_aux(dirM,ids)
    root=fileparts(fileparts(dirM)); f=fullfile(root,'attributes_other_grdc.csv');
    aux=nan(numel(ids),3); if ~isfile(f), return; end
    T=readtable(f,'VariableNamingRule','preserve'); vn=T.Properties.VariableNames;
    key=local_pick(vn,{'gauge_id','station_id'});
    lat=local_pick(vn,{'gauge_lat','gauge_latitude','lat','latitude'});
    area=local_pick(vn,{'area','area_km2','catchment_area','area_calc'});
    gid=local_id(T.(key));
    elev=''; q=find(strcmpi(vn,'gauge_elevation'),1); if ~isempty(q), elev=vn{q}; end
    E=[]; fe=fullfile(root,'attributes_additional_grdc.csv');
    if isempty(elev)&&isfile(fe)
        E=readtable(fe,'VariableNamingRule','preserve');
        en=E.Properties.VariableNames;
        ek=local_pick(en,{'gauge_id','station_id'});
        ev=local_pick(en,{'altitude','gauge_elevation'});
        eid=local_id(E.(ek));
    end
    for k=1:numel(ids)
        q=find(gid==ids(k),1); if isempty(q), continue; end
        aux(k,1)=double(T.(lat)(q)); aux(k,3)=double(T.(area)(q))*1e6;
        if ~isempty(elev), aux(k,2)=double(T.(elev)(q));
        elseif ~isempty(E), z=find(eid==ids(k),1); if ~isempty(z)&&double(E.(ev)(z))>-900, aux(k,2)=double(E.(ev)(z)); end
        end
    end
end
function id=local_id(x)
    id=upper(strip(string(x(:))));
    id=regexprep(id,'^GRDC[_-]','');
    id=regexprep(id,'\.0+$','');
end
