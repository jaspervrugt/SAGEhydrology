function dat = read_Q_NA(~,~,dat,~,~,~)
%READ_Q_NA No-op: GRDC-Caravan streamflow is read with meteorology.
end
