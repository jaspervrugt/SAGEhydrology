function [A,id_gauge,gname,zone] = read_attr_NA(dirD,bas,regionCode,shortCode)
%READ_ATTR_NA Read filtered Namibia GRDC-Caravan attributes.

    if nargin < 2 || isempty(bas), bas=struct(); end
    if nargin < 3 || isempty(regionCode), regionCode='CAMELS_NA'; end
    if nargin < 4 || isempty(shortCode), shortCode='NA'; end
    files = {'attributes_other_grdc.csv','attributes_caravan_grdc.csv', ...
        'attributes_hydroatlas_grdc.csv','attributes_additional_grdc.csv'};
    T=cell(size(files));
    for j=1:numel(files)
        f=fullfile(dirD,files{j});
        if ~isfile(f), error('read_attr_NA:missingFile','Missing %s.',f); end
        T{j}=readtable(f,'VariableNamingRule','preserve');
        T{j}.Properties.VariableNames=matlab.lang.makeValidName( ...
            T{j}.Properties.VariableNames,'ReplacementStyle','delete');
        key=local_name(T{j},{'gauge_id','gaugeid','station_id'});
        T{j}.gauge_id=local_id(T{j}.(key));
        if ~strcmp(key,'gauge_id'), T{j}(:,key)=[]; end
    end
    AA=T{1};
    for j=2:numel(T)
        dup=intersect(AA.Properties.VariableNames,T{j}.Properties.VariableNames);
        dup(strcmp(dup,'gauge_id'))=[]; T{j}(:,dup)=[];
        AA=outerjoin(AA,T{j},'Keys','gauge_id','MergeKeys',true,'Type','left');
    end
    AA=local_alias(AA,'gauge_lat',{'gauge_lat','gauge_latitude','lat','latitude'});
    AA=local_alias(AA,'gauge_lon',{'gauge_lon','gauge_longitude','lon','longitude'});
    AA=local_alias(AA,'area',{'area','area_km2','catchment_area','area_calc'});
    aliases={ ...
      'p_mean',{'p_mean','precipitation_mean'}; ...
      'pet_mean_fao_pm',{'pet_mean_fao_pm','pet_mean_FAO_PM','potential_evaporation_mean_fao_pm'}; ...
      'aridity_fao_pm',{'aridity_fao_pm','aridity_FAO_PM','aridity'}; ...
      'p_seasonality',{'seasonality_FAO_PM','p_seasonality','precipitation_seasonality'}; ...
      'frac_snow',{'frac_snow','fraction_snow'}; ...
      'high_prec_freq',{'high_prec_freq'}; 'high_prec_dur',{'high_prec_dur'}; ...
      'low_prec_freq',{'low_prec_freq'}; 'low_prec_dur',{'low_prec_dur'}};
    for j=1:size(aliases,1), AA=local_alias(AA,aliases{j,1},aliases{j,2},true); end
    [id_all,ix]=sort(local_id(AA.gauge_id)); AA=AA(ix,:);
    nameVar=local_name(AA,{'gauge_name','station_name','name'},true);
    if isempty(nameVar), gname_all=id_all; else, gname_all=string(AA.(nameVar)); end
    gname_all=standardize_camels_gauge_names(gname_all,regionCode,id_all);
    gname_all=local_na_title_case(gname_all);
    if isfield(bas,'id_gauge') && ~isempty(bas.id_gauge)
        id_req=local_id(bas.id_gauge(:)); [tf,loc]=ismember(id_req,id_all);
        if ~all(tf), error('read_attr_NA:missingGauge','Missing Namibia gauge %s.',id_req(find(~tf,1))); end
        AA=AA(loc,:); id_gauge=id_req; gname=gname_all(loc);
    else, id_gauge=id_all; gname=gname_all; end
    minz=local_field(bas,'min_per_zone',5); maxz=local_field(bas,'max_zones',8);
    zone=classify_camels_all_zones(shortCode,AA,minz,maxz);
    [A,labels]=build_attr_matrix(AA,bas,mfilename,local_field(bas,'pr_attr',1));
    assignin('base',['SAGE_' upper(shortCode) '_attribute_labels'],labels);
    local_gauge_info(dirD,AA,id_gauge,gname,shortCode);
    fprintf('... Reading %s GRDC-Caravan attributes ... Done\n',shortCode);
end

function T=local_alias(T,new,candidates,optional)
    if nargin<4, optional=false; end
    if ismember(new,T.Properties.VariableNames), return; end
    old=local_name(T,candidates,optional);
    if isempty(old), T.(new)=nan(height(T),1); else, T.(new)=double(T.(old)); end
end
function n=local_name(T,candidates,optional)
    if nargin<3, optional=false; end
    n=''; vn=T.Properties.VariableNames;
    for k=1:numel(candidates), q=find(strcmpi(vn,candidates{k}),1); if ~isempty(q), n=vn{q}; return; end, end
    if ~optional, error('read_attr_NA:missingColumn','Missing required column (%s).',strjoin(candidates,', ')); end
end
function id=local_id(x)
    id=upper(strip(string(x(:))));
    id=regexprep(id,'^GRDC[_-]','');
    id=regexprep(id,'\.0+$','');
end
function v=local_field(S,f,d), v=d; if isfield(S,f)&&~isempty(S.(f)), v=S.(f); end, end
function names=local_na_title_case(names)
% Convert all-uppercase GRDC station labels to readable title case.
    names=string(names(:));
    for k=1:numel(names)
        c=char(lower(strip(names(k)))); capitalize=true;
        for j=1:numel(c)
            if isstrprop(c(j),'alpha')
                if capitalize, c(j)=upper(c(j)); end
                capitalize=false;
            elseif any(c(j)==[' ' '-' '/' '('])
                capitalize=true;
            elseif c(j)==''''
                capitalize=true;
            end
        end
        names(k)=string(c);
    end
end
function local_gauge_info(dirD,A,id,nm,shortCode)
    f=fullfile(dirD,'gauge_information.txt');
    fid=fopen(f,'w'); if fid<0, return; end; c=onCleanup(@()fclose(fid));
    fprintf(fid,'HUC_02\tGAGE_ID\tGAGE_NAME\tLAT\tLONG\tDRAINAGE AREA (KM^2)\n');
    for k=1:numel(id), fprintf(fid,'%s\t%s\t%s\t%.7f\t%.7f\t%.6f\n',shortCode,char(id(k)),char(nm(k)),double(A.gauge_lat(k)),double(A.gauge_lon(k)),double(A.area(k))); end
end
