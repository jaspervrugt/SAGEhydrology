function [A,id_gauge,gname,zone]=read_attr_EE(dirD,bas)
%READ_ATTR_EE Read filtered Estonia GRDC-Caravan attributes.
    [A,id_gauge,gname,zone]=read_attr_NA(dirD,bas,'CAMELS_EE','EE');
end
