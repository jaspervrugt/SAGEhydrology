function [dat,aux]=read_meteo_EE(dirM,bas,split,meteo)
%READ_METEO_EE Read daily Estonia GRDC-Caravan forcing and discharge.
    [dat,aux]=read_meteo_NA(dirM,bas,split,meteo,'Estonia');
end
