function R=region_config_EE()
%REGION_CONFIG_EE Defaults for Estonia GRDC-Caravan.
    R=region_config_GRDC('EE','Estonia',51,47,39,8, ...
        '01/10/1972','30/09/1992','01/10/1992','30/09/2012');
end
