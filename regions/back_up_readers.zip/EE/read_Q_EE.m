function dat=read_Q_EE(~,~,dat,~,~,~)
%READ_Q_EE No-op: GRDC-Caravan streamflow is read with meteorology.
end
