function [dat,aux] = read_meteo_CZ(dirM,bas,split,meteo)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%READ_METEO_CZ Read CAMELS-CZ daily meteorology and streamflow.
%
% Expected directory:
%   Data/CAMELS_CZ/timeseries/camelscz_*.csv
%
% split.dt must be 1. Source choices:
%   meteo.precip: 1 CHMI, 2 ERA5-Land, 3 CHMI/ERA5-Land combined
%   meteo.temp:   1 CHMI, 2 ERA5-Land, 3 CHMI/ERA5-Land combined
%   meteo.pet:    1 CHMI FAO-PM, 2 ERA5-Land FAO-PM,
%                 3 ERA5-Land native potential evaporation
%
% Streamflow is already in mm/day.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    if nargin < 4 ...
            || isempty(meteo)
        meteo = struct();
    end
    if nargin < 1 ...
            || isempty(dirM)
        error('read_meteo_CZ:missingDir', ...
            'dirM must be provided.');
    end
    dirM = local_cz_timeseries_dir(dirM);
    if ~isfolder(dirM)
        error('read_meteo_CZ:missingDir', ...
            ['CAMELS-CZ daily timeseries ' ...
            'directory does not exist: %s'],dirM);
    end
    if nargin < 2 ...
            || ~isstruct(bas) ...
            || ~isfield(bas,'id_gauge') ...
            || isempty(bas.id_gauge)
        error('read_meteo_CZ:missingBasins', ...
            'bas.id_gauge must be provided.');
    end

    split = local_prepare_cz_split(split);
    if double(split.dt) ~= 1
        error('read_meteo_CZ:dailyOnly', ...
            ['The supplied CAMELS-CZ ' ...
            'archive is daily; split.dt must equal 1.']);
    end

    pChoice = local_choice(meteo,'precip',1);
    tChoice = local_choice(meteo,'temp',1);
    eChoice = local_choice(meteo,'pet',1);

    ids = local_normalize_cz_id(bas.id_gauge(:));
    K = numel(ids);
    dat = cell(K,1);
    aux = nan(K,3);

    rootCZ = local_cz_root_from_dirM(dirM);
    A = local_read_cz_other_attributes(rootCZ);
    cacheDir = fullfile(dirM,'_cache_CZ_daily');
    if ~isfolder(cacheDir)
        mkdir(cacheDir);
    end

    fprintf(['... Reading daily CAMELS-CZ ' ...
        'meteorological data files %3d%%'],0);

    for k = 1:K
        gid = ids(k);
        fname = local_find_cz_file(dirM,gid);
        cacheFile = fullfile(cacheDir,sprintf( ...
            '%s_CZ_daily_p%d_t%d_pet%d.mat', ...
            matlab.lang.makeValidName(char(gid)), ...
            pChoice,tChoice,eChoice));

        [Pfull,Epfull,Tfull,Qfull,badM,badQ, ...
            fileStartDT,fileEndDT,fileStartN,fileEndN] = ...
            local_load_or_build_cz_cache( ...
            fname,cacheFile,pChoice, ...
            tChoice,eChoice);

        req = local_requested_window(split,fileStartN,fileEndN);
        if req.read_start_N < fileStartN ...
                || req.read_end_N > fileEndN
            fprintf('\n');
            error('read_meteo_CZ:periodOutsideFile', ...
                ['Requested period lies ' ...
                'outside CAMELS-CZ file for %s. ' ...
                'File covers %s to %s.'], ...
                char(gid),string(fileStartDT), ...
                string(fileEndDT));
        end

        i0 = double(req.read_start_N-fileStartN)+1;
        i1 = double(req.read_end_N-fileStartN)+1;
        ir = i0:i1;

        Pall = double(Pfull(ir));
        Eall = double(Epfull(ir));
        Tall = double(Tfull(ir));
        Qall = double(Qfull(ir));

        if isfield(split,'idx') ...
                && ~isempty(split.idx)
            idxScore = double(split.idx(:));
        else
            idxScore = (1:numel(Qall))';
        end
        idxScore = idxScore(idxScore>=1 ...
            & idxScore<=numel(Qall));

        dat{k}.meteo.P = single(Pall);
        dat{k}.meteo.Ep = single(Eall);
        dat{k}.meteo.T = single(Tall);
        dat{k}.y_n = single(Qall(idxScore));
        dat{k}.gauge = gid;
        dat{k}.fname = {fname};

        bm = double(badM(:));
        bm = bm(bm>=i0 & bm<=i1)-i0+1;
        dat{k}.meteo.bad = bm(:)';

        bq = double(badQ(:));
        bq = bq(bq>=i0 & bq<=i1)-i0+1;
        mask = false(1,numel(Qall));
        bq = bq(bq>=1 & bq<=numel(Qall));
        mask(round(bq)) = true;
        dat{k}.bad = mask(idxScore);

        aux(k,:) = local_cz_aux(A,gid);

        if mod(k,5)==0 || k==K
            fprintf('\b\b\b\b%3d%%',floor(100*k/K));
            drawnow;
        end

        if isfield(meteo,'progressFcn') ...
                && ~isempty(meteo.progressFcn)
            try
                meteo.progressFcn(k);
            catch MEprogress
                warning('read_meteo_CZ:progressFcn', ...
                    'GUI progress callback failed: %s', ...
                    MEprogress.message);
            end
        end
        
    end
    fprintf('\b\b\b\b%s\n','... Done');

    if isfield(split,'local') ...
            && split.local ...
            && isfield(split,'rainfall_block') ...
            && split.rainfall_block
        dat = rainfall_rank_split(dat,split);
    end
end

function v = local_choice(S,name,defaultValue)
    v = defaultValue;

    if isstruct(S) ...
            && isfield(S,name) ...
            && ~isempty(S.(name))
        v = double(S.(name)(1));
    end

    if ~isfinite(v) ...
            || v ~= round(v) ...
            || ~ismember(v,1:3)
        error('read_meteo_CZ:badChoice', ...
            ['meteo.%s must be an ' ...
            'integer from 1 to 3.'],name);
    end
end

function dirM = local_cz_timeseries_dir(dirM)
%LOCAL_CZ_TIMESERIES_DIR Resolve the CAMELS-CZ daily time-series folder.
%
% Canonical installed layout:
%   Data/CAMELS_CZ/timeseries
%
% The older Data/CAMELS_CZ/daily/timeseries layout is accepted as a
% backward-compatible fallback.

    dirM = char(string(dirM));
    dirM = strtrim(dirM);

    candidates = {dirM};

    [p1,n1] = fileparts(dirM);
    if strcmpi(n1,'timeseries')
        % Caller already supplied a time-series directory. Also try the
        % sibling legacy/canonical alternative when applicable.
        [p2,n2] = fileparts(p1);
        if strcmpi(n2,'daily')
            candidates{end+1} = fullfile(p2,'timeseries'); %#ok<AGROW>
        else
            candidates{end+1} = fullfile(dirM,'daily','timeseries'); %#ok<AGROW>
        end
    elseif strcmpi(n1,'daily')
        candidates{end+1} = fullfile(dirM,'timeseries'); %#ok<AGROW>
        candidates{end+1} = fullfile(p1,'timeseries'); %#ok<AGROW>
    else
        candidates{end+1} = fullfile(dirM,'timeseries'); %#ok<AGROW>
        candidates{end+1} = fullfile(dirM,'daily','timeseries'); %#ok<AGROW>
    end

    candidates = unique(string(candidates),'stable');

    for k = 1:numel(candidates)
        candidate = char(candidates(k));
        if isfolder(candidate) ...
                && ~isempty(dir(fullfile(candidate,'camelscz_*.csv')))
            dirM = candidate;
            return
        end
    end
end

function rootCZ = local_cz_root_from_dirM(dirM)
    rootCZ = dirM;
    [p,n] = fileparts(rootCZ);
    if strcmpi(n,'timeseries')
        [p2,n2] = fileparts(p);
        if strcmpi(n2,'daily')
            rootCZ = p2;
        else
            rootCZ = p;
        end
    end
end

function A = local_read_cz_other_attributes(rootCZ)
    f = fullfile(rootCZ,'attributes_other_camelscz.csv');
    if ~isfile(f)
        error('read_meteo_CZ:missingAttributes', ...
            ['Missing attributes_other_camelscz.csv ' ...
            'under %s.'],rootCZ);
    end
    A = readtable(f,'VariableNamingRule','preserve');
    A.Properties.VariableNames = ...
        matlab.lang.makeValidName( ...
        A.Properties.VariableNames, ...
        'ReplacementStyle','delete');
    A.gauge_id = local_normalize_cz_id(A.gauge_id);
end

function fname = local_find_cz_file(dirM,gid)
    exact = fullfile(dirM,[char(gid) '.csv']);
    if isfile(exact)
        fname = exact;
        return
    end
    D = dir(fullfile(dirM, ...
        ['*' erase(char(gid),'camelscz_') '*.csv']));
    if isempty(D)
        error('read_meteo_CZ:missingFile', ...
            ['Missing CAMELS-CZ timeseries ' ...
            'file for %s.'],char(gid));
    end
    fname = fullfile(D(1).folder,D(1).name);
end

function [P,Ep,T,Q,badM,badQ,fileStartDT, ...
    fileEndDT,fileStartN,fileEndN] = ...
        local_load_or_build_cz_cache(fname, ...
        cacheFile,pChoice,tChoice,eChoice)

    useCache = false;
    if isfile(cacheFile)
        try
            s = dir(fname); 
            c = dir(cacheFile);
            useCache = c.datenum >= s.datenum;
        catch
        end
    end
    if useCache
        S = load(cacheFile);
        P = S.P; 
        Ep = S.Ep; 
        T = S.T; 
        Q = S.Q;
        badM = S.badM; 
        badQ = S.badQ;
        fileStartDT = S.fileStartDT; 
        fileEndDT = S.fileEndDT;
        fileStartN = S.fileStartN;
        fileEndN = S.fileEndN;
        return
    end

    R = readtable(fname,'VariableNamingRule','preserve');
    R.Properties.VariableNames = matlab.lang.makeValidName( ...
        R.Properties.VariableNames,'ReplacementStyle','delete');

    tt = datetime(string(R.date),'InputFormat','yyyy-MM-dd');
    fileStartDT = tt(1);
    fileEndDT = tt(end);
    fileStartN = int64(datenum(fileStartDT)); %#ok<DATNM>
    fileEndN = int64(datenum(fileEndDT)); %#ok<DATNM>

    pVars = { ...
        'total_precipitation_sum_CHMI', ...
        'total_precipitation_sum_ERA5_LAND', ...
        'total_precipitation_sum_CHMI_ERA5_LAND'};
    tVars = { ...
        'temperature_2m_mean_CHMI', ...
        'temperature_2m_mean_ERA5_LAND', ...
        'temperature_2m_mean_CHMI_ERA5_LAND'};
    eVars = { ...
        'potential_evaporation_sum_FAO_PENMAN_MONTEITH_CHMI', ...
        'potential_evaporation_sum_FAO_PENMAN_MONTEITH_ERA5_LAND', ...
        'potential_evaporation_sum_ERA5_LAND'};

    P = single(local_column_choice(R,pVars,pChoice,fname));
    T = single(local_column_choice(R,tVars,tChoice,fname));
    Ep = single(max(local_column_choice(R,eVars,eChoice,fname),0));

    if ~ismember('streamflow',R.Properties.VariableNames)
        error('read_meteo_CZ:missingStreamflow', ...
            'File %s lacks streamflow.',fname);
    end
    
    % CAMELS-CZ streamflow is already catchment-normalized runoff (mm/day)
    % Catchment area is retained only as a basin attribute.
    Q = single(double(R.streamflow(:)));

    badM = int64(find(~isfinite(double(P)) ...
        | ~isfinite(double(Ep)) ...
        | ~isfinite(double(T))));
    badQ = int64(find(~isfinite(double(Q)) ...
        | double(Q)<0));

    save(cacheFile,'P','Ep','T','Q','badM','badQ', ...
        'fileStartDT','fileEndDT','fileStartN','fileEndN', ...
        'pChoice','tChoice','eChoice','-v7.3');
end

function x = local_column_choice(T,cands,choice,fname)
    choice = max(1,min(numel(cands),round(choice)));
    preferred = cands{choice};
    if ismember(preferred,T.Properties.VariableNames)
        x = double(T.(preferred)(:));
        return
    end
    for k = 1:numel(cands)
        if ismember(cands{k},T.Properties.VariableNames)
            warning('read_meteo_CZ:sourceFallback', ...
                'Column %s not found in %s; using %s.', ...
                preferred,fname,cands{k});
            x = double(T.(cands{k})(:));
            return
        end
    end
    error('read_meteo_CZ:missingMeteoColumn', ...
        ['None of the expected ' ...
        'columns are present in %s.'],fname);
end

function split = local_prepare_cz_split(split)
    if nargin < 1 || isempty(split)
        error('read_meteo_CZ:missingSplit', ...
            'split must be provided.');
    end
    if ~isfield(split,'dt') ...
            || isempty(split.dt)
        split.dt = 1;
    end
end

function req = local_requested_window(split,fileStartN,fileEndN)
    if isfield(split,'dt0') ...
            && ~isempty(split.dt0)
        t0 = datetime(split.dt0);
        n = [];
        if isfield(split,'tout') ...
                && ~isempty(split.tout)
            n = numel(split.tout)-1;
        elseif isfield(split,'idx') ...
                && ~isempty(split.idx)
            n = max(double(split.idx));
        end
        if isempty(n) ...
                || n < 1
            n = double(fileEndN-fileStartN)+1;
        end
        req.read_start_N = int64(datenum(t0)); %#ok<DATNM>
        req.read_end_N = req.read_start_N + int64(n-1);
        return
    end

    fieldsStart = {'ds','dstart','start_date'};
    fieldsEnd = {'de','dend','end_date'};
    ds = []; de = [];
    for k=1:numel(fieldsStart)
        if isfield(split,fieldsStart{k}) ...
                && ~isempty(split.(fieldsStart{k}))
            ds = datetime(split.(fieldsStart{k}));
            break
        end
    end
    for k=1:numel(fieldsEnd)
        if isfield(split,fieldsEnd{k}) ...
                && ~isempty(split.(fieldsEnd{k}))
            de = datetime(split.(fieldsEnd{k}));
            break
        end
    end
    if isempty(ds) ...
            || isempty(de)
        req.read_start_N = fileStartN;
        req.read_end_N = fileEndN;
    else
        req.read_start_N = int64(datenum(ds)); %#ok<DATNM>
        req.read_end_N = int64(datenum(de)); %#ok<DATNM>
    end
end

function id = local_normalize_cz_id(x)
    id = lower(strtrim(string(x(:))));
    id = erase(id,'"'); id = erase(id,"'");
    addPrefix = ~startsWith(id,'camelscz_');
    id(addPrefix) = "camelscz_" + id(addPrefix);
end

function aux = local_cz_aux(A,gid)
    aux = [NaN NaN NaN];
    j = find(A.gauge_id==gid,1);
    if isempty(j)
        return
    end
    aux(1) = double(A.gauge_lat(j));
    aux(2) = NaN;
    aux(3) = double(A.area(j))*1e6;
end
