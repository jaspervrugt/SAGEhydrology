function R = region_config_CZ()
%REGION_CONFIG_CZ Regional defaults for CAMELS-CZ.
%
% All X.paths fields are relative to Data/<R.data_root>.
% Dates use dd/MM/yyyy and water-year boundaries.

    R = struct();
    R.code = 'CAMELS_CZ';
    R.acronym = 'CZ';
    R.name = 'Czechia';
    R.dataset = 'CAMELS-CZ';
    R.data_root = 'CAMELS_CZ';
    R.resolutions = {'Daily'};
    R.default_resolution = 'Daily';
    R.basin_file_pattern = 'CZ_%d_basins.txt';

    X = struct();
    X.label = 'Daily';
    X.dt = 1;
    X.basins.universe = 249;
    X.basins.training = 200;
    X.basins.evaluation = 49;
    X.period.spinup_days = 365;
    X.period.manual.train_start = '01/10/2005';
    X.period.manual.train_end = '30/09/2015';
    X.period.manual.eval_start = '01/10/1995';
    X.period.manual.eval_end = '30/09/2005';
    X.period.common_start = '01/10/1995';
    X.period.common_end = '30/09/2015';
    X.paths.run_root = '';
    X.paths.meteo = fullfile('daily','timeseries');
    X.paths.discharge = fullfile('daily','timeseries');
    % Meteorological/PET controls shown by SAGE-GUI.
    X.meteo.product.items = {'CAMELS-CZ [daily]'};
    X.meteo.product.default = 'CAMELS-CZ [daily]';
    X.meteo.product.enabled = false;
    X.meteo.precipitation.items = { ...
        '1 CHMI', ...
        '2 ERA5-Land', ...
        '3 Combined CHMI/ERA5-Land' ...
        };
    X.meteo.precipitation.default = '1 CHMI';
    X.meteo.precipitation.enabled = true;
    X.meteo.temperature.items = { ...
        '1 CHMI', ...
        '2 ERA5-Land', ...
        '3 Combined CHMI/ERA5-Land' ...
        };
    X.meteo.temperature.default = '1 CHMI';
    X.meteo.temperature.enabled = true;
    X.meteo.pet.items = { ...
        '1 CHMI (Penman-Monteith)', ...
        '2 ERA5-Land (Penman-Monteith)', ...
        '3 ERA5-Land native' ...
        };
    X.meteo.pet.default = '1 CHMI (Penman-Monteith)';
    X.meteo.pet.enabled = true;
    C = repmat(struct('name','','type','','path','','pattern','', ...
        'minimum_count',1,'required',true),0,1);
    C(1).name = 'Meteorological data';
    C(1).type = 'folder';
    C(1).path = fullfile('daily','timeseries');
    C(1).pattern = '*';
    C(1).minimum_count = 1;
    X.checks = C;
    R.by_resolution.Daily = X;

end