function [A,id_gauge,gname,zone] = read_attr_CZ(dirD,bas)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%READ_ATTR_CZ Read CAMELS-CZ catchment attributes.
%
% Expected files directly under Data/CAMELS_CZ:
%   attributes_caravan_camelscz.csv
%   attributes_hydroatlas_camelscz.csv
%   attributes_other_camelscz.csv
%
% Monthly HydroATLAS fields ending in _s01 through _s12 are deliberately
% excluded. Annual/statistical fields such as aet_mm_syr are retained.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    if nargin < 1 ...
            || isempty(dirD)
        error('read_attr_CZ:missingDir', ...
            'dirD must be provided.');
    end
    if ~isfolder(dirD)
        error('read_attr_CZ:missingDir', ...
            'Attribute directory does not exist: %s',dirD);
    end
    if nargin < 2 || isempty(bas)
        bas = struct();
    end
    if ~isstruct(bas)
        error('read_attr_CZ:badBas','bas must be a structure.');
    end

    min_per_zone = 5;
    max_zones = 8;
    if isfield(bas,'min_per_zone') && ~isempty(bas.min_per_zone)
        min_per_zone = bas.min_per_zone;
    end
    if isfield(bas,'max_zones') && ~isempty(bas.max_zones)
        max_zones = bas.max_zones;
    end

    pr_table = 1;
    if isfield(bas,'pr_attr') && ~isempty(bas.pr_attr)
        pr_table = bas.pr_attr;
    end

    fCar = fullfile(dirD,'attributes_caravan_camelscz.csv');
    fHyd = fullfile(dirD,'attributes_hydroatlas_camelscz.csv');
    fOth = fullfile(dirD,'attributes_other_camelscz.csv');
    must_exist(fCar,'attributes_caravan_camelscz.csv',mfilename);
    must_exist(fHyd,'attributes_hydroatlas_camelscz.csv',mfilename);
    must_exist(fOth,'attributes_other_camelscz.csv',mfilename);

    fprintf('... Reading CAMELS-CZ basin attributes ');

    O = local_read_cz_table(fOth);
    C = local_read_cz_table(fCar);
    H = local_read_cz_table(fHyd);

    % Retain compact annual/statistical HydroATLAS fields only.
    keep = true(1,width(H));
    for j = 1:width(H)
        nm = H.Properties.VariableNames{j};
        if ~strcmp(nm,'gauge_id') && ...
                ~isempty(regexp(nm,'_s(0[1-9]|1[0-2])$','once'))
            keep(j) = false;
        end
    end
    H = H(:,keep);

    AA = O;
    AA = local_join_cz(AA,C);
    AA = local_join_cz(AA,H);

    id_all = local_normalize_cz_id(AA.gauge_id);
    AA.gauge_id = id_all;
    [id_all,isrt] = sort(id_all);
    AA = AA(isrt,:);

    if isfield(bas,'id_gauge') ...
            && ~isempty(bas.id_gauge)
    
        % Requested IDs may be bare Czech IDs or prefixed CAMELS-CZ IDs.
        id_req_internal = local_normalize_cz_id(bas.id_gauge(:));
        [tf,loc] = ismember(id_req_internal,id_all);
        if ~all(tf)
            missing = local_output_cz_id(id_req_internal(~tf));
            error('read_attr_CZ:missingRequestedGauge', ...
                ['Missing CAMELS-CZ attributes ' ...
                'for %d requested gauges, ' ...
                 'e.g. %s.'], ...
                numel(missing),char(missing(1)));
        end
        AA = AA(loc,:);
        % Return bare uppercase IDs so sample_basins can match basin files.
        id_gauge = local_output_cz_id(id_req_internal);
    else
        % Return bare uppercase IDs:
        % camelscz_b4403000 -> B4403000
        id_gauge = local_output_cz_id(id_all);
    end

    if ismember('gauge_name',AA.Properties.VariableNames)
        gname = string(AA.gauge_name);
    else
        gname = id_gauge;
    end
    gname = standardize_camels_gauge_names( ...
        gname(:),'CAMELS_CZ',id_gauge);

    local_ensure_cz_gauge_information(dirD,AA);

    try
        zone = classify_camels_all_zones( ...
            'CZ',AA,min_per_zone,max_zones);
    catch
        zone = local_cz_fallback_zones(AA,max_zones);
    end

    [A,labelsOut] = build_attr_matrix( ...
        AA,bas,mfilename,pr_table);

    if pr_table == 1
        assignin('base','SAGE_CZ_attribute_labels',labelsOut);
    end
    fprintf(' ... Done\n');
end

function T = local_read_cz_table(fname)
    opts = detectImportOptions(fname,'FileType','text');
    opts.VariableNamingRule = 'preserve';
    T = readtable(fname,opts);
    T.Properties.VariableNames = matlab.lang.makeValidName( ...
        T.Properties.VariableNames,'ReplacementStyle','delete');
    T.Properties.VariableNames = matlab.lang.makeUniqueStrings( ...
        T.Properties.VariableNames);
    if ~ismember('gauge_id',T.Properties.VariableNames)
        error('read_attr_CZ:missingGaugeID', ...
            'File %s does not contain gauge_id.',fname);
    end
    T.gauge_id = local_normalize_cz_id(T.gauge_id);
end

function T = local_join_cz(T,U)
    U.gauge_id = local_normalize_cz_id(U.gauge_id);
    dup = intersect(T.Properties.VariableNames, ...
        U.Properties.VariableNames);
    dup(strcmp(dup,'gauge_id')) = [];
    if ~isempty(dup)
        U(:,dup) = [];
    end
    T = outerjoin(T,U,'Keys','gauge_id', ...
        'MergeKeys',true,'Type','left');
end

function id = local_normalize_cz_id(x)
    id = lower(strtrim(string(x(:))));
    id = erase(id,'"');
    id = erase(id,"'");
    addPrefix = ~startsWith(id,'camelscz_');
    id(addPrefix) = "camelscz_" + id(addPrefix);
end

function local_ensure_cz_gauge_information(dirD,AA)
    fout = fullfile(dirD,'gauge_information.txt');
    need = {'gauge_id','gauge_name', ...
        'gauge_lat','gauge_lon','area'};
    for j = 1:numel(need)
        if ~ismember(need{j},AA.Properties.VariableNames)
            error('read_attr_CZ:missingGaugeInfoVar', ...
                ['Cannot create gauge_information.txt ' ...
                'because %s is missing.'], ...
                need{j});
        end
    end
    fid = fopen(fout,'w');
    if fid < 0
        error('read_attr_CZ:gaugeInfoWriteFailed', ...
            'Could not write %s.',fout);
    end
    cleanup = onCleanup(@() fclose(fid));
    fprintf(fid,['HUC_02\tGAGE_ID\tGAGE_NAME\tLAT\tLONG\t' ...
        'DRAINAGE AREA (KM^2)\n']);
    for k = 1:height(AA)
        nm = string(AA.gauge_name(k));
        nm = replace(nm,char(9),' ');
        nm = replace(nm,newline,' ');
        gaugeID = local_output_cz_id(AA.gauge_id(k));
        fprintf(fid,'CZ\t%s\t%s\t%.7f\t%.7f\t%.6f\n', ...
            char(gaugeID),char(nm), ...
            double(AA.gauge_lat(k)),double(AA.gauge_lon(k)), ...
            double(AA.area(k)));
    end
end

function zone = local_cz_fallback_zones(AA,max_zones)
    K = height(AA);
    if ismember('aridity_FAO_PM',AA.Properties.VariableNames)
        x = double(AA.aridity_FAO_PM);
    elseif ismember('aridity_ERA5_LAND',AA.Properties.VariableNames)
        x = double(AA.aridity_ERA5_LAND);
    else
        x = double(AA.gauge_lat);
    end
    x(~isfinite(x)) = median(x(isfinite(x)),'omitnan');
    nz = max(1,min(max_zones,max(1,round(sqrt(K/5)))));
    q = quantile(x,linspace(0,1,nz+1));
    q = unique(q);
    num = discretize(x,q);
    num(~isfinite(num)) = 1;
    names = "CZ zone " + string((1:max(num))');
    zone = struct();
    zone.num = num(:);
    zone.id = "CZ" + compose('%02d',num(:));
    zone.names = names;
end

function id = local_output_cz_id(x)
%LOCAL_OUTPUT_CZ_ID Return canonical IDs used in CZ basin-list files.
%
% Examples:
%   camelscz_b4403000  -> B4403000
%   camelscz_l8klab00  -> L8KLAB00
%   camelscz_24042409  -> 24042409

    id = lower(strtrim(string(x(:))));
    id = erase(id,'"');
    id = erase(id,"'");
    id = erase(id,'camelscz_');
    id = upper(id);
end