function dat = read_Q_CZ(dirQ,mdl,dat,bas,split,aux)            %#ok
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%READ_Q_CZ Read discharge data for each watershed in Czech Republic
%
% SYNOPSIS: [dat,aux] = read_Q_CZ(dirQ,mdl,dat,bas,split,aux)
%   dirQ        string with main directory of discharge data
%   mdl         model state/parameter info
%   dat         cell structure with meteorological/model information
%   bas         structure basin information
%   split       structure with training/evaluation time split
%   aux         Kx3 matrix with basin metadata
%   dat         OUTPUT: cell structure with discharge information added
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% © Written by Jasper A. Vrugt, Apr. 2026                                 %
% University of California Irvine                                         %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    fprintf(['... Reading daily CZ discharge ' ...
        'data files %3d%%'],0);
    fprintf('\b\b\b\b... Done\n');

end