function [dat,aux] = read_meteo_LUX(dirM,bas,split,meteo)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%READ_METEO_LUX Read daily/hourly/15-minute CAMELS-LUX meteorological 
% and discharge data
%
% SYNOPSIS:
%   [dat,aux] = read_meteo_LUX(dirM,bas,split,meteo)
%
% INPUT:
%   dirM        Directory with CAMELS-LUX daily/hourly/15-min time series.
%               Accepted examples:
%                 Data/CAMELS_LUX
%                 Data/CAMELS_LUX/daily/timeseries
%                 Data/CAMELS_LUX/hourly/timeseries
%                 Data/CAMELS_LUX/15min/timeseries
%   bas         Structure with selected basins
%    .K          number of selected basins
%    .id_gauge   Kx1 gauge identifiers, e.g. "ID_01", "ID_02", ...
%   split       Time-split structure
%    .dt         SAGE steps/day convention: 1=daily, 24=hourly,
%                96=15-minute
%    .idx        scored-period indices after spin-up
%    .dt0        optional datetime of read-window start including spin-up
%    .tout       optional state-time vector; length = nIntervals + 1
%   meteo       Meteorological choices
%    .precip     1 = RR_rad [default]
%                2 = RR_stn
%                3 = tp
%                4 = RR_min_rad
%                5 = RR_max_rad
%    .temp       1 = t2m [default]
%                2 = T_stn
%    .pet        1 = PET_PM [default]
%                2 = PET_Oudin
%                0 = zero PET
%    .progressFcn optional GUI progress callback
%
% OUTPUT:
%   dat{k}.meteo.P   precipitation [mm/time step], including spin-up
%   dat{k}.meteo.Ep  potential evapotranspiration [mm/time step]
%   dat{k}.meteo.T   air temperature [deg C], including spin-up
%   dat{k}.y_n       Qspec [mm/time step], spin-up removed
%   dat{k}.bad       bad discharge mask, same length as y_n
%   dat{k}.gauge     CAMELS-LUX gauge identifier
%   aux              Kx3: latitude [deg], elevation [m], area [m^2]
%
% NOTES:
%   CAMELS-LUX stores precipitation, temperature, PET, and discharge in
%   a single file per basin:
%       CAMELS_LUX_hydromet_timeseries__daily_ID_01.csv
%       CAMELS_LUX_hydromet_timeseries_hourly_ID_01.csv
%       CAMELS_LUX_hydromet_timeseries_15min_ID_01.csv
%   The discharge column used by SAGE is Qspec [mm/time step]. The raw Q 
%   column is retained only in cache for reference. The spin-up is applied 
%   to Q by returning only Qall(split.idx) in dat{k}.y_n, while 
%   meteorological forcings retain the full read window including spin-up.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% © Written by Jasper A. Vrugt, June 2026                                 %
% University of California, Irvine                                        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    if nargin < 4 ...
            || isempty(meteo)
        meteo = struct();
    end
    
    if nargin < 1 ...
            || isempty(dirM)
        error('read_meteo_LUX:missingDir', ...
            ['      Error:read_meteo_LUX: ' ...
            'dirM must be provided.']);
    end

    split = local_prepare_split(split);

    dt = double(split.dt);
    [stream,stepMinutes] = ...
        local_lux_stream_from_dt(dt);

    dirM = local_lux_timeseries_dir(dirM,stream);
    
    if ~isfolder(dirM)
        error('read_meteo_LUX:missingDir', ...
            ['      Error:read_meteo_LUX: ' ...
            'CAMELS-LUX %s timeseries directory ' ...
            'does not exist: %s'],stream,dirM);
    end

    if nargin < 2 || ~isstruct(bas) ...
            || ~isfield(bas,'id_gauge') ...
            || isempty(bas.id_gauge)
        error('read_meteo_LUX:missingBasins', ...
            ['      Error:read_meteo_LUX: ' ...
            'bas.id_gauge must be provided.']);
    end

    if ~isfield(bas,'K') ...
            || isempty(bas.K)
        K = numel(bas.id_gauge);
    else
        K = double(bas.K);
    end

    id_GAUGE = normalize_lux_gauge_id( ...
        bas.id_gauge(:));

    precipChoice = 1;
    tempChoice = 1;
    petChoice = 1;

    if nargin >= 4 ...
            && isstruct(meteo)
        if isfield(meteo,'precip') ...
                && ~isempty(meteo.precip)
            precipChoice = double(meteo.precip(1));
        end
        if isfield(meteo,'temp') ...
                && ~isempty(meteo.temp)
            tempChoice = double(meteo.temp(1));
        end
        if isfield(meteo,'pet') ...
                && ~isempty(meteo.pet)
            petChoice = double(meteo.pet(1));
        end
    end

    dat = cell(K,1);
    aux = nan(K,3);

    cache_dir = fullfile(dirM, ...
        ['_cache_LUX_' stream]);
    if ~isfolder(cache_dir)
        mkdir(cache_dir);
    end

    rootLUX = local_lux_root_from_dirM(dirM);
    Tmeta = local_read_lux_meta(rootLUX);
    Ttopo = local_read_lux_topo(rootLUX);

    fprintf(['... Reading ' stream ' CAMELS-LUX ' ...
        'meteorological data files %3d%%'],0);
    flag_progress = true;

    for k = 1:K
        gid = id_GAUGE(k);
        fname = local_find_lux_timeseries_file( ...
            dirM,gid,stream);
        
        cache_file = fullfile(cache_dir, ...
            sprintf(['%s_LUX_%s_' ...
            'p%d_t%d_pet%d.mat'], ...
            char(gid),stream,precipChoice, ...
            tempChoice,petChoice));

        [Pfull,Epfull,Tfull,Qfull,bad_meteo_full, ...
            bad_q_full,fileStartN,fileEndN, ...
            fileStartDT,fileEndDT] = ...
            local_load_or_build_lux_cache( ...
            fname,cache_file,precipChoice, ...
            tempChoice,petChoice,gid,stream,stepMinutes);

        req = local_requested_window(split, ...
            fileStartN,fileEndN,numel(Pfull),stepMinutes);
        
        if req.read_start_N < fileStartN ...
                || req.read_end_N > fileEndN
            fprintf('\n');
            error('read_meteo_LUX:periodOutsideFile', ...
                ['      Error:read_meteo_LUX: ' ...
                'requested period outside ' ...
                'CAMELS-LUX file for basin %s.\n' ...
                'File covers %s to %s.'], ...
                char(gid),string(fileStartDT), ...
                string(fileEndDT));
        end

        id_read0 = int64(req.read_start_N ...
            - fileStartN) + 1;
        id_read1 = int64(req.read_end_N ...
            - fileStartN) + 1;
        id_r = double(id_read0:id_read1);

        P = double(Pfull(id_r));
        Ep = double(Epfull(id_r));
        Temp = double(Tfull(id_r));
        Qall = double(Qfull(id_r));

        if isfield(split,'idx') ...
                && ~isempty(split.idx)
            idx_score = double(split.idx(:));
        else
            idx_score = (1:numel(Qall)).';
        end

        idx_score = idx_score(idx_score >= 1 ...
            & idx_score <= numel(Qall));

        % Meteo retains spin-up period.
        dat{k}.meteo.P = single(P);
        dat{k}.meteo.Ep = single(Ep);
        dat{k}.meteo.T = single(Temp);

        % Discharge is scored period only: spin-up/burn-in removed here.
        Q = Qall(idx_score);
        dat{k}.y_n = single(Q);
        dat{k}.gauge = gid;
        dat{k}.fname{1} = fname;
        dat{k}.fname{2} = fname;

        id0d = double(id_read0);
        id1d = double(id_read1);

        bad_meteo_full = double(bad_meteo_full(:));
        bad_meteo = bad_meteo_full( ...
            bad_meteo_full >= id0d ...
            & bad_meteo_full <= id1d) - id0d + 1;
        dat{k}.meteo.bad = bad_meteo(:).';

        bad_q_full = double(bad_q_full(:));
        bad_q_all = bad_q_full( ...
            bad_q_full >= id0d ...
            & bad_q_full <= id1d) - id0d + 1;

        badmask_all = false(1,numel(Qall));
        bad_q_all = bad_q_all(isfinite(bad_q_all) ...
            & bad_q_all >= 1 ...
            & bad_q_all <= numel(Qall));
        badmask_all(round(bad_q_all)) = true;
        dat{k}.bad = badmask_all(idx_score);

        aux(k,:) = local_lux_aux(Tmeta,Ttopo,gid);

        if mod(k,5) == 0 ...
                || k == K
            pct = floor(100*k/K);
            fprintf('\b\b\b\b%3d%%',pct);
            drawnow;
        end

        if isfield(meteo,'progressFcn') ...
                && ~isempty(meteo.progressFcn)
            try
                meteo.progressFcn(k);
            catch
            end
        end
    end

    if flag_progress
        fprintf('\b\b\b\b%s\n','... Done');
    end

    if isfield(split,'local') ...
            && split.local ...
            && isfield(split,'rainfall_block') ...
            && split.rainfall_block
        dat = rainfall_rank_split(dat,split);
    end

end

% ======================
% Local helper functions
% ======================
function [stream,stepMinutes] = local_lux_stream_from_dt(dt)

    tol = 1e-8;

    if abs(dt - 1) < tol
        stream = 'daily';
        stepMinutes = 1440;
    elseif abs(dt - 24) < tol ...
            || abs(dt - 1/24) < tol ...
            || abs(dt - 3600) < tol
        stream = 'hourly';
        stepMinutes = 60;
    elseif abs(dt - 96) < tol ...
            || abs(dt - 0.25) < tol ...
            || abs(dt - 15/1440) < tol ...
            || abs(dt - 900) < tol
        stream = '15min';
        stepMinutes = 15;
    else
        error('read_meteo_LUX:badDt', ...
            ['      Error:read_meteo_LUX: unsupported ' ...
            'temporal resolution dt = %g. Expected ' ...
            'dt = 1, 24, or 96.'],dt);
    end

end

function dirM = local_lux_timeseries_dir(dirM,stream)

    dirM = char(string(dirM));
    stream = lower(strtrim(char(stream)));
    % Preferred new layout:
    %   Data/CAMELS_LUX/daily/timeseries
    %   Data/CAMELS_LUX/hourly/timeseries
    %   Data/CAMELS_LUX/15min/timeseries
    if isfolder(fullfile(dirM,stream,'timeseries'))
        dirM = fullfile(dirM,stream,'timeseries');
        return
    end
    % If SAGE_ui already passed the stream folder:
    %   Data/CAMELS_LUX/daily
    %   Data/CAMELS_LUX/hourly
    %   Data/CAMELS_LUX/15min
    if isfolder(fullfile(dirM,'timeseries'))
        [~,n] = fileparts(dirM);
        if strcmpi(n,stream)
            dirM = fullfile(dirM,'timeseries');
            return
        end
    end
    % Older archive-style layout:
    %   Data/CAMELS_LUX/timeseries/daily
    %   Data/CAMELS_LUX/timeseries/hourly
    %   Data/CAMELS_LUX/timeseries/15min
    if isfolder(fullfile(dirM,'timeseries',stream))
        dirM = fullfile(dirM,'timeseries',stream);
        return
    end
end

function rootLUX = local_lux_root_from_dirM(dirM)

    rootLUX = char(string(dirM));
    [p,n] = fileparts(rootLUX);
    if strcmpi(n,'timeseries')
        rootLUX = p;
        [p,n] = fileparts(rootLUX);
    end
    if any(strcmpi(n,{'daily','hourly','15min'}))
        rootLUX = p;
    end
end

function split = local_prepare_split(split)

    if nargin < 1 ...
            || isempty(split)
        split = struct();
    end

    if exist('prepare_split', ...
            'file') == 2
        try
            split = prepare_split(split);
        catch
        end
    end

    if ~isfield(split,'dt') ...
            || isempty(split.dt)
        split.dt = 24;
    end
    if ~isfield(split,'idx') ...
            || isempty(split.idx)
        split.idx = [];
    end

end

function fname = local_find_lux_timeseries_file(dirM,gid,stream)

    gid = char(normalize_lux_gauge_id(gid));
    gidFile = ['ID_' sprintf('%02d', ...
        str2double(gid))];
    stream = lower(strtrim(char(stream)));
    switch stream
        case 'daily'
            mainPat = sprintf(['CAMELS_LUX_hydromet_' ...
                'timeseries__daily_%s.csv'],gidFile);
            label = 'daily';
        case 'hourly'
            mainPat = sprintf(['CAMELS_LUX_hydromet_' ...
                'timeseries_hourly_%s.csv'],gidFile);
            label = 'hourly';
        case '15min'
            mainPat = sprintf(['CAMELS_LUX_hydromet_' ...
                'timeseries_15min_%s.csv'],gidFile);
            label = '15-minute';
        otherwise
            error('read_meteo_LUX:badStream', ...
                'Unknown CAMELS-LUX stream: %s.',stream);
    end
    patterns = { ...
        mainPat, ...
        sprintf('*%s*.csv',gidFile)};
    D = [];
    for i = 1:numel(patterns)
        D = dir(fullfile(dirM,patterns{i}));
        if ~isempty(D)
            break
        end
    end
    if isempty(D)
        error('read_meteo_LUX:missingFile', ...
            ['      Error:read_meteo_LUX: ' ...
            'Missing CAMELS-LUX %s hydromet ' ...
            'timeseries file for basin %s.'], ...
            label,gid);
    end
    fname = fullfile(D(1).folder,D(1).name);
end

function [P,Ep,Tair,Q,bad_meteo,bad_q, ...
    fileStartN,fileEndN,fileStartDT,fileEndDT] = ...
    local_load_or_build_lux_cache(fname,cache_file, ...
    precipChoice,tempChoice,petChoice,gid,stream,stepMinutes)

    use_cache = false;
    if isfile(cache_file)
        try
            info_src = dir(fname);
            info_cch = dir(cache_file);
            use_cache = info_cch.datenum ...
                >= info_src.datenum;
        catch
            use_cache = false;
        end
    end

    if use_cache
        S = load(cache_file, ...
            'P','Ep','Tair','Q', ...
            'bad_meteo','bad_q', ...
            'fileStartN','fileEndN', ...
            'fileStartDT','fileEndDT');
        P = S.P;
        Ep = S.Ep;
        Tair = S.Tair;
        Q = S.Q;
        bad_meteo = S.bad_meteo;
        bad_q = S.bad_q;
        fileStartN = S.fileStartN;
        fileEndN = S.fileEndN;
        fileStartDT = S.fileStartDT;
        fileEndDT = S.fileEndDT;
        return
    end

    [P,Ep,Tair,Q,bad_meteo,bad_q, ...
        fileStartN,fileEndN,fileStartDT,fileEndDT] = ...
        local_read_lux_timeseries_full(fname, ...
        precipChoice,tempChoice,petChoice,stream,stepMinutes);

    save(cache_file, ...
        'P','Ep','Tair','Q', ...
        'bad_meteo','bad_q', ...
        'fileStartN','fileEndN', ...
        'fileStartDT','fileEndDT', ...
        'precipChoice','tempChoice', ...
        'petChoice','gid', ...
        'stream','stepMinutes','-v7.3');

end

function [P,Ep,Tair,Q,bad_meteo,bad_q, ...
    fileStartN,fileEndN,fileStartDT,fileEndDT] = ...
    local_read_lux_timeseries_full(fname, ...
    precipChoice,tempChoice,petChoice,stream,stepMinutes)

    Traw = readtable(fname, ...
        'VariableNamingRule','preserve');

    Traw.Properties.VariableNames = ...
        matlab.lang.makeValidName( ...
        Traw.Properties.VariableNames, ...
        'ReplacementStyle','delete');

    tcol = local_find_existing_var( ...
        Traw.Properties.VariableNames, ...
        {'Date','date','datetime','time'});
    if isempty(tcol)
        error('read_meteo_LUX:missingDate', ...
            ['      Error:read_meteo_LUX: ' ...
            'No Date column found in %s.'], ...
            fname);
    end

    vtime = Traw.(tcol);
    if isdatetime(vtime)
        t = vtime;
    else
        ts = string(vtime);
        if stepMinutes < 1440
            t = datetime(ts, ...
                'InputFormat','yyyy-MM-dd HH:mm:ss');
            if any(isnat(t))
                t = datetime(ts, ...
                    'InputFormat','yyyy-MM-dd''T''HH:mm:ss');
            end
        else
            t = datetime(ts, ...
                'InputFormat','yyyy-MM-dd');
            if any(isnat(t))
                t = datetime(ts, ...
                    'InputFormat','yyyy-MM-dd HH:mm:ss');
            end
        end
    end

    if any(isnat(t))
        error('read_meteo_LUX:badDate', ...
            ['      Error:read_meteo_LUX: ' ...
            'Could not parse Date column in %s.'], ...
            fname);
    end

    if numel(t) > 1
        dmin = minutes(diff(t));
        badStep = ~isfinite(dmin) ...
            | abs(dmin - stepMinutes) > 1e-8;
        if any(badStep)
            j = find(badStep,1,'first');
            error('read_meteo_LUX:irregularTimeStep', ...
                ['      Error:read_meteo_LUX: ' ...
                'irregular %s time step in %s between ' ...
                'rows %d and %d. Expected %g minutes.'], ...
                stream,fname,j,j+1,stepMinutes);
        end
    end

    fileStartDT = t(1);
    fileEndDT = t(end);
    origin = datetime(1950,10,1,0,0,0);
    
    if stepMinutes < 1440
        fileStartN = int64(round(minutes( ...
            fileStartDT - origin) / stepMinutes));
        fileEndN = int64(round(minutes( ...
            fileEndDT - origin) / stepMinutes));
    else
        fileStartN = int64(days( ...
            dateshift(fileStartDT,'start','day') - origin));
        fileEndN = int64(days( ...
            dateshift(fileEndDT,'start','day') - origin));
    end

    Pcol = local_lux_precip_column( ...
        Traw,precipChoice);
    Tcol = local_lux_temp_column( ...
        Traw,tempChoice);
    Ecol = local_lux_pet_column( ...
        Traw,petChoice);
    Qcol = local_find_existing_var( ...
        Traw.Properties.VariableNames, ...
        {'Qspec','qspec','discharge_spec_obs','discharge_spec'});

    if isempty(Qcol)
        error('read_meteo_LUX:missingDischarge', ...
            ['      Error:read_meteo_LUX: ' ...
            'No Qspec/specific-discharge ' ...
            'column found in %s.'],fname);
    end

    P = single(max(local_to_double( ...
        Traw.(Pcol)),0));
    Tair = single(local_to_double( ...
        Traw.(Tcol)));
    Q = single(local_to_double( ...
        Traw.(Qcol)));

    if petChoice == 0
        Ep = single(zeros(height(Traw),1));
    else
        Ep = single(max(local_to_double( ...
            Traw.(Ecol)),0));
    end

    qflag = local_find_existing_var( ...
        Traw.Properties.VariableNames, ...
        {'Qflag','qflag'});
    rrflag = local_find_existing_var( ...
        Traw.Properties.VariableNames, ...
        {'RR_flag_rad','RRflagrad', ...
        'rr_flag_rad'});

    bad_meteo = ~isfinite(double(P)) ...
        | ~isfinite(double(Ep)) ...
        | ~isfinite(double(Tair));
    if ~isempty(rrflag)
        rf = local_to_double(Traw.(rrflag));
        bad_meteo = bad_meteo ...
            | (isfinite(rf) ...
            & rf ~= 0);
    end

    bad_q = ~isfinite(double(Q));
    if ~isempty(qflag)
        qf = local_to_double(Traw.(qflag));
        bad_q = bad_q ...
            | (isfinite(qf) ...
            & qf ~= 0);
    end

    bad_meteo = int64(find(bad_meteo));
    bad_q = int64(find(bad_q));

end

function col = local_lux_precip_column(T,precipChoice)

    switch precipChoice
        case 1
            prefs = {'RR_rad','RR_stn','tp'};
        case 2
            prefs = {'RR_stn','RR_rad','tp'};
        case 3
            prefs = {'tp','RR_rad','RR_stn'};
        case 4
            prefs = {'RR_min_rad','RR_rad'};
        case 5
            prefs = {'RR_max_rad','RR_rad'};
        otherwise
            error('read_meteo_LUX:badPrecipChoice', ...
                ['      Error:read_meteo_LUX: ' ...
                'meteo.precip must ' ...
                'be 1, 2, 3, 4, or 5.']);
    end

    col = local_find_existing_var( ...
        T.Properties.VariableNames,prefs);
    if isempty(col)
        error('read_meteo_LUX:missingPrecipitation', ...
            ['      Error:read_meteo_LUX: ' ...
            'Requested precipitation ' ...
            'column not found.']);
    end

end

function col = local_lux_temp_column(T,tempChoice)

    switch tempChoice
        case 1
            prefs = {'t2m','T_stn'};
        case 2
            prefs = {'T_stn','t2m'};
        otherwise
            error('read_meteo_LUX:badTempChoice', ...
                ['      Error:read_meteo_LUX: ' ...
                'meteo.temp must be 1 or 2.']);
    end

    col = local_find_existing_var( ...
        T.Properties.VariableNames,prefs);
    if isempty(col)
        error('read_meteo_LUX:missingTemperature', ...
            ['      Error:read_meteo_LUX: ' ...
            'Requested temperature ' ...
            'column not found.']);
    end

end

function col = local_lux_pet_column(T,petChoice)

    if petChoice == 0
        col = '';
        return
    end

    switch petChoice
        case 1
            prefs = {'PET_PM','PET_Oudin'};
        case 2
            prefs = {'PET_Oudin','PET_PM'};
        otherwise
            error('read_meteo_LUX:badPetChoice', ...
                ['      Error:read_meteo_LUX: ' ...
                'meteo.pet must be 0, 1, or 2.']);
    end

    col = local_find_existing_var( ...
        T.Properties.VariableNames,prefs);
    if isempty(col)
        error('read_meteo_LUX:missingPET', ...
            ['      Error:read_meteo_LUX: ' ...
            'Requested PET column not found.']);
    end

end

function req = local_requested_window(split, ...
    fileStartN,fileEndN,nFile,stepMinutes)

    if isfield(split,'dt0') ...
            && ~isempty(split.dt0) ...
            && isfield(split,'tout') ...
            && ~isempty(split.tout)

        origin = datetime(1950,10,1,0,0,0);
        if stepMinutes < 1440
            req.read_start_N = int64(round( ...
                minutes(split.dt0 - origin) / stepMinutes));
        else
            req.read_start_N = ...
                int64(days(dateshift(split.dt0, ...
                'start','day') - origin));
        end
        nInt = numel(split.tout) - 1;
        req.read_end_N = ...
            req.read_start_N + int64(nInt) - 1;
        return
    end

    sN = local_first_numeric_field(split, ...
        {'read_start_N','read_start_n', ...
        'start_N','start_n'});
    eN = local_first_numeric_field(split, ...
        {'read_end_N','read_end_n', ...
        'end_N','end_n'});

    if isfinite(sN) ...
            && isfinite(eN)
        req.read_start_N = int64(round(sN));
        req.read_end_N = int64(round(eN));
        return
    end

    sDT = local_first_datetime_field(split, ...
        {'read_start','start_time', ...
        't_start','date_start', ...
        'start_date','date0','t0'});
    eDT = local_first_datetime_field(split, ...
        {'read_end','end_time', ...
        't_end','date_end', ...
        'end_date','date1','t1'});

    if ~isnat(sDT) ...
            && ~isnat(eDT)
        origin = datetime(1950,10,1,0,0,0);
        if stepMinutes < 1440
            req.read_start_N = int64(round( ...
                minutes(sDT - origin) / stepMinutes));
            req.read_end_N = int64(round( ...
                minutes(eDT - origin) / stepMinutes));
        else
            req.read_start_N = ...
                int64(days(dateshift(sDT, ...
                'start','day') - origin));
            req.read_end_N = ...
                int64(days(dateshift(eDT, ...
                'start','day') - origin));
        end
        return
    end

    if exist('build_requested_window', ...
            'file') == 2
        try
            R = build_requested_window( ...
                split,false);
            if isfield(R,'read_start_N') ...
                    && isfield(R,'read_end_N')
                r0 = int64(round( ...
                    double(R.read_start_N)));
                r1 = int64(round( ...
                    double(R.read_end_N)));
                if r0 >= fileStartN ...
                        && r1 <= fileEndN
                    req.read_start_N = r0;
                    req.read_end_N = r1;
                    return
                end
            end
        catch
        end
    end

    req.read_start_N = fileStartN;
    req.read_end_N = fileEndN;

    if nargin >= 3 ...
            && nFile < 1
        req.read_end_N = fileEndN;
    end

end

function x = local_first_numeric_field(S,names)

    x = NaN;
    for i = 1:numel(names)
        if isfield(S,names{i}) ...
                && ~isempty(S.(names{i}))
            v = S.(names{i});
            if isnumeric(v) ...
                    || islogical(v)
                x = double(v(1));
                return
            end
            vv = str2double(string(v(1)));
            if isfinite(vv)
                x = vv;
                return
            end
        end
    end

end

function t = local_first_datetime_field(S,names)

    t = NaT;
    for i = 1:numel(names)
        if isfield(S,names{i}) ...
                && ~isempty(S.(names{i}))
            v = S.(names{i});
            if isdatetime(v)
                t = v(1);
                return
            end
            s = string(v(1));
            try
                t0 = datetime(s);
                if ~isnat(t0)
                    t = t0;
                    return
                end
            catch
            end
            try
                t0 = datetime(s, ...
                    'InputFormat', ...
                    'yyyy-MM-dd HH:mm:ss');
                if ~isnat(t0)
                    t = t0;
                    return
                end
            catch
            end
            try
                t0 = datetime(s, ...
                    'InputFormat', ...
                    'yyyy-MM-dd');
                if ~isnat(t0)
                    t = t0;
                    return
                end
            catch
            end
        end
    end

end

function T = local_read_lux_meta(rootLUX)

    fname = fullfile(rootLUX, ...
        'CAMELS_LUX_meta_attributes.csv');
    if isfile(fname)
        T = readtable(fname, ...
            'VariableNamingRule','preserve');
        T.Properties.VariableNames = ...
            matlab.lang.makeValidName( ...
            T.Properties.VariableNames, ...
            'ReplacementStyle','delete');
    else
        T = table();
    end

end

function T = local_read_lux_topo(rootLUX)

    fname = fullfile(rootLUX, ...
        'CAMELS_LUX_topographic_attributes.csv');
    if isfile(fname)
        T = readtable(fname, ...
            'VariableNamingRule','preserve');
        T.Properties.VariableNames = ...
            matlab.lang.makeValidName( ...
            T.Properties.VariableNames, ...
            'ReplacementStyle','delete');
    else
        T = table();
    end

end

function aux = local_lux_aux(Tmeta,Ttopo,gid)

    aux = [NaN NaN NaN];
    gid = normalize_lux_gauge_id(gid);

    if ~isempty(Tmeta) ...
            && height(Tmeta) > 0
        idcol = local_find_existing_var( ...
            Tmeta.Properties.VariableNames, ...
            {'gauge_id','gaugeid','id'});
        if ~isempty(idcol)
            ids = normalize_lux_gauge_id( ...
                Tmeta.(idcol));
            jj = find(ids == gid,1,'first');
            if ~isempty(jj)
                latcol = ...
                    local_find_existing_var( ...
                    Tmeta.Properties.VariableNames, ...
                    {'Lat','lat','latitude'});
                areacol = ...
                    local_find_existing_var( ...
                    Tmeta.Properties.VariableNames, ...
                    {'area_km2','area', ...
                    'catchment_area'});
                if ~isempty(latcol)
                    aux(1) = local_to_double( ...
                        Tmeta.(latcol)(jj));
                end
                if ~isempty(areacol)
                    a = local_to_double( ...
                        Tmeta.(areacol)(jj));
                    if isfinite(a) ...
                            && a < 1e7
                        a = a * 1e6;
                    end
                    aux(3) = a;
                end
            end
        end
    end

    if ~isempty(Ttopo) ...
            && height(Ttopo) > 0
        idcol = local_find_existing_var( ...
            Ttopo.Properties.VariableNames, ...
            {'gauge_id','gaugeid','id'});
        if ~isempty(idcol)
            ids = normalize_lux_gauge_id( ...
                Ttopo.(idcol));
            jj = find(ids == gid,1,'first');
            if ~isempty(jj)
                elevcol = ...
                    local_find_existing_var( ...
                    Ttopo.Properties.VariableNames, ...
                    {'Z_MEAN','z_mean', ...
                    'elev_mean','elevation'});
                if ~isempty(elevcol)
                    aux(2) = local_to_double( ...
                        Ttopo.(elevcol)(jj));
                end
            end
        end
    end

end

function col = local_find_existing_var(vn,cands)

    col = '';
    idx = local_find_var(vn,cands);
    if ~isempty(idx)
        col = vn{idx};
    end

end

function idx = local_find_var(vn,cands)

    normf = @(s) lower(regexprep(char(s), ...
        '[^a-z0-9]',''));
    vnn = cellfun(normf, ...
        vn,'UniformOutput',false);

    idx = [];
    for k = 1:numel(cands)
        hit = find(strcmp(vnn, ...
            normf(cands{k})),1,'first');
        if ~isempty(hit)
            idx = hit;
            return
        end
    end

end

function x = local_to_double(v)

    if isnumeric(v) ...
            || islogical(v)
        x = double(v(:));
        return
    end

    s = string(v);
    s = strip(s);
    s(ismissing(s) ...
        | strcmpi(s,'NA') ...
        | strcmpi(s,'NAN') ...
        | strcmpi(s,'NULL') ...
        | s == '') = missing;
    x = str2double(s);
    x = x(:);

end

% =====================================
function id = normalize_lux_gauge_id(x)
% =====================================

    s = string(x(:));
    s = upper(strtrim(s));
    s = erase(s,'"');
    s = erase(s,"'");
    s = regexprep(s,'\.0+$','');
    s = regexprep(s,'^ID_?','');

    n = str2double(s);
    id = s;

    ok = isfinite(n) & n > 0;
    id(ok) = compose('%.0f',n(ok));
    
end
