function R = region_config_LUX()
%REGION_CONFIG_LUX Regional defaults for LamaH-Lux.
%
% All X.paths fields are relative to Data/<R.data_root>.
% Dates use dd/MM/yyyy and water-year boundaries.

    R = struct();
    R.code = 'CAMELS_LUX';
    R.acronym = 'LUX';
    R.name = 'Luxembourg';
    R.dataset = 'LamaH-Lux';
    R.data_root = 'CAMELS_LUX';
    R.resolutions = {'Daily','Hourly','15 minutes'};
    R.default_resolution = 'Daily';
    R.basin_file_pattern = 'LUX_%d_basins.txt';

    X = struct();
    X.label = 'Daily';
    X.dt = 1;
    X.basins.universe = 50;
    X.basins.file = 'LUX_50_basins.txt';
    X.basins.training = 40;
    X.basins.evaluation = 10;
    X.period.spinup_days = 365;
    X.period.manual.train_start = '01/10/2013';
    X.period.manual.train_end = '30/09/2019';
    X.period.manual.eval_start = '01/10/2008';
    X.period.manual.eval_end = '30/09/2013';
    X.period.common_start = '01/10/2008';
    X.period.common_end = '30/09/2019';
    X.paths.run_root = '';
    X.paths.meteo = fullfile('daily','timeseries');
    X.paths.discharge = fullfile('daily','timeseries');
    % Meteorological/PET controls shown by SAGE-GUI.
    X.meteo.product.items = {'CAMELS-LUX [daily]'};
    X.meteo.product.default = 'CAMELS-LUX [daily]';
    X.meteo.product.enabled = false;
    X.meteo.precipitation.items = { ...
        '1 Radar', ...
        '2 Station', ...
        '3 ERA5 total', ...
        '4 Radar minimum', ...
        '5 Radar maximum' ...
        };
    X.meteo.precipitation.default = '1 Radar';
    X.meteo.precipitation.enabled = true;
    X.meteo.temperature.items = { ...
        '1 ERA5 2 m', ...
        '2 Station' ...
        };
    X.meteo.temperature.default = '1 ERA5 2 m';
    X.meteo.temperature.enabled = true;
    X.meteo.pet.items = { ...
        '1 Penman-Monteith', ...
        '2 Oudin et al.', ...
        '0 Zero PET' ...
        };
    X.meteo.pet.default = '1 Penman-Monteith';
    X.meteo.pet.enabled = true;
    C = repmat(struct('name','','type','','path','','pattern','', ...
        'minimum_count',1,'required',true),0,1);
    C(1).name = 'Meteorological data';
    C(1).type = 'folder';
    C(1).path = fullfile('daily','timeseries');
    C(1).pattern = '*';
    C(1).minimum_count = 1;
    X.checks = C;
    R.by_resolution.Daily = X;

    X = struct();
    X.label = 'Hourly';
    X.dt = 24;
    X.basins.universe = 51;
    X.basins.file = 'LUX_51_basins.txt';
    X.basins.training = 40;
    X.basins.evaluation = 11;
    X.period.spinup_days = 365;
    X.period.manual.train_start = '01/10/2014';
    X.period.manual.train_end = '30/09/2020';
    X.period.manual.eval_start = '01/10/2008';
    X.period.manual.eval_end = '30/09/2014';
    X.period.common_start = '01/10/2008';
    X.period.common_end = '30/09/2020';
    X.paths.run_root = '';
    X.paths.meteo = fullfile('hourly','timeseries');
    X.paths.discharge = fullfile('hourly','timeseries');
    % Meteorological/PET controls shown by SAGE-GUI.
    X.meteo.product.items = {'CAMELS-LUX [hourly]'};
    X.meteo.product.default = 'CAMELS-LUX [hourly]';
    X.meteo.product.enabled = false;
    X.meteo.precipitation.items = { ...
        '1 Radar', ...
        '2 Station', ...
        '3 ERA5 total', ...
        '4 Radar minimum', ...
        '5 Radar maximum' ...
        };
    X.meteo.precipitation.default = '1 Radar';
    X.meteo.precipitation.enabled = true;
    X.meteo.temperature.items = { ...
        '1 ERA5 2 m', ...
        '2 Station' ...
        };
    X.meteo.temperature.default = '1 ERA5 2 m';
    X.meteo.temperature.enabled = true;
    X.meteo.pet.items = { ...
        '1 Penman-Monteith', ...
        '2 Oudin et al.', ...
        '0 Zero PET' ...
        };
    X.meteo.pet.default = '1 Penman-Monteith';
    X.meteo.pet.enabled = true;
    C = repmat(struct('name','','type','','path','','pattern','', ...
        'minimum_count',1,'required',true),0,1);
    C(1).name = 'Meteorological data';
    C(1).type = 'folder';
    C(1).path = fullfile('hourly','timeseries');
    C(1).pattern = '*';
    C(1).minimum_count = 1;
    X.checks = C;
    R.by_resolution.Hourly = X;

    X = struct();
    X.label = '15 minutes';
    X.dt = 96;
    X.basins.universe = 51;
    X.basins.file = 'LUX_51_basins.txt';
    X.basins.training = 40;
    X.basins.evaluation = 11;
    X.period.spinup_days = 365;
    X.period.manual.train_start = '01/10/2014';
    X.period.manual.train_end = '30/09/2020';
    X.period.manual.eval_start = '01/10/2008';
    X.period.manual.eval_end = '30/09/2014';
    X.period.common_start = '01/10/2008';
    X.period.common_end = '30/09/2020';
    X.paths.run_root = '';
    X.paths.meteo = fullfile('15min','timeseries');
    X.paths.discharge = fullfile('15min','timeseries');
    % Meteorological/PET controls shown by SAGE-GUI.
    X.meteo.product.items = {'CAMELS-LUX [15 minutes]'};
    X.meteo.product.default = 'CAMELS-LUX [15 minutes]';
    X.meteo.product.enabled = false;
    X.meteo.precipitation.items = { ...
        '1 Radar', ...
        '2 Station', ...
        '3 ERA5 total', ...
        '4 Radar minimum', ...
        '5 Radar maximum' ...
        };
    X.meteo.precipitation.default = '1 Radar';
    X.meteo.precipitation.enabled = true;
    X.meteo.temperature.items = { ...
        '1 ERA5 2 m', ...
        '2 Station' ...
        };
    X.meteo.temperature.default = '1 ERA5 2 m';
    X.meteo.temperature.enabled = true;
    X.meteo.pet.items = { ...
        '1 Penman-Monteith', ...
        '2 Oudin et al.', ...
        '0 Zero PET' ...
        };
    X.meteo.pet.default = '1 Penman-Monteith';
    X.meteo.pet.enabled = true;
    C = repmat(struct('name','','type','','path','','pattern','', ...
        'minimum_count',1,'required',true),0,1);
    C(1).name = 'Meteorological data';
    C(1).type = 'folder';
    C(1).path = fullfile('15min','timeseries');
    C(1).pattern = '*';
    C(1).minimum_count = 1;
    X.checks = C;
    R.by_resolution.min15 = X;

end