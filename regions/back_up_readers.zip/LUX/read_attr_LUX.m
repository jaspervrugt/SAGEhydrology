function [A,id_gauge,gname,zone] = read_attr_LUX(dirD,bas)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%READ_ATTR_LUX Read catchment attributes of CAMELS-LUX dataset.
%
% SYNOPSIS:
%   [A,id_gauge,gname,zone] = read_attr_LUX(dirD,bas)
%
% INPUT:
%   dirD        Directory with CAMELS-LUX attribute CSV files,
%               normally Data/CAMELS_LUX
%   bas         OPTIONAL structure with fields
%    .id_gauge   requested basin IDs, e.g. "ID_01", "ID_02", ...
%    .id_attr    selected attribute IDs
%    .pr_attr    print attribute table [1/0]
%
% OUTPUT:
%   A           r x K matrix of standardized selected attributes
%   id_gauge    K x 1 string array with CAMELS-LUX basin identifiers
%   gname       K x 1 string array with station names
%   zone        structure with simple CAMELS-LUX physiographic grouping
%-
% NOTES:
%   The CAMELS-LUX static attributes are distributed in five CSV files:
%     CAMELS_LUX_meta_attributes.csv
%     CAMELS_LUX_climatic_attributes.csv
%     CAMELS_LUX_topographic_attributes.csv
%     CAMELS_LUX_geologic_attributes.csv
%     CAMELS_LUX_landuse_attributes.csv
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% © Written by Jasper A. Vrugt, June 2026                                 %
% University of California, Irvine                                        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    if nargin < 1 ...
            || isempty(dirD)
        error('read_attr_LUX:missingDir', ...
            ['      Error:read_attr_LUX: ' ...
            'dirD must be provided.']);
    end

    if ~isfolder(dirD)
        error('read_attr_LUX:missingDir', ...
            ['      Error:read_attr_LUX: ' ...
            'Attribute directory ' ...
            'does not exist: %s'],dirD);
    end

    if nargin < 2 ...
            || isempty(bas)
        bas = struct();
    end

    if ~isstruct(bas)
        error('read_attr_LUX:badBas', ...
            ['      Error:read_attr_LUX: ' ...
            'bas must be a structure.']);
    end
    % =========================================
    % ZONE CONTROL PARAMETERS (GLOBAL DEFAULTS)
    % =========================================
    if ~isfield(bas,'min_per_zone') ...
            || isempty(bas.min_per_zone)
        min_per_zone = 5;
    else
        min_per_zone = bas.min_per_zone;
    end    
    if ~isfield(bas,'max_zones') ...
            || isempty(bas.max_zones)
        max_zones = 8;
    else
        max_zones = bas.max_zones;
    end
    
    pr_table = 1;
    if isfield(bas,'pr_attr') ...
            && ~isempty(bas.pr_attr)
        pr_table = bas.pr_attr;
    end

    files = local_lux_attribute_files();
    caller = mfilename;
    for i = 1:numel(files)
        must_exist(fullfile(dirD, ...
            files{i}),files{i},caller);
    end

    fprintf('... Reading CAMELS-LUX basin attributes ');

    meta = read_lux_table(fullfile(dirD, ...
        'CAMELS_LUX_meta_attributes.csv'));
    clim = read_lux_table(fullfile(dirD, ...
        'CAMELS_LUX_climatic_attributes.csv'));
    topo = read_lux_table(fullfile(dirD, ...
        'CAMELS_LUX_topographic_attributes.csv'));
    geol = read_lux_table(fullfile(dirD, ...
        'CAMELS_LUX_geologic_attributes.csv'));
    land = read_lux_table(fullfile(dirD, ...
        'CAMELS_LUX_landuse_attributes.csv'));

    % Use metadata as master because it contains station names, location,
    % area, and record start/end dates.
    AA = meta;
    AA = join_lux_attributes(AA,clim);
    AA = join_lux_attributes(AA,topo);
    AA = join_lux_attributes(AA,geol);
    AA = join_lux_attributes(AA,land);

    AA.gauge_id = normalize_lux_gauge_id(AA.gauge_id);
    [~,isrt] = sort(AA.gauge_id);
    AA = AA(isrt,:);

    id_all = AA.gauge_id;

    if isfield(bas,'id_gauge') ...
            && ~isempty(bas.id_gauge)
        id_req = normalize_lux_gauge_id(bas.id_gauge(:));
        [tf,loc] = ismember(id_req,id_all);
        if ~all(tf)
            missing = id_req(~tf);
            error('read_attr_LUX:missingRequestedGauge', ...
                ['      Error:read_attr_LUX: ' ...
                'Missing CAMELS-LUX ' ...
                'attributes for %d requested ' ...
                'basin IDs, e.g. %s.'], ...
                numel(missing),char(missing(1)));
        end
        AA = AA(loc,:);
        id_gauge = id_req(:);
    else
        id_gauge = id_all(:);
    end

    if ismember('Station', ...
            AA.Properties.VariableNames)
        gname = string(AA.Station);
    elseif ismember('stream', ...
            AA.Properties.VariableNames)
        gname = string(AA.stream);
    else
        gname = "Gauge " + id_gauge;
    end
    % gname = ...
    %     local_standardize_lux_names(gname(:));
    gname = standardize_camels_gauge_names(gname, ...
        'CAMELS_LUX',id_gauge);

    ensure_lux_gauge_information(dirD,AA);
    region = erase(mfilename,'read_attr_');
    zone = classify_camels_all_zones(region,AA, ...
        min_per_zone,max_zones);

    % ------------------
    % Generic attributes
    % ------------------
    [A,labels] = build_attr_matrix(AA,bas, ...
        mfilename,pr_table);

    if pr_table == 1
        assignin('base', ...
            'SAGE_LUX_attribute_labels', ...
            labels);
    end

    fprintf(' ... Done\n');

end

% ===============================
function T = read_lux_table(fname)
% ===============================
    opts = detectImportOptions(fname,'FileType','text');
    opts.VariableNamingRule = 'preserve';
    T = readtable(fname,opts);

    T.Properties.VariableNames = matlab.lang.makeValidName( ...
        T.Properties.VariableNames,'ReplacementStyle','delete');
    T.Properties.VariableNames = matlab.lang.makeUniqueStrings( ...
        T.Properties.VariableNames);

    if ~ismember('gauge_id',T.Properties.VariableNames)
        error('read_attr_LUX:missingGaugeID', ...
            ['      Error:read_attr_LUX: ' ...
            'File %s does not contain gauge_id.'],fname);
    end

    T.gauge_id = normalize_lux_gauge_id(T.gauge_id);
    T = sortrows(T,'gauge_id');
end

% ===================================
function T = join_lux_attributes(T,U)
% ===================================
    U.gauge_id = normalize_lux_gauge_id(U.gauge_id);

    dup = intersect(T.Properties.VariableNames, ...
        U.Properties.VariableNames);
    dup(strcmp(dup,'gauge_id')) = [];
    if ~isempty(dup)
        U(:,dup) = [];
    end

    T = outerjoin(T,U, ...
        'Keys','gauge_id', ...
        'MergeKeys',true, ...
        'Type','left');
end

% ============================================
function ensure_lux_gauge_information(dirD,AA)
% ============================================
    f_info = fullfile(dirD,'gauge_information.txt');

    if isfile(f_info)
        return
    end

    id = normalize_lux_gauge_id(AA.gauge_id);

    if ismember('Station',AA.Properties.VariableNames)
        nm = string(AA.Station);
    else
        nm = "Gauge " + id;
    end

    lat = get_numeric_column(AA,{"Lat"});
    lon = get_numeric_column(AA,{"Lon"});
    area = get_numeric_column(AA,{"area_km2"});

    try
        fid = fopen(f_info,'w');
        if fid < 0
            error('Could not open file for writing.');
        end
        cleanup = onCleanup(@() fclose(fid));

        fprintf(fid,['HUC_02\tGAGE_ID\tGAGE_NAME\tLAT\tLONG\t' ...
            'DRAINAGE AREA (KM^2)\n']);

        for k = 1:numel(id)
            gnm = string(nm(k));
            gnm = replace(gnm,char(9),' ');
            gnm = replace(gnm,newline,' ');
            fprintf(fid,'LUX\t%s\t%s\t%.6f\t%.6f\t%.6f\n', ...
                char(id(k)),char(gnm), ...
                lat(k),lon(k),area(k));
        end

        fprintf(['\n      Wrote CAMELS-LUX gauge ' ...
            'information file: %s'],f_info);

    catch ME
        warning('read_attr_LUX:gaugeInfoWriteFailed', ...
            ['      Warning:read_attr_LUX: ' ...
            'Could not write %s.\n%s'], ...
            f_info,ME.message);
    end
end

% =====================================
function id = normalize_lux_gauge_id(x)
% =====================================

    s = string(x(:));
    s = upper(strtrim(s));
    s = erase(s,'"');
    s = erase(s,"'");
    s = regexprep(s,'\.0+$','');
    s = regexprep(s,'^ID_?','');

    n = str2double(s);
    id = s;

    ok = isfinite(n) & n > 0;
    id(ok) = compose('%.0f',n(ok));
    
end

% % =========================================
% function s = local_standardize_lux_names(s)
% % =========================================
%     s = string(s);
%     s = strip(s);
%     s(ismissing(s)) = "";
%     s = regexprep(s,'[_]+',' ');
%     s = s(:);
% end

% ==========================================
function files = local_lux_attribute_files()
% ==========================================
    files = { ...
        'CAMELS_LUX_climatic_attributes.csv', ...
        'CAMELS_LUX_geologic_attributes.csv', ...
        'CAMELS_LUX_landuse_attributes.csv', ...
        'CAMELS_LUX_meta_attributes.csv', ...
        'CAMELS_LUX_topographic_attributes.csv'};
end
