function dat=read_Q_BE(~,~,dat,~,~,~)
%READ_Q_BE No-op: GRDC-Caravan streamflow is read with meteorology.
end
