function R=region_config_BE()
%REGION_CONFIG_BE Defaults for Belgium GRDC-Caravan.
    R=region_config_GRDC('BE','Belgium',55,47,39,8, ...
        '01/10/1982','30/09/2002','01/10/2002','30/09/2022');
end
