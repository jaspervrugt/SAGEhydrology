function [dat,aux]=read_meteo_BE(dirM,bas,split,meteo)
%READ_METEO_BE Read daily Belgium GRDC-Caravan forcing and discharge.
    [dat,aux]=read_meteo_NA(dirM,bas,split,meteo,'Belgium');
end
