function [A,id_gauge,gname,zone]=read_attr_BE(dirD,bas)
%READ_ATTR_BE Read filtered Belgium GRDC-Caravan attributes.
    [A,id_gauge,gname,zone]=read_attr_NA(dirD,bas,'CAMELS_BE','BE');
end
