function [dat,aux] = read_meteo_NZ(dirM,bas,split,meteo)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%READ_METEO_NZ Read CAMELS-NZ daily or hourly meteorological data for SAGE.
%
% EXPECTED FOLDERS
%
% Daily:
%   Data/CAMELS_NZ/daily/timeseries/precipitation
%   Data/CAMELS_NZ/daily/timeseries/temperature
%   Data/CAMELS_NZ/daily/timeseries/relative_humidity
%
% Hourly:
%   Data/CAMELS_NZ/hourly/timeseries/precipitation
%   Data/CAMELS_NZ/hourly/timeseries/temperature
%   Data/CAMELS_NZ/hourly/timeseries/pet
%
% DAILY FILES
%   daily_precipitation_station_id_XXXX.csv
%   daily_temperature_station_id_XXXX.csv
%   daily_RH_station_id_XXXX.csv
%
% HOURLY FILES
%   precipitation_station_id_XXXX.csv
%   temperature_station_id_XXXX.csv
%   PET_station_id_XXXX.csv
%
% Daily temperature is converted from K to degC when needed. Daily PET is
% calculated with the Oudin formulation [mm d-1], because the CAMELS-NZ
% daily release does not include a PET archive. Relative humidity is
% retained in dat{k}.meteo.RH. Hourly behavior is unchanged: released PET
% is read directly and retained in mm h-1.
%
% CAMELS-NZ station identifiers are not USGS identifiers and must not be
% zero-padded.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    split = prepare_split(split);

    dt = double(split.dt);
    if abs(dt - 1) < 1e-8
        stream = 'daily';
    elseif abs(dt - 24) < 1e-8
        stream = 'hourly';
    else
        fprintf('\n');
        error(['      Error:read_meteo_NZ: ' ...
            'CAMELS-NZ supports daily data ' ...
            '(SAGE split.dt = 1) and hourly data ' ...
            '(SAGE split.dt = 24).']);
    end

    K = bas.K;
    id_GAUGE = bas.id_gauge;

    dirTS = local_nz_timeseries_root(dirM,stream);
    dirP = fullfile(dirTS,'precipitation');
    dirT = fullfile(dirTS,'temperature');

    if strcmp(stream,'hourly')
        dirX = fullfile(dirTS,'pet');
        xLabel = 'PET';
    else
        dirX = fullfile(dirTS,'relative_humidity');
        xLabel = 'relative humidity';
    end

    if ~isfolder(dirP)
        error(['      Error:read_meteo_NZ: ' ...
            'Cannot find precipitation folder: %s'],dirP);
    end
    if ~isfolder(dirT)
        error(['      Error:read_meteo_NZ: ' ...
            'Cannot find temperature folder: %s'],dirT);
    end
    if ~isfolder(dirX)
        error(['      Error:read_meteo_NZ: ' ...
            'Cannot find %s folder: %s'],xLabel,dirX);
    end

    dat = cell(K,1);
    aux = nan(K,3);

    try
        aux = local_aux_from_bas(bas,aux);
    catch
    end
    try
        aux = local_aux_from_gauge_info(dirTS,bas,aux);
    catch
    end

    if strcmp(stream,'hourly')
        req = local_requested_hourly_window(split);
    else
        req = local_requested_daily_window(split);
    end

    fprintf(['... Reading %s CAMELS-NZ meteorological ' ...
        'data files %3d%%'],stream,0);
    flag_progress = true;

    cache_dir = fullfile(dirTS, ...
        ['_cache_NZ_' stream '_meteo']);
    if ~isfolder(cache_dir)
        mkdir(cache_dir);
    end

    for k = 1:K

        id = local_nz_id(id_GAUGE(k));

        if strcmp(stream,'hourly')
            fP = fullfile(dirP, ...
                sprintf('precipitation_station_id_%s.csv',id));
            fT = fullfile(dirT, ...
                sprintf('temperature_station_id_%s.csv',id));
            fX = fullfile(dirX, ...
                sprintf('PET_station_id_%s.csv',id));
        else
            fP = fullfile(dirP, ...
                sprintf('daily_precipitation_station_id_%s.csv',id));
            fT = fullfile(dirT, ...
                sprintf('daily_temperature_station_id_%s.csv',id));
            fX = fullfile(dirX, ...
                sprintf('daily_RH_station_id_%s.csv',id));
        end

        % Be tolerant to archive versions that add a parent directory or
        % vary capitalization, while preferring the documented exact names.
        if ~isfile(fP)
            fP = local_find_nz_station_file(dirP,id, ...
                {'precipitation','precip','rainfall'},stream);
        end
        if ~isfile(fT)
            fT = local_find_nz_station_file(dirT,id, ...
                {'temperature','temp'},stream);
        end
        if ~isfile(fX)
            if strcmp(stream,'hourly')
                fX = local_find_nz_station_file(dirX,id,{'pet'},stream);
            else
                fX = local_find_nz_station_file(dirX,id, ...
                    {'daily_rh','relative_humidity', ...
                    'relativehumidity','humidity'},stream);
            end
        end

        if ~isfile(fP)
            fprintf('\n');
            error(['      Error:read_meteo_NZ: ' ...
                'Missing %s precipitation file for station %s.'], ...
                stream,id);
        end
        if ~isfile(fT)
            fprintf('\n');
            error(['      Error:read_meteo_NZ: ' ...
                'Missing %s temperature file for station %s.'], ...
                stream,id);
        end
        if ~isfile(fX)
            fprintf('\n');
            error(['      Error:read_meteo_NZ: ' ...
                'Missing %s %s file for station %s.'], ...
                stream,xLabel,id);
        end

        cache_file = fullfile(cache_dir, ...
            sprintf('%s_NZ_%s_meteo.mat',id,stream));

        if strcmp(stream,'hourly')
            win_key = sprintf('%s_%s', ...
                char(req.time(1),'yyyyMMddHH'), ...
                char(req.time(end),'yyyyMMddHH'));
        else
            win_key = sprintf('%s_%s', ...
                char(req.time(1),'yyyyMMdd'), ...
                char(req.time(end),'yyyyMMdd'));
        end

        win_cache = fullfile(cache_dir, ...
            sprintf('%s_NZ_%s_meteo_%s.mat', ...
            id,stream,win_key));

        use_win_cache = false;
        if isfile(win_cache)
            try
                if strcmp(stream,'hourly')
                    Smet = load(win_cache, ...
                        'P','Ep','T','badrows');
                    P = Smet.P;
                    Ep = Smet.Ep;
                    T = Smet.T;
                else
                    Smet = load(win_cache, ...
                        'P','Ep','T','RH','badrows');
                    P = Smet.P;
                    Ep = Smet.Ep;
                    T = Smet.T;
                    RH = Smet.RH;
                end
                badrows = Smet.badrows;
                use_win_cache = true;
            catch
                use_win_cache = false;
            end
        end

        if ~use_win_cache

            [tP,P] = local_load_or_read_series( ...
                fP,cache_file,'P','precipitation');
            [tT,Tk] = local_load_or_read_series( ...
                fT,cache_file,'T','temperature');

            % Both daily and hourly released examples store temperature in K.
            T = double(Tk);
            medT = median(T(isfinite(T)),'omitnan');
            if isfinite(medT) && medT > 100
                T = T - 273.15;
            end

            if strcmp(stream,'hourly')

                [tE,Ep] = local_load_or_read_series( ...
                    fX,cache_file,'Ep','PET');

                [P,Ep,T,badrows] = ...
                    local_extract_aligned_window( ...
                    tP,P,tE,Ep,tT,T,req);

                try
                    save(win_cache, ...
                        'P','Ep','T','badrows','-v7.3');
                catch
                end

            else

                [tR,RH] = local_load_or_read_series( ...
                    fX,cache_file,'RH','Relative_humidity');

                [P,RH,T,~] = ...
                    local_extract_aligned_window( ...
                    tP,P,tR,RH,tT,T,req);

                % Support either fraction [0,1] or percent [0,100].
                medRH = median(RH(isfinite(RH)),'omitnan');
                if isfinite(medRH) && medRH <= 1.5
                    RH = 100 * RH;
                end

                lat = aux(k,1);
                if ~isfinite(lat)
                    fprintf('\n');
                    error(['      Error:read_meteo_NZ: ' ...
                        'Cannot calculate daily Oudin PET for station %s ' ...
                        'because basin latitude is unavailable.'],id);
                end

                Ep = local_oudin_daily_pet(req.time,T,lat);

                badmask = ~isfinite(P) ...
                    | ~isfinite(RH) ...
                    | ~isfinite(T) ...
                    | ~isfinite(Ep);
                badrows = int64(find(badmask));

                try
                    save(win_cache, ...
                        'P','Ep','T','RH','badrows','-v7.3');
                catch
                end
            end
        end

        dat{k}.meteo.P = single(P);
        dat{k}.meteo.Ep = single(Ep);
        dat{k}.meteo.T = single(T);
        if strcmp(stream,'daily')
            dat{k}.meteo.RH = single(RH);
        end

        dat{k}.gauge = string(id);
        dat{k}.fname{1} = fP;
        dat{k}.fname{3} = fT;
        dat{k}.fname{4} = fX;
        dat{k}.meteo.bad = badrows(:)';

        if ~isempty(badrows)
            if flag_progress
                fprintf('\n');
            end
            fprintf(['      Warning:read_meteo_NZ: ' ...
                'station %s has %d invalid/missing %s ' ...
                'meteo rows in requested window.\n'], ...
                id,numel(badrows),stream);
            pct = floor(100*k/K);
            fprintf(['... Reading %s CAMELS-NZ ' ...
                'meteorological data files %3d%%'], ...
                stream,pct);
            flag_progress = true;
        end

        if mod(k,5)==0 ...
                || k==K
            pct = floor(100*k/K);
            fprintf('\b\b\b\b%3d%%',pct);
            drawnow;
        end

        if isfield(meteo,'progressFcn') ...
                && ~isempty(meteo.progressFcn)
            meteo.progressFcn(k);
        end
    end

    if flag_progress
        fprintf('\b\b\b\b%s\n','... Done');
    end

    if isfield(split,'local') ...
            && split.local ...
            && isfield(split,'rainfall_block') ...
            && split.rainfall_block
        dat = rainfall_rank_split(dat,split);
    end

end

% ----------------------------------------------------
function dirTS = local_nz_timeseries_root(dirM,stream)
% ----------------------------------------------------

    dirM = char(string(dirM));

    cands = { ...
        dirM, ...
        fullfile(dirM,stream,'timeseries'), ...
        fullfile(dirM,'CAMELS_NZ',stream,'timeseries'), ...
        fullfile(dirM,'Data','CAMELS_NZ',stream,'timeseries')};

    % Retain legacy hourly layout as a final fallback only.
    if strcmp(stream,'hourly')
        cands = [cands, { ...
            fullfile(dirM,'timeseries'), ...
            fullfile(dirM,'CAMELS_NZ','timeseries'), ...
            fullfile(dirM,'Data','CAMELS_NZ','timeseries')}];
    end

    for i = 1:numel(cands)
        d = cands{i};
        hasCore = isfolder(fullfile(d,'precipitation')) ...
            && isfolder(fullfile(d,'temperature'));

        if strcmp(stream,'hourly')
            hasExtra = isfolder(fullfile(d,'pet'));
        else
            hasExtra = isfolder(fullfile(d,'relative_humidity'));
        end

        if hasCore && hasExtra
            dirTS = d;
            return
        end
    end

    error(['      Error:read_meteo_NZ: ' ...
        'Cannot resolve CAMELS_NZ %s timeseries ' ...
        'directory from: %s'],stream,dirM);
end

% -------------------------------------------------
function req = local_requested_hourly_window(split)
% -------------------------------------------------

    tref = datetime(1950,10,1,0,0,0);

    % Preferred shared SAGE helper.
    if exist('build_requested_window','file') == 2
        try
            req0 = build_requested_window(split,true);

            if isfield(req0,'time') ...
                    && ~isempty(req0.time)
                req.time = dateshift( ...
                    datetime(req0.time(:)), ...
                    'start','hour');
                req.read_start_N = ...
                    int64(hours(req.time(1) - tref));
                req.read_end_N = ...
                    int64(hours(req.time(end) - tref));
                return
            end

            if isfield(req0,'read_start_N') ...
                    && isfield(req0,'read_end_N')
                req.read_start_N = ...
                    int64(req0.read_start_N);
                req.read_end_N = ...
                    int64(req0.read_end_N);
                req.time = ...
                    (tref + hours(double(req.read_start_N)): ...
                    hours(1): ...
                    tref + hours(double(req.read_end_N))).';
                return
            end
        catch
        end
    end

    [t0,t1] = local_requested_bounds(split);

    t0 = dateshift(t0,'start','hour');
    % Hourly files contain all 24 hours of the final requested day when
    % split end dates are day-based.
    if hour(t1) == 0 ...
            && minute(t1) == 0 ...
            && second(t1) == 0
        t1 = dateshift(t1,'start','day') + hours(23);
    else
        t1 = dateshift(t1,'start','hour');
    end

    if t1 < t0
        error(['      Error:read_meteo_NZ: ' ...
            'requested hourly period is empty: %s to %s.'], ...
            string(t0),string(t1));
    end

    req.time = (t0:hours(1):t1).';
    req.read_start_N = ...
        int64(hours(req.time(1) - tref));
    req.read_end_N = ...
        int64(hours(req.time(end) - tref));
end

% ------------------------------------------------
function req = local_requested_daily_window(split)
% ------------------------------------------------

    tref = datetime(1950,10,1);

    % Preferred shared SAGE helper.
    if exist('build_requested_window','file') == 2
        try
            req0 = build_requested_window(split,true);

            if isfield(req0,'time') ...
                    && ~isempty(req0.time)
                req.time = dateshift( ...
                    datetime(req0.time(:)), ...
                    'start','day');
                return
            end

            if isfield(req0,'read_start_N') ...
                    && isfield(req0,'read_end_N')
                t0 = tref + days(double(req0.read_start_N));
                t1 = tref + days(double(req0.read_end_N));
                req.time = ...
                    (dateshift(t0,'start','day'): ...
                    days(1): ...
                    dateshift(t1,'start','day')).';
                return
            end
        catch
        end
    end

    [t0,t1] = local_requested_bounds(split);

    t0 = dateshift(t0,'start','day');
    t1 = dateshift(t1,'start','day');

    if t1 < t0
        error(['      Error:read_meteo_NZ: ' ...
            'requested daily period is empty: %s to %s.'], ...
            string(t0),string(t1));
    end

    req.time = (t0:days(1):t1).';
end

% -----------------------------------------------
function [t0,t1] = local_requested_bounds(split)
% -----------------------------------------------

    spinup = 0;
    if isfield(split,'spinup') ...
            && ~isempty(split.spinup)
        spinup = max(0,round(double(split.spinup)));
    elseif isfield(split,'n_spin') ...
            && ~isempty(split.n_spin)
        spinup = max(0,round(double(split.n_spin)));
    end

    starts = NaT(0,1);
    ends = NaT(0,1);

    startFields = {'ds','dts','des','d1', ...
        'dt_train0','dt_eval0','dt_spin0'};
    endFields = {'de','dte','dee','d2', ...
        'dt_train1','dt_eval1','dt_spin1'};

    for i = 1:numel(startFields)
        nm = startFields{i};
        if isfield(split,nm) ...
                && ~isempty(split.(nm))
            starts(end+1,1) = ...
                local_to_datetime(split.(nm)); %#ok<AGROW>
        end
    end

    for i = 1:numel(endFields)
        nm = endFields{i};
        if isfield(split,nm) ...
                && ~isempty(split.(nm))
            ends(end+1,1) = ...
                local_to_datetime(split.(nm)); %#ok<AGROW>
        end
    end

    starts = starts(~isnat(starts));
    ends = ends(~isnat(ends));

    if isempty(starts) || isempty(ends)
        error(['      Error:read_meteo_NZ: ' ...
            'Could not determine the requested time window from split. ' ...
            'Expected date fields such as ds/dts/des and dte/dee, or ' ...
            'dt_train0/dt_train1.']);
    end

    t0 = min(starts);
    t1 = max(ends);

    % Apply spin-up only when no explicit spin-up start was supplied.
    hasExplicitSpinStart = isfield(split,'dt_spin0') ...
        && ~isempty(split.dt_spin0);
    if ~hasExplicitSpinStart && spinup > 0
        t0 = t0 - days(spinup);
    end
end

% ----------------------------------
function t = local_to_datetime(x)
% ----------------------------------

    if isdatetime(x)
        t = x(1);
    elseif isnumeric(x)
        x = double(x);
        if numel(x) >= 3
            % SAGE date vectors are normally [day month year].
            if x(1) <= 31 && x(2) <= 12 && x(3) >= 1000
                t = datetime(x(3),x(2),x(1));
            else
                t = datetime(x(1),x(2),x(3));
            end
        else
            t = datetime(x(1),'ConvertFrom','datenum');
        end
    else
        xs = string(x);
        t = datetime(xs(1));
    end
end

% ---------------------------------------------------------
function f = local_find_nz_station_file(dirX,id,tokens,stream)
% ---------------------------------------------------------

    f = '';
    D = dir(fullfile(dirX,'*.csv'));
    if isempty(D)
        return
    end

    nm = string({D.name});
    low = lower(nm);

    % Require the station identifier as a complete numeric token.
    idExpr = ['(^|[^0-9])0*' regexptranslate('escape',id) ...
        '([^0-9]|$)'];
    idMatch = false(size(low));
    for i = 1:numel(low)
        idMatch(i) = ~isempty(regexp(char(low(i)), ...
            idExpr,'once'));
    end

    tokenMatch = false(size(low));
    for i = 1:numel(tokens)
        token = lower(string(tokens{i}));
        tokenMatch = tokenMatch | contains(low,token);
    end

    if strcmp(stream,'daily')
        dailyMatch = contains(low,'daily');
        j = find(idMatch & tokenMatch & dailyMatch,1,'first');
    else
        j = find(idMatch & tokenMatch,1,'first');
    end

    if isempty(j)
        j = find(idMatch & tokenMatch,1,'first');
    end
    if isempty(j)
        j = find(idMatch,1,'first');
    end
    if ~isempty(j)
        f = fullfile(D(j).folder,D(j).name);
    end
end

% -------------------------------------------------
function Ep = local_oudin_daily_pet(t,T,latitude)
% -------------------------------------------------
% Oudin et al. temperature-based potential evapotranspiration.
% Ra is extraterrestrial radiation in MJ m-2 d-1 and Ep is mm d-1.

    phi = deg2rad(double(latitude));
    J = day(t,'dayofyear');

    dr = 1 + 0.033*cos(2*pi*J/365);
    delta = 0.409*sin(2*pi*J/365 - 1.39);

    arg = -tan(phi).*tan(delta);
    arg = max(-1,min(1,arg));
    ws = acos(arg);

    Gsc = 0.0820;
    Ra = (24*60/pi)*Gsc .* dr .* ...
        (ws.*sin(phi).*sin(delta) + ...
        cos(phi).*cos(delta).*sin(ws));

    Ep = Ra .* (double(T) + 5) / (100*2.45);
    Ep(~isfinite(Ep)) = NaN;
    Ep = max(0,Ep);
end

% --------------------------
function id = local_nz_id(x)
% --------------------------
    if isnumeric(x)
        if isscalar(x)
            id = sprintf('%.0f',double(x));
        else
            id = char(string(x(1)));
        end
    else
        id = char(string(x));
    end

    id = strtrim(id);
    id = regexprep(id,'\.0+$','');
    id = regexprep(id,'^NZ','');
    id = regexprep(id,'[^0-9]','');
    id = regexprep(id,'^0+','');

    if isempty(id)
        error(['      Error:read_meteo_NZ: ' ...
            'Empty CAMELS-NZ station id ' ...
            'after normalization.']);
    end
end

% ----------------------------------------------------------------------
function [t,x] = local_load_or_read_series(fname,cache_file,key,colname)
% ----------------------------------------------------------------------

    src = dir(fname);
    vtime = ['t_' key];
    vdata = ['x_' key];

    if isfile(cache_file)
        try
            S = load(cache_file);
            if isfield(S,vtime) ...
                    && isfield(S,vdata) ...
                    && isfield(S,[key '_source_datenum']) ...
                    && S.([key '_source_datenum']) >= src.datenum
                t = S.(vtime);
                x = S.(vdata);
                return
            end
        catch
        end
    end

    [t,x] = local_read_two_column_csv(fname,colname);

    try
        if isfile(cache_file)
            S = load(cache_file);
        else
            S = struct();
        end
        S.(vtime) = t;
        S.(vdata) = x;
        S.([key '_source_datenum']) = src.datenum;
        save(cache_file,'-struct','S','-v7.3');
    catch
    end
end

% -------------------------------------------------------
function [t,x] = local_read_two_column_csv(fname,colname)
% -------------------------------------------------------

    opts = detectImportOptions(char(fname), ...
        'Delimiter',',', ...
        'VariableNamingRule','preserve');
    opts = setvartype(opts,opts.VariableNames{1},'char');

    T = readtable(char(fname),opts);

    if width(T) < 2
        error(['      Error:read_meteo_NZ: ' ...
            'File has fewer than two columns: %s'], ...
            fname);
    end

    t = local_parse_time(T{:,1});

    vn = string(T.Properties.VariableNames);
    j = find(strcmpi(vn,string(colname)),1,'first');
    if isempty(j)
        j = 2;
    end
    x = local_to_double(T{:,j});
end

% --------------------------------------------------------------
function [P,Ep,T,badrows] = local_extract_aligned_window(tP, ...
    P,tE,Ep,tT,T,req)
% --------------------------------------------------------------
    tq = req.time(:);
    n = numel(tq);

    Pout  = nan(n,1);
    Epout = nan(n,1);
    Tout  = nan(n,1);

    [tfP,locP] = ismember(tq,tP);
    [tfE,locE] = ismember(tq,tE);
    [tfT,locT] = ismember(tq,tT);

    Pout(tfP) = double(P(locP(tfP)));
    Epout(tfE) = double(Ep(locE(tfE)));
    Tout(tfT) = double(T(locT(tfT)));

    P = Pout;
    Ep = Epout;
    T = Tout;

    badmask = ~isfinite(P) ...
        | ~isfinite(Ep) ...
        | ~isfinite(T);
    badrows = int64(find(badmask));
end

% ------------------------------
function t = local_parse_time(x)
% ------------------------------
    if isdatetime(x)
        t = x(:);
        return
    end

    x = string(x(:));
    x = strip(x);
    x = erase(x,'"');

    fmts = {'yyyy-MM-dd HH:mm:ss', ...
            'yyyy/MM/dd HH:mm:ss', ...
            'dd/MM/yyyy HH:mm:ss', ...
            'yyyy-MM-dd''T''HH:mm:ss', ...
            'yyyy-MM-dd', ...
            'yyyy/MM/dd', ...
            'dd/MM/yyyy'};

    for i = 1:numel(fmts)
        try
            t = datetime(x, ...
                'InputFormat',fmts{i});
            if ~any(isnat(t))
                return
            end
        catch
        end
    end

    t = datetime(x);
end

% -----------------------------
function x = local_to_double(x)
% -----------------------------
    if isnumeric(x)
        x = double(x(:));
        return
    end
    if iscell(x)
        x = string(x);
    end
    if ischar(x)
        x = string(cellstr(x));
    end
    if isstring(x) ...
            || iscategorical(x)
        xs = string(x(:));
        xs = erase(xs,'"');
        xs = regexprep(xs, ...
            '^(NA|NaN|null|NULL)$', ...
            'NaN','ignorecase');
        x = str2double(xs);
        return
    end
    error(['      Error:read_meteo_NZ: ' ...
        'Unable to convert column to double.']);
end

% ----------------------------------------
function aux = local_aux_from_bas(bas,aux)
% ----------------------------------------

    K = bas.K;

    if isfield(bas,'lat')
        aux(1:K,1) = double(bas.lat(1:K));
    elseif isfield(bas,'gauge_lat')
        aux(1:K,1) = double(bas.gauge_lat(1:K));
    end

    if isfield(bas,'elev')
        aux(1:K,2) = double(bas.elev(1:K));
    elseif isfield(bas,'gauge_elev')
        aux(1:K,2) = double(bas.gauge_elev(1:K));
    elseif isfield(bas,'elev_mean')
        aux(1:K,2) = double(bas.elev_mean(1:K));
    end

    if isfield(bas,'area')
        a = double(bas.area(1:K));
        if median(a,'omitnan') < 1e7
            a = a * 1e6; % km2 -> m2
        end
        aux(1:K,3) = a;
    elseif isfield(bas,'area_km2')
        aux(1:K,3) = 1e6 * double(bas.area_km2(1:K));
    end
end

function aux = local_aux_from_gauge_info(dirTS,bas,aux)

    % dirTS normally points to:
    %   Data/CAMELS_NZ/daily/timeseries, or
    %   Data/CAMELS_NZ/hourly/timeseries.
    % Static gauge information is shared by both resolutions and is kept
    % directly in Data/CAMELS_NZ.
    dirStream = fileparts(dirTS);
    dirNZ = fileparts(dirStream);

    cands = { ...
        fullfile(dirNZ, ...
        'gauge_information.txt'), ...
        fullfile(dirStream, ...
        'gauge_information.txt'), ...
        fullfile(dirTS, ...
        'gauge_information.txt'), ...
        fullfile(fileparts(dirNZ), ...
        'CAMELS_NZ', ...
        'gauge_information.txt')};

    f = '';
    for ii = 1:numel(cands)
        if isfile(cands{ii})
            f = cands{ii};
            break
        end
    end

    if isempty(f)
        fprintf(['\n      Warning:read_meteo_NZ: ' ...
            'Cannot find gauge_information.txt ' ...
            'near %s.\n'],dirTS);
        return
    end

    T = readtable(f, ...
        'Delimiter','\t', ...
        'VariableNamingRule','preserve');

    vn = lower(strtrim(string(T.Properties.VariableNames)));
    vn_clean = regexprep(vn,'[^a-z0-9]','');

    % CAMELS-NZ uses GAGE_ID, not gauge_id.  Keep broader aliases too.
    iID = find(ismember(vn_clean, ...
        ["gageid","gaugeid", ...
        "gauge","id","stationid"]),1);

    % CAMELS-NZ uses DRAINAGE AREA (KM^2).
    iArea = find(ismember(vn_clean, ...
        ["drainageareakm2", ...
        "drainageareakm", ...
         "catchmentareakm2", ...
         "basinareakm2", ...
         "areakm2","area"]),1);

    iLat = find(ismember(vn_clean, ...
        ["lat","latitude"]),1);
    iLon = find(ismember(vn_clean, ...
        ["long","lon","longitude"]),1); %#ok<NASGU>

    if isempty(iID) || isempty(iArea)
        fprintf(['\n      Warning:' ...
            'read_meteo_NZ: ' ...
            'Could not identify ID/' ...
            'area columns in %s.\n'],f);
        fprintf('      Columns are: %s\n', ...
            strjoin(string( ...
            T.Properties.VariableNames),', '));
        return
    end

    idT = strings(height(T),1);
    for ii = 1:height(T)
        idT(ii) = string(local_nz_id(T{ii,iID}));
    end

    area = double(T{:,iArea});

    % Convert km2 -> m2.  The CAMELS-NZ column is DRAINAGE AREA (KM^2).
    area = area * 1e6;

    nmatch = 0;
    for k = 1:bas.K
        id = string(local_nz_id(bas.id_gauge(k)));
        j = find(idT == id,1,'first');
        if ~isempty(j)
            aux(k,3) = area(j);
            if ~isempty(iLat)
                aux(k,1) = double(T{j,iLat});
            end
            nmatch = nmatch + 1;
        end
    end

    if nmatch == 0
        fprintf(['\n      Warning:read_meteo_NZ: ' ...
            'No selected basin IDs matched %s. ' ...
            'Check gauge ID formatting.\n'],f);
    else
        fprintf(['\n      read_meteo_NZ: matched area for ' ...
            '%d of %d selected basins from %s.\n'], ...
            nmatch,bas.K,f);
    end
end
