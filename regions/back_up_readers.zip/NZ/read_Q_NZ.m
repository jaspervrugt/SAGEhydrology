function dat = read_Q_NZ(dirQ,mdl,dat,bas,split,aux)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%READ_Q_NZ Read CAMELS-NZ daily or hourly streamflow data for SAGE.
%
% Expected folders
%   Data/CAMELS_NZ/daily/timeseries/streamflow/
%       daily_flow_station_id_XXXX.csv
%   Data/CAMELS_NZ/hourly/timeseries/streamflow/
%       flow_station_id_XXXX.csv
%
% File columns:
%   time, flow
%
% The supplied CAMELS-NZ examples store flow as discharge [m3 s-1].
% This reader converts discharge to basin-average runoff depth using
% basin area from aux(:,3), where aux(:,3) must be area [m2]:
%   daily  -> mm d-1
%   hourly -> mm h-1.
%
% CAMELS-NZ station IDs are not USGS IDs and must not be zero-padded.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    split = prepare_split(split);

    K = bas.K;
    K_t = bas.K_t;
    id_GAUGE = bas.id_gauge;

    dt = double(split.dt);
    if abs(dt - 1) < 1e-8
        stream = 'daily';
        stepHours = 24;
        flowPattern = 'daily_flow_station_id_*.csv';
        flowNamePattern = 'daily_flow_station_id_%s.csv';
        unitLabel = 'mm d-1';
    elseif abs(dt - 24) < 1e-8
        stream = 'hourly';
        stepHours = 1;
        flowPattern = 'flow_station_id_*.csv';
        flowNamePattern = 'flow_station_id_%s.csv';
        unitLabel = 'mm h-1';
    else
        fprintf('\n');
        error(['      Error:read_Q_NZ: CAMELS-NZ discharge supports ' ...
            'daily data (SAGE split.dt = 1) and hourly data ' ...
            '(SAGE split.dt = 24).']);
    end

    mode = mdl.mode;
    hasEval = ismember(mode,[2 4]);

    id_train = expand_index(mdl.id_train);

    if hasEval ...
            && isfield(mdl,'id_eval') ...
            && ~isempty(mdl.id_eval)
        id_eval = expand_index(mdl.id_eval);
    else
        id_eval = [];
    end

    dirFlow = local_nz_streamflow_dir(dirQ,stream,flowPattern);

    static_name = fullfile(dirFlow, ...
        sprintf('NZ_discharge_summary_%s.csv',stream));

    run_stamp = char(datetime('now', ...
        'Format','yyyyMMdd_HHmmss'));

    run_name = fullfile(dirFlow, ...
        sprintf('NZ_discharge_run_%s_%s.csv', ...
        stream,run_stamp));

    info_static = dir(static_name);
    need_static = isempty(info_static) || info_static.bytes == 0;

    if hasEval
        Qrun = table('Size',[K 10], ...
            'VariableTypes',{'double', ...
            'string','string', ...
            'string','double','double', ...
            'string', ...
            'string','double','double'}, ...
            'VariableNames',{'gauge', ...
            'use','start_train', ...
            'end_train','n_train', ...
            'n_bad_train', ...
            'start_eval','end_eval', ...
            'n_eval', ...
            'n_bad_eval'});
    else
        Qrun = table('Size',[K 6], ...
            'VariableTypes',{'double', ...
            'string','string', ...
            'string','double','double'}, ...
            'VariableNames',{'gauge','use', ...
            'start_train', ...
            'end_train','n_train', ...
            'n_bad_train'});
    end

    req = local_requested_window(split,stream);

    cache_root = fullfile(dirFlow, ...
        ['_cache_NZ_' stream '_Q']);
    if ~isfolder(cache_root)
        mkdir(cache_root);
    end

    if need_static
        Dall = dir(fullfile(dirFlow, ...
            flowPattern));

        % Some CAMELS-NZ archives may contain zero-byte placeholder files.
        % They should not stop a run if the basin was removed from bas.K.
        isEmpty = [Dall.bytes] == 0;
        if any(isEmpty)
            fprintf(['      Warning:read_Q_NZ: ' ...
                'Skipping %d empty NZ streamflow files ' ...
                'while building the static summary.\n'], ...
                sum(isEmpty));
        end
        D = Dall(~isEmpty);

        Qstat = table('Size',[numel(D) 5], ...
            'VariableTypes',{'double','string', ...
            'string','double','double'}, ...
            'VariableNames',{'gauge','start_record', ...
            'end_record','n_all','n_bad'});

        fprintf(['      Building static ' ...
            '%s NZ discharge summary %3d%%'],stream,0);

        for i = 1:numel(D)
            id = local_id_from_flow_file( ...
                D(i).name);
            fname = fullfile(D(i).folder, ...
                D(i).name);
            % [t,q] = local_read_two_column_csv( ...
            %     fname,'flow');
            % 
            % Qstat.gauge(i) = str2double(id);
            % Qstat.start_record(i) = string( ...
            %     datetime(t(1), ...
            %     'Format','dd/MM/yyyy HH:mm'));
            % Qstat.end_record(i) = string( ...
            %     datetime(t(end), ...
            %     'Format','dd/MM/yyyy HH:mm'));
            % Qstat.n_all(i) = numel(q);
            % Qstat.n_bad(i) = sum(~isfinite(q));
            try
                [t,q] = local_read_two_column_csv( ...
                    fname,'flow');

                Qstat.gauge(i) = str2double(id);
                Qstat.start_record(i) = string( ...
                    datetime(t(1), ...
                    'Format','dd/MM/yyyy HH:mm'));
                Qstat.end_record(i) = string( ...
                    datetime(t(end), ...
                    'Format','dd/MM/yyyy HH:mm'));
                Qstat.n_all(i) = numel(q);
                Qstat.n_bad(i) = sum(~isfinite(q));

            catch MEfile
                Qstat.gauge(i) = str2double(id);
                Qstat.start_record(i) = missing;
                Qstat.end_record(i) = missing;
                Qstat.n_all(i) = 0;
                Qstat.n_bad(i) = NaN;

                fprintf('\n');
                fprintf(['      Warning:' ...
                    'read_Q_NZ: ' ...
                    'skipping bad ' ...
                    'static-summary ' ...
                    'file %s\n'], ...
                    fname);
                fprintf('      Cause: %s\n', ...
                    MEfile.message);
                fprintf(['      Building static %s NZ ' ...
                    'discharge summary ... '],stream);
            end

            if mod(i,25)==0 ...
                    || i==numel(D)
                pct = floor(100*i/max(1,numel(D)));
                fprintf('\b\b\b\b%3d%%',pct);
                drawnow;
            end
        end
        fprintf('\b\b\b\bDone\n');

        % Write the static cache immediately after it is built.  This
        % prevents rebuilding the expensive all-file summary if a later
        % selected-basin read or run-dependent write fails.
        writetable(Qstat,static_name);
        fprintf(['      Read_Q_NZ: ' ...
            'Wrote static discharge summary: %s\n'], ...
            static_name);
    else
        fprintf(['      Using cached %s NZ ' ...
            'discharge summary: %s\n'],stream,static_name);
    end

    fprintf(['... Reading %s CAMELS-NZ ' ...
        'discharge data files %3d%%'],stream,0);

    for k = 1:K

        id = local_nz_id(id_GAUGE(k));
        fname = fullfile(dirFlow, ...
            sprintf(flowNamePattern,id));

        if ~isfile(fname)
            fprintf('\n');
            error(['      Error:read_Q_NZ: ' ...
                'Missing %s streamflow ' ...
                'file for station %s: %s'], ...
                stream,id,fname);
        end

        cache_file = fullfile(cache_root, ...
            sprintf('%s_NZ_Q_%s.mat',id,stream));

        area = aux(k,3);
        if ~isfinite(area) ...
                || area <= 0
            fprintf('\n');
            error(['      Error:read_Q_NZ: ' ...
                'Missing/invalid basin area ' ...
                'for station %s. aux(k,3) ' ...
                'must be area in m2.'],id);
        end

        [Qdepth,startN,endN] = ...
            local_load_or_build_q_cache( ...
            fname,cache_file,area,stream,stepHours);

        [Qmm,badmask] = ...
            local_extract_q_window_fast( ...
            Qdepth,startN,endN,req,id,stream);

        dat{k}.y_n = single(Qmm);

        if k <= K_t
            dat{k}.use = 'training';
        else
            dat{k}.use = 'evaluation';
        end

        dat{k}.fname{2} = fname;
        dat{k}.bad = badmask(:)';

        n_train = numel(id_train);
        n_bad_train = sum(badmask(id_train));

        if hasEval
            n_eval = numel(id_eval);
            n_bad_eval = sum(badmask(id_eval));
        else
            n_eval = 0;
            n_bad_eval = 0;
        end

        Qrun.gauge(k) = str2double(id);

        if k <= K_t
            Qrun.use(k) = "training";
        else
            Qrun.use(k) = "evaluation";
        end

        [train0,train1,eval0,eval1] = ...
            local_split_summary_dates(split,stream);

        Qrun.start_train(k) = string(datetime( ...
            train0,'Format','dd/MM/yyyy HH:mm'));
        Qrun.end_train(k) = string(datetime( ...
            train1,'Format','dd/MM/yyyy HH:mm'));
        Qrun.n_train(k) = n_train;
        Qrun.n_bad_train(k) = n_bad_train;

        if hasEval
            Qrun.start_eval(k) = string(datetime( ...
                eval0,'Format','dd/MM/yyyy HH:mm'));
            Qrun.end_eval(k) = string(datetime( ...
                eval1,'Format','dd/MM/yyyy HH:mm'));
            Qrun.n_eval(k) = n_eval;
            Qrun.n_bad_eval(k) = n_bad_eval;
        end

        if mod(k,20)==0 ...
                || k==K
            pct = floor(100*k/K);
            fprintf('\b\b\b\b%3d%%',pct);
            drawnow;
        end

        if isfield(bas,'progressFcn') ...
                && ~isempty(bas.progressFcn)
            bas.progressFcn(k);
        end
    end

    fprintf('\b\b\b\b... Done\n');

    writetable(Qrun,run_name);
    fprintf(['      Read_Q_NZ: ' ...
        'Wrote run-dependent discharge ' ...
        'summary: %s\n'],run_name);
end

% -------------------------------------------------------
function dirFlow = local_nz_streamflow_dir(dirQ,stream,flowPattern)
% -------------------------------------------------------

    dirQ = char(string(dirQ));

    cands = { ...
        dirQ, ...
        fullfile(dirQ,'streamflow'), ...
        fullfile(dirQ,stream,'timeseries','streamflow'), ...
        fullfile(dirQ,'CAMELS_NZ',stream,'timeseries','streamflow'), ...
        fullfile(dirQ,'Data','CAMELS_NZ',stream,'timeseries','streamflow')};

    % Retain the legacy hourly layout as a final fallback.
    if strcmp(stream,'hourly')
        cands = [cands, { ...
            fullfile(dirQ,'timeseries','streamflow'), ...
            fullfile(dirQ,'CAMELS_NZ','timeseries','streamflow'), ...
            fullfile(dirQ,'Data','CAMELS_NZ','timeseries','streamflow')}];
    end

    for i = 1:numel(cands)
        d = cands{i};
        if isfolder(d) ...
                && ~isempty(dir(fullfile(d,flowPattern)))
            dirFlow = d;
            return
        end
    end

    error(['      Error:read_Q_NZ: Cannot resolve CAMELS-NZ %s ' ...
        'streamflow directory from: %s'],stream,dirQ);
end

% ------------------------------------------------
function req = local_requested_window(split,stream)
% ------------------------------------------------

    if strcmp(stream,'hourly')
        tref = datetime(1950,10,1,0,0,0);
    else
        tref = datetime(1950,10,1);
    end

    if exist('build_requested_window','file') == 2
        try
            req0 = build_requested_window(split,false);

            if isfield(req0,'time') && ~isempty(req0.time)
                req.time = datetime(req0.time(:));
                if strcmp(stream,'hourly')
                    req.time = dateshift(req.time,'start','hour');
                    req.read_start_N = int64(hours(req.time(1)-tref));
                    req.read_end_N = int64(hours(req.time(end)-tref));
                else
                    req.time = dateshift(req.time,'start','day');
                    req.read_start_N = int64(days(req.time(1)-tref));
                    req.read_end_N = int64(days(req.time(end)-tref));
                end
                return
            end

            if isfield(req0,'read_start_N') ...
                    && isfield(req0,'read_end_N')
                req.read_start_N = int64(req0.read_start_N);
                req.read_end_N = int64(req0.read_end_N);
                if strcmp(stream,'hourly')
                    req.time = (tref + hours(double(req.read_start_N)): ...
                        hours(1): ...
                        tref + hours(double(req.read_end_N))).';
                else
                    req.time = (tref + days(double(req.read_start_N)): ...
                        days(1): ...
                        tref + days(double(req.read_end_N))).';
                end
                return
            end
        catch
        end
    end

    [t0,t1] = local_requested_bounds(split);

    if strcmp(stream,'hourly')
        t0 = dateshift(t0,'start','hour');
        if hour(t1)==0 && minute(t1)==0 && second(t1)==0
            t1 = dateshift(t1,'start','day') + hours(23);
        else
            t1 = dateshift(t1,'start','hour');
        end
        req.time = (t0:hours(1):t1).';
        req.read_start_N = int64(hours(req.time(1)-tref));
        req.read_end_N = int64(hours(req.time(end)-tref));
    else
        t0 = dateshift(t0,'start','day');
        t1 = dateshift(t1,'start','day');
        req.time = (t0:days(1):t1).';
        req.read_start_N = int64(days(req.time(1)-tref));
        req.read_end_N = int64(days(req.time(end)-tref));
    end
end

% -----------------------------------------------
function [t0,t1] = local_requested_bounds(split)
% -----------------------------------------------

    spinup = 0;
    if isfield(split,'spinup') && ~isempty(split.spinup)
        spinup = max(0,round(double(split.spinup)));
    elseif isfield(split,'n_spin') && ~isempty(split.n_spin)
        spinup = max(0,round(double(split.n_spin)));
    end

    starts = NaT(0,1);
    ends = NaT(0,1);

    startFields = {'ds','dts','des','d1', ...
        'dt_train0','dt_eval0','dt_spin0'};
    endFields = {'de','dte','dee','d2', ...
        'dt_train1','dt_eval1','dt_spin1'};

    for i = 1:numel(startFields)
        nm = startFields{i};
        if isfield(split,nm) && ~isempty(split.(nm))
            starts(end+1,1) = local_to_datetime(split.(nm)); %#ok<AGROW>
        end
    end
    for i = 1:numel(endFields)
        nm = endFields{i};
        if isfield(split,nm) && ~isempty(split.(nm))
            ends(end+1,1) = local_to_datetime(split.(nm)); %#ok<AGROW>
        end
    end

    starts = starts(~isnat(starts));
    ends = ends(~isnat(ends));

    if isempty(starts) || isempty(ends)
        error(['      Error:read_Q_NZ: Could not determine requested ' ...
            'time window from split.']);
    end

    t0 = min(starts);
    t1 = max(ends);

    hasExplicitSpinStart = isfield(split,'dt_spin0') ...
        && ~isempty(split.dt_spin0);
    if ~hasExplicitSpinStart && spinup > 0
        t0 = t0 - days(spinup);
    end
end

% ------------------------------------------------------------
function [train0,train1,eval0,eval1] = ...
    local_split_summary_dates(split,stream)
% ------------------------------------------------------------

    train0 = local_first_split_date(split, ...
        {'dt_train0','dts','ds'});
    train1 = local_first_split_date(split, ...
        {'dt_train1','dte','de'});

    eval0 = local_first_split_date(split, ...
        {'dt_eval0','des'},train0);
    eval1 = local_first_split_date(split, ...
        {'dt_eval1','dee'},train1);

    if strcmp(stream,'hourly')
        if hour(train1)==0 && minute(train1)==0 && second(train1)==0
            train1 = train1 + hours(23);
        end
        if hour(eval1)==0 && minute(eval1)==0 && second(eval1)==0
            eval1 = eval1 + hours(23);
        end
    else
        train0 = dateshift(train0,'start','day');
        train1 = dateshift(train1,'start','day');
        eval0 = dateshift(eval0,'start','day');
        eval1 = dateshift(eval1,'start','day');
    end
end

% ------------------------------------------------
function t = local_first_split_date(split,names,varargin)
% ------------------------------------------------

    for i = 1:numel(names)
        nm = names{i};
        if isfield(split,nm) && ~isempty(split.(nm))
            t = local_to_datetime(split.(nm));
            return
        end
    end

    if ~isempty(varargin)
        t = varargin{1};
        return
    end

    error(['      Error:read_Q_NZ: Missing split date field: ' ...
        strjoin(names,', ')]);
end

% ----------------------------------
function t = local_to_datetime(x)
% ----------------------------------

    if isdatetime(x)
        t = x(1);
    elseif isnumeric(x)
        x = double(x);
        if numel(x) >= 3
            if x(1) <= 31 && x(2) <= 12 && x(3) >= 1000
                t = datetime(x(3),x(2),x(1));
            else
                t = datetime(x(1),x(2),x(3));
            end
        else
            t = datetime(x(1),'ConvertFrom','datenum');
        end
    else
        xs = string(x);
        t = datetime(xs(1));
    end
end

% --------------------------
function id = local_nz_id(x)
% --------------------------

    if isnumeric(x)
        if isscalar(x)
            id = sprintf('%.0f',double(x));
        else
            id = char(string(x(1)));
        end
    else
        id = char(string(x));
    end

    id = strtrim(id);
    id = regexprep(id,'\.0+$','');
    id = regexprep(id,'^NZ','');
    id = regexprep(id,'[^0-9]','');
    id = regexprep(id,'^0+','');

    if isempty(id)
        error(['      Error:read_Q_NZ: ' ...
            'Empty CAMELS-NZ station id ' ...
            'after normalization.']);
    end
end

% ------------------------------------------
function id = local_id_from_flow_file(fname)
% ------------------------------------------

tok = regexp(char(fname), ...
    '(?:daily_)?flow_station_id_(\d+)\.csv$', ...
    'tokens','once');
    if isempty(tok)
        id = '';
    else
        id = tok{1};
    end
end

% ---------------------------------------------------------------------
function [Qdepth,startN,endN] = local_load_or_build_q_cache(fname,cache_file,area,stream,stepHours)
% ---------------------------------------------------------------------
% Cache the full NZ discharge vector once, together with integer time
% offsets. Later runs can slice by index without datetime matching.

    src = dir(fname);
    tref = datetime(1950,10,1,0,0,0);
    rebuild = true;

    if isfile(cache_file)
        try
            S = load(cache_file,'Qdepth','startN','endN', ...
                'area_m2','source_datenum');
            if isfield(S,'Qdepth') ...
                    && isfield(S,'startN') ...
                    && isfield(S,'endN') ...
                    && isfield(S,'area_m2') ...
                    && isfield(S,'source_datenum') ...
                    && S.source_datenum >= src.datenum ...
                    && abs(double(S.area_m2) - double(area)) ...
                    <= max(1,1e-9*double(area))
                Qdepth = S.Qdepth;
                startN = int64(S.startN);
                endN = int64(S.endN);
                rebuild = false;
            end
        catch
        end
    end

    if rebuild
        [t,Qcms] = local_read_two_column_csv(fname,'flow');

        % flow [m3 s-1] -> runoff depth for the selected time step.
        Qdepth = single(double(Qcms) * stepHours * 3600 * 1000 / double(area));

        if strcmp(stream,'hourly')
            startN = int64(round(hours(t(1) - tref)));
            endN = int64(round(hours(t(end) - tref)));
        else
            tref = datetime(1950,10,1);
            t = dateshift(t,'start','day');
            startN = int64(round(days(t(1) - tref)));
            endN = int64(round(days(t(end) - tref)));
        end

        nExpected = double(endN - startN + 1);
        if nExpected ~= numel(Qdepth)
            error(['      Error:read_Q_NZ: ' ...
                '%s streamflow file is not a continuous record: %s'], ...
                stream,fname);
        end

        source_datenum = src.datenum;
        area_m2 = area;
        save(cache_file,'Qdepth','startN','endN','area_m2', ...
            'source_datenum','-v7.3');
    end
end

% ---------------------------------------------------------------------
function [Qmm,badmask] = local_extract_q_window_fast(Qdepth,startN,endN,req,id,stream)
% ---------------------------------------------------------------------
% Fast extraction using integer time offsets instead of datetime matching.

    if req.read_start_N < startN || req.read_end_N > endN
        error(['      Error:read_Q_NZ: requested period outside ' ...
            '%s streamflow file for station %s.'],stream,id);
    end

    id0 = double(req.read_start_N - startN) + 1;
    id1 = double(req.read_end_N - startN) + 1;

    if id0 < 1 || id1 > numel(Qdepth) || id1 < id0
        error(['      Error:read_Q_NZ: invalid hourly slice for ' ...
            'station %s.'],id);
    end

    Qmm = double(Qdepth(id0:id1));
    badmask = ~isfinite(Qmm);
    badmask = badmask(:)';
end

% -------------------------------------------------------
function [t,x] = local_read_two_column_csv(fname,colname)
% -------------------------------------------------------

    info = dir(char(fname));
    if isempty(info) || info.bytes == 0
        error(['      Error:read_Q_NZ: ' ...
            'Empty streamflow file: %s'],fname);
    end

    opts = detectImportOptions(char(fname), ...
        'Delimiter',',', ...
        'VariableNamingRule','preserve');

    if isempty(opts.VariableNames) ...
            || numel(opts.VariableNames) < 2
        error(['      Error:read_Q_NZ: ' ...
            'Could not detect two columns in file: %s'],fname);
    end

    opts = setvartype(opts, ...
        opts.VariableNames{1},'char');

    T = readtable(char(fname),opts);

    if width(T) < 2
        error(['      Error:read_Q_NZ: ' ...
            'File has fewer than ' ...
            'two columns: %s'],fname);
    end

    t = local_parse_time(T{:,1});

    vn = string(T.Properties.VariableNames);
    j = find(strcmpi(vn, ...
        string(colname)),1,'first');
    if isempty(j)
        j = 2;
    end
    x = local_to_double(T{:,j});
end

% ------------------------------
function t = local_parse_time(x)
% ------------------------------
    if isdatetime(x)
        t = x(:);
        return
    end

    x = string(x(:));
    x = strip(x);
    x = erase(x,'"');

    fmts = {'yyyy-MM-dd HH:mm:ss', ...
            'yyyy/MM/dd HH:mm:ss', ...
            'dd/MM/yyyy HH:mm:ss', ...
            'yyyy-MM-dd''T''HH:mm:ss', ...
            'yyyy-MM-dd', ...
            'yyyy/MM/dd', ...
            'dd/MM/yyyy'};

    for i = 1:numel(fmts)
        try
            t = datetime(x, ...
                'InputFormat',fmts{i});
            if ~any(isnat(t))
                return
            end
        catch
        end
    end

    t = datetime(x);
end

% -----------------------------
function x = local_to_double(x)
% -----------------------------
    if isnumeric(x)
        x = double(x(:));
        return
    end
    if iscell(x)
        x = string(x);
    end
    if ischar(x)
        x = string(cellstr(x));
    end
    if isstring(x) ...
            || iscategorical(x)
        xs = string(x(:));
        xs = erase(xs,'"');
        xs = regexprep(xs, ...
            '^(NA|NaN|null|NULL)$', ...
            'NaN','ignorecase');
        x = str2double(xs);
        return
    end
    error(['      Error:read_Q_NZ: ' ...
        'Unable to convert ' ...
        'column to double.']);
end
