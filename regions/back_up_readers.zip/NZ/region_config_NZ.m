function R = region_config_NZ()
%REGION_CONFIG_NZ Regional defaults for CAMELS-NZ.
%
% All X.paths fields are relative to Data/<R.data_root>.
% Dates use dd/MM/yyyy and water-year boundaries.

    R = struct();
    R.code = 'CAMELS_NZ';
    R.acronym = 'NZ';
    R.name = 'New Zealand';
    R.dataset = 'CAMELS-NZ';
    R.data_root = 'CAMELS_NZ';
    R.resolutions = {'Daily','Hourly'};
    R.default_resolution = 'Daily';
    R.basin_file_pattern = 'NZ_%d_basins.txt';

    X = struct();
    X.label = 'Daily';
    X.dt = 1;
    X.basins.universe = 341;
    X.basins.training = 300;
    X.basins.evaluation = 41;
    X.period.spinup_days = 365;
    X.period.manual.train_start = '01/10/2003';
    X.period.manual.train_end = '30/09/2013';
    X.period.manual.eval_start = '01/10/1993';
    X.period.manual.eval_end = '30/09/2003';
    X.period.common_start = '01/10/1993';
    X.period.common_end = '30/09/2013';
    X.paths.run_root = '';
    X.paths.meteo = fullfile('daily','timeseries');
    X.paths.discharge = fullfile('daily','timeseries');
    % Meteorological/PET controls shown by SAGE-GUI.
    X.meteo.product.items = {'CAMELS-NZ [daily]'};
    X.meteo.product.default = 'CAMELS-NZ [daily]';
    X.meteo.product.enabled = false;
    X.meteo.precipitation.items = {'1 precipitation'};
    X.meteo.precipitation.default = '1 precipitation';
    X.meteo.precipitation.enabled = false;
    X.meteo.temperature.items = {'1 air temperature'};
    X.meteo.temperature.default = '1 air temperature';
    X.meteo.temperature.enabled = false;
    X.meteo.pet.items = {'1 PET'};
    X.meteo.pet.default = '1 PET';
    X.meteo.pet.enabled = false;
    C = repmat(struct('name','','type','','path','','pattern','', ...
        'minimum_count',1,'required',true),0,1);
    C(1).name = 'Meteorological data';
    C(1).type = 'folder';
    C(1).path = fullfile('daily','timeseries');
    C(1).pattern = '*';
    C(1).minimum_count = 1;
    X.checks = C;
    R.by_resolution.Daily = X;

    X = struct();
    X.label = 'Hourly';
    X.dt = 24;
    X.basins.universe = 341;
    X.basins.training = 300;
    X.basins.evaluation = 41;
    X.period.spinup_days = 365;
    X.period.manual.train_start = '01/10/2003';
    X.period.manual.train_end = '30/09/2013';
    X.period.manual.eval_start = '01/10/1993';
    X.period.manual.eval_end = '30/09/2003';
    X.period.common_start = '01/10/1993';
    X.period.common_end = '30/09/2013';
    X.paths.run_root = '';
    X.paths.meteo = fullfile('hourly','timeseries');
    X.paths.discharge = fullfile('hourly','timeseries');
    % Meteorological/PET controls shown by SAGE-GUI.
    X.meteo.product.items = {'CAMELS-NZ [hourly]'};
    X.meteo.product.default = 'CAMELS-NZ [hourly]';
    X.meteo.product.enabled = false;
    X.meteo.precipitation.items = {'1 precipitation'};
    X.meteo.precipitation.default = '1 precipitation';
    X.meteo.precipitation.enabled = false;
    X.meteo.temperature.items = {'1 air temperature'};
    X.meteo.temperature.default = '1 air temperature';
    X.meteo.temperature.enabled = false;
    X.meteo.pet.items = {'1 PET'};
    X.meteo.pet.default = '1 PET';
    X.meteo.pet.enabled = false;
    C = repmat(struct('name','','type','','path','','pattern','', ...
        'minimum_count',1,'required',true),0,1);
    C(1).name = 'Meteorological data';
    C(1).type = 'folder';
    C(1).path = fullfile('hourly','timeseries');
    C(1).pattern = '*';
    C(1).minimum_count = 1;
    X.checks = C;
    R.by_resolution.Hourly = X;

end