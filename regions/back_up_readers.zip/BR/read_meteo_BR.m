function [dat,aux] = read_meteo_BR(dirM,bas,split,meteo)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%READ_METEO_BR Read CAMELS-BR daily meteorological data for SAGE.
%
% SYNOPSIS: [dat,aux] = read_meteo_BR(dirM,bas,split,meteo)
%   dirM        CAMELS-BR data directory, normally .../Data/CAMELS_BR
%   bas         basin structure with fields
%    .K          number of selected basins
%    .id_gauge   Kx1 gauge IDs in final basin order
%   split       SAGE split structure. Supports daily dt = 1 only.
%               Uses spinup aware requested window from manual or ds/de fld
%   meteo       options structure
%    .data       precipitation source:
%                 0 mean of available precipitation products [default]
%                 1 p_brdwgd
%                 2 p_chirps
%                 3 p_cpc
%                 4 p_era5land
%                 5 p_mswep
%    .pet        PET source:
%                 0 mean of available pet products [default]
%                 1 pet_gleam
%                 2 pet_era5land
%    .temp       temperature source:
%                1 tmean_era5land [default]
%                2 mean(tmax_cpc,tmin_cpc)
%                3 mean(tmax_era5land,tmin_era5land)
%                4 mean(tmax_brdwgd,tmin_brdwgd)
%    .progressFcn OPTIONAL function handle called progressFcn(k)
%   dat         OUTPUT: Kx1 cell array. 
%    .P          nx1 precipitation vector (mm/day)
%    .Ep         nx1 potential evapotranspiration vector (mm/day)
%    .T          nx1 temperature vector (°C)
%    .bad        nx1 logical array with 0 (= good) and 1 (= bad)
%   aux         OUTPUT: Kx3 mtrx [lat,elv,area_m2] if gauge_information.txt
%               is available; otherwise NaN values are returned.
%
% NOTES
%   Expected CAMELS-BR files:
%     precipitation/<gauge_id>_precipitation.txt
%     pet/<gauge_id>_potential_evapotransp.txt
%     temperature/<gauge_id>_temperature.txt
%
%   Each file must contain columns year month day plus data columns.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% © Written by Jasper A. Vrugt, May 2025                                  %
% University of California, Irvine                                        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    if nargin < 1 ...
            || isempty(dirM)
        error('read_meteo_BR:missingDir', ...
            ['      Error:read_meteo_BR: ' ...
            'dirM must be provided.']);
    end
    if ~isfolder(dirM)
        error('read_meteo_BR:missingDir', ...
            ['      Error:read_meteo_BR: ' ...
            'Directory does not exist: %s'],dirM);
    end
    if nargin < 2 ...
            || ~isstruct(bas) ...
            || ~isfield(bas,'id_gauge')
        error('read_meteo_BR:missingBasins', ...
            ['      Error:read_meteo_BR: ' ...
            'bas.id_gauge ' ...
            'must be provided.']);
    end
    if nargin < 3 ...
            || isempty(split)
        error('read_meteo_BR:missingSplit', ...
            ['      Error:read_meteo_BR: ' ...
            'split must be provided.']);
    end
    if nargin < 4 || isempty(meteo)
        meteo = struct();
    end
    
    split = prepare_split_BR(split);
    dt = double(split.dt);
    if dt ~= 1
        error('read_meteo_BR:dailyOnly', ...
            ['      Error:read_meteo_BR: ' ...
            'CAMELS-BR currently ' ...
            'supports daily data only, ' ...
            'so split.dt must be 1.']);
    end
    
    K = bas.K;
    id_gauge = double(string_to_double_BR( ...
        bas.id_gauge(:)));
    if numel(id_gauge) ~= K
        K = numel(id_gauge);
    end
    
    [p_name,p_id] = ...
        precipitation_source_BR(meteo);
    [pet_name,pet_id] = ...
        pet_source_BR(meteo);
    t_name = ...
        temperature_source_BR(meteo);
    
    req = build_requested_window_BR( ...
        split,true);
    
    [rootBR,dailyBR] = local_br_data_roots(dirM);
    precDir = fullfile(dailyBR, ...
        'precipitation');
    petDir = fullfile(dailyBR, ...
        'pet');
    tempDir = fullfile(dailyBR, ...
        'temperature');
    
    if ~isfolder(precDir)
        error('read_meteo_BR:missingPrecipDir', ...
            ['      Error:read_meteo_BR: ' ...
            'Missing folder: %s'],precDir);
    end
    if ~isfolder(petDir)
        error('read_meteo_BR:missingPETDir', ...
            ['      Error:read_meteo_BR: ' ...
            'Missing folder: %s'],petDir);
    end
    if ~isfolder(tempDir)
        error('read_meteo_BR:missingTempDir', ...
            ['      Error:read_meteo_BR: ' ...
            'Missing folder: %s'],tempDir);
    end
    
    cacheDir = fullfile(dailyBR,'timeseries');
    if ~isfolder(cacheDir)
        mkdir(cacheDir);
    end
    
    dat = cell(K,1);
    aux = nan(K,3);
    ginfo = read_gauge_info_BR(rootBR);
    
    msg = ['... Reading CAMELS-BR ' ...
        'daily meteorological data'];
    fprintf('%s ... %3d%%',msg,0);
    
    flag_progress = true;
    
    for k = 1:K
        gid = id_gauge(k);
    
        cacheFile = fullfile(cacheDir, ...
            sprintf('%d_BR_daily_p%d_pet%d_t%s.mat', ...
            gid,p_id,pet_id, ...
            matlab.lang.makeValidName(t_name)));
    
        if isfile(cacheFile)
            S = load(cacheFile,'P','Ep', ...
                'T','bad_meteo', ...
                'fileStartDT','fileEndDT', ...
                'fileStartN','fileEndN', ...
                'gid','precipSource', ...
                'petSource','tempSource');
            Pfull = S.P;
            Epfull = S.Ep;
            Tfull = S.T;
            bad_full = S.bad_meteo;
            fileStartDT = S.fileStartDT;
            fileEndDT = S.fileEndDT;
            fileStartN = S.fileStartN;
            fileEndN = S.fileEndN;
        else
            fP = resolve_br_file(precDir, ...
                gid,'precipitation');
            fE = resolve_br_file(petDir, ...
                gid,'potential_evapotransp');
            fT = resolve_br_file(tempDir, ...
                gid,'temperature');
    
            [Pfull,Epfull,Tfull,bad_full, ...
                fileStartDT,fileEndDT, ...
                fileStartN,fileEndN] = ...
                build_br_meteo_cache( ...
                fP,fE,fT,p_name,pet_name,t_name);
    
            P = single(Pfull);
            Ep = single(Epfull);
            T = single(Tfull); 
            bad_meteo = int64(bad_full(:));
            precipSource = p_name;
            petSource = pet_name;
            tempSource = t_name; 
            save(cacheFile,'P','Ep','T', ...
                'bad_meteo', ...
                'fileStartDT','fileEndDT', ...
                'fileStartN','fileEndN', ...
                'gid','precipSource', ...
                'petSource','tempSource','-v7.3');
        end
    
        if req.read_start_N < fileStartN ...
                || req.read_end_N > fileEndN
            if flag_progress
                fprintf('\n');
            end
            error(['      Error:read_meteo_BR: ' ...
                'requested period ' ...
                'outside CAMELS-BR meteo ' ...
                'files for basin %d.\n' ...
                'File covers %s to %s.'],gid, ...
                string(fileStartDT), ...
                string(fileEndDT));
        end
    
        id0 = double(req.read_start_N ...
            - fileStartN) + 1;
        id1 = double(req.read_end_N ...
            - fileStartN) + 1;
        idx = id0:id1;
    
        dat{k}.meteo.P = single(Pfull(idx));
        dat{k}.meteo.Ep = single(Epfull(idx));
        dat{k}.meteo.T = single(Tfull(idx));
        dat{k}.gauge = gid;
        dat{k}.fname = {cacheFile};
    
        bad_full = double(bad_full(:));
        bad_loc = bad_full(bad_full >= id0 ...
            & bad_full <= id1) - id0 + 1;
        dat{k}.meteo.bad = bad_loc(:)';
    
        if ~isempty(ginfo)
            j = find(ginfo.gauge_id == gid,1);
            if ~isempty(j)
                aux(k,1) = ginfo.lat(j);
                aux(k,2) = ginfo.elev(j);
                aux(k,3) = ginfo.area_m2(j);
            end
        end
    
        if mod(k,5) == 0 ...
                || k == K
            pct = floor(100*k/K);
            fprintf('\b\b\b\b%3d%%',pct);
            drawnow;
        end
    
        if isfield(meteo,'progressFcn') ...
                && ~isempty(meteo.progressFcn)
            try
                meteo.progressFcn(k);
            catch MEprogress
                warning('read_meteo_BR:progressFcn', ...
                    'GUI progress callback failed: %s', ...
                    MEprogress.message);
            end
        end
    end
    
    if flag_progress
        fprintf('\b\b\b\bDone\n');
    end
    
    if isfield(split,'local') ... 
            && split.local ...
            && isfield(split,'rainfall_block') ...
            && split.rainfall_block
        dat = rainfall_rank_split(dat,split);
    end

end

% ===================================================================
function [P,Ep,T,bad,fileStartDT,fileEndDT,fileStartN,fileEndN] = ...
    build_br_meteo_cache(fP,fE,fT,p_name,pet_name,t_name)
% ===================================================================

    TP = read_br_meteo_table(fP);
    TE = read_br_meteo_table(fE);
    TT = read_br_meteo_table(fT);
    
    tP = datetime(TP.year, ...
        TP.month,TP.day);
    tE = datetime(TE.year, ...
        TE.month,TE.day);
    tT = datetime(TT.year, ...
        TT.month,TT.day);
    
    fileStartDT = max([min(tP), ...
        min(tE),min(tT)]);
    fileEndDT = min([max(tP), ...
        max(tE),max(tT)]);
    
    if fileEndDT < fileStartDT
        error('read_meteo_BR:noOverlap', ...
            ['      Error:read_meteo_BR: ' ...
            'meteo files do not ' ...
            'overlap in time.']);
    end
    
    t = (fileStartDT:days(1):fileEndDT)';
    
    P0 = column_by_date_BR(TP, ...
        tP,t,p_name,fP);
    E0 = column_by_date_BR(TE, ...
        tE,t,pet_name,fE);
    T0 = temperature_by_date_BR(TT, ...
        tT,t,t_name,fT);
    
    P = single(P0(:));
    Ep = single(E0(:));
    T = single(T0(:));
    
    bad = find(~isfinite(P) ...
        | ~isfinite(Ep) ...
        | ~isfinite(T));
    bad = int64(bad(:));
    
    fileStartN = int64(datenum(fileStartDT)); %#ok
    fileEndN = int64(datenum(fileEndDT));     %#ok
end

% -------------------------------------
function T = read_br_meteo_table(fname)
% -------------------------------------

    opts = detectImportOptions(fname, ...
        'FileType','text');
    opts.VariableNamingRule = 'preserve';
    T = readtable(fname,opts);
    T.Properties.VariableNames = ...
        matlab.lang.makeValidName( ...
        T.Properties.VariableNames, ...
        'ReplacementStyle','delete');
    need = {'year','month','day'};
    for i = 1:numel(need)
        if ~ismember(need{i}, ...
                T.Properties.VariableNames)
            error('read_meteo_BR:badFile', ...
                ['      Error:read_meteo_BR: ' ...
                '%s lacks column %s.'], ...
                fname,need{i});
        end
    end
end

% --------------------------------------------------------
function x = column_by_date_BR(T,tFile,tReq,varName,fname)
% --------------------------------------------------------

    if strcmp(varName,'p_mean_available')
        vars = {'p_brdwgd','p_chirps', ...
            'p_cpc','p_era5land','p_mswep'};
        X = nan(height(T),numel(vars));
        for j = 1:numel(vars)
            if ismember(vars{j}, ...
                    T.Properties.VariableNames)
                X(:,j) = double(T.(vars{j}));
            end
        end
        xAll = mean(X,2,'omitnan');
        [tf,loc] = ismember(tReq,tFile);
        if ~all(tf)
            error('read_meteo_BR:missingDates', ...
                ['      Error:read_meteo_BR: ' ...
                '%s lacks %d requested dates, e.g. %s.'], ...
                fname,sum(~tf),string(tReq(find(~tf,1))));
        end
        x = xAll(loc);
        return
    end
    
    if strcmp(varName,'pet_mean_available')
        vars = {'pet_gleam','pet_era5land'};
        X = nan(height(T),numel(vars));
        for j = 1:numel(vars)
            if ismember(vars{j}, ...
                    T.Properties.VariableNames)
                X(:,j) = double(T.(vars{j}));
            end
        end
        xAll = mean(X,2,'omitnan');
        [tf,loc] = ismember(tReq,tFile);
        if ~all(tf)
            error('read_meteo_BR:missingDates', ...
                ['      Error:read_meteo_BR: ' ...
                '%s lacks %d requested dates, e.g. %s.'], ...
                fname,sum(~tf),string(tReq(find(~tf,1))));
        end
        x = xAll(loc);
        return
    end
    
    if ~ismember(varName, ...
            T.Properties.VariableNames)
        error('read_meteo_BR:missingVariable', ...
            ['      Error:read_meteo_BR: ' ...
            '%s lacks column %s.'], ...
            fname,varName);
    end
    [tf,loc] = ismember(tReq,tFile);
    if ~all(tf)
        error('read_meteo_BR:missingDates', ...
            ['      Error:read_meteo_BR: ' ...
            '%s lacks %d requested ' ...
            'dates, e.g. %s.'],fname,sum(~tf), ...
            string(tReq(find(~tf,1))));
    end
    x = double(T.(varName)(loc));
end

% ----------------------------------------
function x = temperature_by_date_BR(T, ...
    tFile,tReq,t_name,fname)
% ----------------------------------------

    switch t_name
        case 'tmean_era5land'
            x = column_by_date_BR(T, ...
                tFile,tReq,'tmean_era5land',fname);
        case 'tmean_cpc'
            tx = column_by_date_BR(T, ...
                tFile,tReq,'tmax_cpc',fname);
            tn = column_by_date_BR(T, ...
                tFile,tReq,'tmin_cpc',fname);
            x = 0.5*(tx + tn);
        case 'tmean_era5land_from_minmax'
            tx = column_by_date_BR(T, ...
                tFile,tReq,'tmax_era5land',fname);
            tn = column_by_date_BR(T, ...
                tFile,tReq,'tmin_era5land',fname);
            x = 0.5*(tx + tn);
        case 'tmean_brdwgd'
            tx = column_by_date_BR(T, ...
                tFile,tReq,'tmax_brdwgd',fname);
            tn = column_by_date_BR(T, ...
                tFile,tReq,'tmin_brdwgd',fname);
            x = 0.5*(tx + tn);
        otherwise
            error('read_meteo_BR:badTempSource', ...
                ['      Error:read_meteo_BR: ' ...
                'Unknown temperature source: %s'], ...
                t_name);
    end
end

% ------------------------------------------
function fname = resolve_br_file(d,gid,kind)
% ------------------------------------------

    patterns = { ...
        sprintf('%d_%s.txt',gid,kind), ...
        sprintf('%08d_%s.txt',gid,kind), ...
        sprintf('%d*.txt',gid), ...
        sprintf('%08d*.txt',gid)};
    
    fname = ''; %#ok
    for i = 1:numel(patterns)
        q = dir(fullfile(d,patterns{i}));
        q = q(~[q.isdir]);
        if ~isempty(q)
            fname = fullfile(q(1).folder,q(1).name);
            return
        end
    end
    
    error('read_meteo_BR:missingFile', ...
        ['      Error:read_meteo_BR: ' ...
        'Missing %s file for basin %d in %s.'], ...
        kind,gid,d);
end

% -------------------------------------------------
function [rootBR,dailyBR] = local_br_data_roots(dirM)
    p = char(string(dirM));
    [parent,nm] = fileparts(p);
    if strcmpi(nm,'daily')
        rootBR = parent;
        dailyBR = p;
    elseif any(strcmpi(nm,{'streamflow','precipitation','pet', ...
            'temperature','soil_moisture'}))
        dailyBR = parent;
        [rootBR,nmDaily] = fileparts(dailyBR);
        if ~strcmpi(nmDaily,'daily')
            rootBR = p;
            dailyBR = fullfile(p,'daily');
        end
    else
        rootBR = p;
        dailyBR = fullfile(p,'daily');
    end
end

function [name,id] = precipitation_source_BR(meteo)
% -------------------------------------------------
    id = 0;   % default: ensemble mean
    if isfield(meteo,'data') ...
            && ~isempty(meteo.data)
        id = double(meteo.data);
    end
    
    switch id
        case 0
            name = 'p_mean_available';
        case 1
            name = 'p_brdwgd';
        case 2
            name = 'p_chirps';
        case 3
            name = 'p_cpc';
        case 4
            name = 'p_era5land';
        case 5
            name = 'p_mswep';
        otherwise
            error('read_meteo_BR:badPrecipSource', ...
                ['      Error:read_meteo_BR: ' ...
                'meteo.data must be ' ...
                '0,1,...,5 for CAMELS-BR.']);
    end
end

% ---------------------------------------
function [name,id] = pet_source_BR(meteo)
% ---------------------------------------

    id = 0;   % default: ensemble mean
    if isfield(meteo,'pet') ...
            && ~isempty(meteo.pet)
        id = double(meteo.pet);
    end
    
    switch id
        case 0
            name = 'pet_mean_available';
        case 1
            name = 'pet_gleam';
        case 2
            name = 'pet_era5land';
        otherwise
            error('read_meteo_BR:badPETSource', ...
                ['      Error:read_meteo_BR: ' ...
                'meteo.pet must be ' ...
                '0, 1 or 2 for CAMELS-BR.']);
    end
end

% ------------------------------------------
function name = temperature_source_BR(meteo)
% ------------------------------------------

    id = 1;
    if isfield(meteo,'temp') ...
            && ~isempty(meteo.temp)
        id = double(meteo.temp);
    end
    switch id
        case 1
            name = 'tmean_era5land';
        case 2
            name = 'tmean_cpc';
        case 3
            name = 'tmean_era5land_from_minmax';
        case 4
            name = 'tmean_brdwgd';
        otherwise
            error('read_meteo_BR:badTempSource', ...
                ['      Error:read_meteo_BR: ' ...
                'meteo.temp must be ' ...
                '1..4 for CAMELS-BR.']);
    end
end

% --------------------------------------
function split = prepare_split_BR(split)
% --------------------------------------

    if ~isfield(split,'dt') ...
            || isempty(split.dt)
        split.dt = 1;
    end
    if ~isfield(split,'spinup') ...
            || isempty(split.spinup)
        split.spinup = 0;
    end
end

% -----------------------------------------------------------
function req = build_requested_window_BR(split,includeSpinup)
% -----------------------------------------------------------

    if nargin < 2
        includeSpinup = true;
    end
    spinup = max(0,round(double(split.spinup)));
    
    if isfield(split,'ds') ...
            && isfield(split,'de') ...
            && ~isempty(split.ds) ...
            && ~isempty(split.de)
        d0 = as_datetime_BR(split.ds);
        d1 = as_datetime_BR(split.de);
    elseif isfield(split,'dts') ...
            && isfield(split,'dte') ...
            && ~isempty(split.dts) ...
            && ~isempty(split.dte)
        d0 = as_datetime_BR(split.dts);
        d1 = as_datetime_BR(split.dte);
        if isfield(split,'des') ...
                && isfield(split,'dee') ...
                && ~isempty(split.des) ...
                && ~isempty(split.dee)
            d0 = min(d0,as_datetime_BR(split.des));
            d1 = max(d1,as_datetime_BR(split.dee));
        end
    elseif isfield(split,'d1') ...
            && isfield(split,'d2')
        d0 = as_datetime_BR(split.d1);
        d1 = as_datetime_BR(split.d2);
    else
        error('read_meteo_BR:badSplit', ...
            ['      Error:read_meteo_BR: ' ...
            'Could not determine ' ...
            'requested dates from split. ' ...
            'Expected ds/de or dts/dte.']);
    end
    
    if includeSpinup
        d0 = d0 - days(spinup);
    end
    
    req.read_start_DT = d0;
    req.read_end_DT = d1;
    
    req.read_start_N = int64(datenum(d0)); %#ok<DATNM>
    req.read_end_N = int64(datenum(d1));   %#ok<DATNM>

end

% ----------------------------
function d = as_datetime_BR(x)
% ----------------------------

    if isdatetime(x)
        d = x;
    elseif isnumeric(x)
        x = double(x(:).');
        % SAGE GUI format: [day month year]
        if numel(x) == 3
            if x(1) > 1800
                % [year month day]
                d = datetime(x(1),x(2),x(3));
            elseif x(3) > 1800
                % [day month year]
                d = datetime(x(3),x(2),x(1));
            else
                error('read_meteo_BR:badDate', ...
                    'Cannot determine date-vector order.');
            end
        % Compact yyyymmdd
        elseif isscalar(x) ...
                && x > 1e7 ...
                && x < 1e8
            y = floor(x/10000);
            mo = floor((x - 10000*y)/100);
            da = x - 10000*y - 100*mo;
            d = datetime(y,mo,da);
    
        % Legacy MATLAB datenum
        elseif isscalar(x)
            d = datetime(x, ...
                'ConvertFrom','datenum');
        else
            error('read_meteo_BR:badDate', ...
                ['Unsupported numeric ' ...
                'date format.']);
        end
    elseif ischar(x) ...
            || isstring(x)
        s = strtrim(string(x));
        % GUI string format such as 1/10/2005 or 01/10/2005
        try
            d = datetime(s, ...
                'InputFormat','d/M/yyyy');
        catch
            try
                d = datetime(s, ...
                    'InputFormat','dd/MM/yyyy');
            catch
                d = datetime(s);
            end
        end
    else
        error('read_meteo_BR:badDate', ...
            'Unsupported date input type.');
    end
    
    d = d(1);
end

% -----------------------------------
function G = read_gauge_info_BR(dirM)
% -----------------------------------
    G = [];
    f = fullfile(dirM,'gauge_information.txt');
    if ~isfile(f)
        return
    end
    try
        opts = detectImportOptions(f, ...
            'FileType','text', ...
            'VariableNamingRule','preserve');
        T = readtable(f,opts);
        vn = matlab.lang.makeValidName( ...
            T.Properties.VariableNames, ...
            'ReplacementStyle','delete');
        T.Properties.VariableNames = vn;
        G.gauge_id = double( ...
            string_to_double_BR(T.GAGE_ID));
        G.lat = double(T.LAT);
        G.area_m2 = double(T.DRAINAGEAREAKM2) * 1e6;
        if ismember('ELEV', ...
                T.Properties.VariableNames)
            G.elev = double(T.ELEV);
        else
            G.elev = nan(size(G.gauge_id));
        end
    catch
        G = [];
    end
end

% ---------------------------------
function x = string_to_double_BR(x)
% ---------------------------------
    if isnumeric(x)
        x = double(x);
        return
    end
    x = string(x);
    x = strtrim(x);
    x = regexprep(x,'\.0+$','');
    x = str2double(x);
end
