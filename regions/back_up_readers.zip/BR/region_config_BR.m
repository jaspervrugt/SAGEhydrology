function R = region_config_BR()
%REGION_CONFIG_BR Regional defaults for CAMELS-BR.
%
% All X.paths fields are relative to Data/<R.data_root>.
% Dates use dd/MM/yyyy and water-year boundaries.

    R = struct();
    R.code = 'CAMELS_BR';
    R.acronym = 'BR';
    R.name = 'Brazil';
    R.dataset = 'CAMELS-BR';
    R.data_root = 'CAMELS_BR';
    R.resolutions = {'Daily'};
    R.default_resolution = 'Daily';
    R.basin_file_pattern = 'BR_%d_basins.txt';

    X = struct();
    X.label = 'Daily';
    X.dt = 1;
    X.basins.universe = 685;
    X.basins.training = 500;
    X.basins.evaluation = 185;
    X.period.spinup_days = 365;
    X.period.manual.train_start = '01/10/2007';
    X.period.manual.train_end = '30/09/2017';
    X.period.manual.eval_start = '01/10/1996';
    X.period.manual.eval_end = '30/09/2007';
    X.period.common_start = '01/10/1996';
    X.period.common_end = '30/09/2017';
    X.paths.run_root = '';
    X.paths.meteo = fullfile('daily');
    X.paths.discharge = fullfile('daily','streamflow');
    % Meteorological/PET controls shown by SAGE-GUI.
    X.meteo.product.items = {'CAMELS-BR [daily]'};
    X.meteo.product.default = 'CAMELS-BR [daily]';
    X.meteo.product.enabled = false;
    X.meteo.precipitation.items = { ...
        '0 Mean of all products', ...
        '1 BR-GWGD', ...
        '2 CHIRPS', ...
        '3 CPC', ...
        '4 ERA5-Land', ...
        '5 MSWEP' ...
        };
    X.meteo.precipitation.default = '0 Mean of all products';
    X.meteo.precipitation.enabled = true;
    X.meteo.temperature.items = { ...
        '1 ERA5-Land', ...
        '2 CPC: (Tmin+Tmax)/2', ...
        '3 ERA5-Land: (Tmin+Tmax)/2', ...
        '4 BR-DWGD: (Tmin+Tmax)/2' ...
        };
    X.meteo.temperature.default = '1 ERA5-Land';
    X.meteo.temperature.enabled = true;
    X.meteo.pet.items = { ...
        '0 Mean of both products', ...
        '1 GLEAM', ...
        '2 ERA5-Land' ...
        };
    X.meteo.pet.default = '0 Mean of both products';
    X.meteo.pet.enabled = true;
    C = repmat(struct('name','','type','','path','','pattern','', ...
        'minimum_count',1,'required',true),0,1);
    C(1).name = 'Precipitation';
    C(1).type = 'folder';
    C(1).path = fullfile('daily','precipitation');
    C(1).pattern = '*';
    C(1).minimum_count = 1;
    C(2).name = 'Temperature';
    C(2).type = 'folder';
    C(2).path = fullfile('daily','temperature');
    C(2).pattern = '*';
    C(2).minimum_count = 1;
    C(3).name = 'PET';
    C(3).type = 'folder';
    C(3).path = fullfile('daily','pet');
    C(3).pattern = '*';
    C(3).minimum_count = 1;
    C(4).name = 'Streamflow';
    C(4).type = 'folder';
    C(4).path = fullfile('daily','streamflow');
    C(4).pattern = '*';
    C(4).minimum_count = 1;
    X.checks = C;
    R.by_resolution.Daily = X;

end