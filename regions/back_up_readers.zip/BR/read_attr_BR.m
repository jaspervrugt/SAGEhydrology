function [A,id_gauge,gname,zone] = read_attr_BR(dirD,bas)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%READ_ATTR_BR Read catchment attributes of CAMELS-BR dataset.
%
% SYNOPSIS:
%   [A,id_gauge,gname,zone] = read_attr_BR(dirD,bas)
%
% INPUT:
%   dirD        Directory with CAMELS-BR catchment-attribute files
%   bas         OPTIONAL: structure with basin and attribute information
%    .id_gauge   OPTIONAL: vector of requested ANA gauge identifiers
%    .id_attr    rx1 vector of integer attribute IDs
%    .pr_attr    OPTIONAL: print attribute table [1/0]
%
% OUTPUT:
%   A           r x K matrix of standardized selected attributes
%   id_gauge    K x 1 vector with ANA gauge identifiers
%   gname       K x 1 string array with standardized gauge names
%   zone        structure with CAMELS-BR basin classification
%    .id          K x 1 string array with zone labels per basin
%    .long        K x 1 string array with descriptive zone labels
%    .num         K x 1 numeric vector with integer zone identifiers
%    .codes       mx1 string array with unique compact zone codes
%    .names       mx1 string array with unique zone names
%    .lat         K x 1 vector with gauge latitude
%    .runoff_ratio K x 1 vector with runoff-ratio values
%    .forest_perc K x 1 vector with forest-percentage values
%
% DESCRIPTION:
%   This function reads and joins CAMELS-BR location, topography, geology,
%   climate, soil, land-cover, human-intervention, hydrology, and
%   quality-control attributes by gauge_id. Location is used as the master
%   table because it contains gauge_id, gauge_name, gauge latitude, and
%   gauge longitude.
%
% NOTES:
%   If bas is omitted, a small default attribute set is used. Default
%   attributes should include only basic watershed and climate information,
%   not discharge-derived hydrologic signatures.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% © Written by Jasper A. Vrugt, Dec. 2025 / updated Apr. 2026             %
% University of California, Irvine                                        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    if nargin < 1 ...
            || isempty(dirD)
        error('read_attr_BR:missingDir', ...
            ['      Error:read_attr_BR: ' ...
            'dirD must be provided.']);
    end
    
    if ~isfolder(dirD)
        error('read_attr_BR:missingDir', ...
            ['      Error:read_attr_BR: ' ...
            'Attribute directory ' ...
            'does not exist: %s'],dirD);
    end
    
    if nargin < 2
        bas = struct();
    end
    
    if ~isstruct(bas)
        error('read_attr_BR:badBas', ...
            ['      Error:read_attr_BR: ' ...
            'bas must be a structure.']);
    end
    % =========================================
    % ZONE CONTROL PARAMETERS (GLOBAL DEFAULTS)
    % =========================================
    if ~isfield(bas,'min_per_zone') ...
            || isempty(bas.min_per_zone)
        min_per_zone = 5;
    else
        min_per_zone = bas.min_per_zone;
    end    
    if ~isfield(bas,'max_zones') ...
            || isempty(bas.max_zones)
        max_zones = 8;
    else
        max_zones = bas.max_zones;
    end

    do_attr = ~isempty(bas);
    % If bas is omitted as input argument, use a small default 
    % climate-only attribute set.

    pr_table = 1;
    if do_attr ...
            && isstruct(bas) ...
            && isfield(bas,'pr_attr') ...
            && ~isempty(bas.pr_attr)
        pr_table = bas.pr_attr;
    end
    
    if do_attr
        if ~isstruct(bas) ...
                || ~isfield(bas,'id_attr') ...
                || isempty(bas.id_attr)
            error('read_attr_BR:missingIdAttr', ...
                ['      Error:read_attr_BR: ' ...
                'bas.id_attr must be provided.']);
        end
    end
    
    f_topo = fullfile(dirD, ...
        'camels_br_topography.txt');
    f_geol = fullfile(dirD, ...
        'camels_br_geology.txt');
    f_clim = fullfile(dirD, ...
        'camels_br_climate.txt');
    f_soil = fullfile(dirD, ...
        'camels_br_soil.txt');
    f_land = fullfile(dirD, ...
        'camels_br_land_cover.txt');
    f_hydr = fullfile(dirD, ...
        'camels_br_hydrology.txt');
    f_hint = fullfile(dirD, ...
        'camels_br_human_intervention.txt');
    f_qual = fullfile(dirD, ...
        'camels_br_quality_check.txt');
    f_loc = fullfile(dirD, ...
        'camels_br_location.txt');
    
    caller = mfilename;
    must_exist(f_topo, ...
        'camels_br_topography.txt',caller);
    must_exist(f_geol, ...
        'camels_br_geology.txt',caller);
    must_exist(f_clim, ...
        'camels_br_climate.txt',caller);
    must_exist(f_soil, ...
        'camels_br_soil.txt',caller);
    must_exist(f_land, ...
        'camels_br_land_cover.txt',caller);
    must_exist(f_hydr, ...
        'camels_br_hydrology.txt',caller);
    must_exist(f_hint, ...
        'camels_br_human_intervention.txt',caller);
    must_exist(f_qual, ...
        'camels_br_quality_check.txt',caller);
    must_exist(f_loc, ...
        'camels_br_location.txt',caller);
    
    fprintf(['... Reading CAMELS-BR ' ...
        'basin attributes ']);
    
    topo = read_br_table(f_topo);
    geol = read_br_table(f_geol);
    clim = read_br_table(f_clim);
    soil = read_br_table(f_soil);
    land = read_br_table(f_land);
    hydr = read_br_table(f_hydr);
    hint = read_br_table(f_hint);
    qual = read_br_table(f_qual);
    
    loc = read_br_table(f_loc);
    
    % Location is master because it contains gauge_id, gauge_name, lat, lon.
    AA = loc;
    AA = join_br_attributes(AA,topo);
    AA = join_br_attributes(AA,geol);
    AA = join_br_attributes(AA,clim);
    AA = join_br_attributes(AA,soil);
    AA = join_br_attributes(AA,land);
    AA = join_br_attributes(AA,hydr);
    AA = join_br_attributes(AA,hint);
    AA = join_br_attributes(AA,qual);
    
    id_gauge_all = double(AA.gauge_id);
    % If no explicit basin list is provided, use the clean 685-basin set
    % when available. This avoids gauges with incomplete attribute/streamflow
    % support in the full CAMELS-BR location table.
    if ~(isstruct(bas) ...
            && isfield(bas,'id_gauge') ...
            && ~isempty(bas.id_gauge))
    
        f685 = fullfile(dirD,'BR_685_basins.txt');
    
        if isfile(f685)
            bas.id_gauge = readmatrix(f685);
        end
    end
    
    if isstruct(bas) ...
            && isfield(bas,'id_gauge') ...
            && ~isempty(bas.id_gauge)
        id_req = double(string_to_double( ...
            bas.id_gauge(:)));
        [tf,locid] = ismember(id_req, ...
            id_gauge_all);
    
        if ~all(tf)
            missing = id_req(~tf);
            error('read_attr_BR:missingRequestedGauge', ...
                ['      Error:read_attr_BR: ' ...
                'Missing CAMELS-BR ' ...
                'attributes for %d requested ' ...
                'gauge IDs, e.g. %s.'], ...
                numel(missing), ...
                local_id_str(missing(1)));
        end
    
        AA = AA(locid,:);
        id_gauge = id_req(:);
    else
        id_gauge = id_gauge_all(:);
    end
    
    if ismember('gauge_name', ...
            AA.Properties.VariableNames)
        gname = string(AA.gauge_name);
    else
        gname = "Gauge " + string(id_gauge);
    end

    gname = standardize_camels_gauge_names( ...
        gname(:),'CAMELS_BR');
    
    ensure_br_gauge_information(dirD,AA);
    region = erase(mfilename,'read_attr_');
    zone = classify_camels_all_zones(region,AA, ...
        min_per_zone,max_zones);
    
    % ------------------
    % Generic attributes
    % ------------------
    [A,labels] = build_attr_matrix(AA,bas, ...
        mfilename,pr_table);

    if pr_table == 1
        assignin('base', ...
            'SAGE_BR_attribute_labels', ...
            labels);
    end
    
    fprintf(' ... Done\n');

end

% ===============================
function T = read_br_table(fname)
% ===============================

    opts = detectImportOptions(fname, ...
        'FileType','text');
    opts.VariableNamingRule = 'preserve';
    
    T = readtable(fname,opts);
    
    T.Properties.VariableNames = ...
        matlab.lang.makeValidName( ...
        T.Properties.VariableNames, ...
        'ReplacementStyle','delete');
    
    if ~ismember('gauge_id', ...
            T.Properties.VariableNames)
        error('read_attr_BR:missingGaugeID', ...
            ['      Error:read_attr_BR: ' ...
            'File %s does not ' ...
            'contain gauge_id.'],fname);
    end
    
    T.gauge_id = double(string_to_double( ...
        T.gauge_id));
    T = sortrows(T,'gauge_id');

end

% ==================================
function T = join_br_attributes(T,U)
% ==================================

    varsT = string(T.Properties.VariableNames);
    varsU = string(U.Properties.VariableNames);
    varsU = varsU(varsU ~= "gauge_id");
    
    for j = 1:numel(varsU)
        if any(varsT == varsU(j))
            old = char(varsU(j));
            new = char(varsU(j) + "_br");
            U.Properties.VariableNames{strcmp( ...
                U.Properties.VariableNames,old)} = new;
        end
    end
    
    T = outerjoin(T,U, ...
        'Keys','gauge_id', ...
        'MergeKeys',true, ...
        'Type','left');

end

% ===========================================
function ensure_br_gauge_information(dirD,AA)
% ===========================================

    fout = fullfile(dirD,'gauge_information.txt');
    
    if isfile(fout)
        return
    end
    
    needVars = {'gauge_id','gauge_name', ...
        'gauge_lat','gauge_lon'};
    for j = 1:numel(needVars)
        if ~ismember(needVars{j}, ...
                AA.Properties.VariableNames)
            error('read_attr_BR:missingGaugeInfoVar', ...
                ['      Error:read_attr_BR: ' ...
                'Cannot create ' ...
                'gauge_information.txt ' ...
                'because %s is missing.'], ...
                needVars{j});
        end
    end
    
    if ismember('area_gsim', ...
            AA.Properties.VariableNames)
        areaVar = 'area_gsim';
    elseif ismember('area', ...
            AA.Properties.VariableNames)
        areaVar = 'area';
    elseif ismember('area_ana', ...
            AA.Properties.VariableNames)
        areaVar = 'area_ana';
    else
        error('read_attr_BR:missingArea', ...
            ['      Error:read_attr_BR: ' ...
            'Cannot create ' ...
            'gauge_information.txt because ' ...
            'no area variable was found.']);
    end
    
    fid = fopen(fout,'w');
    if fid < 0
        error('read_attr_BR:gaugeInfoWriteFailed', ...
            ['      Error:read_attr_BR: ' ...
            'Could not write ' ...
            'gauge_information.txt to %s.'], ...
            dirD);
    end
    
    cleanup = onCleanup(@() fclose(fid));
    
    fprintf(fid,['HUC_02\tGAGE_ID' ...
        '\tGAGE_NAME\tLAT\tLONG\t' ...
        'DRAINAGE AREA (KM^2)\n']);
    
    for k = 1:height(AA)
        gid = string(AA.gauge_id(k));
        gid = regexprep(gid,'\.0+$','');
    
        gnm = string(AA.gauge_name(k));
        gnm = replace(gnm,char(9),' ');
        gnm = replace(gnm,newline,' ');
    
        lat = double(AA.gauge_lat(k));
        lon = double(AA.gauge_lon(k));
        area = double(AA.(areaVar)(k));
    
        fprintf(fid,['BR\t%s\t%s\t%.6f' ...
            '\t%.6f\t%.6f\n'], ...
            char(gid),char(gnm), ...
            lat,lon,area);
    end
    
    fprintf(['\n      Wrote CAMELS-BR gauge ' ...
        'information file: %s'],fout);

end

% ==============================
function x = string_to_double(x)
% ==============================

    if isnumeric(x)
        x = double(x);
        return
    end
    
    x = string(x);
    x = strtrim(x);
    x = regexprep(x,'\.0+$','');
    x = str2double(x);

end

% ==========================
function s = local_id_str(x)
% ==========================

    if isnumeric(x) ...
            && isfinite(x)
        s = sprintf('%d',x);
    else
        s = char(string(x));
    end

end