function dat = read_Q_BR(dirQ,mdl,dat,bas,split,aux)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%READ_Q_BR Read CAMELS-BR daily streamflow data for SAGE
%
% SYNOPSIS: dat = read_Q_BR(dirQ,mdl,dat,bas,split,aux)
%   dirQ        Directory with CAMELS-BR streamflow txt files, normally
%               Data/CAMELS_BR/daily/streamflow
%   mdl         model/run structure with fields mode, id_train, id_eval
%   dat         Kx1 cell structure to which discharge is added
%   bas         basin structure with fields K, K_t, id_gauge
%   split       time-split structure
%   aux         basin metadata; aux(:,3) is drainage area. The routine
%               accepts area in either m^2 or km^2 and converts if needed.
%
% OUTPUT:
%   dat{k}.y_n       daily discharge depth [mm/day]
%   dat{k}.bad       1xn logical mask for invalid/missing discharge
%   dat{k}.fname{2}  source streamflow file
%   dat{k}.use       'training' or 'evaluation'
%
% CAMELS-BR streamflow files are expected to have columns:
%   year month day streamflow_m3s qual_control_by_ana qual_flag
%
% Notes
%   - Unlike the original CAMELS-US reader, this reader fills days outside
%     the available BR streamflow record with NaN instead of throwing an
%     error. This is safer for Brazil because record start/end dates vary
%     strongly among gauges.
%   - Values are converted from m3/s to mm/day using basin area.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% © Written by Jasper A. Vrugt, Apr. 2026                                 %
% University of California, Irvine                                        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    if nargin < 1 ...
            || isempty(dirQ)
        error('read_Q_BR:missingDir', ...
            ['      Error:read_Q_BR: ' ...
            'dirQ must be provided.']);
    end
    
    if ~isfolder(dirQ)
        error('read_Q_BR:missingDir', ...
            ['      Error:read_Q_BR: ' ...
            'Streamflow directory ' ...
            'does not exist: %s'],dirQ);
    end
    
    if nargin < 6 || isempty(aux)
        error('read_Q_BR:missingAux', ...
            ['      Error:read_Q_BR: ' ...
            'aux with drainage area ' ...
            'in column 3 must be provided.']);
    end
    
    split = local_prepare_split(split);
    
    K = bas.K;
    K_t = bas.K_t;
    id_GAUGE = double(local_string_to_double( ...
        bas.id_gauge(:)));
    
    dt = double(split.dt);
    if dt ~= 1
        error('read_Q_BR:dailyOnly', ...
            ['      Error:read_Q_BR: ' ...
            'CAMELS-BR streamflow ' ...
            'reader supports daily data only.']);
    end
    
    mode = mdl.mode;
    hasEval = ismember(mode,[2 4]);
    
    id_train = expand_index(mdl.id_train);
    if hasEval ...
            && isfield(mdl,'id_eval') ...
            && ~isempty(mdl.id_eval)
        id_eval = expand_index( ...
            mdl.id_eval);
    else
        id_eval = [];
    end
    
    req = local_build_requested_window(split);
    tRef = datetime(req.read_start_N, ...
        'ConvertFrom','datenum');
    tEnd = datetime(req.read_end_N, ...
        'ConvertFrom','datenum');
    timeGrid = (tRef:days(1):tEnd).';
    nGrid = numel(timeGrid);
    
    static_name = fullfile(dirQ, ...
        'CAMELS_BR_discharge_summary_daily.csv');
    run_stamp = char(datetime('now', ...
        'Format','yyyyMMdd_HHmmss'));
    run_name = fullfile(dirQ, ...
        sprintf(['CAMELS_BR_discharge_' ...
        'run_daily_%s.csv'],run_stamp));
    
    if hasEval
        Qrun = table('Size',[K 10], ...
            'VariableTypes',{'double', ...
            'string','string','string', ...
            'double','double','string', ...
            'string','double','double'}, ...
            'VariableNames',{'gauge', ...
            'use','start_train','end_train', ...
            'n_train','n_bad_train', ...
            'start_eval','end_eval', ...
            'n_eval','n_bad_eval'});
    else
        Qrun = table('Size',[K 6], ...
            'VariableTypes',{'double', ...
            'string','string','string', ...
            'double','double'}, ...
            'VariableNames',{'gauge', ...
            'use','start_train','end_train', ...
            'n_train','n_bad_train'});
    end
    
    msg = '... Reading daily CAMELS-BR streamflow files';
    fprintf('%s ... %3d%%',msg,0);
    
    summaryRows = table('Size',[K 7], ...
        'VariableTypes',{'double', ...
        'string','string', ...
        'double','double', ...
        'double','double'}, ...
        'VariableNames',{'gauge', ...
        'start_record','end_record', ...
        'n_all','n_bad_all', ...
        'n_requested','n_bad_requested'});
    
    for k = 1:K
    
        gid = id_GAUGE(k);
        fname = local_find_br_streamflow_file( ...
            dirQ,gid);
    
        if isempty(fname)
            fprintf('\n');
            error('read_Q_BR:missingFile', ...
                ['      Error:read_Q_BR: ' ...
                'Missing CAMELS-BR ' ...
                'streamflow file ' ...
                'for basin %d in %s.'],gid,dirQ);
        end
    
        T = local_read_br_streamflow_table(fname);
        tFile = datetime(T.year, ...
            T.month,T.day);
        Qm3s = double(T.streamflow_m3s);
    
        if ismember('qual_flag', ...
                T.Properties.VariableNames)
            qflag = double(T.qual_flag);
        else
            qflag = ones(size(Qm3s));
        end
    
        if ismember('qual_control_by_ana', ...
                T.Properties.VariableNames)
            qana = double(T.qual_control_by_ana);
        else
            qana = ones(size(Qm3s));
        end
    
        area_m2 = local_area_m2(k,bas,dirQ);
        QmmFile = 1000 * Qm3s * 86400 ./ area_m2;
    
        % Treat non-finite, negative, and non-positive quality flags as bad.
        badFile = ~isfinite(QmmFile) ...
            | QmmFile < 0 ...
            | ~isfinite(qflag) ...
            | qflag <= 0 ...
            | ~isfinite(qana) ...
            | qana <= 0;
    
        % Place available values on requested daily grid.
        Qmm = nan(nGrid,1);
        badmask = true(nGrid,1);
    
        [tf,loc] = ismember(tFile,timeGrid);
        iiFile = find(tf);
        iiGrid = loc(tf);
    
        Qmm(iiGrid) = QmmFile(iiFile);
        badmask(iiGrid) = badFile(iiFile);
    
        % Missing days remain NaN and bad.
        badmask = badmask ...
            | ~isfinite(Qmm);
        % Remove spin-up from discharge output, same convention as read_Q_US
        spinup = 0;
        if isfield(split,'spinup') ...
                && ~isempty(split.spinup)
            spinup = max(0, ...
                round(double(split.spinup)));
        end    
        if spinup > 0
            Qmm = Qmm(spinup+1:end);
            badmask = badmask(spinup+1:end);
        end
    
        dat{k}.y_n = single(Qmm);
        dat{k}.bad = badmask(:)';
        dat{k}.fname{2} = fname;
        dat{k}.gid = gid;
    
        if k <= K_t
            dat{k}.use = 'training';
        else
            dat{k}.use = 'evaluation';
        end
    
        n_train = numel(id_train);
        n_bad_train = sum(badmask(id_train));
    
        if hasEval
            n_eval = numel(id_eval);
            n_bad_eval = sum(badmask(id_eval));
        else
            n_eval = 0;
            n_bad_eval = 0;
        end
    
        Qrun.gauge(k) = gid;
        if k <= K_t
            Qrun.use(k) = "training";
        else
            Qrun.use(k) = "evaluation";
        end
    
        Qrun.start_train(k) = string( ...
            datetime(split.dt_train0, ...
            'ConvertFrom','datenum', ...
            'Format','dd/MM/yyyy'));
        Qrun.end_train(k) = string( ...
            datetime(split.dt_train1, ...
            'ConvertFrom','datenum', ...
            'Format','dd/MM/yyyy'));
        Qrun.n_train(k) = n_train;
        Qrun.n_bad_train(k) = n_bad_train;
    
        if hasEval
            Qrun.start_eval(k) = ...
                string(datetime(split.dt_eval0, ...
                'ConvertFrom','datenum', ...
                'Format','dd/MM/yyyy'));
            Qrun.end_eval(k) = ...
                string(datetime(split.dt_eval1, ...
                'ConvertFrom','datenum', ...
                'Format','dd/MM/yyyy'));
            Qrun.n_eval(k) = n_eval;
            Qrun.n_bad_eval(k) = n_bad_eval;
        end
    
        summaryRows.gauge(k) = gid;
        summaryRows.start_record(k) = ...
            string(datetime(min(tFile), ...
            'Format','dd/MM/yyyy'));
        summaryRows.end_record(k) = ...
            string(datetime(max(tFile), ...
            'Format','dd/MM/yyyy'));
        summaryRows.n_all(k) = numel(QmmFile);
        summaryRows.n_bad_all(k) = sum(badFile);
        summaryRows.n_requested(k) = nGrid;
        summaryRows.n_bad_requested(k) = sum(badmask);
    
        if mod(k,20)==0 ...
                || k==K
            pct = floor(100*k/K);
            fprintf('\b\b\b\b%3d%%',pct);
        end
    
        % Graphical User Interface
        if isfield(bas,'progressFcn') ...
                && ~isempty(bas.progressFcn)
            try
                bas.progressFcn(k,K);
            catch
                try
                    bas.progressFcn(k);
                catch
                end
            end
        end
    end
    
    fprintf('\b\b\b\bDone\n');
    
    try
        writetable(summaryRows,static_name);
    catch ME
        warning('read_Q_BR:summaryWriteFailed', ...
            ['Could not write BR ' ...
            'discharge summary: %s'],ME.message);
    end
    
    try
        writetable(Qrun,run_name);
    catch ME
        warning('read_Q_BR:runWriteFailed', ...
            ['Could not write BR ' ...
            'discharge run summary: %s'], ...
            ME.message);
    end
end

% ================================================
function T = local_read_br_streamflow_table(fname)
% ================================================

    opts = detectImportOptions(fname, ...
        'FileType','text');
    opts.VariableNamingRule = 'preserve';
    T = readtable(fname,opts);
    T.Properties.VariableNames = ...
        matlab.lang.makeValidName( ...
        T.Properties.VariableNames, ...
        'ReplacementStyle','delete');
    
    need = {'year','month','day','streamflow_m3s'};
    for j = 1:numel(need)
        if ~ismember(need{j},T.Properties.VariableNames)
            error('read_Q_BR:badFile', ...
                ['      Error:read_Q_BR: File %s is missing ' ...
                'required column %s.'],fname,need{j});
        end
    end
end

% ------------------------------------------------------
function fname = local_find_br_streamflow_file(dirQ,gid)
% ------------------------------------------------------

    gidText = sprintf('%.0f', ...
        double(gid));
    pat = fullfile(dirQ, ...
        [gidText '_streamflow.txt']);
    if isfile(pat)
        fname = pat;
        return
    end
    
    D = dir(fullfile(dirQ, ...
        [gidText '*streamflow*.txt']));
    if ~isempty(D)
        fname = fullfile(D(1).folder,D(1).name);
    else
        fname = '';
    end
end

% -----------------------------------------
function split = local_prepare_split(split)
% -----------------------------------------

    if ~isfield(split,'dt') ...
            || isempty(split.dt)
        split.dt = 1;
    end
    
    names = {'dt_train0','dt_train1', ...
        'dt_eval0','dt_eval1'};
    for j = 1:numel(names)
        nm = names{j};
        if isfield(split,nm) ...
                && ~isempty(split.(nm))
            split.(nm) = local_to_datenum( ...
                split.(nm));
        end
    end
    
    if ~isfield(split,'dt_eval0') ...
            || isempty(split.dt_eval0)
        split.dt_eval0 = split.dt_train0;
    end
    if ~isfield(split,'dt_eval1') ...
            || isempty(split.dt_eval1)
        split.dt_eval1 = split.dt_train1;
    end
end

% ------------------------------------------------
function req = local_build_requested_window(split)
% ------------------------------------------------

    if isfield(split,'read_start_N') ...
            && isfield(split,'read_end_N') ...
            && ~isempty(split.read_start_N) ...
            && ~isempty(split.read_end_N)
        req.read_start_N = local_to_datenum( ...
            split.read_start_N);
        req.read_end_N = local_to_datenum( ...
            split.read_end_N);
        return
    end
    
    starts = [];
    ends = [];
    if isfield(split,'dt_train0')
        starts(end+1) = split.dt_train0;
    end
    if isfield(split,'dt_eval0')
        starts(end+1) = split.dt_eval0;
    end
    if isfield(split,'dt_train1')
        ends(end+1) = split.dt_train1;
    end
    if isfield(split,'dt_eval1')
        ends(end+1) = split.dt_eval1;
    end
    
    if isempty(starts) ...
            || isempty(ends)
        error('read_Q_BR:badSplit', ...
            ['      Error:read_Q_BR: ' ...
            'Could not determine requested ' ...
            'date window from split.']);
    end
    
    req.read_start_N = min(starts);
    req.read_end_N = max(ends);
    
    if isfield(split,'spinup') ...
            && ~isempty(split.spinup)
        spinup = max(0,round(double(split.spinup)));
        req.read_start_N = ...
            req.read_start_N - spinup;
    end
end

% ------------------------------
function xN = local_to_datenum(x)

    if isdatetime(x)
        d = x(1);
    
    elseif ischar(x) ...
            || isstring(x)
        s = strtrim(string(x));
        try
            d = datetime(s, ...
                'InputFormat','d/M/yyyy');
        catch
            d = datetime(s);
        end
    
    elseif isnumeric(x)
    
        x = double(x(:).');
    
        if numel(x) == 3
    
            if x(1) > 1800
                % [year month day]
                d = datetime(x(1),x(2),x(3));
    
            elseif x(3) > 1800
                % [day month year]
                d = datetime(x(3),x(2),x(1));
    
            else
                error('read_Q_BR:badDate', ...
                    ['Cannot determine ' ...
                    'date-vector order.']);
            end
    
        elseif isscalar(x) ...
                && x > 1e7 ...
                && x < 1e8
            % yyyymmdd
            y  = floor(x/10000);
            mo = floor((x - 10000*y)/100);
            da = x - 10000*y - 100*mo;
            d = datetime(y,mo,da);
    
        elseif isscalar(x)
            % legacy MATLAB datenum
            d = datetime(x,'ConvertFrom', ...
                'datenum');
    
        else
            error('read_Q_BR:badDate', ...
                ['Unsupported numeric ' ...
                'date format.']);
        end
    
    else
        error('read_Q_BR:badDate', ...
            'Unsupported date input type.');
    end
    
    xN = datenum(d); %#ok<DATNM>
end

% ------------------------------------------
function area_m2 = local_area_m2(k,bas,dirQ)
% ------------------------------------------

    area_km2 = NaN;
    
    if isstruct(bas) ...
            && isfield(bas,'area') ...
            && numel(bas.area) >= k ...
            && isfinite(bas.area(k)) ...
            && bas.area(k) > 0
        area_km2 = double(bas.area(k));
    end
    
    if ~isfinite(area_km2)
        dirD = fileparts(dirQ);
        [pDaily,nmDaily] = fileparts(dirD);
        if strcmpi(nmDaily,'daily')
            dirD = pDaily;
        end
        fTop = fullfile(dirD, ...
            'camels_br_topography.txt');
    
        if isfile(fTop)
            T = readtable(fTop);
            gid = double(bas.id_gauge(k));
    
            ii = T.gauge_id == gid;
    
            if any(ii)
                area_km2 = double( ...
                    T.area(find(ii,1)));
            end
        end
    end
    
    if ~isfinite(area_km2) ...
            || area_km2 <= 0
        error('read_Q_BR:badArea', ...
            ['      Error:read_Q_BR: ' ...
            'Invalid drainage area ' ...
            'for basin %s.'], ...
            string(bas.id_gauge(k)));
    end
    
    area_m2 = area_km2 * 1e6;
end

% ------------------------------------
function x = local_string_to_double(x)
% ------------------------------------

    if isnumeric(x)
        x = double(x);
        return
    end
    x = string(x);
    x = strtrim(x);
    x = regexprep(x,'\.0+$','');
    x = str2double(x);
end
