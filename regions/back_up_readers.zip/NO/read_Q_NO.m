function dat=read_Q_NO(~,~,dat,~,~,~)
%READ_Q_NO No-op: GRDC-Caravan streamflow is read with meteorology.
end
