function [dat,aux]=read_meteo_NO(dirM,bas,split,meteo)
%READ_METEO_NO Read daily Norway GRDC-Caravan forcing and discharge.
    [dat,aux]=read_meteo_NA(dirM,bas,split,meteo,'Norway');
end
