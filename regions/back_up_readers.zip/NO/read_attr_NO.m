function [A,id_gauge,gname,zone]=read_attr_NO(dirD,bas)
%READ_ATTR_NO Read filtered Norway GRDC-Caravan attributes.
    [A,id_gauge,gname,zone]=read_attr_NA(dirD,bas,'CAMELS_NO','NO');
end
