function R = region_config_CA()
%REGION_CONFIG_CA Regional defaults for CAMELS-SPAT.
%
% All X.paths fields are relative to Data/<R.data_root>.
% Dates use dd/MM/yyyy and water-year boundaries.

    R = struct();
    R.code = 'CAMELS_CA';
    R.acronym = 'CA';
    R.name = 'Canada';
    R.dataset = 'CAMELS-SPAT';
    R.data_root = 'CAMELS_CA';
    R.resolutions = {'Daily','Hourly'};
    R.default_resolution = 'Daily';
    R.basin_file_pattern = 'CA_%d_basins.txt';

    X = struct();
    X.label = 'Daily';
    X.dt = 1;
    X.basins.universe = 764;
    X.basins.training = 600;
    X.basins.evaluation = 164;
    X.period.spinup_days = 365;
    X.period.manual.train_start = '01/10/2005';
    X.period.manual.train_end = '30/09/2020';
    X.period.manual.eval_start = '01/10/1990';
    X.period.manual.eval_end = '30/09/2005';
    X.period.common_start = '01/10/1990';
    X.period.common_end = '30/09/2020';
    X.paths.run_root = '';
    X.paths.meteo = fullfile('daily','forcing','daymet');
    X.paths.discharge = fullfile('daily','discharge');
    % Meteorological/PET controls shown by SAGE-GUI.
    X.meteo.product.items = {'CAMELS-SPAT Daymet [daily]'};
    X.meteo.product.default = 'CAMELS-SPAT Daymet [daily]';
    X.meteo.product.enabled = false;
    X.meteo.precipitation.items = {'1 Daymet'};
    X.meteo.precipitation.default = '1 Daymet';
    X.meteo.precipitation.enabled = false;
    X.meteo.temperature.items = {'1 Daymet (Tmin+Tmax)/2'};
    X.meteo.temperature.default = '1 Daymet (Tmin+Tmax)/2';
    X.meteo.temperature.enabled = false;
    X.meteo.pet.items = {'1 Daymet Priestley-Taylor'};
    X.meteo.pet.default = '1 Daymet Priestley-Taylor';
    X.meteo.pet.enabled = false;
    C = repmat(struct('name','','type','','path','','pattern','', ...
        'minimum_count',1,'required',true),0,1);
    C(1).name = 'CAMELS-SPAT metadata';
    C(1).type = 'pattern';
    C(1).path = '';
    C(1).pattern = 'camels-spat-metadata.csv';
    C(1).minimum_count = 1;
    C(2).name = 'CAMELS-SPAT attributes';
    C(2).type = 'pattern';
    C(2).path = '';
    C(2).pattern = 'attributes-lumped.csv';
    C(2).minimum_count = 1;
    C(3).name = 'Daily Daymet forcing';
    C(3).type = 'pattern';
    C(3).path = fullfile('daily','forcing','daymet');
    C(3).pattern = 'CAN_*_daymet_lumped.nc';
    C(3).minimum_count = 764;
    C(4).name = 'Daily discharge';
    C(4).type = 'pattern';
    C(4).path = fullfile('daily','discharge');
    C(4).pattern = 'CAN_*_daily_flow_observations.nc';
    C(4).minimum_count = 764;
    X.checks = C;
    R.by_resolution.Daily = X;

    X = struct();
    X.label = 'Hourly';
    X.dt = 24;
    X.basins.universe = 764;
    X.basins.training = 600;
    X.basins.evaluation = 164;
    X.period.spinup_days = 365;
    X.period.manual.train_start = '01/10/2008';
    X.period.manual.train_end = '30/09/2018';
    X.period.manual.eval_start = '01/10/1998';
    X.period.manual.eval_end = '30/09/2008';
    X.period.common_start = '01/10/1998';
    X.period.common_end = '30/09/2018';
    X.paths.run_root = '';
    X.paths.meteo = fullfile('hourly','forcing','rdrs');
    X.paths.discharge = fullfile('hourly','discharge');
    % Meteorological/PET controls shown by SAGE-GUI.
    X.meteo.product.items = {'CAMELS-SPAT RDRS [hourly]'};
    X.meteo.product.default = 'CAMELS-SPAT RDRS [hourly]';
    X.meteo.product.enabled = false;
    X.meteo.precipitation.items = {'1 RDRS'};
    X.meteo.precipitation.default = '1 RDRS';
    X.meteo.precipitation.enabled = false;
    X.meteo.temperature.items = {'1 RDRS air temperature'};
    X.meteo.temperature.default = '1 RDRS air temperature';
    X.meteo.temperature.enabled = false;
    X.meteo.pet.items = {'1 RDRS Penman-Monteith'};
    X.meteo.pet.default = '1 RDRS Penman-Monteith';
    X.meteo.pet.enabled = false;
    C = repmat(struct('name','','type','','path','','pattern','', ...
        'minimum_count',1,'required',true),0,1);
    C(1).name = 'CAMELS-SPAT metadata';
    C(1).type = 'pattern';
    C(1).path = '';
    C(1).pattern = 'camels-spat-metadata.csv';
    C(1).minimum_count = 1;
    C(2).name = 'CAMELS-SPAT attributes';
    C(2).type = 'pattern';
    C(2).path = '';
    C(2).pattern = 'attributes-lumped.csv';
    C(2).minimum_count = 1;
    C(3).name = 'Hourly RDRS forcing';
    C(3).type = 'pattern';
    C(3).path = fullfile('hourly','forcing','rdrs');
    C(3).pattern = 'CAN_*_rdrs_lumped.nc';
    C(3).minimum_count = 764;
    C(4).name = 'Hourly discharge';
    C(4).type = 'pattern';
    C(4).path = fullfile('hourly','discharge');
    C(4).pattern = 'CAN_*_hourly_flow_observations.nc';
    C(4).minimum_count = 764;
    X.checks = C;
    R.by_resolution.Hourly = X;

end