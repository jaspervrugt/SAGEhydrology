function [dat,aux] = read_meteo_CA(dirM,bas,split,meteo)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%READ_METEO_CA Read CAMELS-SPAT Canada lumped meteorological forcing.
%
% Supported installed structures:
%   Data/CAMELS_CA/daily/forcing/daymet/
%     CAN_<id>_daymet_lumped.nc
%   Data/CAMELS_CA/hourly/forcing/rdrs/
%     CAN_<id>_rdrs_lumped.nc
%
% Daily Daymet:
%   prcp [mm/day], tmin/tmax [deg C], pet [mm/day].
%
% Hourly RDRS:
%   RDRS_v2.1_A_PR0_SFC [kg m-2 s-1] -> precipitation [mm/hour]
%   RDRS_v2.1_P_TT_1.5m [K]          -> temperature [deg C]
%   pet [kg m-2 s-1]                 -> PET [mm/hour]
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    if nargin < 4 ...
            || isempty(meteo)
        meteo = struct(); 
    end
    if nargin < 3 ...
            || isempty(split)
        error('read_meteo_CA:missingSplit', ...
            'split must be provided.');
    end
    split = local_prepare_split(split);
    dt = double(split.dt);
    if ~any(dt == [1 24])
        error('read_meteo_CA:badDt', ...
            ['CAMELS-CA supports dt = 1 ' ...
            '(daily) or dt = 24 (hourly).']);
    end
    if ~isfield(bas,'id_gauge') ...
            || isempty(bas.id_gauge)
        error('read_meteo_CA:missingBasins', ...
            'bas.id_gauge is required.');
    end

    ids = local_ca_ids(bas.id_gauge);
    K = numel(ids);
    stream = local_stream_from_dt(dt);
    dirF = local_forcing_dir(dirM,stream);
    root = local_ca_root(dirF);
    [aux,meta] = local_aux(root,ids,bas);

    tReq = local_requested_window(split,dt,true);
    nReq = numel(tReq);
    cacheDir = fullfile(dirF, ...
        sprintf('_cache_CA_%s_meteo',stream));
    if ~isfolder(cacheDir), mkdir(cacheDir); end

    dat = cell(K,1);
    fprintf(['... Reading %s CAMELS-CA ' ...
        'forcing files %3d%%'],stream,0);
    for k = 1:K
        gid = ids(k);
        if dt == 1
            fname = fullfile(dirF, ...
                char("CAN_" + gid + "_daymet_lumped.nc"));
            product = 'daymet';
        else
            fname = fullfile(dirF, ...
                char("CAN_" + gid + "_rdrs_lumped.nc"));
            product = 'rdrs';
        end
        if ~isfile(fname)
            error('read_meteo_CA:missingFile', ...
                ['Missing %s forcing file ' ...
                'for %s: %s'],product,gid,fname);
        end

        key = local_window_key(tReq,dt);
        cacheFile = fullfile(cacheDir, ...
            char(gid + "_" + product + ...
            "_" + key + ".mat"));
        useCache = false;
        if isfile(cacheFile)
            try
                S = load(cacheFile,'P','Ep', ...
                    'T','Tmin','Tmax', ...
                    'badrows','src_datenum');
                fi = dir(fname);
                if S.src_datenum >= fi.datenum
                    P = S.P; Ep = S.Ep; T = S.T;
                    Tmin = S.Tmin; Tmax = S.Tmax;
                    badrows = S.badrows;
                    useCache = true;
                end
            catch
            end
        end

        if ~useCache
            tf = local_nc_time(fname,'time',dt);
            P = nan(nReq,1); Ep = P; T = P; Tmin = P; Tmax = P;

            if dt == 1
                pf = local_nc_vector(fname,'prcp');
                ef = local_nc_vector(fname,'pet');
                tn = local_nc_vector(fname,'tmin');
                tx = local_nc_vector(fname,'tmax');
                tm = (tn+tx)/2;
            else
                pf = local_nc_vector(fname, ...
                    'RDRS_v2.1_A_PR0_SFC') * 3600;
                ef = local_nc_vector(fname, ...
                    'pet') * 3600;
                tm = local_nc_vector(fname, ...
                    'RDRS_v2.1_P_TT_1.5m') - 273.15;
                tn = tm;
                tx = tm;
            end

            [ok,loc] = ismember(tReq,tf);
            P(ok) = pf(loc(ok)); 
            Ep(ok) = ef(loc(ok)); 
            T(ok) = tm(loc(ok));
            Tmin(ok) = tn(loc(ok)); 
            Tmax(ok) = tx(loc(ok));
            P(P<0) = NaN; 
            % Hourly Penman-Monteith PET can be negative during nighttime periods.
            % Hydrologic models require nonnegative potential evaporation, so truncate
            % finite negative values to zero rather than marking them as missing.
            negPET = isfinite(Ep) & Ep < 0;
            Ep(negPET) = 0;

            badrows = int64(find(~isfinite(P) ...
                | ~isfinite(Ep) ...
                | ~isfinite(T)));
            fi = dir(fname); 
            src_datenum = fi.datenum;
            try
                save(cacheFile,'P','Ep','T','Tmin','Tmax', ...
                    'badrows','src_datenum','-v7.3');
            catch
            end
        end

        dat{k}.meteo.P = single(P);
        dat{k}.meteo.Ep = single(Ep);
        dat{k}.meteo.T = single(T);
        dat{k}.meteo.Tmin = single(Tmin);
        dat{k}.meteo.Tmax = single(Tmax);
        dat{k}.meteo.bad = badrows(:)';
        if dt == 1
            dat{k}.meteo_source = 'Daymet';
        else
            dat{k}.meteo_source = 'RDRS';
        end
        dat{k}.gauge = gid;
        dat{k}.fname{1} = fname;
        if isfield(meta,'name')
            dat{k}.gname = meta.name(k); 
        end

        if mod(k,20) == 0 ...
                || k == K
            pct = floor(100*k/K);
            fprintf('\b\b\b\b%3d%%',pct);
            drawnow;
        end

        if isfield(meteo,'progressFcn') ...
                && ~isempty(meteo.progressFcn)
            try
                meteo.progressFcn(k);
            catch MEprogress
                warning('read_meteo_CA:progressFcn', ...
                    'GUI progress callback failed: %s', ...
                    MEprogress.message);
            end
        end
    end
    fprintf('\b\b\b\b%s\n','... Done');

    if isfield(split,'local') ...
            && split.local ...
            && isfield(split,'rainfall_block') ...
            && split.rainfall_block
        dat = rainfall_rank_split(dat,split);
    end
end

function stream = local_stream_from_dt(dt)
    if dt == 24 
        stream = 'hourly'; 
    else 
        stream = 'daily'; 
    end
end

function dirF = local_forcing_dir(dirM,stream)
    d0 = char(string(dirM));
    if strcmp(stream,'daily')
        sub = fullfile('daily','forcing','daymet');
        leaf = 'daymet';
        pat = 'CAN_*_daymet_lumped.nc';
    else
        sub = fullfile('hourly','forcing','rdrs');
        leaf = 'rdrs';
        pat = 'CAN_*_rdrs_lumped.nc';
    end
    c = {d0,fullfile(d0,leaf),fullfile(d0,sub), ...
        fullfile(d0,'CAMELS_CA',sub), ...
        fullfile(d0,'Data','CAMELS_CA',sub)};
    for i=1:numel(c)
        if isfolder(c{i}) ...
                && ~isempty(dir(fullfile(c{i},pat)))
            dirF=c{i}; 
            return
        end
    end
    error('read_meteo_CA:missingDir', ...
        ['Cannot resolve CAMELS-CA ' ...
        '%s forcing directory.'],stream);
end

function root = local_ca_root(dirF)
    root = dirF;
    for i = 1:6
        if isfile(fullfile(root, ...
                'camels-spat-metadata.csv'))
            return
        end
        parent = fileparts(root);
        if strcmp(parent,root)
            break
        end
        root = parent;
    end
    error('read_meteo_CA:missingMetadata', ...
        'Cannot locate CAMELS-CA metadata.');
end

function [aux,Mout] = local_aux(root,ids,bas)
    aux = nan(numel(ids),3); 
    Mout = struct();
    f = fullfile(root,'camels-spat-metadata.csv');
    M = readtable(f,'VariableNamingRule','preserve');
    bid = local_ca_ids(M.Station_id);
    [tf,loc] = ismember(ids,bid);
    if all(tf)
        aux(:,1) = local_double(M.Station_lat(loc));
        aux(:,3) = local_double(M.Basin_area_km2(loc))*1e6;
        Mout.name = string(M.Station_name(loc));
    end
    fA = fullfile(root,'attributes-lumped.csv');
    if isfile(fA)
        try
            L = readtable(fA,'VariableNamingRule', ...
                'preserve');
            row = find(string(L.Attribute) ...
                =="elev_mean",1);
            bcols = local_ca_ids(string( ...
                L.Properties.VariableNames(5:end)));
            [tf,lc] = ismember(ids,bcols);
            if ~isempty(row)
                for k = find(tf(:))'
                    aux(k,2) = double(L{row,4+lc(k)});
                end
            end
        catch
        end
    end
    if isfield(bas,'lat') ...
            && numel(bas.lat)>=numel(ids)
        q = ~isfinite(aux(:,1)); 
        aux(q,1) = double(bas.lat(q));
    end
    if isfield(bas,'elev') ...
            && numel(bas.elev)>=numel(ids)
        q = ~isfinite(aux(:,2));
        aux(q,2) = double(bas.elev(q));
    end
    if isfield(bas,'area') ...
        && numel(bas.area)>=numel(ids)
        q = ~isfinite(aux(:,3)); 
        a = double(bas.area(q));
        a(a<1e7) = a(a<1e7)*1e6; 
        aux(q,3) = a;
    end
end

function x = local_double(x)
    if isnumeric(x)
        x = double(x); 
    else
        x = str2double(string(x)); 
    end
end

function split = local_prepare_split(split)
    if exist('prepare_split','file') == 2
        split = prepare_split(split);
    elseif ~isfield(split,'dt') ...
            || isempty(split.dt)
        split.dt = 1;
    end
end

function tReq = local_requested_window(split,dt,includeSpinup)
    if nargin < 3
        includeSpinup = true;
    end

    % Prefer integer offsets from the common reference epoch. For hourly
    % data, req.time can otherwise end at 00:00 on the final date and omit
    % the remaining 23 hours of that day.
    if exist('build_requested_window','file') == 2
        try
            R = build_requested_window(split,includeSpinup);

            if isfield(R,'read_start_N') ...
                    && isfield(R,'read_end_N') ...
                    && ~isempty(R.read_start_N) ...
                    && ~isempty(R.read_end_N)

                tRef = datetime(1950,10,1,0,0,0);

                if dt == 24
                    t0 = tRef + hours(double(R.read_start_N));
                    t1 = tRef + hours(double(R.read_end_N));
                    tReq = (dateshift(t0,'start','hour'): ...
                        hours(1):dateshift(t1,'start','hour')).';
                else
                    t0 = tRef + days(double(R.read_start_N));
                    t1 = tRef + days(double(R.read_end_N));
                    tReq = (dateshift(t0,'start','day'): ...
                        days(1):dateshift(t1,'start','day')).';
                end
                return
            end

            if isfield(R,'time') ...
                    && ~isempty(R.time)
                tReq = local_snap_time(datetime(R.time(:)),dt);
                return
            end
        catch
        end
    end

    starts = NaT(0,1);
    ends = NaT(0,1);
    sf = {'ds','dts','des','d1', ...
        'dt_train0','dt_eval0','dt_spin0'};
    ef = {'de','dte','dee','d2', ...
        'dt_train1','dt_eval1'};

    for i = 1:numel(sf)
        if isfield(split,sf{i}) ...
                && ~isempty(split.(sf{i}))
            starts(end+1,1) = ...
                local_as_datetime(split.(sf{i})); %#ok<AGROW>
        end
    end
    for i = 1:numel(ef)
        if isfield(split,ef{i}) ...
                && ~isempty(split.(ef{i}))
            ends(end+1,1) = ...
                local_as_datetime(split.(ef{i})); %#ok<AGROW>
        end
    end

    starts = starts(~isnat(starts));
    ends = ends(~isnat(ends));
    if isempty(starts) ...
            || isempty(ends)
        error('read_meteo_CA:badWindow', ...
            ['Could not determine ' ...
            'requested dates from split.']);
    end

    spinDays = 0;
    if includeSpinup
        if isfield(split,'spinup') ...
                && ~isempty(split.spinup)
            spinDays = max(0,double(split.spinup));
        elseif isfield(split,'n_spin') ...
                && ~isempty(split.n_spin)
            spinDays = max(0,double(split.n_spin))/dt;
        end
    end

    if dt == 24
        t0 = dateshift(min(starts),'start','hour') ...
            - hours(spinDays*24);
        t1 = dateshift(max(ends),'end','day');
        t1 = dateshift(t1,'start','hour');
        tReq = (t0:hours(1):t1).';
    else
        t0 = dateshift(min(starts),'start','day') ...
            - days(spinDays);
        t1 = dateshift(max(ends),'start','day');
        tReq = (t0:days(1):t1).';
    end
end

function d = local_as_datetime(x)
    if isdatetime(x)
        d = x(1);
    elseif isnumeric(x)
        x = double(x(:));
        if numel(x) >= 3 ...
                && all(isfinite(x(1:3))) ...
                && x(3)>1000
            d = datetime(x(3),x(2),x(1));
        elseif isscalar(x)
            d = datetime(x,'ConvertFrom','datenum');
        else
            d = NaT;
        end
    else
        d = datetime(string(x(1)));
    end
end

function t = local_snap_time(t,dt)
    t = datetime(t(:));
    if dt == 1
        t = dateshift(t,'start','day');
    else
        t = dateshift(t,'start','hour');
    end
end

function key = local_window_key(t,dt)
    if dt == 1
        fmt = 'yyyyMMdd';
    else
        fmt = 'yyyyMMddHH';
    end
    a = t(1); 
    b = t(end); 
    a.Format = fmt; 
    b.Format = fmt;
    key = string(char(a))+"_"+string(char(b));
end

function ids = local_ca_ids(x)
    ids = upper(strtrim(string(x(:))));
    ids = regexprep(ids,'^CAN[-_]?','');
%    ids = "CAN_"+ids;
end

function t = local_nc_time(fname,varname,dt)
    values = double(ncread(fname,varname));
    units = string(ncreadatt(fname,varname,'units'));
    tok = regexp(char(units), ...
        '^\s*(seconds|minutes|hours|days)\s+since\s+(.+?)\s*$', ...
        'tokens','once');
    if isempty(tok)
        error('read_meteo_CA:badTimeUnits', ...
            'Unsupported NetCDF time units in %s: %s',fname,units);
    end
    baseTxt = regexprep(strtrim(tok{2}),'[TZ]$','');
    try
        base = datetime(baseTxt,'InputFormat', ...
            'yyyy-MM-dd HH:mm:ss');
    catch
        try
            base = datetime(baseTxt, ...
                'InputFormat','yyyy-MM-dd''T''HH:mm:ss');
        catch
            try
                base = datetime(baseTxt, ...
                    'InputFormat','yyyy-MM-dd');
            catch
                base = datetime(baseTxt);
            end
        end
    end
    switch lower(tok{1})
        case 'seconds'
            t = base + seconds(values);
        case 'minutes'
            t = base + minutes(values);
        case 'hours'
            t = base + hours(values);
        otherwise
            t = base + days(values);
    end
    t = local_snap_time(t,dt);
end

function x = local_nc_vector(fname,varname)
    x = double(squeeze(ncread(fname,varname)));
    x = x(:);
    try
        fv = double(ncreadatt(fname, ...
            varname,'_FillValue'));
        x(x==fv) = NaN;
    catch
    end
    x(x<=-9990) = NaN;
end
