function dat = read_Q_CA(dirQ,mdl,dat,bas,split,aux) %#ok<INUSD>
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%READ_Q_CA Read CAMELS-SPAT Canadian discharge observations.
%
% Supported installed structures:
%   Data/CAMELS_CA/daily/discharge/
%     CAN_<id>_daily_flow_observations.nc
%   Data/CAMELS_CA/hourly/discharge/
%     CAN_<id>_hourly_flow_observations.nc
%
% q_obs [m3/s] is converted to basin-average runoff depth:
%   daily  -> mm/day
%   hourly -> mm/hour
%
% Daily ice-affected and partial-day values are treated as missing.
% Hourly ice-affected and below-sensor-level values are treated as missing.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    if nargin < 6
        aux = []; 
    end
    split = local_prepare_split(split);
    dt = double(split.dt);
    if ~any(dt == [1 24])
        error('read_Q_CA:badDt', ...
            ['CAMELS-CA supports dt = 1 ' ...
            '(daily) or dt = 24 (hourly).']);
    end

    ids = local_ca_ids(bas.id_gauge);
    K = numel(ids);
    stream = local_stream_from_dt(dt);
    dirD = local_discharge_dir(dirQ,stream);
    root = local_ca_root(dirD);
    area = local_areas(root,ids,bas,aux);

    tFull=local_requested_window(split,dt,true);
    if isfield(split,'idx') ...
            && ~isempty(split.idx)
        idx = round(double(split.idx(:)));
        idx = idx(idx>=1 ...
            & idx<=numel(tFull));
    else
        spin = 0;
        if isfield(split,'spinup') ...
                && ~isempty(split.spinup)
            spin = max(0,round(double(split.spinup)*dt));
        elseif isfield(split,'n_spin') ...
                && ~isempty(split.n_spin)
            spin = max(0,round(double(split.n_spin)));
        end
        idx = (spin+1:numel(tFull)).';
    end

    cacheDir = fullfile(dirD,sprintf('_cache_CA_%s_Q',stream));
    if ~isfolder(cacheDir)
        mkdir(cacheDir); 
    end

    fprintf(['... Reading %s CAMELS-CA ' ...
        'discharge files %3d%%'],stream,0);
    for k=1:K
        gid = ids(k);
        if dt == 1
            fname = fullfile(dirD, ...
                char("CAN_" + gid + "_daily_flow_observations.nc"));
        else
            fname = fullfile(dirD, ...
                char("CAN_" + gid + "_hourly_flow_observations.nc"));
        end
        if ~isfile(fname)
            error('read_Q_CA:missingFile', ...
                ['Missing %s discharge file ' ...
                'for %s: %s'],stream,gid,fname);
        end

        key = local_window_key(tFull,dt);
        cacheFile = fullfile(cacheDir, ...
            char(gid+"_Q_"+key+".mat"));
        useCache = false;
        if isfile(cacheFile)
            try
                S = load(cacheFile,'Qmm_all', ...
                    'bad_all','src_datenum');
                fi = dir(fname);
                if S.src_datenum >= fi.datenum
                    Qmm_all = S.Qmm_all;
                    bad_all = S.bad_all;
                    useCache = true;
                end
            catch
            end
        end

        if ~useCache
            tf = local_nc_time(fname,'time',dt);
            q = local_nc_vector(fname,'q_obs');
            ice = local_optional_flag(fname, ...
                'q_obs_is_ice_affected',numel(q));

            if dt == 1
                partial = local_optional_flag(fname, ...
                    'q_obs_is_partial_day',numel(q));
                extraBad = partial~=0;
                stepSeconds = 86400;
            else
                below = local_optional_flag(fname, ...
                    'q_obs_is_below_sensor_level',numel(q));
                extraBad = below ~= 0;
                stepSeconds = 3600;
            end

            q(q<0) = NaN;
            qmm = q*stepSeconds*1000/area(k);
            badFile = ~isfinite(qmm) ...
                | ice~=0 ...
                | extraBad;
            qmm(badFile) = NaN;

            Qmm_all = nan(numel(tFull),1);
            bad_all = true(numel(tFull),1);
            [ok,loc] = ismember(tFull,tf);
            Qmm_all(ok) = qmm(loc(ok));
            bad_all(ok) = badFile(loc(ok));
            bad_all=bad_all ...
                | ~isfinite(Qmm_all);
            fi = dir(fname); 
            src_datenum = fi.datenum;
            try
                save(cacheFile,'Qmm_all', ...
                    'bad_all','src_datenum','-v7.3');
            catch
            end
        end

        dat{k}.y_n = single(Qmm_all(idx));
        dat{k}.bad = bad_all(idx).';
        dat{k}.Q_mm_CA = single(Qmm_all);
        dat{k}.fname{2} = fname;
        dat{k}.gauge = gid;

        if mod(k,20) == 0 ...
                || k == K
            pct = floor(100*k/K);
            fprintf('\b\b\b\b%3d%%',pct);
        end
    
        % Graphical User Interface
        if isfield(bas,'progressFcn') ...
                && ~isempty(bas.progressFcn)
            try
                bas.progressFcn(k,K);
            catch
                try
                    bas.progressFcn(k);
                catch
                end
            end
        end
    end
    fprintf('\b\b\b\b%s\n','... Done');
end

function stream = local_stream_from_dt(dt)
    if dt == 24
        stream = 'hourly'; 
    else
        stream = 'daily'; 
    end
end

function dirD = local_discharge_dir(dirQ,stream)
    d0 = char(string(dirQ));
    sub = fullfile(stream,'discharge');
    if strcmp(stream,'daily')
        pat = 'CAN_*_daily_flow_observations.nc';
    else
        pat = 'CAN_*_hourly_flow_observations.nc';
    end
    c={d0,fullfile(d0,'discharge'), ...
        fullfile(d0,sub), ...
       fullfile(d0,'CAMELS_CA',sub), ...
       fullfile(d0,'Data','CAMELS_CA',sub)};
    for i=1:numel(c)
        if isfolder(c{i}) ...
                && ~isempty(dir(fullfile(c{i},pat)))
            dirD=c{i}; 
            return
        end
    end
    error('read_Q_CA:missingDir', ...
        ['Cannot resolve CAMELS-CA %s ' ...
        'discharge directory.'],stream);
end

function root=local_ca_root(dirD)
    root = dirD;
    for i = 1:6
        if isfile(fullfile(root,'camels-spat-metadata.csv'))
            return
        end
        parent = fileparts(root);
        if strcmp(parent,root)
            break
        end
        root = parent;
    end
    error('read_Q_CA:missingMetadata', ...
        'Cannot locate CAMELS-CA metadata.');
end

function area = local_areas(root,ids,bas,aux)
    area = nan(numel(ids),1);
    if ~isempty(aux) ...
            && size(aux,1) >= numel(ids) ...
            && size(aux,2)>=3
        area = double(aux(1:numel(ids),3));
    end
    bad = ~isfinite(area) ...
        | area<=0;
    if any(bad)
        M = readtable(fullfile(root, ...
            'camels-spat-metadata.csv'), ...
            'VariableNamingRule','preserve');
        mid = local_ca_ids(M.Station_id);
        [tf,loc] = ismember(ids,mid);
        vals = local_double(M.Basin_area_km2)*1e6;
        q=bad ...
            & tf;
        area(q) = vals(loc(q));
    end
    if isfield(bas,'area') ...
            && numel(bas.area) >= numel(ids)
        q = ~isfinite(area) ...
            | area<=0;
        a = double(bas.area(q));
        a(a<1e7) = a(a<1e7)*1e6;
        area(q) = a;
    end
    if any(~isfinite(area) ...
            | area<=0)
        error('read_Q_CA:badArea', ...
            'Missing positive basin area.');
    end
end

function x=local_double(x)
    if isnumeric(x)
        x = double(x); 
    else 
        x = str2double(string(x)); 
    end
end

function split=local_prepare_split(split)
    if exist('prepare_split','file') == 2
        split = prepare_split(split);
    elseif ~isfield(split,'dt') ...
            || isempty(split.dt)
        split.dt = 1;
    end
end

function tReq = local_requested_window(split,dt,includeSpinup)
    if nargin < 3
        includeSpinup = true;
    end

    % Prefer integer offsets from the common reference epoch. For hourly
    % data, req.time can otherwise end at 00:00 on the final date and omit
    % the remaining 23 hours of that day.
    if exist('build_requested_window','file') == 2
        try
            R = build_requested_window(split,includeSpinup);

            if isfield(R,'read_start_N') ...
                    && isfield(R,'read_end_N') ...
                    && ~isempty(R.read_start_N) ...
                    && ~isempty(R.read_end_N)

                tRef = datetime(1950,10,1,0,0,0);

                if dt == 24
                    t0 = tRef + hours(double(R.read_start_N));
                    t1 = tRef + hours(double(R.read_end_N));
                    tReq = (dateshift(t0,'start','hour'): ...
                        hours(1):dateshift(t1,'start','hour')).';
                else
                    t0 = tRef + days(double(R.read_start_N));
                    t1 = tRef + days(double(R.read_end_N));
                    tReq = (dateshift(t0,'start','day'): ...
                        days(1):dateshift(t1,'start','day')).';
                end
                return
            end

            if isfield(R,'time') ...
                    && ~isempty(R.time)
                tReq = local_snap_time(datetime(R.time(:)),dt);
                return
            end
        catch
        end
    end

    starts = NaT(0,1);
    ends = NaT(0,1);
    sf = {'ds','dts','des','d1', ...
        'dt_train0','dt_eval0','dt_spin0'};
    ef = {'de','dte','dee','d2', ...
        'dt_train1','dt_eval1'};

    for i = 1:numel(sf)
        if isfield(split,sf{i}) ...
                && ~isempty(split.(sf{i}))
            starts(end+1,1) = ...
                local_as_datetime(split.(sf{i})); %#ok<AGROW>
        end
    end
    for i = 1:numel(ef)
        if isfield(split,ef{i}) ...
                && ~isempty(split.(ef{i}))
            ends(end+1,1) = ...
                local_as_datetime(split.(ef{i})); %#ok<AGROW>
        end
    end

    starts = starts(~isnat(starts));
    ends = ends(~isnat(ends));
    if isempty(starts) || isempty(ends)
        error('read_Q_CA:badWindow', ...
            'Could not determine requested dates from split.');
    end

    spinDays = 0;
    if includeSpinup
        if isfield(split,'spinup') ...
                && ~isempty(split.spinup)
            spinDays = max(0,double(split.spinup));
        elseif isfield(split,'n_spin') ...
                && ~isempty(split.n_spin)
            spinDays = max(0,double(split.n_spin))/dt;
        end
    end

    if dt == 24
        t0 = dateshift(min(starts),'start','hour') ...
            - hours(spinDays*24);
        t1 = dateshift(max(ends),'end','day');
        t1 = dateshift(t1,'start','hour');
        tReq = (t0:hours(1):t1).';
    else
        t0 = dateshift(min(starts),'start','day') ...
            - days(spinDays);
        t1 = dateshift(max(ends),'start','day');
        tReq = (t0:days(1):t1).';
    end
end

function d = local_as_datetime(x)
    if isdatetime(x)
        d = x(1);
    elseif isnumeric(x)
        x = double(x(:));
        if numel(x)>=3 ...
                && all(isfinite(x(1:3))) ...
                && x(3)>1000
            d = datetime(x(3),x(2),x(1));
        elseif isscalar(x)
            d = datetime(x,'ConvertFrom','datenum');
        else
            d = NaT;
        end
    else
        d = datetime(string(x(1)));
    end
end

function t = local_snap_time(t,dt)
    t = datetime(t(:));
    if dt==1
        t = dateshift(t,'start','day');
    else
        t = dateshift(t,'start','hour');
    end
end

function key = local_window_key(t,dt)
    if dt==1
        fmt = 'yyyyMMdd'; 
    else
        fmt = 'yyyyMMddHH';
    end
    a = t(1); 
    b = t(end); 
    a.Format = fmt; 
    b.Format = fmt;
    key = string(char(a)) + "_" + string(char(b));
end

function ids = local_ca_ids(x)
    ids=upper(strtrim(string(x(:))));
    ids=regexprep(ids,'^CAN[-_]?','');
%    ids="CAN_"+ids;
end

function t=local_nc_time(fname,varname,dt)
    values = double(ncread(fname,varname));
    units = string(ncreadatt(fname,varname,'units'));
    tok = regexp(char(units), ...
        '^\s*(seconds|minutes|hours|days)\s+since\s+(.+?)\s*$', ...
        'tokens','once');
    if isempty(tok)
        error('read_Q_CA:badTimeUnits', ...
            ['Unsupported NetCDF time ' ...
            'units in %s: %s'],fname,units);
    end
    baseTxt = regexprep(strtrim(tok{2}),'[TZ]$','');
    try
        base = datetime(baseTxt, ...
            'InputFormat','yyyy-MM-dd HH:mm:ss');
    catch
        try
            base = datetime(baseTxt, ...
                'InputFormat','yyyy-MM-dd''T''HH:mm:ss');
        catch
            try
                base = datetime(baseTxt, ...
                    'InputFormat','yyyy-MM-dd');
            catch
                base = datetime(baseTxt);
            end
        end
    end
    switch lower(tok{1})
        case 'seconds'
            t = base + seconds(values);
        case 'minutes'
            t = base + minutes(values);
        case 'hours'
            t = base + hours(values);
        otherwise
            t = base + days(values);
    end
    t = local_snap_time(t,dt);
end

function x = local_nc_vector(fname,varname)
    x = double(squeeze(ncread(fname,varname)));
    x = x(:);
    try
        fv = double(ncreadatt(fname,varname,'_FillValue'));
        x(x==fv) = NaN;
    catch
    end
    x(x<=-9990) = NaN;
end

function f = local_optional_flag(fname,varname,n)
    f = zeros(n,1);
    try
        f = double(squeeze(ncread(fname,varname)));
        f = f(:);
        if numel(f)~=n
            f = zeros(n,1); 
        end
    catch
    end
end
