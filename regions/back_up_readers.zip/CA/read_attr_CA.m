function [A,id_gauge,gname,zone] = read_attr_CA(dirD,bas)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%READ_ATTR_CA Read Canadian CAMELS-SPAT metadata and lumped attributes.
%
% Expected files:
%   Data/CAMELS_CA/camels-spat-metadata.csv
%   Data/CAMELS_CA/attributes-lumped.csv
%
% The CAMELS-SPAT lumped attribute table is transposed: rows are attributes
% and columns are basin identifiers. This reader converts it to the standard
% SAGE layout (rows = basins, columns = attributes), joins station metadata,
% and retains Canadian stations only.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    if nargin < 1 ...
            || isempty(dirD) ...
            || ~isfolder(dirD)
        error('read_attr_CA:missingDir', ...
            ['      Error:read_attr_CA: ' ...
            'Invalid data directory: %s'], ...
            char(string(dirD)));
    end
    if nargin < 2 || isempty(bas)
        bas = struct();
    end
    if ~isstruct(bas)
        error('read_attr_CA:badBas', ...
            ['      Error:read_attr_CA: ' ...
            'bas must be a structure.']);
    end

    min_per_zone = local_field_or(bas,'min_per_zone',5);
    max_zones = local_field_or(bas,'max_zones',8);
    pr_table = local_field_or(bas,'pr_attr',1);

    if ~isfield(bas,'id_attr') ...
            || isempty(bas.id_attr)
        error('read_attr_CA:missingIdAttr', ...
            ['      Error:read_attr_CA: ' ...
            'bas.id_attr must be provided. ' ...
             'Use attr_catalog(''CAMELS_CA'') for valid IDs.']);
    end

    fMeta = fullfile(dirD,'camels-spat-metadata.csv');
    fAttr = fullfile(dirD,'attributes-lumped.csv');
    must_exist(fMeta,'camels-spat-metadata.csv',mfilename);
    must_exist(fAttr,'attributes-lumped.csv',mfilename);

    fprintf('... Reading CAMELS-CA basin attributes ');

    M = readtable(fMeta,'VariableNamingRule','preserve');
    M.Properties.VariableNames = ...
        matlab.lang.makeUniqueStrings( ...
        matlab.lang.makeValidName(strtrim( ...
        string(M.Properties.VariableNames))));

    required = {'Country','Station_id', ...
        'Station_name','Station_lat', ...
        'Station_lon','Basin_area_km2'};
    if ~all(ismember(required,M.Properties.VariableNames))
        error('read_attr_CA:badMetadata', ...
            ['      Error:read_attr_CA: ' ...
            'Metadata columns are incomplete.']);
    end

    isCA = strcmpi(strtrim(string(M.Country)),'CAN');
    M = M(isCA,:);
    M.basin_id = local_ca_ids(M.Station_id);
    [M.basin_id,isrt] = sort(M.basin_id);
    M = M(isrt,:);

    % Start the basin-row table with standardized metadata variables.
    AA = table(M.basin_id,string(M.Station_name), ...
        local_double(M.Station_lat), ...
        local_double(M.Station_lon), ...
        local_double(M.Basin_area_km2), ...
        'VariableNames',{'basin_id', ...
        'Station_name','Station_lat', ...
        'Station_lon','Basin_area_km2'});

    % Read every numeric attribute exposed by the CAMELS-SPAT catalog.
    CAT = attr_catalog('CAMELS_CA');
    rawNames = string(CAT.names(:));
    lumpedNames = rawNames(~ismember(rawNames, ...
        ["Station_lat","Station_lon","Basin_area_km2"]));

    L = readtable(fAttr,'VariableNamingRule','preserve');
    vn = string(L.Properties.VariableNames);
    if ~all(ismember(["Category","Attribute","Unit","Source"],vn))
        error('read_attr_CA:badAttributeTable', ...
            ['      Error:read_attr_CA: ' ...
            'attributes-lumped.csv must start ' ...
             'with Category, Attribute, Unit, and Source.']);
    end

    attrRaw = strtrim(string(L.Attribute));
    attrValid = string(matlab.lang.makeValidName(attrRaw));

    basinCols = string(L.Properties.VariableNames(5:end));
    basinIDs = local_ca_ids(basinCols);
    [tfB,locB] = ismember(AA.basin_id,basinIDs);
    if ~all(tfB)
        miss = AA.basin_id(~tfB);
        error('read_attr_CA:missingBasinColumns', ...
            ['      Error:read_attr_CA: ' ...
            '%d Canadian basins are absent from ' ...
             'attributes-lumped.csv, e.g. %s.'], ...
             numel(miss),char(miss(1)));
    end

    for j = 1:numel(lumpedNames)
        nm = lumpedNames(j);

        if nm == "forest_fraction"
            forestParts = [ ...
                "lc2_evergreen_needleleaf_forest_fraction", ...
                "lc2_evergreen_broadleaf_forest_fraction", ...
                "lc2_deciduous_needleleaf_forest_fraction", ...
                "lc2_deciduous_broadleaf_forest_fraction", ...
                "lc2_mixed_forest_fraction"];
            rows = nan(numel(forestParts),1);
            for q = 1:numel(forestParts)
                rows(q) = find(attrValid == forestParts(q),1,'first');
            end
            if any(~isfinite(rows))
                error('read_attr_CA:missingForestAttributes', ...
                    ['      Error:read_attr_CA: ' ...
                    'Forest-fraction components are missing.']);
            end
            vals = zeros(height(AA),1);
            for k = 1:height(AA)
                vv = nan(numel(rows),1);
                for q = 1:numel(rows)
                    vv(q) = local_scalar_double( ...
                        L{rows(q),4 + locB(k)});
                end
                vals(k) = sum(vv,'omitnan');
                if all(~isfinite(vv))
                    vals(k) = NaN; 
                end
            end
        else
            row = find(attrValid == nm,1,'first');
            if isempty(row)
                error('read_attr_CA:missingAttribute', ...
                    ['      Error:read_attr_CA: ' ...
                    'Missing lumped attribute %s.'],nm);
            end

            % Convert the complete transposed source row once, then select
            % Canadian basin columns in metadata order. This is much faster
            % than converting one table cell at a time for ~1,178 fields.
            valsAll = local_row_double(L{row,5:end});
            vals = valsAll(locB);
            vals = vals(:);
        end
        AA.(char(nm)) = vals;
    end

    if isfield(bas,'id_gauge') ...
            && ~isempty(bas.id_gauge)
        id_req = local_ca_ids(bas.id_gauge(:));
        [tf,loc] = ismember(id_req,AA.basin_id);
        if ~all(tf)
            miss = id_req(~tf);
            error('read_attr_CA:missingRequestedGauge', ...
                ['      Error:read_attr_CA: ' ...
                'Missing attributes for %d ' ...
                 'requested basin IDs, e.g. %s.'], ...
                 numel(miss),char(miss(1)));
        end
        AA = AA(loc,:);
        id_gauge = id_req(:);
    else
        id_gauge = AA.basin_id;
    end

    gname = string(AA.Station_name);
    try
        gname = standardize_camels_gauge_names( ...
            gname,'CAMELS_CA',id_gauge);
    catch
        bad = strlength(strtrim(gname)) == 0;
        gname(bad) = id_gauge(bad);
    end

    % Write compact gauge-information file used by meteo & dischrge readers
    G = table(id_gauge,gname,AA.Station_lat,AA.Station_lon, ...
        AA.Basin_area_km2, ...
        'VariableNames',{'gauge_id','gauge_name','gauge_lat', ...
        'gauge_lon','area_km2'});
    try
        writetable(G,fullfile(dirD,'gauge_information.txt'), ...
            'Delimiter','\t','FileType','text');
    catch
    end

    zone = classify_camels_all_zones('CA',AA, ...
        min_per_zone,max_zones);

    [A,labels] = build_attr_matrix(AA,bas,mfilename,pr_table);
    if pr_table == 1
        assignin('base','SAGE_CA_attribute_labels',labels);
    end

    fprintf(' ... Done\n');
end

function ids = local_ca_ids(x)
    ids = upper(strtrim(string(x(:))));
    ids = regexprep(ids,'^CAN[-_]?','');
end

function x = local_double(x)
    if isnumeric(x) ...
            || islogical(x)
        x = double(x(:));
    else
        x = str2double(strrep(string(x(:)),',','.'));
    end
end

function x = local_row_double(x)
    if iscell(x)
        y = nan(numel(x),1);
        for i = 1:numel(x)
            y(i) = local_scalar_double(x{i});
        end
        x = y;
    elseif isnumeric(x) ...
            || islogical(x)
        x = double(x(:));
    else
        x = str2double(strrep(string(x(:)),',','.'));
    end
end

function x = local_scalar_double(x)
    if iscell(x)
        x = x{1}; 
    end
    if isnumeric(x) ...
            || islogical(x)
        x = double(x(1));
    else
        x = str2double(strrep(string(x(1)),',','.'));
    end
end

function v = local_field_or(S,f,d)
    if isfield(S,f) ...
            && ~isempty(S.(f))
        v = S.(f);
    else
        v = d;
    end
end
