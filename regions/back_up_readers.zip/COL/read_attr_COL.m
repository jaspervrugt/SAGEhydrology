function [A,id_gauge,gname,zone] = read_attr_COL(dirD,bas)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%READ_ATTR_COL Read catchment attributes of CAMELS-COL dataset.
%
% Expected files in Data/CAMELS_COL:
%   02_CAMELS_COL_Catchment_information.csv
%   05_CAMELS_COL_Geologic_characteristics.csv
%   06_CAMELS_COL_Land_cover_characteristics.csv
%   07_CAMELS_COL_Soil_characteristics.csv
%   08_CAMELS_COL_Climatic_indices.csv
%   09_CAMELS_COL_Hydrological_signatures.csv
%   10_CAMELS_COL_Physiograpic_characteristics.csv
%   11_CAMELS_COL_Land_use_capability.csv
%
% NOTES
%   The default attribute selection should exclude hydrologic signatures
%   and streamflow-record metadata. These fields remain available for
%   manual inspection/selection through attr_catalog('CAMELS_COL'), but
%   are not used by default.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    if nargin < 1 ...
            || isempty(dirD)
        error('read_attr_COL:missingDir', ...
            ['      Error:read_attr_COL: ' ...
            'dirD must be provided.']);
    end

    if ~isfolder(dirD)
        error('read_attr_COL:missingDir', ...
            ['      Error:read_attr_COL: ' ...
            'Attribute directory ' ...
            'does not exist: %s'],dirD);
    end

    if nargin < 2 ...
            || isempty(bas)
        bas = struct();
    end
    if ~isstruct(bas)
        error('read_attr_COL:badBas', ...
            ['      Error:read_attr_COL: ' ...
            'bas must be a structure.']);
    end
    % =========================================
    % ZONE CONTROL PARAMETERS (GLOBAL DEFAULTS)
    % =========================================
    if ~isfield(bas,'min_per_zone') ...
            || isempty(bas.min_per_zone)
        min_per_zone = 5;
    else
        min_per_zone = bas.min_per_zone;
    end    
    if ~isfield(bas,'max_zones') ...
            || isempty(bas.max_zones)
        max_zones = 8;
    else
        max_zones = bas.max_zones;
    end

    pr_table = 1;
    if isfield(bas,'pr_attr') ...
            && ~isempty(bas.pr_attr)
        pr_table = bas.pr_attr;
    end

    fprintf('... Reading CAMELS-COL basin attributes ');

    AA = read_camels_col_attribute_tables(dirD);

    needVars = {'gauge_id','gauge_lat', ...
        'gauge_lon','area'};
    for j = 1:numel(needVars)
        if ~ismember(needVars{j}, ...
                AA.Properties.VariableNames)
            error(['read_attr_COL:' ...
                'missingMetadata'], ...
                ['      Error:read_attr_COL: ' ...
                'missing required ' ...
                'variable: %s'],needVars{j});
        end
    end

    id_all = normalize_col_gauge_id(AA.gauge_id);
    AA.gauge_id = id_all;

    [~,isrt] = sort(str2double(id_all));
    if any(isnan(str2double(id_all)))
        [~,isrt] = sort(id_all);
    end
    AA = AA(isrt,:);
    id_all = id_all(isrt);

    if isfield(bas,'id_gauge') ...
            && ~isempty(bas.id_gauge)
        id_req = normalize_col_gauge_id( ...
            bas.id_gauge(:));
        [tf,locid] = ismember(id_req,id_all);
        if ~all(tf)
            missing = id_req(~tf);
            error(['read_attr_COL:' ...
                'missingRequestedGauge'], ...
                ['      Error:read_attr_COL: ' ...
                'Missing CAMELS-COL ' ...
                'attributes for %d requested ' ...
                'gauge IDs, e.g. %s.'], ...
                numel(missing),char(missing(1)));
        end
        AA = AA(locid,:);
        id_gauge = id_req(:);
    else
        id_gauge = id_all(:);
    end

    % CAMELS-COL stores gauge_lat/gauge_lon as World Mercator
    % EPSG:3395 coordinates in meters, not geographic degrees.
    % Convert them here so maps receive valid latitude/longitude.
    AA = local_col_projected_to_geographic(AA);

    if ismember('gauge_department', ...
            AA.Properties.VariableNames)
        gname = string(AA.gauge_department);
    else
        gname = "COL_" + id_gauge;
    end
    % gname = local_clean_col_gname(gname,id_gauge);
    gname = standardize_camels_gauge_names(gname, ...
        'CAMELS_COL',id_gauge);

    ensure_col_gauge_information(dirD,AA,gname);

    % Use a precomputed mean-temperature cache when available. Do not
    % scan hundreds of full time-series files during Prepare Basins.
    AA = local_read_col_mean_temperature_cache(dirD,AA);

    region = erase(mfilename,'read_attr_');
    zone = classify_camels_all_zones(region,AA, ...
        min_per_zone,max_zones);

    % ------------------
    % Generic attributes
    % ------------------
    [A,labels] = build_attr_matrix(AA,bas, ...
        mfilename,pr_table);

    if pr_table == 1
        assignin('base', ...
            'SAGE_COL_attribute_labels', ...
            labels);
    end

    fprintf(' ... Done\n');

end

% ==================================================
function AA = read_camels_col_attribute_tables(dirD)
% ==================================================
% Cache the fully joined CAMELS-COL attribute table in memory. Preparing a
% new train/evaluation split should not reread and outer-join all eight
% source CSV files. The cache is invalidated automatically when one of the
% source files changes in size or modification time.

    persistent AA_cache cache_key

    f_info = fullfile(dirD, ...
        '02_CAMELS_COL_Catchment_information.csv');
    f_geo  = fullfile(dirD, ...
        '05_CAMELS_COL_Geologic_characteristics.csv');
    f_land = fullfile(dirD, ...
        '06_CAMELS_COL_Land_cover_characteristics.csv');
    f_soil = fullfile(dirD, ...
        '07_CAMELS_COL_Soil_characteristics.csv');
    f_clim = fullfile(dirD, ...
        '08_CAMELS_COL_Climatic_indices.csv');
    f_hyd  = fullfile(dirD, ...
        '09_CAMELS_COL_Hydrological_signatures.csv');
    f_phys = fullfile(dirD, ...
        '10_CAMELS_COL_Physiograpic_characteristics.csv');
    f_luc  = fullfile(dirD, ...
        '11_CAMELS_COL_Land_use_capability.csv');

    sourceFiles = {f_info,f_geo,f_land,f_soil, ...
        f_clim,f_hyd,f_phys,f_luc};
    cache_key_now = local_col_attribute_cache_key(sourceFiles);

    if ~isempty(AA_cache) ...
            && isequal(cache_key,cache_key_now)
        AA = AA_cache;
        return
    end

    caller = mfilename;
    must_exist(f_info, ...
        '02_CAMELS_COL_Catchment_information.csv',caller);
    must_exist(f_geo, ...
        '05_CAMELS_COL_Geologic_characteristics.csv',caller);
    must_exist(f_land, ...
        '06_CAMELS_COL_Land_cover_characteristics.csv',caller);
    must_exist(f_soil, ...
        '07_CAMELS_COL_Soil_characteristics.csv',caller);
    must_exist(f_clim, ...
        '08_CAMELS_COL_Climatic_indices.csv',caller);
    must_exist(f_hyd, ...
        '09_CAMELS_COL_Hydrological_signatures.csv',caller);
    must_exist(f_phys, ...
        '10_CAMELS_COL_Physiograpic_characteristics.csv',caller);
    must_exist(f_luc, ...
        '11_CAMELS_COL_Land_use_capability.csv',caller);

    info = read_col_csv(f_info, ...
        'catchment');
    phys = read_col_csv(f_phys, ...
        'physiographic');
    clim = read_col_csv(f_clim, ...
        'climate');
    geo  = read_col_csv(f_geo, ...
        'geology');
    land = read_col_csv(f_land, ...
        'landcover');
    soil = read_col_csv(f_soil, ...
        'soil');
    luc  = read_col_csv(f_luc, ...
        'landuse');
    hyd  = read_col_csv(f_hyd, ...
        'hydrology');

    AA = info;
    AA = join_col_attributes(AA,phys);
    AA = join_col_attributes(AA,clim);
    AA = join_col_attributes(AA,geo);
    AA = join_col_attributes(AA,land);
    AA = join_col_attributes(AA,soil);
    AA = join_col_attributes(AA,luc);
    AA = join_col_attributes(AA,hyd);

    AA_cache = AA;
    cache_key = cache_key_now;

end

% =======================================================
function key = local_col_attribute_cache_key(sourceFiles)
% =======================================================
% Compact cache signature based on full path, byte count, and modification
% time for each attribute source file.
%
% This key is used only for the persistent in-memory attribute cache.
% It does not create a cache file on disk.

    if ischar(sourceFiles) ...
            || isstring(sourceFiles)
        sourceFiles = cellstr(sourceFiles);
    end
    parts = cell(numel(sourceFiles),1);
    for i = 1:numel(sourceFiles)
        f = char(sourceFiles{i});
        d = dir(f);
        if isempty(d)
            parts{i} = sprintf('%s|missing',f);
        else
            parts{i} = sprintf('%s|%d|%.12f', ...
                f,double(d(1).bytes), ...
                double(d(1).datenum));
        end
    end
    key = strjoin(parts,';');
end

% ===================================
function T = read_col_csv(fname,kind)
% ===================================

    delim = local_detect_delimiter(fname);
    opts = detectImportOptions(fname, ...
        'FileType','text', ...
        'Delimiter',delim, ...
        'Encoding','ISO-8859-1');
    opts.VariableNamingRule = 'preserve';

    T = readtable(fname,opts);
    if height(T) > 0
        emptyRow = true(height(T),1);
        for j = 1:width(T)
            v = T{:,j};
            if isnumeric(v) ...
                    || islogical(v)
                emptyRow = emptyRow ...
                    & all(isnan(v),2);
            else
                s = string(v);
                emptyRow = emptyRow ...
                    & (ismissing(s) ...
                    | strlength(strtrim(s)) == 0);
            end
        end
        T(emptyRow,:) = [];
    end

    T.Properties.VariableNames = ...
        matlab.lang.makeUniqueStrings( ...
        matlab.lang.makeValidName( ...
        strtrim(string( ...
        T.Properties.VariableNames))));

    T = rename_col_var(T, ...
        'gravelius_index_', ...
        'gravelius_index');
    T = rename_col_var(T, ...
        'streng_chanel_', ...
        'streng_chanel');
    T = rename_col_var(T, ...
        'Urban_area', ...
        'urban_area_luc');
    T = rename_col_var(T, ...
        'No_classified', ...
        'no_classified_luc');

    if strcmpi(kind,'soil')
        T = rename_col_var(T, ...
            'water_bodies_perc', ...
            'soil_water_bodies_perc');
    end

    if ~ismember('gauge_id', ...
            T.Properties.VariableNames)
        error(['read_attr_COL:' ...
            'missingGaugeID'], ...
            ['      Error:read_attr_COL: ' ...
            '%s has no ' ...
            'gauge_id column.'],fname);
    end

    T.gauge_id = normalize_col_gauge_id(T.gauge_id);

    for j = 1:width(T)
        vn = T.Properties.VariableNames{j};
        if strcmp(vn,'gauge_id') ...
                || strcmp(vn,'gauge_department') ...
                || strcmp(vn,'gauge_star') ...
                || strcmp(vn,'gauge_end')
            continue
        end
        T.(vn) = local_to_double_or_keep(T.(vn));
    end
end


% ====================================
function T = rename_col_var(T,old,new)
% ====================================
    jj = find(strcmp( ...
        T.Properties.VariableNames,old), ...
        1,'first');
    if ~isempty(jj)
        T.Properties.VariableNames{jj} = new;
    end
end

% ============================================
function delim = local_detect_delimiter(fname)
% ============================================
    fid = fopen(fname,'r');
    if fid < 0
        error('read_attr_COL:openFailed', ...
            'Could not open %s',fname);
    end
    c = onCleanup(@() fclose(fid));
    line = fgetl(fid);
    if ~ischar(line)
        error('read_attr_COL:emptyFile', ...
            'Empty file: %s',fname);
    end
    if count(string(line),";") ...
            >= count(string(line),",")
        delim = ';';
    else
        delim = ',';
    end
end

% =====================================
function x = local_to_double_or_keep(x)
% =====================================
    if isnumeric(x) ...
            || islogical(x)
        return
    end
    if iscell(x)
        xs = string(x);
    elseif ischar(x)
        xs = string(cellstr(x));
    elseif isstring(x) ...
            || iscategorical(x)
        xs = string(x);
    else
        return
    end
    xs = strtrim(xs);
    xs = erase(xs,'"');
    xs = regexprep(xs,'^(NA|NaN|null|NULL|-9999)$', ...
        'NaN','ignorecase');
    y = str2double(xs);
    good = ~(ismissing(xs) | xs == "");
    if ~any(good) ...
            || sum(isfinite(y(good)) ...
            | isnan(y(good))) >= 0.9*sum(good)
        x = y;
    end
end

% ===================================
function T = join_col_attributes(T,U)
% ===================================

    varsT = string(T.Properties.VariableNames);
    varsU = string(U.Properties.VariableNames);
    varsU = varsU(varsU ~= "gauge_id");

    for j = 1:numel(varsU)
        if any(varsT == varsU(j))
            old = char(varsU(j));
            new = char(varsU(j) + "_col");
            U.Properties.VariableNames{ ...
                strcmp( ...
                U.Properties.VariableNames, ...
                old)} = new;
        end
    end

    T = outerjoin(T,U, ...
        'Keys','gauge_id', ...
        'MergeKeys',true, ...
        'Type','left');

end

% =====================================
function id = normalize_col_gauge_id(x)
% =====================================

    x = string(x(:));
    x = strtrim(x);
    x = regexprep(x,'\.0+$','');
    x = regexprep(x,'[^0-9]','');

    id = x;
    if any(id == "")
        error('read_attr_COL:badGaugeID', ...
            ['      Error:read_attr_COL: ' ...
            'empty gauge_id ' ...
            'after normalization.']);
    end
end

% =================================================
function AA = local_col_projected_to_geographic(AA)
% =================================================
% Convert CAMELS-COL gauge coordinates from EPSG:3395 World Mercator
% meters to geographic latitude/longitude degrees.  The source table uses
% gauge_lat = northing [m] and gauge_lon = easting [m].

    if ~all(ismember({'gauge_lat','gauge_lon'}, ...
            AA.Properties.VariableNames))
        return
    end

    y = double(AA.gauge_lat(:));   % northing [m]
    x = double(AA.gauge_lon(:));   % easting  [m]

    % If the coordinates already look like degrees, leave them alone.
    if all(isfinite(y) ...
            & abs(y) <= 90) ...
            && all(isfinite(x) ...
            & abs(x) <= 180)
        return
    end

    try
        crs = projcrs(3395);
        [lat,lon] = projinv(crs,x,y);
    catch
        % Spherical Mercator fallback.  This is sufficiently accurate for
        % display and avoids requiring Mapping Toolbox projection support.
        R = 6378137;
        lon = x ./ R * 180/pi;
        lat = (2*atan(exp(y./R)) ...
            - pi/2) * 180/pi;
    end

    AA.gauge_lat = lat(:);
    AA.gauge_lon = lon(:);
end

% % ====================================================
% function gname = local_clean_col_gname(gname,id_gauge)
% % ====================================================
% % Remove appended basin IDs and trailing zero flags from display names.
% % Example: Caldas_26157020 0 -> Caldas
% 
%     gname = string(gname(:));
%     id_gauge = string(id_gauge(:));
% 
%     for i = 1:numel(gname)
%         id = regexptranslate('escape', ...
%             char(id_gauge(i)));
%         gname(i) = regexprep(gname(i), ...
%             ['[_\s]*' id '\s*0?\s*$'],'');
%     end
% 
%     gname = strrep(gname,'_',' ');
%     gname = strtrim(gname);
% 
%     bad = ismissing(gname) ...
%         | strlength(gname) == 0;
%     gname(bad) = "COL_" + id_gauge(bad);
% end

% ===========================================================
function AA = local_read_col_mean_temperature_cache(dirD,AA)
% ===========================================================
% Read a precomputed CAMELS-COL mean-temperature cache without opening
% hydrometeorological time-series files during basin preparation.

    cacheFile = fullfile(dirD,'CAMELS_COL_mean_temperature.csv');
    if ~isfile(cacheFile) ...
            || ~ismember('gauge_id',AA.Properties.VariableNames)
        return
    end

    try
        C = readtable(cacheFile, ...
            'TextType','string', ...
            'VariableNamingRule','preserve');

        if ~all(ismember({'gauge_id','temp_mean'}, ...
                C.Properties.VariableNames))
            return
        end

        id = normalize_col_gauge_id(AA.gauge_id);
        cid = normalize_col_gauge_id(C.gauge_id);
        ctm = double(C.temp_mean);

        [tf,loc] = ismember(id,cid);
        temp_mean = nan(height(AA),1);
        temp_mean(tf) = ctm(loc(tf));

        if any(isfinite(temp_mean))
            AA.temp_mean = temp_mean;
        end
    catch
        % A missing or malformed optional cache must not block basin setup.
    end
end

% =====================================================
function AA = local_add_col_mean_temperature(dirD,AA)
% =====================================================
% Add long-term mean daily air temperature to CAMELS-COL attributes.
%
% The static CAMELS-COL tables do not contain a snow-fraction or mean-air-
% temperature attribute. The global zone classifier can use temp_mean as
% a physically based fallback for estimating snow influence. Values are
% calculated once from:
%
%   daily/timeseries/Hydromet_data_<gauge_id>.txt
%
% using 0.5*(Temperatura_minima + Temperatura_maxima), then stored in:
%
%   CAMELS_COL_mean_temperature.csv
%
% Subsequent GUI starts read the small cache instead of all time series.

    K = height(AA);
    AA.temp_mean = nan(K,1);

    if ~ismember('gauge_id',AA.Properties.VariableNames)
        return
    end

    id = normalize_col_gauge_id(AA.gauge_id);
    cacheFile = fullfile(dirD, ...
        'CAMELS_COL_mean_temperature.csv');

    % ---------------------------
    % Read an existing valid cache
    % ---------------------------
    if isfile(cacheFile)
        try
            C = readtable(cacheFile, ...
                'TextType','string', ...
                'VariableNamingRule','preserve');

            if all(ismember({'gauge_id','temp_mean'}, ...
                    C.Properties.VariableNames))
                cid = normalize_col_gauge_id(C.gauge_id);
                ctm = double(C.temp_mean);
                [tf,loc] = ismember(id,cid);
                AA.temp_mean(tf) = ctm(loc(tf));

                if all(isfinite(AA.temp_mean))
                    return
                end
            end
        catch
            % Rebuild an unreadable or obsolete cache below.
        end
    end

    % -----------------------------
    % Locate CAMELS-COL time series
    % -----------------------------
    tsDir = fullfile(dirD,'daily','timeseries');
    if ~isfolder(tsDir)
        warning('read_attr_COL:missingTimeseries', ...
            ['Cannot derive CAMELS-COL mean temperature because ' ...
             'the time-series directory was not found:\n%s'],tsDir);
        return
    end

    fprintf('\n... Deriving CAMELS-COL mean temperature ');
    nDone = 0;

    for k = 1:K
        fname = fullfile(tsDir, ...
            sprintf('Hydromet_data_%s.txt',char(id(k))));

        if ~isfile(fname)
            continue
        end

        try
            opts = detectImportOptions(fname, ...
                'FileType','text', ...
                'Delimiter','\t');
            opts.VariableNamingRule = 'preserve';
            T = readtable(fname,opts);

            vn = string(T.Properties.VariableNames);
            iMin = find(strcmpi(vn,'Temperatura_minima'),1);
            iMax = find(strcmpi(vn,'Temperatura_maxima'),1);

            if isempty(iMin) || isempty(iMax)
                continue
            end

            Tmin = local_to_numeric_vector(T{:,iMin});
            Tmax = local_to_numeric_vector(T{:,iMax});
            good = isfinite(Tmin) & isfinite(Tmax);

            if any(good)
                AA.temp_mean(k) = mean( ...
                    0.5*(Tmin(good) + Tmax(good)), ...
                    'omitnan');
            end
        catch
            % Leave this basin as NaN; report the total below.
        end

        nDone = nDone + 1;
        if mod(nDone,25) == 0 || nDone == K
            fprintf('.');
        end
    end
    fprintf(' Done\n');

    % ---------------------
    % Write reusable cache
    % ---------------------
    try
        C = table(id(:),AA.temp_mean(:), ...
            'VariableNames',{'gauge_id','temp_mean'});
        writetable(C,cacheFile);
    catch ME
        warning('read_attr_COL:temperatureCache', ...
            'Could not write mean-temperature cache: %s',ME.message);
    end

    nMissing = sum(~isfinite(AA.temp_mean));
    if nMissing > 0
        warning('read_attr_COL:temperatureMissing', ...
            ['Mean temperature could not be derived for %d of %d ' ...
             'CAMELS-COL basins.'],nMissing,K);
    end
end

% ============================================
function x = local_to_numeric_vector(x)
% ============================================
    if isnumeric(x) || islogical(x)
        x = double(x(:));
        return
    end

    x = string(x(:));
    x = strtrim(x);
    x = erase(x,'"');
    x = regexprep(x,',','.');
    x = str2double(x);
end

% ==================================================
function ensure_col_gauge_information(dirD,AA,gname)
% ==================================================

    fname = fullfile(dirD, ...
        'gauge_information.txt');
    if isfile(fname)
        return
    end

    T = table();
    T.gauge_id = normalize_col_gauge_id( ...
        AA.gauge_id);

    if nargin >= 3 && ~isempty(gname)
        T.gauge_name = string(gname(:));
    elseif ismember('gauge_department', ...
            AA.Properties.VariableNames)
        T.gauge_name = string(AA.gauge_department);
    else
        T.gauge_name = "COL_" + T.gauge_id;
    end

    if ismember('gauge_lat', ...
            AA.Properties.VariableNames)
        T.gauge_lat = AA.gauge_lat;
    else
        T.gauge_lat = nan(height(AA),1);
    end
    if ismember('gauge_lon', ...
            AA.Properties.VariableNames)
        T.gauge_lon = AA.gauge_lon;
    else
        T.gauge_lon = nan(height(AA),1);
    end
    if ismember('area', ...
            AA.Properties.VariableNames)
        T.area_km2 = AA.area;
    else
        T.area_km2 = nan(height(AA),1);
    end

    writetable(T,fname);
end
