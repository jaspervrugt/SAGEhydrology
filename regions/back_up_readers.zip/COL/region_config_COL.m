function R = region_config_COL()
%REGION_CONFIG_COL Regional defaults for CAMELS-COL.
%
% All X.paths fields are relative to Data/<R.data_root>.
% Dates use dd/MM/yyyy and water-year boundaries.

    R = struct();
    R.code = 'CAMELS_COL';
    R.acronym = 'COL';
    R.name = 'Colombia';
    R.dataset = 'CAMELS-COL';
    R.data_root = 'CAMELS_COL';
    R.resolutions = {'Daily'};
    R.default_resolution = 'Daily';
    R.basin_file_pattern = 'COL_%d_basins.txt';

    X = struct();
    X.label = 'Daily';
    X.dt = 1;
    X.basins.universe = 91;
    X.basins.training = 75;
    X.basins.evaluation = 16;
    X.period.spinup_days = 365;
    X.period.manual.train_start = '01/10/1990';
    X.period.manual.train_end = '30/09/1994';
    X.period.manual.eval_start = '01/10/1986';
    X.period.manual.eval_end = '30/09/1990';
    X.period.common_start = '01/10/1986';
    X.period.common_end = '30/09/1994';
    X.paths.run_root = '';
    X.paths.meteo = fullfile('daily','timeseries');
    X.paths.discharge = fullfile('daily','timeseries');
    % Meteorological/PET controls shown by SAGE-GUI.
    X.meteo.product.items = {'CAMELS-COL [daily]'};
    X.meteo.product.default = 'CAMELS-COL [daily]';
    X.meteo.product.enabled = false;
    X.meteo.precipitation.items = {'1 Precipitation'};
    X.meteo.precipitation.default = '1 Precipitation';
    X.meteo.precipitation.enabled = false;
    X.meteo.temperature.items = {'1 (Tmin+Tmax)/2'};
    X.meteo.temperature.default = '1 (Tmin+Tmax)/2';
    X.meteo.temperature.enabled = false;
    X.meteo.pet.items = {'1 ETP'};
    X.meteo.pet.default = '1 ETP';
    X.meteo.pet.enabled = false;
    C = repmat(struct('name','','type','','path','','pattern','', ...
        'minimum_count',1,'required',true),0,1);
    C(1).name = 'Meteorological data';
    C(1).type = 'folder';
    C(1).path = fullfile('daily','timeseries');
    C(1).pattern = '*';
    C(1).minimum_count = 1;
    X.checks = C;
    R.by_resolution.Daily = X;

end