function [dat,aux] = read_meteo_COL(dirM,bas,split,meteo)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%READ_METEO_COL Read CAMELS-COL daily hydrometeorological data for SAGE.
%
% Expected folder:
%   Data/CAMELS_COL/daily/timeseries/Hydromet_data_XXXXXXXX.txt
%
% Expected file columns:
%   Fecha                  date
%   Precipitacion          precipitation [mm/day]
%   ETP_                   potential evapotranspiration [mm/day]
%   Temperatura_minima     minimum air temperature [deg C]
%   Temperatura_maxima     maximum air temperature [deg C]
%   Caudal                 streamflow [m3/s]
%
% Output follows the standard SAGE meteorological-reader interface:
%   [dat,aux] = read_meteo_COL(dirM,bas,split,meteo)
%
%   dat{k}.meteo.P
%   dat{k}.meteo.Ep
%   dat{k}.meteo.T
%   dat{k}.meteo.bad
%   dat{k}.gauge
%   dat{k}.fname
%   dat{k}.y_n       scored period only, spin-up removed [mm/day]
%   dat{k}.bad       logical mask, same length as y_n
%
%   aux(:,1) = latitude  [deg]
%   aux(:,2) = elevation [m]
%   aux(:,3) = area      [m2]
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    if nargin < 4
        meteo = struct();
    end
    if nargin < 3
        error(['      Error:read_meteo_COL: ' ...
            'Expected input signature ' ...
            '[dat,aux] = read_meteo_COL' ...
            '(dirM,bas,split,meteo).']);
    end
    if nargin < 1 ...
            || isempty(dirM)
        error(['      Error:read_meteo_COL: ' ...
            'dirM must be provided.']);
    end

    split = local_prepare_split(split);

    if double(split.dt) ~= 1
        error(['      Error:read_meteo_COL: ' ...
            'CAMELS-COL hydrometeorological ' ...
            'data are daily only.']);
    end

    K = bas.K;
    id_GAUGE = local_col_id_strings( ...
        bas.id_gauge(:));

    dirTs = local_col_timeseries_dir( ...
        dirM);
    dirCOL = local_col_root_from_timeseries( ...
        dirTs);

    dat = cell(K,1);
    aux = nan(K,3);

    try
        aux = local_aux_from_bas( ...
            bas,aux);
    catch
    end
    try
        aux = local_aux_from_gauge_information( ...
            dirCOL,bas,aux);
    catch MEaux
        fprintf('\n');
        fprintf(['      Warning:' ...
            'read_meteo_COL: could not read ' ...
            'Colombia gauge information ' ...
            'for aux fields.\n']);
        fprintf('      Cause: %s\n',MEaux.message);
    end

    req = local_requested_daily_window(split);
    tReq = dateshift(datetime(req.time(:)), ...
        'start','day');
    nReq = numel(tReq);

    if nReq == 0
        error(['      Error:read_meteo_COL: ' ...
            'requested daily time ' ...
            'window is empty. ' ...
            'Check split.dt_spin0, ' ...
            'split.dt_train0, ' ...
            'split.dt_train1, ' ...
            'split.dt_eval0, and split.dt_eval1.']);
    end

    % Discharge is stored for the scored period only.  split.idx is the
    % common SAGE index vector after removing spin-up from the read window.
    if isfield(split,'idx') ...
            && ~isempty(split.idx)
        idx_score = double(split.idx(:));
    else
        idx_score = (1:nReq).';
    end
    idx_score = idx_score(isfinite(idx_score) ...
        & idx_score >= 1 ...
        & idx_score <= nReq);
    idx_score = round(idx_score(:));

    if isempty(idx_score)
        error(['      Error:read_meteo_COL: ' ...
            'scored-period index split.idx is empty ' ...
            'or outside the requested read window.']);
    end

    cache_dir = fullfile(dirTs, ...
        '_cache_COL_daily_meteo');
    if ~isfolder(cache_dir)
        mkdir(cache_dir);
    end

    fprintf(['... Reading daily CAMELS-COL ' ...
        'meteorological ' ...
        'data files %3d%%'],0);
    flag_progress = true;

    for k = 1:K

        gid = id_GAUGE(k);
        fname = fullfile(dirTs, ...
            sprintf('Hydromet_data_%s.txt',gid));

        if ~isfile(fname)
            fprintf('\n');
            error(['      Error:read_meteo_COL: ' ...
                'Missing hydrometeorological ' ...
                'file for basin %s: %s'], ...
                gid,fname);
        end

        win_key = sprintf('%s_%s', ...
            char(tReq(1),'yyyyMMdd'), ...
            char(tReq(end),'yyyyMMdd'));
        cache_file = fullfile(cache_dir, ...
            sprintf('%s_COL_daily_meteo_%s.mat', ...
            gid,win_key));

        use_cache = false;
        if isfile(cache_file)
            try
                S = load(cache_file, ...
                    'P','Ep','Tmean', ...
                    'Tmin','Tmax', ...
                    'Qcms','badrows', ...
                    'src_datenum');
                info = dir(fname);
                if isfield(S,'src_datenum') ...
                        && S.src_datenum >= info.datenum
                    P = S.P;
                    Ep = S.Ep;
                    Tmean = S.Tmean;
                    Tmin = S.Tmin;
                    Tmax = S.Tmax;
                    Qcms = S.Qcms;
                    badrows = S.badrows;
                    use_cache = true;
                end
            catch
                use_cache = false;
            end
        end

        if ~use_cache
            [tFile,Pfile,Epfile, ...
                TminFile,TmaxFile,QcmsFile] = ...
                local_read_col_hydromet_file(fname);

            P = nan(nReq,1);
            Ep = nan(nReq,1);
            Tmin = nan(nReq,1);
            Tmax = nan(nReq,1);
            Qcms = nan(nReq,1);

            [tf,loc] = ismember(tReq,tFile);
            P(tf) = Pfile(loc(tf));
            Ep(tf) = Epfile(loc(tf));
            Tmin(tf) = TminFile(loc(tf));
            Tmax(tf) = TmaxFile(loc(tf));
            Qcms(tf) = QcmsFile(loc(tf));

            Tmean = 0.5*(Tmin + Tmax);

            badmask = ~isfinite(P) ...
                | ~isfinite(Ep) ...
                | ~isfinite(Tmean);
            badrows = int64(find(badmask));

            try
                info = dir(fname);
                src_datenum = info.datenum;
                save(cache_file, ...
                    'P','Ep','Tmean', ...
                    'Tmin','Tmax', ...
                    'Qcms','badrows', ...
                    'src_datenum','-v7.3');
            catch
            end
        end

        % Meteorological forcing keeps the full requested read window,
        % including spin-up, consistent with the other regional readers.
        dat{k}.meteo.P = single(P);
        dat{k}.meteo.Ep = single(Ep);
        dat{k}.meteo.T = single(Tmean);
        dat{k}.meteo.Tmin = single(Tmin);
        dat{k}.meteo.Tmax = single(Tmax);
        dat{k}.meteo.bad = badrows(:)';

        % Discharge in CAMELS-COL is in the same hydromet file as Caudal
        % [m3/s].  Convert to basin-average runoff depth [mm/day], then
        % remove spin-up by retaining only split.idx.
        area = aux(k,3);
        if ~isfinite(area) ...
                || area <= 0
            fprintf('\n');
            error(['      Error:read_meteo_COL: ' ...
                'Missing/invalid basin area for basin %s. ' ...
                'aux(k,3) must be area in m2.'],gid);
        end

        Qmm_all = double(Qcms) * 86400 * 1000 / double(area);
        bad_q_all = ~isfinite(Qmm_all);

        Q = Qmm_all(idx_score);
        dat{k}.y_n = single(Q);
        dat{k}.bad = bad_q_all(idx_score).';

        % Keep raw streamflow only for diagnostic checks.
        dat{k}.Q_cms_COL = single(Qcms);

        dat{k}.gauge = gid;
        dat{k}.fname{1} = fname;
        dat{k}.fname{2} = fname;

        if ~isempty(badrows)
            if flag_progress
                fprintf('\n');
            end
            fprintf(['      Warning:' ...
                'read_meteo_COL: basin %s has ' ...
                '%d invalid/missing daily ' ...
                'meteo rows in requested window.\n'], ...
                gid,numel(badrows));
            pct = floor(100*k/K);
            fprintf(['... Reading daily CAMELS-COL ' ...
                'meteorological data files %3d%%'],pct);
            flag_progress = true;
        end

        if mod(k,20)==0 ...
                || k==K
            pct = floor(100*k/K);
            fprintf('\b\b\b\b%3d%%',pct);
            drawnow;
        end

        if isfield(meteo,'progressFcn') ...
                && ~isempty(meteo.progressFcn)
            try
                meteo.progressFcn(k);
            catch
            end
        end
    end

    if flag_progress
        fprintf('\b\b\b\b%s\n','... Done');
    end
    
    if isfield(split,'local') ... 
            && split.local ...
            && isfield(split,'rainfall_block') ...
            && split.rainfall_block
        dat = rainfall_rank_split(dat,split);
    end
    
end

% =========================================
function split = local_prepare_split(split)
% =========================================

    if exist('prepare_split','file') == 2
        split = prepare_split(split);
        return
    end

    flds = {'dt_spin0','dt_train0', ...
        'dt_train1','dt_eval0','dt_eval1'};
    for i = 1:numel(flds)
        f = flds{i};
        if isfield(split,f) ...
                && ~isempty(split.(f))
            split.(f) = ...
                local_to_datetime(split.(f));
        end
    end
end

function req = local_requested_daily_window(split)
%LOCAL_REQUESTED_DAILY_WINDOW Build the daily read window.
%
% Prefer the shared SAGE helper used by read_meteo_GB/FI/FR.  The earlier
% CAMELS-COL version reconstructed the window from date fields and then
% extended the end date using max(split.idx).  For rainfall-block/local
% splits this can add one extra day to the requested window.  That is why
% Colombia produced, for example, 3654 meteo rows instead of 3653 and then
% one extra evaluated/scored day downstream.

    if exist('build_requested_window','file') == 2
        try
            req0 = build_requested_window(split,true);
            if isfield(req0,'read_start_N') ...
                    && isfield(req0,'read_end_N')
                tRef = datetime(1950,10,1);
                t0 = tRef + days(double(req0.read_start_N));
                t1 = tRef + days(double(req0.read_end_N));
                req.time = (dateshift(t0,'start','day'):days(1): ...
                    dateshift(t1,'start','day')).';
                return
            end
            if isfield(req0,'time') ...
                    && ~isempty(req0.time)
                req.time = dateshift(datetime(req0.time(:)), ...
                    'start','day');
                return
            end
        catch
            % Fall through to the local implementation below.  This keeps
            % the reader usable outside the full SAGE path.
        end
    end

    spinup = 0;
    if isfield(split,'spinup') ...
            && ~isempty(split.spinup)
        spinup = max(0,round(double(split.spinup)));
    elseif isfield(split,'n_spin') ...
            && ~isempty(split.n_spin)
        spinup = max(0,round(double(split.n_spin)));
    end

    starts = NaT(0,1);
    ends = NaT(0,1);

    if isfield(split,'ds') ...
            && ~isempty(split.ds)
        starts(end+1,1) = local_to_datetime(split.ds);
    end
    if isfield(split,'dts') ...
            && ~isempty(split.dts)
        starts(end+1,1) = local_to_datetime(split.dts);
    end
    if isfield(split,'des') ...
            && ~isempty(split.des)
        starts(end+1,1) = local_to_datetime(split.des);
    end
    if isfield(split,'d1') ...
            && ~isempty(split.d1)
        starts(end+1,1) = local_to_datetime(split.d1);
    end
    if isfield(split,'dt_train0') ...
            && ~isempty(split.dt_train0)
        starts(end+1,1) = local_to_datetime(split.dt_train0);
    end
    if isfield(split,'dt_eval0') ...
            && ~isempty(split.dt_eval0)
        starts(end+1,1) = local_to_datetime(split.dt_eval0);
    end
    if isfield(split,'dt_spin0') ...
            && ~isempty(split.dt_spin0)
        starts(end+1,1) = local_to_datetime(split.dt_spin0);
    end

    if isfield(split,'de') ...
            && ~isempty(split.de)
        ends(end+1,1) = local_to_datetime(split.de);
    end
    if isfield(split,'dte') ...
            && ~isempty(split.dte)
        ends(end+1,1) = local_to_datetime(split.dte);
    end
    if isfield(split,'dee') ...
            && ~isempty(split.dee)
        ends(end+1,1) = local_to_datetime(split.dee);
    end
    if isfield(split,'d2') ...
            && ~isempty(split.d2)
        ends(end+1,1) = local_to_datetime(split.d2);
    end
    if isfield(split,'dt_train1') ...
            && ~isempty(split.dt_train1)
        ends(end+1,1) = local_to_datetime(split.dt_train1);
    end
    if isfield(split,'dt_eval1') ...
            && ~isempty(split.dt_eval1)
        ends(end+1,1) = local_to_datetime(split.dt_eval1);
    end

    starts = starts(~isnat(starts));
    ends = ends(~isnat(ends));

    if isempty(starts) ...
            || isempty(ends)
        error(['      Error:read_meteo_COL: ' ...
            'could not determine requested daily time window from split.']);
    end

    t0 = dateshift(min(starts),'start','day') - days(spinup);
    t1 = dateshift(max(ends),'start','day');

    % Important: do NOT extend t1 from max(split.idx).  For rainfall-block
    % splits, split.idx can include the already-prepared scored-period
    % indexing and extending the read window here creates a one-day mismatch
    % relative to the other readers.

    if t1 < t0
        error(['      Error:read_meteo_COL: ' ...
            'requested period is empty: %s to %s.'],string(t0),string(t1));
    end

    req.time = (t0:days(1):t1).';
end

% =============================================
function dirTs = local_col_timeseries_dir(dirM)
% =============================================

    dirM = char(string(dirM));
    cands = { ...
        dirM, ...
        fullfile(dirM,'daily','timeseries'), ...
        fullfile(dirM, ...
        'timeseries'), ...
        fullfile(dirM, ...
        '3_Hydrometeorological_data'), ...
        fullfile(dirM, ...
        '04_CAMELS_COL_Hydrometeorological_data'), ...
        fullfile(dirM,'CAMELS_COL','daily','timeseries'), ...
        fullfile(dirM, ...
        'CAMELS_COL','timeseries'), ...
        fullfile(dirM,'Data','CAMELS_COL','daily','timeseries'), ...
        fullfile(dirM,'Data', ...
        'CAMELS_COL','timeseries')};

    for i = 1:numel(cands)
        d = cands{i};
        if isfolder(d) ...
                && ~isempty(dir( ...
                fullfile(d, ...
                'Hydromet_data_*.txt')))
            dirTs = d;
            return
        end
    end

    error(['      Error:read_meteo_COL: ' ...
        'Cannot resolve CAMELS_COL ' ...
        'timeseries directory from: %s'],dirM);
end

% =====================================================
function dirCOL = local_col_root_from_timeseries(dirTs)
% =====================================================

    dirCOL = fileparts(dirTs);
    [~,nm] = fileparts(dirTs);
    if strcmpi(nm,'timeseries')
        [pDaily,nmDaily] = fileparts(dirCOL);
        if strcmpi(nmDaily,'daily')
            dirCOL = pDaily;
        end
    elseif contains(lower(nm), ...
            'hydrometeorological')
        % dirCOL is already the regional parent folder.
    else
        dirCOL = dirTs;
    end
end

% ====================================================================
function [t,P,Ep,Tmin,Tmax,Qcms] = local_read_col_hydromet_file(fname)
% ====================================================================

    info = dir(fname);
    if isempty(info) ...
            || info.bytes == 0
        error(['      Error:read_meteo_COL: ' ...
            'Empty hydrometeorological ' ...
            'file: %s'],fname);
    end

    delim = local_detect_delimiter(fname);
    opts = detectImportOptions(char(fname), ...
        'FileType','text', ...
        'Delimiter',delim, ...
        'VariableNamingRule','preserve');

    if isempty(opts.VariableNames) ...
            || numel(opts.VariableNames) < 6
        error(['      Error:read_meteo_COL: ' ...
            'Expected at least ' ...
            'six columns in: %s'],fname);
    end

    opts = setvartype(opts,opts.VariableNames{1},'char');
    T = readtable(char(fname),opts);

    vn = string(T.Properties.VariableNames);
    jDate = local_find_var(vn, ...
        ["Fecha","date","time"],1);
    jP = local_find_var(vn, ...
        ["Precipitacion","pr","precipitation"],2);
    jEp = local_find_var(vn, ...
        ["ETP_","ETP","poten_evapo","pet"],3);
    jTmin = local_find_var(vn, ...
        ["Temperatura_minima","t_min","tmin"],4);
    jTmax = local_find_var(vn, ...
        ["Temperatura_maxima","t_max","tmax"],5);
    jQ = local_find_var(vn, ...
        ["Caudal","streamflow","q"],6);

    t = local_parse_col_date(T{:,jDate});
    P = local_to_double(T{:,jP});
    Ep = local_to_double(T{:,jEp});
    Tmin = local_to_double(T{:,jTmin});
    Tmax = local_to_double(T{:,jTmax});
    Qcms = local_to_double(T{:,jQ});

    t = t(:);
    P = P(:);
    Ep = Ep(:);
    Tmin = Tmin(:);
    Tmax = Tmax(:);
    Qcms = Qcms(:);

    good = ~isnat(t);
    t = t(good);
    P = P(good);
    Ep = Ep(good);
    Tmin = Tmin(good);
    Tmax = Tmax(good);
    Qcms = Qcms(good);

    if isempty(t)
        error(['      Error:read_meteo_COL: ' ...
            'No valid dates ' ...
            'found in: %s'],fname);
    end

    [t,isrt] = sort(t);
    P = P(isrt);
    Ep = Ep(isrt);
    Tmin = Tmin(isrt);
    Tmax = Tmax(isrt);
    Qcms = Qcms(isrt);

    [t,ia] = unique(t,'stable');
    P = P(ia);
    Ep = Ep(ia);
    Tmin = Tmin(ia);
    Tmax = Tmax(ia);
    Qcms = Qcms(ia);
end

% ============================================
function delim = local_detect_delimiter(fname)
% ============================================
    fid = fopen(char(fname),'r');
    if fid < 0
        error('Could not open %s',fname);
    end
    c = onCleanup(@() fclose(fid));
    line = fgetl(fid);
    if ~ischar(line)
        error('Empty file: %s',fname);
    end
    if count(string(line),"\t") ...
            >= count(string(line),";") ...
            && count(string(line),"\t") ...
            >= count(string(line),",")
        delim = '\t';
    elseif count(string(line),";") ...
            >= count(string(line),",")
        delim = ';';
    else
        delim = ',';
    end
end

% ============================================
function j = local_find_var(vn,cands,fallback)
% ============================================

    vnl = lower(regexprep(vn, ...
        '[^a-zA-Z0-9]',''));
    for i = 1:numel(cands)
        c = lower(regexprep(string(cands(i)), ...
            '[^a-zA-Z0-9]',''));
        jj = find(vnl == c,1,'first');
        if ~isempty(jj)
            j = jj;
            return
        end
    end
    for i = 1:numel(cands)
        c = lower(regexprep(string(cands(i)), ...
            '[^a-zA-Z0-9]',''));
        jj = find(contains(vnl,c),1,'first');
        if ~isempty(jj)
            j = jj;
            return
        end
    end
    j = fallback;
end

% ==================================
function t = local_parse_col_date(x)
% ==================================

    if isdatetime(x)
        t = dateshift(x(:),'start','day');
        return
    end

    x = string(x(:));
    x = strip(x);
    x = erase(x,'"');

    fmts = {'dd/MM/yyyy','d/MM/yyyy', ...
        'dd/M/yyyy','d/M/yyyy', ...
        'yyyy-MM-dd','yyyy/MM/dd','MM/dd/yyyy'};

    for i = 1:numel(fmts)
        try
            t = datetime(x, ...
                'InputFormat',fmts{i});
            if ~any(isnat(t))
                t = dateshift(t,'start','day');
                return
            end
        catch
        end
    end

    t = datetime(x);
    t = dateshift(t,'start','day');
end

% =============================
function x = local_to_double(x)
% =============================

    if isnumeric(x)
        x = double(x(:));
        return
    end
    if iscell(x)
        x = string(x);
    end
    if ischar(x)
        x = string(cellstr(x));
    end
    if isstring(x) || iscategorical(x)
        xs = string(x(:));
        xs = strip(xs);
        xs = erase(xs,'"');
        xs = strrep(xs,',','.');
        xs = regexprep(xs, ...
            '^(NA|NaN|null|NULL|nan|None|-9999)$', ...
            'NaN','ignorecase');
        xs(xs == "") = "NaN";
        x = str2double(xs);
        return
    end
    error(['      Error:read_meteo_COL: ' ...
        'Unable to convert column to double.']);
end

% ===================================
function id = local_col_id_strings(x)
% ===================================

    x = string(x(:));
    x = strtrim(x);
    x = regexprep(x,'\.0+$','');
    x = regexprep(x,'[^0-9]','');

    if any(x == "")
        error(['      Error:read_meteo_COL: ' ...
            'Empty CAMELS-COL basin ID after normalization.']);
    end
    id = x;
end

% ===============================
function t = local_to_datetime(x)
% ===============================
    
    if isdatetime(x)
        t = x(1);

    elseif isnumeric(x)
        if numel(x) >= 3
            t = datetime(x(1),x(2),x(3));
        else
            t = datetime(x(1), ...
                'ConvertFrom','datenum');
        end

    else
        x = string(x);
        t = datetime(x(1));
    end

    t = dateshift(t,'start','day');
end

% ----------------------------------------
function aux = local_aux_from_bas(bas,aux)
% ----------------------------------------

    K = bas.K;
    if isfield(bas,'lat')
        aux(1:K,1) = double(bas.lat(1:K));
    elseif isfield(bas,'gauge_lat')
        aux(1:K,1) = double(bas.gauge_lat(1:K));
    end

    if isfield(bas,'elev')
        aux(1:K,2) = double(bas.elev(1:K));
    elseif isfield(bas,'gauge_elev')
        aux(1:K,2) = double(bas.gauge_elev(1:K));
    elseif isfield(bas,'mean_ele')
        aux(1:K,2) = double(bas.mean_ele(1:K));
    end

    if isfield(bas,'area')
        a = double(bas.area(1:K));
        if median(a,'omitnan') < 1e7
            a = a * 1e6;
        end
        aux(1:K,3) = a;
    elseif isfield(bas,'area_km2')
        aux(1:K,3) = 1e6 * double(bas.area_km2(1:K));
    end
end

% -------------------------------------------------------------
function aux = local_aux_from_gauge_information(dirCOL,bas,aux)
% -------------------------------------------------------------

    files = { ...
        fullfile(dirCOL, ...
        'gauge_information_COL.csv'), ...
        fullfile(dirCOL, ...
        'gauge_information.txt'), ...
        fullfile(dirCOL, ...
        '02_CAMELS_COL_Catchment_information.csv')};

    f = '';
    for i = 1:numel(files)
        if isfile(files{i})
            f = files{i};
            break
        end
    end
    if isempty(f)
        return
    end

    delim = local_detect_delimiter(f);
    T = readtable(f,'FileType','text', ...
        'Delimiter',delim, ...
        'VariableNamingRule','preserve', ...
        'Encoding','ISO-8859-1');

    vn0 = string(T.Properties.VariableNames);
    vn = lower(regexprep(vn0,'[^a-zA-Z0-9]',''));

    iID = find(ismember(vn,["gaugeid", ...
        "gageid","id","stationid"]),1);
    if isempty(iID)
        iID = find(contains(vn,"gaugeid") ...
            | contains(vn,"gageid"),1);
    end
    if isempty(iID)
        return
    end

    iLat = find(ismember(vn,["gaugelat", ...
        "lat","latitude"]),1);
    iLon = find(ismember(vn,["gaugelon", ...
        "lon","long","longitude"]),1);
    iElev = find(contains(vn,"elev") ...
        | contains(vn,"meanele"),1);
    iArea = find(contains(vn,"area"),1);

    idT = local_col_id_strings(T{:,iID});
    idReq = local_col_id_strings(bas.id_gauge(:));
    [tf,loc] = ismember(idReq,idT);

    if ~any(tf)
        fprintf('\n');
        fprintf(['      Warning:read_meteo_COL: ' ...
            'no selected basin IDs ' ...
            'matched gauge metadata file: %s\n'],f);
        return
    end

    if ~isempty(iLat)
        aux(tf,1) = double(local_to_double(T{loc(tf),iLat}));
    end
    if ~isempty(iElev)
        aux(tf,2) = double(local_to_double(T{loc(tf),iElev}));
    end
    if ~isempty(iArea)
        area = double(local_to_double(T{loc(tf),iArea}));
        if median(area,'omitnan') < 1e7
            area = area * 1e6;
        end
        aux(tf,3) = area;
    end

    % If lat/lon are still projected coordinates, use the safe WGS84 values
    % already written by read_attr_COL in gauge_information_COL.csv.  If not,
    % try a World Mercator conversion.
    if ~isempty(iLon)
        lon = double(local_to_double(T{loc(tf),iLon}));
        lat = aux(tf,1);
        if any(abs(lat) > 90 | abs(lon) > 180)
            try
                crs = projcrs(3395);
                [lat2,~] = projinv(crs,lon,lat);
            catch
                R = 6378137;
                %lon2 = lon / R * 180/pi;
                lat2 = (2*atan(exp(lat/R)) - pi/2) * 180/pi;
            end
            aux(tf,1) = lat2;
        end
    end
end
