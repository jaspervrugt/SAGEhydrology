function R = region_config_DE()
%REGION_CONFIG_DE Regional defaults for CAMELS-DE.
%
% All X.paths fields are relative to Data/<R.data_root>.
% Dates use dd/MM/yyyy and water-year boundaries.

    R = struct();
    R.code = 'CAMELS_DE';
    R.acronym = 'DE';
    R.name = 'Germany';
    R.dataset = 'CAMELS-DE';
    R.data_root = 'CAMELS_DE';
    R.resolutions = {'Daily','Hourly'};
    R.default_resolution = 'Daily';
    R.basin_file_pattern = 'DE_%d_basins.txt';

    X = struct();
    X.label = 'Daily';
    X.dt = 1;
    X.basins.universe = 1484;
    X.basins.file = 'DE_1484_basins.txt';
    X.basins.training = 1200;
    X.basins.evaluation = 284;
    X.period.spinup_days = 365;
    X.period.manual.train_start = '01/10/2008';
    X.period.manual.train_end = '30/09/2020';
    X.period.manual.eval_start = '01/10/1996';
    X.period.manual.eval_end = '30/09/2008';
    X.period.common_start = '01/10/1996';
    X.period.common_end = '30/09/2020';
    X.paths.run_root = '';
    X.paths.meteo = fullfile('daily','timeseries');
    X.paths.discharge = fullfile('daily','timeseries');
    % Meteorological/PET controls shown by SAGE-GUI.
    X.meteo.product.items = {'1 CAMELS-DE daily'};
    X.meteo.product.default = '1 CAMELS-DE daily';
    X.meteo.product.enabled = false;
    X.meteo.precipitation.items = {'1 precipitation'};
    X.meteo.precipitation.default = '1 precipitation';
    X.meteo.precipitation.enabled = false;
    X.meteo.temperature.items = {'1 air temperature'};
    X.meteo.temperature.default = '1 air temperature';
    X.meteo.temperature.enabled = false;
    X.meteo.pet.items = { ...
        '1 Penman-Monteith', ...
        '2 Priestley-Taylor', ...
        '3 Makkink' ...
        };
    X.meteo.pet.default = '1 Penman-Monteith';
    X.meteo.pet.enabled = true;
    C = repmat(struct('name','','type','','path','','pattern','', ...
        'minimum_count',1,'required',true),0,1);
    C(1).name = 'Meteorological data';
    C(1).type = 'folder';
    C(1).path = fullfile('daily','timeseries');
    C(1).pattern = '*';
    C(1).minimum_count = 1;
    X.checks = C;
    R.by_resolution.Daily = X;

    X = struct();
    X.label = 'Hourly';
    X.dt = 24;
    X.basins.universe = 1256;
    X.basins.file = 'DE_1256_basins.txt';
    X.basins.training = 1000;
    X.basins.evaluation = 256;
    X.period.spinup_days = 365;
    X.period.manual.train_start = '01/10/2013';
    X.period.manual.train_end = '30/09/2021';
    X.period.manual.eval_start = '01/10/2005';
    X.period.manual.eval_end = '30/09/2013';
    X.period.common_start = '01/10/2005';
    X.period.common_end = '30/09/2021';
    X.paths.run_root = '';
    X.paths.meteo = fullfile('hourly','timeseries');
    X.paths.discharge = fullfile('hourly','timeseries');
    % Meteorological/PET controls shown by SAGE-GUI.
    X.meteo.product.items = {'1 CAMELS-DE hourly'};
    X.meteo.product.default = '1 CAMELS-DE hourly';
    X.meteo.product.enabled = false;
    X.meteo.precipitation.items = {'1 precipitation'};
    X.meteo.precipitation.default = '1 precipitation';
    X.meteo.precipitation.enabled = false;
    X.meteo.temperature.items = {'1 air temperature'};
    X.meteo.temperature.default = '1 air temperature';
    X.meteo.temperature.enabled = false;
    X.meteo.pet.items = { ...
        '1 Penman-Monteith', ...
        '2 Priestley-Taylor', ...
        '3 Makkink' ...
        };
    X.meteo.pet.default = '1 Penman-Monteith';
    X.meteo.pet.enabled = true;
    C = repmat(struct('name','','type','','path','','pattern','', ...
        'minimum_count',1,'required',true),0,1);
    C(1).name = 'Meteorological data';
    C(1).type = 'folder';
    C(1).path = fullfile('hourly','timeseries');
    C(1).pattern = '*';
    C(1).minimum_count = 1;
    X.checks = C;
    R.by_resolution.Hourly = X;

end