function [A,id_gauge,gname,zone] = read_attr_DE(dirD,bas)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%READ_ATTR_DE Read catchment attributes of CAMELS-DE hourly dataset.
%
% SYNOPSIS:
%   [A,id_gauge,gname,zone] = read_attr_DE(dirD,bas)
%
% INPUT:
%   dirD        Directory with CAMELS-DE catchment-attribute files
%               Expected location: Data/CAMELS_DE
%   bas         OPTIONAL: structure with basin and attribute information
%    .id_gauge   OPTIONAL: string/cell/vector of requested CAMELS-DE gauge IDs
%    .id_attr    rx1 vector of integer attribute IDs
%    .pr_attr    OPTIONAL: print attribute table [1/0]
%
% OUTPUT:
%   A           r x K matrix of standardized selected attributes
%   id_gauge    K x 1 string array with CAMELS-DE gauge identifiers
%   gname       K x 1 string array with standardized gauge names
%   zone        structure with CAMELS-DE basin classification
%    .id            K x 1 string array with zone labels per basin
%    .long          K x 1 string array with descriptive zone labels
%    .num           K x 1 numeric vector with integer zone identifiers
%    .codes         mx1 string array with unique compact zone codes
%    .names         mx1 string array with unique zone names
%    .lat           K x 1 vector with gauge latitude
%    .lon           K x 1 vector with gauge longitude
%    .area          K x 1 vector with catchment area [km^2]
%    .elev_mean     K x 1 vector with mean elevation [m]
%    .p_mean        K x 1 vector with mean precipitation
%    .frac_snow     K x 1 vector with snow fraction
%    .forest_perc   K x 1 vector with forest/seminatural area percentage
%
% DESCRIPTION:
%   This function reads and joins CAMELS-DE 1-hour topographic, climatic,
%   hydrogeology, soil, land-cover, and human-influence attributes by
%   gauge_id. The topographic table is used as the master table because it
%   contains gauge_id, gauge_name, gauge location, elevation, and basin area.
%
%   The hydrologic-signature file is joined into the full attribute table,
%   so users may explicitly select streamflow-derived signatures such as
%   q_mean, runoff_ratio, FDC slope, Q5/Q95, and high/low-flow metrics.
%   These hydrologic attributes are not part of the default attribute set.
%   The simulation-benchmark file is checked only as release metadata and
%   is not joined because it contains model-performance information.
%
% NOTES:
%   If bas.id_attr is omitted, a default set of about 30 static/non-discharge
%   attributes is selected using name matching. Hydrologic signatures remain
%   available for manual selection through bas.id_attr. The default set includes
%   location, size, elevation, precipitation/snow, hydrogeology, soil,
%   land cover, and dam descriptors.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% © Written by Jasper A. Vrugt, May 2026                                  %
% University of California, Irvine                                        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    if nargin < 1 ...
            || isempty(dirD)
        error('read_attr_DE:missingDir', ...
            ['      Error:read_attr_DE: ' ...
            'dirD must be provided.']);
    end
    
    if ~isfolder(dirD)
        error('read_attr_DE:missingDir', ...
            ['      Error:read_attr_DE: ' ...
            'Attribute directory ' ...
            'does not exist: %s'],dirD);
    end
    
    if nargin < 2 ...
            || isempty(bas)
        bas = struct();
    end
    
    if ~isstruct(bas)
        error('read_attr_DE:badBas', ...
            ['      Error:read_attr_DE: ' ...
            'bas must be a structure.']);
    end
    % =========================================
    % ZONE CONTROL PARAMETERS (GLOBAL DEFAULTS)
    % =========================================
    if ~isfield(bas,'min_per_zone') ...
            || isempty(bas.min_per_zone)
        min_per_zone = 5;
    else
        min_per_zone = bas.min_per_zone;
    end    
    if ~isfield(bas,'max_zones') ...
            || isempty(bas.max_zones)
        max_zones = 8;
    else
        max_zones = bas.max_zones;
    end

    pr_table = 1;
    if isfield(bas,'pr_attr') ...
            && ~isempty(bas.pr_attr)
        pr_table = bas.pr_attr;
    elseif ~isfield(bas,'id_attr') ...
            || isempty(bas.id_attr)
        pr_table = 0;
    end
 
    [dirD,~,prefix] = local_resolve_de_attr_dir(dirD,bas);

    % File paths. These files are expected directly under Data/CAMELS_DE.
    f_topo = fullfile(dirD, ...
        [prefix 'topographic_attributes.csv']);
    f_clim = fullfile(dirD, ...
        [prefix 'climatic_attributes.csv']);
    f_hinf = fullfile(dirD, ...
        [prefix 'humaninfluence_attributes.csv']);
    f_hgeo = fullfile(dirD, ...
        [prefix 'hydrogeology_attributes.csv']);
    f_land = fullfile(dirD, ...
        [prefix 'landcover_attributes.csv']);
    f_soil = fullfile(dirD, ...
        [prefix 'soil_attributes.csv']);
    f_hydro = fullfile(dirD, ...
        [prefix 'hydrologic_attributes.csv']);
    f_bench = fullfile(dirD, ...
        [prefix 'simulation_benchmark.csv']);

    caller = mfilename;
    must_exist(f_topo, ...
        [prefix 'topographic_attributes.csv'],caller);
    must_exist(f_clim, ...
        [prefix 'climatic_attributes.csv'],caller);
    must_exist(f_hinf, ...
        [prefix 'humaninfluence_attributes.csv'],caller);
    must_exist(f_hgeo, ...
        [prefix 'hydrogeology_attributes.csv'],caller);
    must_exist(f_land, ...
        [prefix 'landcover_attributes.csv'],caller);
    must_exist(f_soil, ...
        [prefix 'soil_attributes.csv'],caller);
    must_exist(f_hydro, ...
        [prefix 'hydrologic_attributes.csv'],caller);
    
    % Soft warning only: this file is part of the release, but the reader
    % does not depend on model benchmark scores.
    if ~isfile(f_bench)
        warning('read_attr_DE:missingBenchmarkFile', ...
            ['      Warning:read_attr_DE: ' ...
            '%s not found; continuing because ' ...
            'benchmark scores are not used.'], ...
            [prefix 'simulation_benchmark.csv']);
    end
    
    fprintf('... Reading CAMELS-DE basin attributes ');
    
    topo = read_de_table(f_topo);
    clim = read_de_table(f_clim);
    hinf = read_de_table(f_hinf);
    hgeo = read_de_table(f_hgeo);
    land = read_de_table(f_land);
    soil = read_de_table(f_soil);
    hydro = read_de_table(f_hydro);
    
    % Use topography as master table because it contains names, locations,
    % elevations, and drainage area. The join order defines the attribute-ID
    % order used by print_attr_DE and attr_catalog('CAMELS_DE').
    AA = topo;
    AA = join_de_attributes(AA,clim);
    AA = join_de_attributes(AA,hydro);
    AA = join_de_attributes(AA,hgeo);
    AA = join_de_attributes(AA,soil);
    AA = join_de_attributes(AA,land);
    AA = join_de_attributes(AA,hinf);
    
    % Daily CAMELS-DE does not contain a few metadata/completeness
    % fields that are present in the hourly catalog. Add neutral
    % compatibility columns so attr_catalog('CAMELS_DE') remains valid
    % for both daily and hourly data.
    if ~ismember('area_pct_in_germany', ...
            AA.Properties.VariableNames)
        AA.area_pct_in_germany = ...
            100 * ones(height(AA),1);
    end

    if ~ismember('precipitation_perc_complete', ...
            AA.Properties.VariableNames)
        AA.precipitation_perc_complete = ...
            100 * ones(height(AA),1);
    end

    id_all = normalize_de_gauge_id(AA.gauge_id);
    AA.gauge_id = id_all;
    
    % Sort for reproducibility.
    [~,isrt] = sort(id_all);
    AA = AA(isrt,:);
    id_all = id_all(isrt);
    
    % Optional selected basin order. This keeps compatibility with the SAGE
    % basin selection/sampling code, which may pass bas.id_gauge.
    if isfield(bas,'id_gauge') ...
            && ~isempty(bas.id_gauge)
        id_req = normalize_de_gauge_id(bas.id_gauge(:));
        % CAMELS-DE lists may store IDs with or without leading DE.
        [id_all_h,id_req_h] = local_harmonize_de_ids(id_all,id_req);
        [tf,loc] = ismember(id_req_h,id_all_h);
    
        if ~all(tf)
            missing = id_req(~tf);
            error('read_attr_DE:missingRequestedGauge', ...
                ['      Error:read_attr_DE: ' ...
                'Missing CAMELS-DE attributes ' ...
                'for %d requested gauge IDs ' ...
                '(e.g., %s).'],numel(missing), ...
                char(missing(1)));
        end
    
        AA = AA(loc,:);
        id_gauge = id_req(:);
    else
        id_gauge = id_all(:);
    end
    
    % Gauge names.
    if ismember('gauge_name', ...
            AA.Properties.VariableNames)
        gname = string(AA.gauge_name);
    else
        gname = "Gauge " + id_gauge;
    end

    gname = standardize_camels_gauge_names( ...
        gname(:),'CAMELS_DE',id_gauge);
    
    ensure_de_gauge_information(dirD,AA);
    
    % German hydroclimatic / physiographic classification.
    region = erase(mfilename,'read_attr_');
    zone = classify_camels_all_zones(region,AA, ...
        min_per_zone,max_zones);
    
    % ------------------
    % Generic attributes
    % ------------------
    [A,labels] = build_attr_matrix(AA,bas, ...
        mfilename,pr_table);
    
    if pr_table == 1
        assignin('base', ...
            'SAGE_DE_attribute_labels', ...
            labels);
    end
    
    fprintf(' ... Done\n');

end

% ===============================
function T = read_de_table(fname)
% ===============================

    opts = detectImportOptions(fname, ...
        'FileType','text');
    opts.VariableNamingRule = 'preserve';
    T = readtable(fname,opts);
    
    T.Properties.VariableNames = ...
        matlab.lang.makeValidName( ...
        T.Properties.VariableNames, ...
        'ReplacementStyle','delete');
    
    if ~ismember('gauge_id',T.Properties.VariableNames)
        error('read_attr_DE:missingGaugeID', ...
            ['      Error:read_attr_DE: ' ...
            'File %s does not contain gauge_id.'],fname);
    end
    
    T.gauge_id = normalize_de_gauge_id(T.gauge_id);
    T = sortrows(T,'gauge_id');

end

% ==================================
function T = join_de_attributes(T,U)
% ==================================

    varsT = string(T.Properties.VariableNames);
    varsU = string(U.Properties.VariableNames);
    varsU = varsU(varsU ~= "gauge_id");
    
    for j = 1:numel(varsU)
        if any(varsT == varsU(j))
            old = char(varsU(j));
            new = char(varsU(j) + "_de");
            U.Properties.VariableNames{ ...
                strcmp(U.Properties.VariableNames,old)} = new;
        end
    end
    
    T = outerjoin(T,U, ...
        'Keys','gauge_id', ...
        'MergeKeys',true, ...
        'Type','left');

end

% ===========================================
function ensure_de_gauge_information(dirD,AA)
% ===========================================

    fout = fullfile(dirD,'gauge_information.txt');
    
    % Refresh the file because the CAMELS-DE source provides clean names and
    % coordinates in the topographic attribute table.
    if isfile(fout)
        try
            delete(fout)
        catch
        end
    end
    
    needVars = {'gauge_id','gauge_name', ...
        'gauge_lat','gauge_lon','area'};
    for j = 1:numel(needVars)
        if ~ismember(needVars{j}, ...
                AA.Properties.VariableNames)
            error('read_attr_DE:missingGaugeInfoVar', ...
                ['      Error:read_attr_DE: ' ...
                'Cannot create gauge_information.txt ' ...
                'because %s is missing.'], ...
                needVars{j});
        end
    end
    
    fid = fopen(fout,'w');
    if fid < 0
        warning('read_attr_DE:gaugeInformationWriteFailed', ...
            ['      Warning:read_attr_DE: ' ...
            'Could not write ' ...
            'gauge_information.txt to %s'],dirD);
        return
    end
    cleanup = onCleanup(@() fclose(fid));
    
    fprintf(fid,['HUC_02\tGAGE_ID\tGAGE_NAME\tLAT\tLONG\t' ...
        'DRAINAGE AREA (KM^2)\n']);
    
    for k = 1:height(AA)
        gid = char(normalize_de_gauge_id( ...
            AA.gauge_id(k)));
    
        gnm = string(AA.gauge_name(k));
        gnm = replace(gnm,char(9),' ');
        gnm = replace(gnm,newline,' ');
    
        lat = double(AA.gauge_lat(k));
        lon = double(AA.gauge_lon(k));
        area = double(AA.area(k));
    
        fprintf(fid,['DE\t%s\t%s\t%.6f' ...
            '\t%.6f\t%.6f\n'], ...
            gid,char(gnm),lat,lon,area);
    end
    
    fprintf(['\n      Wrote CAMELS-DE gauge ' ...
        'information file: %s'],fout);

end

% ====================================
function id = normalize_de_gauge_id(x)
% ====================================

    if isnumeric(x) || islogical(x)
        id = string(compose('%.0f', ...
            double(x(:))));
    else
        id = string(x(:));
        id = strip(id);
        id = erase(id,'"');
        id(ismissing(id)) = "";
        id = regexprep(id,'\.0+$','');
    end

end

% =========================================
function [id_ref,id_query] = ...
    local_harmonize_de_ids(id_ref,id_query)
% =========================================

    id_ref = normalize_de_gauge_id(id_ref);
    id_query = normalize_de_gauge_id(id_query);
    
    hasDE_ref = startsWith(id_ref,"DE");
    hasDE_query = startsWith(id_query,"DE");
    
    if any(hasDE_ref) ...
            && ~all(hasDE_query)
        id_query = local_add_de_prefix(id_query);
    elseif any(hasDE_query) ...
            && ~all(hasDE_ref)
        id_ref = local_add_de_prefix(id_ref);
    end

end

% ===================================
function id = local_add_de_prefix(id)
% ===================================

    id = normalize_de_gauge_id(id);
    
    for i = 1:numel(id)
        s = char(id(i));
        if isempty(s)
            continue
        end
        if ~startsWith(s,'DE')
            s = ['DE' s]; %#ok
        end
        id(i) = string(s);
    end

end

% =================================================================
function [dirD,stream,prefix] = local_resolve_de_attr_dir(dirD,bas)
% =================================================================

    stream = '';

    if nargin >= 2 && isstruct(bas)
        if isfield(bas,'stream') && ~isempty(bas.stream)
            stream = lower(strtrim(char(bas.stream)));
        elseif isfield(bas,'dt') && ~isempty(bas.dt)
            dt = double(bas.dt);
            if abs(dt - 24) < 1e-8 ...
                    || abs(dt - 1/24) < 1e-8 ...
                    || abs(dt - 3600) < 1e-8
                stream = 'hourly';
            else
                stream = 'daily';
            end
        end
    end

    if isempty(stream)
        if isfile(fullfile(dirD,'daily', ...
                'CAMELS_DE_topographic_attributes.csv'))
            stream = 'daily';
        elseif isfile(fullfile(dirD,'hourly', ...
                'CAMELS_DE_1h_topographic_attributes.csv'))
            stream = 'hourly';
        elseif isfile(fullfile(dirD, ...
                'CAMELS_DE_topographic_attributes.csv'))
            stream = 'daily';
        elseif isfile(fullfile(dirD, ...
                'CAMELS_DE_1h_topographic_attributes.csv'))
            stream = 'hourly';
        else
            stream = 'daily';
        end
    end

    if strcmp(stream,'daily')
        if isfolder(fullfile(dirD,'daily'))
            dirD = fullfile(dirD,'daily');
        end
        prefix = 'CAMELS_DE_';
    elseif strcmp(stream,'hourly')
        if isfolder(fullfile(dirD,'hourly'))
            dirD = fullfile(dirD,'hourly');
        end
        prefix = 'CAMELS_DE_1h_';
    else
        error('read_attr_DE:badStream', ...
            'CAMELS-DE stream must be daily or hourly.');
    end
end