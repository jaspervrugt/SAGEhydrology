function [dat,aux] = read_meteo_DE(dirM,bas,split,meteo)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%READ_METEO_DE Read CAMELS-DE daily/hourly meteorological data for each 
% watershed
%
% SYNOPSIS:
%   [dat,aux] = read_meteo_DE(dirM,bas,split,meteo)
%
% INPUT:
%   dirM        string with main directory of CAMELS-DE timeseries data
%                normally: Data/CAMELS_DE/[daily/hourly]/timeseries
%   bas         structure basin information
%    .K          number of selected watersheds
%    .id_gauge   Kx1 string/cell/string-array CAMELS-DE gauge identifiers
%                 e.g. "DE110000"
%   split       structure with training/evaluation time split
%    .dt         temporal resolution. CAMELS-DE is daily/hourly:
%                   dt = 1/24, 1/24 day, or 3600 s depending on caller
%                   dt = 1, 1 day, or 86400 s depending on caller
%    .idx        indices of scored period after spin-up
%    .local      optional flag for basin-local split
%   meteo       structure basin-average meteorological data
%    .precip     OPTIONAL precipitation choice
%                   1 = precipitation_mean_gapfilled [default]
%                   2 = precipitation_mean original
%                   3 = precipitation_min_gapfilled
%                   4 = precipitation_max_gapfilled
%    .temp       OPTIONAL temperature choice
%                   1 = air_temperature_mean [default]
%                   2 = air_temperature_min
%                   3 = air_temperature_max
%    .pet        OPTIONAL PET choice
%                   0 = use PET column if present, otherwise zero PET
%                   1 = Penman-Monteith using hourly CAMELS-DE variables
%                   2 = Priestley-Taylor using hourly CAMELS-DE variables
%                   3 = Makkink using hourly CAMELS-DE variables
%    .progressFcn optional GUI progress callback
%
% OUTPUT:
%   dat         OUTPUT: Kx1 cell structure with meteorological information
%    {k}.meteo.P   precipitation [mm/day] or [mm/hour]
%    {k}.meteo.Ep  potential evapotranspiration [mm/day] or [mm/hour]
%    {k}.meteo.T   air temperature [deg C]
%    {k}.meteo.bad indices with invalid meteorological data
%    {k}.y_n       scored period only, spin-up removed [mm/d] or [mm/hour]
%    {k}.bad       logical mask, same length as y_n
%    {k}.gauge     gauge/catchment identifier
%    {k}.fname     source file names
%   aux         OUTPUT: Kx3 matrix with basin metadata
%                column 1 = latitude  [degrees]
%                column 2 = elevation [m]
%                column 3 = basin area [m^2]
%
% DESCRIPTION:
%   CAMELS-DE stores daily/hourly precipitation, temperature, discharge, 
%   and additional meteorological variables together in one 
%   hydrometeorological timeseries file per catchment:
%
%       CAMELS_DE_hydromet_timeseries_<gauge_id>.csv
%       CAMELS_DE_1h_hydromet_timeseries_<gauge_id>.csv
%
%   This reader extracts precipitation, temperature, and specific discharge,
%   converts them to the common SAGE structure used by the hydrologic models,
%   and writes basin-level MAT cache files so repeated reads avoid parsing
%   the original CSV files.
%
%   The CAMELS-DE daily/hourly files do not ship PET directly. Therefore 
%   Ep is computed from the available daily/hourly meteorological variables 
%   using the same three choices as the US hourly reader when
%   meteo.pet = 1, 2, or 3. Because CAMELS-DE does not include downwelling 
%   longwave radiation, this reader estimates it from air temperature, 
%   vapor pressure, and cloud cover.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% © Written by Jasper A. Vrugt, May 2026                                  %
% University of California, Irvine                                        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    if nargin < 4 ...
            || isempty(meteo)
        meteo = struct();
    end
    
    if nargin < 1 ...
            || isempty(dirM)
        error('read_meteo_DE:missingDir', ...
            ['      Error:read_meteo_DE: ' ...
            'dirM must be provided.']);
    end
    
    if ~isfolder(dirM)
        error('read_meteo_DE:missingDir', ...
            ['      Error:read_meteo_DE: ' ...
            'Timeseries directory ' ...
            'does not exist: %s'],dirM);
    end
    
    if nargin < 2 ...
            || ~isstruct(bas) ...
            || ~isfield(bas,'id_gauge') ...
            || isempty(bas.id_gauge)
        error('read_meteo_DE:missingBasins', ...
            ['      Error:read_meteo_DE: ' ...
            'bas.id_gauge must be provided.']);
    end
    
    if ~isfield(bas,'K') ...
            || isempty(bas.K)
        K = numel(bas.id_gauge);
    else
        K = double(bas.K);
    end
    
    split = local_prepare_split(split);
    
    dt = double(split.dt);
    % SAGE convention: dt = 24 for hourly, dt = 1 for daily.
    % Also accept 1/24 days or 3600 seconds for standalone use.
    isHourly = abs(dt - 24) < 1e-8 ...
            || abs(dt - 1/24) < 1e-8 ...
            || abs(dt - 3600) < 1e-8;
    
    isDaily = abs(dt - 1) < 1e-8;
    
    if ~isHourly ...
            && ~isDaily
        error('read_meteo_DE:unsupportedDt', ...
            ['      Error:read_meteo_DE: ' ...
            'CAMELS-DE reader supports dt = 1 daily ' ...
            'or dt = 24 hourly.']);
    end 

    id_GAUGE = normalize_de_gauge_id( ...
        bas.id_gauge(:));
    
    precipChoice = 1;
    tempChoice = 1;
    petChoice = 1;

    if nargin >= 4 ...
            && isstruct(meteo)
        if isfield(meteo,'precip') ...
                && ~isempty(meteo.precip)
            precipChoice = double(meteo.precip(1));
        end
        if isfield(meteo,'temp') ...
                && ~isempty(meteo.temp)
            tempChoice = double(meteo.temp(1));
        end
        if isfield(meteo,'pet') ...
                && ~isempty(meteo.pet)
            petChoice = double(meteo.pet(1));
        end
    end
    
    dat = cell(K,1);
    aux = nan(K,3);
    
    if isDaily
        cache_dir = fullfile(dirM,'_cache_DE_daily');
    else
        cache_dir = fullfile(dirM,'_cache_DE_hourly');
    end
    if ~isfolder(cache_dir)
        mkdir(cache_dir);
    end
    
    % Metadata for aux: file sits one level above /timeseries
    rootDE = fileparts(dirM);    
    if isDaily
        f_topo = fullfile(rootDE, ...
            'CAMELS_DE_topographic_attributes.csv');
    else
        f_topo = fullfile(rootDE, ...
            'CAMELS_DE_1h_topographic_attributes.csv');
    end

    if isfile(f_topo)
        Ttopo = readtable(f_topo, ...
            'VariableNamingRule','preserve');
    else
        Ttopo = table();
        if isDaily
            topoName = 'CAMELS_DE_topographic_attributes.csv';
        else
            topoName = 'CAMELS_DE_1h_topographic_attributes.csv';
        end
        fprintf(['      Warning:read_meteo_DE: ' ...
            'Could not find ' topoName '. aux will be NaN.\n']);
    end
    
    if isDaily
        tag = 'daily';
    else
        tag = 'hourly';
    end
    
    fprintf(['... Reading ' tag ' CAMELS-DE ' ...
        'meteorological data files %3d%%'],0);
    flag_progress = true;
    
    warned_no_pet = false;
    
    for k = 1:K
    
        gid = id_GAUGE(k);
        fname = local_find_de_timeseries_file( ...
            dirM,gid,isDaily);
    
        if isDaily
            cache_file = fullfile(cache_dir, ...
                sprintf('%s_DE_daily_p%d_t%d_pet%d.mat', ...
                char(gid),precipChoice,tempChoice,petChoice));
        else
            cache_file = fullfile(cache_dir, ...
                sprintf('%s_DE_hourly_p%d_t%d_pet%d.mat', ...
                char(gid),precipChoice,tempChoice,petChoice));
        end
    
        auxNow = local_de_aux(Ttopo,gid);

        [Pfull,Epfull,Tfull,Qfull,bad_meteo_full, ...
            bad_q_full,fileStartN,fileEndN, ...
            fileStartDT,fileEndDT,hasPet] = ...
            local_load_or_build_de_cache(fname, ...
            cache_file, ...
            precipChoice,tempChoice, ...
            petChoice,gid,isDaily,auxNow);
    
        if ~hasPet && ~warned_no_pet
            if isDaily
                fprintf(['\n      Warning:read_meteo_DE: ' ...
                    'PET could not be computed from the ' ...
                    'available CAMELS-DE daily columns; ' ...
                    'using Ep = 0 mm/day.\n']);
            else
                fprintf(['\n      Warning:read_meteo_DE: ' ...
                    'PET could not be computed from the ' ...
                    'available CAMELS-DE hourly columns; ' ...
                    'using Ep = 0 mm/hour.\n']);
            end
            warned_no_pet = true;
        end
   
        req = local_requested_window(split, ...
            fileStartN,fileEndN,numel(Pfull),isDaily);
    
        if req.read_start_N < fileStartN ...
                || req.read_end_N > fileEndN
            if flag_progress
                fprintf('\n');
            end
            error('read_meteo_DE:periodOutsideFile', ...
                ['      Error:read_meteo_DE: ' ...
                'requested period outside CAMELS-DE file ' ...
                'for basin %s.\nFile covers %s to %s.'], ...
                char(gid),string(fileStartDT), ...
                string(fileEndDT));
        end
    
        id_read0 = int64(req.read_start_N ...
            - fileStartN) + 1;
        id_read1 = int64(req.read_end_N ...
            - fileStartN) + 1;
        id_r = double(id_read0:id_read1);
    
        P = double(Pfull(id_r));
        Ep = double(Epfull(id_r));
        Temp = double(Tfull(id_r));
        Qall = double(Qfull(id_r));
    
        if isfield(split,'idx') ...
                && ~isempty(split.idx)
            idx_score = double(split.idx(:));
        else
            idx_score = (1:numel(Qall)).';
        end
        
        idx_score = idx_score(idx_score >= 1 ...
            & idx_score <= numel(Qall));
    
        % Meteo keeps spin-up period
        dat{k}.meteo.P = single(P);
        dat{k}.meteo.Ep = single(Ep);
        dat{k}.meteo.T = single(Temp);
    
        Q = Qall(idx_score);
        dat{k}.y_n = single(Q);
        dat{k}.gauge = gid;
        dat{k}.fname{1} = fname;
        dat{k}.fname{2} = fname;
    
        id0d = double(id_read0);
        id1d = double(id_read1);
    
        bad_meteo_full = double(bad_meteo_full(:));
        bad_meteo = bad_meteo_full( ...
            bad_meteo_full >= id0d & ...
            bad_meteo_full <= id1d) - id0d + 1;
    
        dat{k}.meteo.bad = bad_meteo(:).';
    
        bad_q_full = double(bad_q_full(:));
    
        bad_q_all = bad_q_full( ...
            bad_q_full >= id0d ...
            & bad_q_full <= id1d) - id0d + 1;
    
        % Discharge bad mask must match y_n
        badmask_all = false(1,numel(Qall));
        bad_q_all = bad_q_all(isfinite(bad_q_all) ...
            & bad_q_all >= 1 ...
            & bad_q_all <= numel(Qall));
        badmask_all(round(bad_q_all)) = true;
    
        dat{k}.bad = badmask_all(idx_score);
        aux(k,:) = auxNow;
        if mod(k,5)==0 ...
                || k==K
            pct = floor(100*k/K);
            fprintf('\b\b\b\b%3d%%',pct);
            drawnow;
        end
    
        if isfield(meteo,'progressFcn') ...
                && ~isempty(meteo.progressFcn)
            try
                meteo.progressFcn(k);
            catch
            end
        end
    end
    
    if flag_progress
        fprintf('\b\b\b\b%s\n','... Done');
    end

    % ----------------------------------------------------------
    % Local basin-specific split based on ranked annual rainfall
    % ----------------------------------------------------------
    if isfield(split,'local') ...
            && split.local ...
            && isfield(split,'rainfall_block') ...
            && split.rainfall_block
    
        dat = rainfall_rank_split(dat,split);
    end

end

% ======================
% Local helper functions
% ======================

function split = local_prepare_split(split)

    if nargin < 1 ...
            || isempty(split)
        split = struct();
    end
    
    if exist('prepare_split','file') == 2
        try
            split = prepare_split(split);
        catch
            % Fall through to minimal local defaults.
        end
    end
    
    if ~isfield(split,'dt') ...
            || isempty(split.dt)
        split.dt = 1/24;
    end
    
    if ~isfield(split,'idx') ...
            || isempty(split.idx)
        % If no split was provided, use all records after the file-window
        % decision. This is overwritten inside local_requested_window when
        % possible only by the caller, so here we keep a harmless placeholder.
        split.idx = [];
    end

end

function fname = local_find_de_timeseries_file(dirM,gid,isDaily)

    if nargin < 3
        isDaily = false;
    end
    gid0 = char(normalize_de_gauge_id(gid));
    gid1 = gid0;
    
    if ~startsWith(gid1,'DE')
        gid1 = ['DE' gid1];
    end
    
    if isDaily
        patterns = { ...
            sprintf('CAMELS_DE_hydromet_timeseries_%s.csv',gid0), ...
            sprintf('CAMELS_DE_hydromet_timeseries_%s.csv',gid1), ...
            sprintf('*%s*.csv',gid0), ...
            sprintf('*%s*.csv',gid1)};
    else
        patterns = { ...
            sprintf('CAMELS_DE_1h_hydromet_timeseries_%s.csv',gid0), ...
            sprintf('CAMELS_DE_1h_hydromet_timeseries_%s.csv',gid1), ...
            sprintf('*%s*.csv',gid0), ...
            sprintf('*%s*.csv',gid1)};
    end
    
    D = [];
    for i = 1:numel(patterns)
        D = dir(fullfile(dirM,patterns{i}));
        if ~isempty(D)
            break
        end
    end
    
    if isempty(D)
        error('read_meteo_DE:missingFile', ...
            ['      Error:read_meteo_DE: ' ...
            'Missing CAMELS-DE hydromet ' ...
            'timeseries file for basin %s.'], ...
            gid0);
    end
    
    fname = fullfile(D(1).folder,D(1).name);

end

function [P,Ep,Tair,Q,bad_meteo,bad_q, ...
    fileStartN,fileEndN,fileStartDT,fileEndDT,hasPet] = ...
    local_load_or_build_de_cache(fname,cache_file, ...
    precipChoice,tempChoice,petChoice,gid,isDaily,auxNow)

    use_cache = false;
    
    if isfile(cache_file)
        try
            info_src = dir(fname);
            info_cch = dir(cache_file);
            use_cache = info_cch.datenum >= info_src.datenum;
        catch
            use_cache = false;
        end
    end
    
    if use_cache
        S = load(cache_file, ...
            'P','Ep','Tair','Q', ...
            'bad_meteo','bad_q', ...
            'fileStartN','fileEndN', ...
            'fileStartDT','fileEndDT','hasPet');
    
        P = S.P;
        Ep = S.Ep;
        Tair = S.Tair;
        Q = S.Q;
        bad_meteo = S.bad_meteo;
        bad_q = S.bad_q;
        fileStartN = S.fileStartN;
        fileEndN = S.fileEndN;
        fileStartDT = S.fileStartDT;
        fileEndDT = S.fileEndDT;
        if isfield(S,'hasPet')
            hasPet = S.hasPet;
        else
            hasPet = any(double(S.Ep) ~= 0);
        end
        return
    end
    
    [Traw,P,Ep,Tair,Q,bad_meteo,bad_q, ...
        fileStartN,fileEndN,fileStartDT, ...
        fileEndDT,hasPet] = ...
        local_read_de_timeseries_full(fname, ...
        precipChoice,tempChoice, ...
        petChoice,gid,isDaily,auxNow); %#ok<ASGLU>
    
    save(cache_file, ...
        'P','Ep','Tair','Q', ...
        'bad_meteo','bad_q', ...
        'fileStartN','fileEndN', ...
        'fileStartDT','fileEndDT', ...
        'precipChoice', ...
        'tempChoice','petChoice', ...
        'gid','hasPet','-v7.3');

end

function [Traw,P,Ep,Tair,Q,bad_meteo,bad_q, ...
    fileStartN,fileEndN,fileStartDT,fileEndDT,hasPet] = ...
    local_read_de_timeseries_full(fname, ...
    precipChoice,tempChoice,petChoice,gid,isDaily,auxNow)

    Traw = readtable(fname, ...
        'VariableNamingRule','preserve');
    
    Traw.Properties.VariableNames = ...
        matlab.lang.makeValidName( ...
        Traw.Properties.VariableNames, ...
        'ReplacementStyle','delete');
    
    if isDaily
        Traw = local_standardize_de_daily_table( ...
            Traw,fname);
        t = datetime(string(Traw.date), ...
            'InputFormat','yyyy-MM-dd');
        if any(isnat(t))
            error('read_meteo_DE:badDate', ...
                ['      Error:read_meteo_DE: ' ...
                'Could not parse daily date column in %s.'],fname);
        end

        fileStartDT = t(1);
        fileEndDT = t(end);

        origin = datetime(1950,10,1);
        fileStartN = int64(days(fileStartDT - origin));
        fileEndN = int64(days(fileEndDT - origin));

        Pcol = local_de_daily_precip_column(Traw,precipChoice);
        Tcol = local_de_daily_temp_column(Traw,tempChoice);

        Qcol = local_find_existing_var( ...
            Traw.Properties.VariableNames, ...
            {'discharge_spec_obs','discharge_spec', ...
             'qobs','q_obs'});

        if isempty(Qcol)
            error('read_meteo_DE:missingDischarge', ...
                ['      Error:read_meteo_DE: ' ...
                'No specific-discharge column found in %s.'],fname);
        end

        P = single(max(double(Traw.(Pcol)(:)),0));
        Tair = single(double(Traw.(Tcol)(:)));
        Q = single(double(Traw.(Qcol)(:)));
        
        [Ep,hasPet] = local_de_pet_daily( ...
            Traw,petChoice,gid,auxNow);
        Ep = single(max(double(Ep(:)),0));
    else
        Traw = local_standardize_de_table(Traw,fname);

        t = datetime(string(Traw.date), ...
            'InputFormat','yyyy-MM-dd HH:mm:ss');

        if any(isnat(t))
            t = datetime(string(Traw.date), ...
                'InputFormat', ...
                'yyyy-MM-dd''T''HH:mm:ss');
        end

        if any(isnat(t))
            error('read_meteo_DE:badDate', ...
                ['      Error:read_meteo_DE: ' ...
                'Could not parse hourly date column in %s.'],fname);
        end

        fileStartDT = t(1);
        fileEndDT = t(end);

        origin = datetime(1950,10,1,0,0,0);
        fileStartN = int64(hours(fileStartDT - origin));
        fileEndN = int64(hours(fileEndDT - origin));

        Pcol = local_de_precip_column(Traw,precipChoice);
        Tcol = local_de_temp_column(Traw,tempChoice);

        Qcol = local_find_existing_var( ...
            Traw.Properties.VariableNames, ...
            {'discharge_spec_obs','discharge_spec', ...
             'qobs','q_obs'});

        if isempty(Qcol)
            error('read_meteo_DE:missingDischarge', ...
                ['      Error:read_meteo_DE: ' ...
                'No specific-discharge column found in %s.'],fname);
        end

        P = single(max(double(Traw.(Pcol)(:)),0));
        Tair = single(double(Traw.(Tcol)(:)));
        Q = single(double(Traw.(Qcol)(:)));

        [Ep,hasPet] = local_de_pet_hourly(Traw,petChoice,gid);
        Ep = single(max(double(Ep(:)),0));
    end

    bad_meteo = int64(find(~isfinite(double(P)) ...
        | ~isfinite(double(Ep)) ...
        | ~isfinite(double(Tair))));

    bad_q = int64(find(~isfinite(double(Q))));

end

function T = local_standardize_de_table(T,fname)

    need = {'date','discharge_spec_obs', ...
        'air_temperature_mean'};
    for i = 1:numel(need)
        if ~ismember(need{i}, ...
                T.Properties.VariableNames)
            error('read_meteo_DE:missingColumn', ...
                ['      Error:read_meteo_DE: ' ...
                'Required column "%s" ' ...
                'not found in %s.'], ...
                need{i},fname);
        end
    end
    
    if ~any(ismember({'precipitation_mean_gapfilled', ...
            'precipitation_mean'}, ...
            T.Properties.VariableNames))
        error('read_meteo_DE:missingPrecipitation', ...
            ['      Error:read_meteo_DE: ' ...
            'No precipitation_mean_gapfilled ' ...
            'or precipitation_mean ' ...
            'column found in %s.'],fname);
    end

end

function col = local_de_precip_column(T, ...
    precipChoice)

    switch precipChoice
        case 1
            prefs = {'precipitation_mean_gapfilled', ...
                'precipitation_mean'};
        case 2
            prefs = {'precipitation_mean', ...
                'precipitation_mean_gapfilled'};
        case 3
            prefs = {'precipitation_min_gapfilled', ...
                'precipitation_min', ...
                'precipitation_mean_gapfilled'};
        case 4
            prefs = {'precipitation_max_gapfilled', ...
                'precipitation_max', ...
                'precipitation_mean_gapfilled'};
        otherwise
            error('read_meteo_DE:badPrecipChoice', ...
                ['      Error:read_meteo_DE: ' ...
                'meteo.precip must be 1, 2, 3, or 4.']);
    end
    
    col = local_find_existing_var(T.Properties.VariableNames,prefs);
    
    if isempty(col)
        error('read_meteo_DE:missingPrecipChoice', ...
            ['      Error:read_meteo_DE: ' ...
            'Requested precipitation ' ...
            'column not found.']);
    end

end

function col = local_de_temp_column(T,tempChoice)

    switch tempChoice
        case 1
            prefs = {'air_temperature_mean'};
        case 2
            prefs = {'air_temperature_min', ...
                'air_temperature_mean'};
        case 3
            prefs = {'air_temperature_max', ...
                'air_temperature_mean'};
        otherwise
            error('read_meteo_DE:badTempChoice', ...
                ['      Error:read_meteo_DE: ' ...
                'meteo.temp must be 1, 2, or 3.']);
    end
    
    col = local_find_existing_var(T.Properties.VariableNames,prefs);
    
    if isempty(col)
        error('read_meteo_DE:missingTempChoice', ...
            ['      Error:read_meteo_DE: ' ...
            'Requested temperature column not found.']);
    end

end

function T = local_standardize_de_daily_table(T,fname)

    need = {'date','discharge_spec_obs', ...
        'precipitation_mean','temperature_mean'};

    for i = 1:numel(need)
        if ~ismember(need{i},T.Properties.VariableNames)
            error('read_meteo_DE:missingColumn', ...
                ['      Error:read_meteo_DE: ' ...
                'Required daily column "%s" not found in %s.'], ...
                need{i},fname);
        end
    end
end

function col = local_de_daily_precip_column(T,precipChoice)

    switch precipChoice
        case 1
            prefs = {'precipitation_mean'};
        case 2
            prefs = {'precipitation_mean'};
        case 3
            prefs = {'precipitation_min','precipitation_mean'};
        case 4
            prefs = {'precipitation_max','precipitation_mean'};
        otherwise
            error('read_meteo_DE:badPrecipChoice', ...
                ['      Error:read_meteo_DE: ' ...
                'meteo.precip must be 1, 2, 3, or 4.']);
    end

    col = local_find_existing_var(T.Properties.VariableNames,prefs);

    if isempty(col)
        error('read_meteo_DE:missingPrecipChoice', ...
            ['      Error:read_meteo_DE: ' ...
            'Requested daily precipitation column not found.']);
    end
end

function col = local_de_daily_temp_column(T,tempChoice)

    switch tempChoice
        case 1
            prefs = {'temperature_mean'};
        case 2
            prefs = {'temperature_min','temperature_mean'};
        case 3
            prefs = {'temperature_max','temperature_mean'};
        otherwise
            error('read_meteo_DE:badTempChoice', ...
                ['      Error:read_meteo_DE: ' ...
                'meteo.temp must be 1, 2, or 3.']);
    end

    col = local_find_existing_var(T.Properties.VariableNames,prefs);

    if isempty(col)
        error('read_meteo_DE:missingTempChoice', ...
            ['      Error:read_meteo_DE: ' ...
            'Requested daily temperature column not found.']);
    end
end

function [Ep,hasPet] = local_de_pet_daily(T,petChoice,gid,auxNow) %#ok<INUSD>
%LOCAL_DE_PET_DAILY Compute daily PET for CAMELS-DE.
%
% meteo.pet:
%   0 = use PET column if present, otherwise zero PET
%   1 = FAO-56 Penman-Monteith daily
%   2 = Priestley-Taylor daily
%   3 = Makkink daily

    vn = T.Properties.VariableNames;

    petcol = local_find_existing_var(vn, ...
        {'pet', ...
         'PET', ...
         'potential_evapotranspiration', ...
         'potential_evaporation', ...
         'evaporation_potential', ...
         'pet_daily', ...
         'pet_mean'});

    if petChoice == 0
        if ~isempty(petcol)
            Ep = double(T.(petcol)(:));
            hasPet = true;
        else
            Ep = zeros(height(T),1);
            hasPet = false;
        end
        return
    end

    if ~ismember(petChoice,[1 2 3])
        error('read_meteo_DE:badPetChoice', ...
            ['      Error:read_meteo_DE: ' ...
            'meteo.pet must be 0, 1, 2, or 3.']);
    end

    Tcol = local_find_existing_var(vn, ...
        {'temperature_mean', ...
         'air_temperature_mean', ...
         'tmean', ...
         'tas_mean'});

    Tmincol = local_find_existing_var(vn, ...
        {'temperature_min', ...
         'air_temperature_min', ...
         'tmin', ...
         'tas_min'});

    Tmaxcol = local_find_existing_var(vn, ...
        {'temperature_max', ...
         'air_temperature_max', ...
         'tmax', ...
         'tas_max'});

    Rscol = local_find_existing_var(vn, ...
        {'global_radiation', ...
         'global_radiation_mean', ...
         'shortwave_radiation', ...
         'shortwave_radiation_mean', ...
         'solar_radiation', ...
         'radiation_global', ...
         'rs'});

    Rncol = local_find_existing_var(vn, ...
        {'net_radiation', ...
         'net_radiation_mean', ...
         'rn'});

    Pcol = local_find_existing_var(vn, ...
        {'air_pressure_surface_mean', ...
         'air_pressure_mean', ...
         'surface_pressure', ...
         'pressure', ...
         'air_pressure_sea_level_mean'});

    RHcol = local_find_existing_var(vn, ...
        {'relative_humidity', ...
         'relative_humidity_mean', ...
         'relativ_humidity_mean', ...
         'humidity_mean', ...
         'rh'});

    Tdcol = local_find_existing_var(vn, ...
        {'dew_point_temperature', ...
         'dew_point_temperature_mean', ...
         'dewpoint_temperature', ...
         'tdew'});

    Qcol = local_find_existing_var(vn, ...
        {'water_vapor_mixing_ratio', ...
         'water_vapor_mixing_ratio_mean', ...
         'specific_humidity', ...
         'specific_humidity_mean'});

    Ucol = local_find_existing_var(vn, ...
        {'wind_speed', ...
         'wind_speed_mean', ...
         'wind_speed_2m', ...
         'windspeed'});

    Ueast = local_find_existing_var(vn, ...
        {'wind_speed_eastward_mean', ...
         'u_wind', ...
         'u10'});

    Unorth = local_find_existing_var(vn, ...
        {'wind_speed_northward_mean', ...
         'v_wind', ...
         'v10'});

    if isempty(Tcol) ...
            || (isempty(Rscol) ...
            && isempty(Rncol))
        if ~isempty(petcol)
            Ep = double(T.(petcol)(:));
            hasPet = true;
        else
            Ep = zeros(height(T),1);
            hasPet = false;
        end
        return
    end

    Tmean = double(T.(Tcol)(:));

    if ~isempty(Tmincol)
        Tmin = double(T.(Tmincol)(:));
    else
        Tmin = Tmean;
    end

    if ~isempty(Tmaxcol)
        Tmax = double(T.(Tmaxcol)(:));
    else
        Tmax = Tmean;
    end

    if ~isempty(Pcol)
        PkPa = local_daily_pressure_to_kPa( ...
            double(T.(Pcol)(:)));
    else
        % If pressure is absent, use sea-level pressure. This is less
        % exact than basin-elevation pressure, but avoids zero PET.
        PkPa = 101.3 .* ones(size(Tmean));
    end

    if ~isempty(Rncol)
        Rn = local_daily_radiation_to_MJ( ...
            double(T.(Rncol)(:)));
        Rs = Rn ./ 0.77;
    else
        Rs = local_daily_radiation_to_MJ( ...
            double(T.(Rscol)(:)));
        %Rn = 0.77 .* Rs;
    end

    ea = local_de_daily_actual_vapor_pressure( ...
        T,Tmean,PkPa,RHcol,Tdcol,Qcol);

    if ~isempty(Ucol)
        u2 = double(T.(Ucol)(:));
    elseif ~isempty(Ueast) && ~isempty(Unorth)
        u2 = hypot(double(T.(Ueast)(:)), ...
                   double(T.(Unorth)(:)));
    else
        % Default wind speed if daily wind is unavailable.
        u2 = 2 .* ones(size(Tmean));
    end

    u2 = max(u2,0);

        % Day of year
        dateCol = local_find_existing_var(vn,{'date'});
        if ~isempty(dateCol)
            tt = datetime(string(T.(dateCol)), ...
                'InputFormat','yyyy-MM-dd');
            DOY = day(tt,'dayofyear');
        else
            DOY = ones(size(Tmean));
        end

        % Latitude/elevation are not available in each daily time-series
        % file, so use conservative defaults here. The radiation method is
        % most accurate if the caller later passes basin-specific lat/elev.
        if nargin >= 4 ...
                && numel(auxNow) >= 2 ...
                && isfinite(auxNow(1))
            lat_deg = auxNow(1) .* ones(size(Tmean));
        else
            lat_deg = 51.0 .* ones(size(Tmean));
        end
        
        if nargin >= 4 ...
                && numel(auxNow) >= 2 ...
                && isfinite(auxNow(2))
            z_m = auxNow(2) .* ones(size(Tmean));
        else
            z_m = zeros(size(Tmean));
        end
        % et0_fao56_daily wants vapor pressure in Pa
        Vp_Pa = ea .* 1000;
        
        % It also expects Rs in W/m2, not MJ/m2/day.
        Rs_Wm2 = Rs ./ 0.0864;
        
        if exist('et0_fao56_daily','file') ~= 2
            if ~isempty(petcol)
                Ep = double(T.(petcol)(:));
                hasPet = true;
            else
                Ep = zeros(height(T),1);
                hasPet = false;
            end
            return
        end

        Ep = et0_fao56_daily( ...
            Tmax,Tmin,Rs_Wm2,Vp_Pa,DOY, ...
            lat_deg,z_m,u2,petChoice);

    Ep = max(double(Ep(:)),0);
    hasPet = any(isfinite(Ep) & Ep > 0);

    if ~hasPet
        if ~isempty(petcol)
            Ep = double(T.(petcol)(:));
            hasPet = true;
        else
            Ep = zeros(height(T),1);
            hasPet = false;
        end
    end
end

function PkPa = local_daily_pressure_to_kPa(p)
%LOCAL_DAILY_PRESSURE_TO_KPA for CAMELS-DE

    p = double(p(:));
    medp = median(p(isfinite(p)));

    if isempty(medp) || ~isfinite(medp)
        PkPa = 101.3 .* ones(size(p));
    elseif medp > 20000
        PkPa = p ./ 1000;       % Pa -> kPa
    elseif medp > 200
        PkPa = p ./ 10;         % hPa -> kPa
    else
        PkPa = p;               % already kPa
    end

end

function R = local_daily_radiation_to_MJ(R)
%LOCAL_DAILY_RADIATION_TO_MJ for CAMELS-DE

    R = double(R(:));
    medR = median(R(isfinite(R) & R > 0));

    if isempty(medR) || ~isfinite(medR)
        return
    end

    if medR > 1e5
        R = R .* 1e-6;          % J m-2 day-1 -> MJ m-2 day-1
    elseif medR > 80
        R = R .* 0.0864;        % W m-2 -> MJ m-2 day-1
    else
        % already MJ m-2 day-1
    end

end

function ea = local_de_daily_actual_vapor_pressure( ...
    T,Tmean,PkPa,RHcol,Tdcol,Qcol)
%LOCAL_DE_DAILY_ACTUAL_VAPOR_PRESSURE for CAMELS-DE

    if ~isempty(Tdcol)
        Td = double(T.(Tdcol)(:));
        ea = 0.6108 .* exp((17.27 .* Td) ./ (Td + 237.3));
        return
    end

    if ~isempty(RHcol)
        RH = double(T.(RHcol)(:));
        RH = min(max(RH,0),100);
        es = 0.6108 .* exp((17.27 .* Tmean) ./ ...
            (Tmean + 237.3));
        ea = RH ./ 100 .* es;
        return
    end

    if ~isempty(Qcol)
        qraw = double(T.(Qcol)(:));
        mq = median(qraw(isfinite(qraw)));

        if isfinite(mq) && mq > 0.1
            r = qraw ./ 1000;       % g/kg -> kg/kg dry air
            q = r ./ (1 + r);
        else
            q = qraw;               % already kg/kg
        end

        ea_Pa = q .* (PkPa .* 1000) ./ ...
            (0.622 + 0.378 .* q);
        ea = ea_Pa ./ 1000;
        return
    end

    es = 0.6108 .* exp((17.27 .* Tmean) ./ ...
        (Tmean + 237.3));
    ea = 0.5 .* es;

end

function [Ep,hasPet] = local_de_pet_hourly(T,petChoice,gid) %#ok<INUSD>
%LOCAL_DE_PET_HOURLY Compute hourly PET for CAMELS-DE.
%
% meteo.pet:
%   0 = use PET column if present, otherwise zero PET
%   1 = FAO-56 Penman-Monteith daily
%   2 = Priestley-Taylor daily
%   3 = Makkink daily

    vn = T.Properties.VariableNames;
    
    % Future-proof: use a PET/ET column if a later CAMELS-DE release or a
    % local preprocessing step adds it.
    petcol = local_find_existing_var(vn, ...
        {'pet', ...
        'PET', ...
        'potential_evapotranspiration', ...
        'potential_evaporation', ...
        'evaporation_potential', ...
        'pet_hourly', ...
        'pet_mean'});
    
    if petChoice == 0
        if ~isempty(petcol)
            Ep = double(T.(petcol)(:));
            hasPet = true;
        else
            Ep = zeros(height(T),1);
            hasPet = false;
        end
        return
    end
    
    if ~ismember(petChoice,[1 2 3])
        error('read_meteo_DE:badPetChoice', ...
            ['      Error:read_meteo_DE: ' ...
            'meteo.pet must be 0, 1, 2, or 3.']);
    end
    
    % CAMELS-DE provides all meteorological inputs used by the US hourly PET
    % routine except downwelling longwave radiation. We estimate downwelling
    % longwave radiation locally from air temperature, vapor pressure, and cloud
    % cover, and then call et0_fao56_hourly:
    %   method 1 = Penman-Monteith
    %   method 2 = Priestley-Taylor
    %   method 3 = Makkink
    
    Tcol = local_find_existing_var(vn, ...
        {'air_temperature_mean'});
    Rscol = local_find_existing_var(vn, ...
        {'global_radiation_mean'});
    Pcol = local_find_existing_var(vn, ...
        {'air_pressure_surface_mean', ...
         'air_pressure_sea_level_mean'});
    Qcol = local_find_existing_var(vn, ...
        {'water_vapor_mixing_ratio_mean'});
    RHcol = local_find_existing_var(vn, ...
        {'relative_humidity_mean', ...
         'relativ_humidity_mean'});
    Tdcol = local_find_existing_var(vn, ...
        {'dew_point_temperature_mean'});
    Ccol = local_find_existing_var(vn, ...
        {'cloud_cover_mean'});
    Ucol = local_find_existing_var(vn, ...
        {'wind_speed_eastward_mean'});
    Vcol = local_find_existing_var(vn, ...
        {'wind_speed_northward_mean'});
    Wcol = local_find_existing_var(vn, ...
        {'wind_speed_mean'});
    
    haveCore = ~isempty(Tcol) ...
        && ~isempty(Rscol) ...
        && ~isempty(Pcol) ...
        && (~isempty(Qcol) ...
        || ~isempty(RHcol) ...
        || ~isempty(Tdcol)) ...
        && ((~isempty(Ucol) ...
        && ~isempty(Vcol)) ...
        || ~isempty(Wcol));
    
    if ~haveCore || exist('et0_fao56_hourly','file') ~= 2
        if ~isempty(petcol)
            Ep = double(T.(petcol)(:));
            hasPet = true;
        else
            Ep = zeros(height(T),1);
            hasPet = false;
        end
        return
    end
    
    Tair = double(T.(Tcol)(:));          % deg C
    Rs = double(T.(Rscol)(:));           % W m-2, global shortwave radiation
    p = double(T.(Pcol)(:)) .* 100;      % hPa -> Pa
    
    % Specific humidity q [kg kg-1]. CAMELS-DE gives water vapor mixing ratio
    % in g kg-1. Convert mixing ratio r to specific humidity q = r/(1+r).
    if ~isempty(Qcol)
        r = double(T.(Qcol)(:)) ./ 1000; % kg kg-1 dry air
        q = r ./ (1 + r);
    else
        ea_kPa = local_de_actual_vapor_pressure(T,Tair,RHcol,Tdcol);
        ea_Pa = ea_kPa .* 1000;
        q = 0.622 .* ea_Pa ./ (p - 0.378 .* ea_Pa);
    end
    
    if ~isempty(Ucol) && ~isempty(Vcol)
        u10 = double(T.(Ucol)(:));
        v10 = double(T.(Vcol)(:));
    else
        u10 = double(T.(Wcol)(:));
        v10 = zeros(size(u10));
    end
    
    Rld = local_de_longwave_down(T,Tair,p,q,Ccol,RHcol,Tdcol);
    
    Ep = et0_fao56_hourly(Rld,p,Rs,q,Tair,u10,v10,petChoice);
    Ep = max(double(Ep(:)),0);
    hasPet = true;

end

function ea_kPa = local_de_actual_vapor_pressure(T,Tair,RHcol,Tdcol)

    if ~isempty(Tdcol)
        Td = double(T.(Tdcol)(:));
        ea_kPa = 0.6108 .* exp((17.27 .* Td) ./ (Td + 237.3));
        return
    end
    
    if ~isempty(RHcol)
        RH = double(T.(RHcol)(:));
        es_kPa = 0.6108 .* exp((17.27 .* Tair) ./ (Tair + 237.3));
        ea_kPa = max(RH,0) ./ 100 .* es_kPa;
        return
    end
    
    % Last-resort fallback from pressure only is intentionally conservative.
    ea_kPa = nan(size(Tair));
    ea_kPa(:) = 0.5 .* 0.6108 .* exp((17.27 .* Tair) ./ (Tair + 237.3));

end

function Rld = local_de_longwave_down(T,Tair,p,q,Ccol,RHcol,Tdcol)

    sigma = 5.670374419e-8;
    Tk = Tair + 273.15;
    
    % Actual vapor pressure [kPa]. Prefer dew point / RH if present; otherwise
    % derive it from specific humidity and pressure.
    ea_kPa = local_de_actual_vapor_pressure(T,Tair,RHcol,Tdcol);
    
    badEa = ~isfinite(ea_kPa);
    if any(badEa)
        ea_Pa = (q .* p) ./ (0.622 + 0.378 .* q);
        ea_kPa2 = ea_Pa ./ 1000;
        ea_kPa(badEa) = ea_kPa2(badEa);
    end
    
    % Brutsaert-style clear-sky emissivity with a simple cloud correction.
    % ea/Tk is in kPa/K. Clamp to physically plausible values for robustness.
    eps_clear = 1.24 .* max(ea_kPa ./ Tk,0).^(1/7);
    eps_clear = min(max(eps_clear,0.55),1.00);
    
    if ~isempty(Ccol)
        cloud = double(T.(Ccol)(:));
        cloud = min(max(cloud ./ 100,0),1);
    else
        cloud = zeros(size(Tair));
    end
    
    eps_sky = eps_clear .* (1 + 0.22 .* cloud.^2);
    eps_sky = min(max(eps_sky,0.55),1.00);
    
    Rld = eps_sky .* sigma .* Tk.^4;  % W m-2

end


function req = local_requested_window(split, ...
    fileStartN,fileEndN,nFile,isDaily)

    if nargin < 5
        isDaily = false;
    end
    % Preferred SAGE split fields: read full spin-up + score window.
    if isfield(split,'dt0') ...
            && ~isempty(split.dt0) ...
            && isfield(split,'tout') ...
            && ~isempty(split.tout)
    
        if isDaily
            toN = @(t) int64(days(t - datetime(1950,10,1)));
        else
            toN = @(t) int64(hours(t - datetime(1950,10,1,0,0,0)));
        end
        req.read_start_N = toN(split.dt0);
    
        % split.tout is state time: 0:26280 has 26281 states,
        % but forcing/discharge has 26280 intervals.
        nInt = numel(split.tout) - 1;
        req.read_end_N = req.read_start_N + int64(nInt) - 1;
    
        return
    end
    
    % Preferred explicit integer-hour fields.
    startFields = {'read_start_N','read_start_n', ...
        'start_N','start_n','file_start_N'};
    endFields = {'read_end_N','read_end_n', ...
        'end_N','end_n','file_end_N'};
    
    sN = local_first_numeric_field(split,startFields);
    eN = local_first_numeric_field(split,endFields);
    
    if isfinite(sN) ...
            && isfinite(eN)
        req.read_start_N = int64(round(sN));
        req.read_end_N = int64(round(eN));
        return
    end
    
    % Explicit datetime/date fields.
    sDT = local_first_datetime_field(split, ...
        {'read_start','start_time','t_start', ...
        'date_start','start_date','date0','t0'});
    eDT = local_first_datetime_field(split, ...
        {'read_end','end_time','t_end', ...
        'date_end','end_date','date1','t1'});
    
    if ~isnat(sDT) ...
            && ~isnat(eDT)
        if isDaily
            toN = @(t) int64(days(t - datetime(1950,10,1)));
        else
            toN = @(t) int64(hours(t - datetime(1950,10,1,0,0,0)));
        end
        req.read_start_N = toN(sDT);
        req.read_end_N = toN(eDT);
        return
    end
    
    % If the project-level build_requested_window helper exists and returns
    % useful fields, use it as a last attempt. It is primarily daily in some
    % SAGE readers, so only accept it if its window intersects the hourly file.
    if exist('build_requested_window','file') == 2
        try
            R = build_requested_window(split,false);
            if isfield(R,'read_start_N') ...
                    && isfield(R,'read_end_N')
                r0 = int64(round(double(R.read_start_N)));
                r1 = int64(round(double(R.read_end_N)));
                if r0 >= fileStartN && r1 <= fileEndN
                    req.read_start_N = r0;
                    req.read_end_N = r1;
                    return
                end
            end
        catch
        end
    end
    
    % Fallback: read the full file. This is safe for standalone testing and
    % for workflows where split.idx already indexes the full available record.
    req.read_start_N = fileStartN;
    req.read_end_N = fileEndN;
    
    % If split.idx is finite and shorter than the file, no action is required:
    % the caller will score only split.idx. If split.idx is Inf placeholder,
    % replace it with full file length in the caller's workspace is impossible,
    % so handle here by warning through field size only.
    if isscalar(split.idx) ...
            && isinf(split.idx)
        split.idx = 1:nFile;
    end

end

function x = local_first_numeric_field(S,names)

    x = NaN;
    for i = 1:numel(names)
        if isfield(S,names{i}) ...
                && ~isempty(S.(names{i}))
            v = S.(names{i});
            if isnumeric(v) ...
                    || islogical(v)
                x = double(v(1));
                return
            end
            vv = str2double(string(v(1)));
            if isfinite(vv)
                x = vv;
                return
            end
        end
    end

end

function t = local_first_datetime_field(S,names)

    t = NaT;
    for i = 1:numel(names)
        if isfield(S,names{i}) ...
                && ~isempty(S.(names{i}))
            v = S.(names{i});
            if isdatetime(v)
                t = v(1);
                return
            end
    
            s = string(v(1));
            try
                t0 = datetime(s);
                if ~isnat(t0)
                    t = t0;
                    return
                end
            catch
            end
            try
                t0 = datetime(s,'InputFormat', ...
                    'yyyy-MM-dd HH:mm:ss');
                if ~isnat(t0)
                    t = t0;
                    return
                end
            catch
            end
            try
                t0 = datetime(s,'InputFormat', ...
                    'yyyy-MM-dd');
                if ~isnat(t0)
                    t = t0;
                    return
                end
            catch
            end
        end
    end

end

function aux = local_de_aux(Ttopo,gid)

    aux = [NaN NaN NaN];
    
    if isempty(Ttopo) ...
            || height(Ttopo) == 0
        return
    end
    
    Ttopo.Properties.VariableNames = ...
        matlab.lang.makeValidName( ...
        Ttopo.Properties.VariableNames, ...
        'ReplacementStyle','delete');
    
    vn = Ttopo.Properties.VariableNames;
    idcol = local_find_var(vn, ...
        {'gauge_id','gaugeid','id'});
    latcol = local_find_var(vn, ...
        {'gauge_lat','lat','latitude'});
    elevcol = local_find_var(vn, ...
        {'elev_mean','elevation', ...
        'elev','gauge_elev'});
    areacol = local_find_var(vn, ...
        {'area','area_km2', ...
        'catchment_area'});
    
    if isempty(idcol)
        return
    end
    
    ids = normalize_de_gauge_id(Ttopo{:,idcol});
    jj = find(ids == normalize_de_gauge_id(gid),1,'first');
    
    if isempty(jj)
        return
    end
    
    if ~isempty(latcol)
        aux(1) = double(Ttopo{jj,latcol});
    end
    if ~isempty(elevcol)
        aux(2) = double(Ttopo{jj,elevcol});
    end
    if ~isempty(areacol)
        a = double(Ttopo{jj,areacol});
        % CAMELS-DE topographic area is km^2. Convert to m^2 if needed.
        if isfinite(a) && a < 1e7
            a = 1e6 * a;
        end
        aux(3) = a;
    end

end

function idx = local_find_var(vn,cands)

    normf = @(s) lower(regexprep(char(s), ...
        '[^a-z0-9]',''));
    vnn = cellfun(normf,vn, ...
        'UniformOutput',false);
    
    idx = [];
    for k = 1:numel(cands)
        hit = find(strcmp(vnn, ...
            normf(cands{k})),1,'first');
        if ~isempty(hit)
            idx = hit;
            return
        end
    end

end

function col = local_find_existing_var(vn,cands)

    col = '';
    idx = local_find_var(vn,cands);
    if ~isempty(idx)
        col = vn{idx};
    end

end

function id = normalize_de_gauge_id(x)

    if isnumeric(x) ...
            || islogical(x)
        id = string(compose('%.0f', ...
            double(x(:))));
    else
        id = string(x(:));
        id = strip(id);
        id = erase(id,'"');
        id(ismissing(id)) = "";
        id = regexprep(id,'\.0+$','');
    end

end
