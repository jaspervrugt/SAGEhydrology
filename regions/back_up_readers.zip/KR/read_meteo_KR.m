function [dat,aux] = read_meteo_KR(dirM,bas,split,meteo)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%READ_METEO_KR Read hourly CAMELSH-KR forcing and observed discharge.
%
% Each <STAID>.csv file contains forcing and discharge together.
% Choices: meteo.precip = 1 ERA5-Land, 2 observed precipitation;
%          meteo.temp   = 1 ERA5-Land, 2 observed air temperature.
%
% Common SAGE fields and units:
%   dat{k}.meteo.P          precipitation                 [mm h-1]
%   dat{k}.meteo.Ep         potential evapotranspiration  [mm h-1]
%   dat{k}.meteo.T          air temperature               [deg C]
%   dat{k}.meteo.snow_cover ERA5-Land snow cover          [%]
%   dat{k}.meteo.snow_depth ERA5-Land snow depth          [source units]
%   dat{k}.y_n              runoff depth                  [mm h-1]
%
% The source potential_evaporation follows the ERA5 signed evaporation
% convention, so Ep = max(0,-potential_evaporation). Source streamflow is
% treated as m3 s-1 and converted to basin-average mm h-1 using Area.
% Snow cover/depth are retained in their distributed source scaling.
% The file calls the latter snow_depth, not snow-depth water equivalent;
% it is therefore deliberately not relabeled as SWE.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    if nargin < 4 || isempty(meteo), meteo = struct(); end
    if nargin < 3 || isempty(split)
        error('read_meteo_KR:missingSplit','split must be provided.');
    end
    if nargin < 2 || ~isstruct(bas) ...
            || ~isfield(bas,'id_gauge') || isempty(bas.id_gauge)
        error('read_meteo_KR:missingBasins', ...
            'bas.id_gauge must be provided.');
    end
    if nargin < 1 || isempty(dirM)
        error('read_meteo_KR:missingDir','dirM must be provided.');
    end

    split = prepare_split(split);
    if double(split.dt) ~= 24
        error('read_meteo_KR:hourlyOnly', ...
            'CAMELSH-KR supports hourly data only; split.dt must be 24.');
    end
    dirM = local_timeseries_dir(dirM);
    if ~isfolder(dirM)
        error('read_meteo_KR:missingDir', ...
            'CAMELSH-KR timeseries directory does not exist: %s',dirM);
    end

    pChoice = local_choice(meteo,'precip',1,1:2);
    tChoice = local_choice(meteo,'temp',1,1:2);
    ids = local_id(bas.id_gauge(:));
    K = numel(ids);
    [aux,areaM2] = local_aux(dirM,ids);
    req = build_requested_window(split,true);
    tref = datetime(1950,10,1,0,0,0);
    tReq = (tref + hours(double(req.read_start_N:req.read_end_N))).';
    nReq = numel(tReq);
    idxScore = double(split.idx(:));
    idxScore = round(idxScore(isfinite(idxScore) ...
        & idxScore >= 1 & idxScore <= nReq));

    dat = cell(K,1);
    cacheDir = fullfile(dirM, ...
        sprintf('_cache_KR_hourly_p%d_t%d',pChoice,tChoice));
    if ~isfolder(cacheDir), mkdir(cacheDir); end
    prt = reader_progress('start', ...
        '... Reading hourly CAMELSH-KR meteorological data',K);

    for k = 1:K
        gid = ids(k);
        fname = fullfile(dirM,[char(gid) '.csv']);
        if ~isfile(fname)
            error('read_meteo_KR:missingFile', ...
                'Missing CAMELSH-KR file: %s',fname);
        end
        key0 = char(string(tReq(1),'yyyyMMddHH'));
        key1 = char(string(tReq(end),'yyyyMMddHH'));
        cacheFile = fullfile(cacheDir,sprintf('%s_%s_%s.mat', ...
            char(gid),key0,key1));
        useCache = false;
        if isfile(cacheFile)
            try
                S = load(cacheFile,'P','Ep','Tair','snowCover', ...
                    'snowDepth','Qmm','badM','badQ','src_datenum');
                info = dir(fname);
                useCache = S.src_datenum >= info.datenum;
            catch
                useCache = false;
            end
        end
        if useCache
            P=S.P; Ep=S.Ep; Tair=S.Tair; snowCover=S.snowCover;
            snowDepth=S.snowDepth; Qmm=S.Qmm; badM=S.badM; badQ=S.badQ;
        else
            X = local_read_file(fname,pChoice,tChoice);
            P = nan(nReq,1); Ep=P; Tair=P; snowCover=P; snowDepth=P; Qmm=P;
            [tf,loc] = ismember(tReq,X.time);
            P(tf)=X.P(loc(tf)); Ep(tf)=X.Ep(loc(tf));
            Tair(tf)=X.T(loc(tf)); snowCover(tf)=X.snow_cover(loc(tf));
            snowDepth(tf)=X.snow_depth(loc(tf));
            if isfinite(areaM2(k)) && areaM2(k)>0
                Qmm(tf)=X.Q(loc(tf))*3600*1000/areaM2(k);
            end
            badM = ~isfinite(P)|P<0|~isfinite(Ep)|Ep<0|~isfinite(Tair);
            badQ = ~isfinite(Qmm)|Qmm<0;
            try
                info=dir(fname); src_datenum=info.datenum; %#ok<NASGU>
                save(cacheFile,'P','Ep','Tair','snowCover','snowDepth', ...
                    'Qmm','badM','badQ','src_datenum','-v7.3');
            catch
            end
        end

        dat{k}.meteo.P = single(P);
        dat{k}.meteo.Ep = single(Ep);
        dat{k}.meteo.T = single(Tair);
        dat{k}.meteo.snow_cover = single(snowCover);
        dat{k}.meteo.snow_depth = single(snowDepth);
        dat{k}.meteo.bad = find(badM).';
        dat{k}.y_n = single(Qmm(idxScore));
        dat{k}.bad = badQ(idxScore).';
        dat{k}.gauge = gid;
        dat{k}.fname = {fname,fname};

        prt = reader_progress('update',prt,k);
        if isfield(meteo,'progressFcn') && ~isempty(meteo.progressFcn)
            try, meteo.progressFcn(k); catch, end
        end
    end
    reader_progress('finish',prt,K);

    if isfield(split,'local') && split.local ...
            && isfield(split,'rainfall_block') && split.rainfall_block
        dat = rainfall_rank_split(dat,split);
    end
end

function X = local_read_file(fname,pChoice,tChoice)
    need = {'DateTime','total_precipitation','temperature_2m', ...
        'snow_cover','snow_depth','potential_evaporation', ...
        'precip_obs','air_temp_obs','streamflow'};
    o = detectImportOptions(fname,'VariableNamingRule','preserve');
    miss = setdiff(need,o.VariableNames);
    if ~isempty(miss)
        error('read_meteo_KR:missingColumns', ...
            'Missing columns in %s: %s',fname,strjoin(miss,', '));
    end
    o.SelectedVariableNames = need;
    T = readtable(fname,o);
    time = datetime(string(T.DateTime), ...
        'InputFormat','dd-MMM-yyyy HH:mm:ss','Locale','en_US');
    if any(isnat(time)) || any(diff(time)~=hours(1))
        error('read_meteo_KR:badTime', ...
            'Timestamps are invalid or nonconsecutive in %s.',fname);
    end
    if pChoice == 1
        P = double(T.total_precipitation);
    else
        P = double(T.precip_obs);
    end
    if tChoice == 1
        Ta = double(T.temperature_2m);
    else
        Ta = double(T.air_temp_obs);
    end
    X.time=time(:); X.P=max(0,P(:));
    X.Ep=max(0,-double(T.potential_evaporation(:)));
    X.T=Ta(:); X.snow_cover=double(T.snow_cover(:));
    X.snow_depth=double(T.snow_depth(:)); X.Q=double(T.streamflow(:));
end

function [aux,areaM2] = local_aux(dirM,ids)
    root = fileparts(fileparts(dirM));
    G = readtable(fullfile(root,'attributes_general.csv'), ...
        'VariableNamingRule','preserve');
    H = readtable(fullfile(root,'attributes_HydroATLAS.csv'), ...
        'VariableNamingRule','preserve');
    gid=local_id(G.STAID); hid=local_id(H.STAID);
    K=numel(ids); aux=nan(K,3); areaM2=nan(K,1);
    for k=1:K
        j=find(gid==ids(k),1); h=find(hid==ids(k),1);
        if ~isempty(j)
            aux(k,1)=double(G.Lat_gage(j));
            areaM2(k)=double(G.Area(j))*1e6; aux(k,3)=areaM2(k);
        end
        if ~isempty(h) && ismember('ele_mt_sav',H.Properties.VariableNames)
            aux(k,2)=double(H.ele_mt_sav(h));
        end
    end
end

function d = local_timeseries_dir(d)
    d=char(string(d)); [~,n]=fileparts(d);
    if strcmpi(n,'timeseries')
        return
    end
    if strcmpi(n,'hourly')
        d = fullfile(d,'timeseries');
    else
        d = fullfile(d,'hourly','timeseries');
    end
end

function id = local_id(x)
    id=strip(string(x)); id=regexprep(id,'\.0+$','');
end

function v = local_choice(S,f,d,allowed)
    v=d; if isfield(S,f)&&~isempty(S.(f)), v=double(S.(f)); end
    if ~ismember(v,allowed), v=d; end
end
