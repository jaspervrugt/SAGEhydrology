function [A,id_gauge,gname,zone] = read_attr_KR(dirD,bas)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%READ_ATTR_KR Read and merge CAMELSH-KR catchment attributes.
%
% The five Zenodo attribute tables are joined by STAID. The complete
% HydroATLAS inventory is exposed to SAGE; attr_catalog('CAMELSH_KR')
% controls defaults and disables discharge/runoff target-leakage fields.
% Negative evaporation/aridity sign conventions in the source files are
% converted to positive magnitudes.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    if nargin < 1 ...
            || isempty(dirD) ...
            || ~isfolder(dirD)
        error('read_attr_KR:missingDir', ...
            ['CAMELSH-KR attribute directory ' ...
            'does not exist: %s'],dirD);
    end
    if nargin < 2 ...
            || isempty(bas)
        bas = struct();
    end

    min_per_zone = local_field_or(bas,'min_per_zone',5);
    max_zones = local_field_or(bas,'max_zones',8);
    pr_table = local_field_or(bas,'pr_attr',1);

    fprintf('... Reading CAMELSH-KR basin attributes ');
    G = local_read(fullfile(dirD, ...
        'attributes_general.csv'));
    O = local_read(fullfile(dirD, ...
        'attributes_climate_obs.csv'));
    E = local_read(fullfile(dirD, ...
        'attributes_climate_ERA5Land.csv'));
    D = local_read(fullfile(dirD, ...
        'attributes_dam.csv'));
    H = local_read(fullfile(dirD, ...
        'attributes_HydroATLAS.csv'));

    G.STAID = local_id(G.STAID);
    O.STAID = local_id(O.STAID);
    E.STAID = local_id(E.STAID);
    D.STAID = local_id(D.STAID);
    H.STAID = local_id(H.STAID);

    AA = table(G.STAID,double(G.Lat_gage),double(G.Lon_gage), ...
        double(G.Area),double(G.Area_HydroATLAS), ...
        'VariableNames',{'station_id','gauge_lat', ...
        'gauge_lon','area','area_hydroatlas'});

    AA = local_add(AA,O,{'p_mean','aridity_index', ...
        'p_seasonality','frac_snow','high_prec_freq', ...
        'high_prec_dur','low_prec_freq','low_prec_dur'}, ...
        {'p_mean','aridity','p_seasonality','frac_snow', ...
        'high_prec_freq','high_prec_dur','low_prec_freq', ...
        'low_prec_dur'},{'aridity'});
    AA = local_add(AA,E,{'p_mean','pet_mean','aridity_index', ...
        'p_seasonality','frac_snow','high_prec_freq', ...
        'high_prec_dur','low_prec_freq','low_prec_dur'}, ...
        {'era5_p_mean','era5_pet_mean','era5_aridity', ...
        'era5_p_seasonality','era5_frac_snow', ...
        'era5_high_prec_freq','era5_high_prec_dur', ...
        'era5_low_prec_freq','era5_low_prec_dur'}, ...
        {'era5_pet_mean','era5_aridity'});
    AA = local_add_hydroatlas(AA,H);
    AA = local_add(AA,D,{'vol_tot','vol_eff','vol_low', ...
        'vol_flood','WL_flood','WL_normal','WL_low'}, ...
        {'dam_vol_tot','dam_vol_eff','dam_vol_low', ...
        'dam_vol_flood','dam_wl_flood','dam_wl_normal', ...
        'dam_wl_low'},{});

    id_all = AA.station_id;
    [~,ix] = sort(str2double(id_all));
    AA = AA(ix,:);
    id_all = id_all(ix);

    % Official WAMIS station names for all 178 CAMELSH-KR gauges.
    % Write the complete regional inventory before applying an optional
    % basin subset, just as the other regional readers do.
    [gname_all,gname_kr_all] = local_kr_gauge_names(id_all);
    gname_all = standardize_camels_gauge_names( ...
        gname_all,'CAMELSH_KR',id_all);
    local_ensure_kr_gauge_information( ...
        dirD,AA,id_all,gname_all,gname_kr_all);

    if isfield(bas,'id_gauge') ...
            && ~isempty(bas.id_gauge)
        id_req = local_id(bas.id_gauge(:));
        [tf,loc] = ismember(id_req,id_all);
        if ~all(tf)
            error('read_attr_KR:missingGauge', ...
                ['Missing CAMELSH-KR attributes ' ...
                'for gauge %s.'],id_req(find(~tf,1)));
        end
        AA = AA(loc,:);
        id_gauge = id_req;
        gname = gname_all(loc);
    else
        id_gauge = id_all;
        gname = gname_all;
    end

    zone = classify_camels_all_zones('KR',AA, ...
        min_per_zone,max_zones);
    [A,labels] = build_attr_matrix(AA, ...
        bas,mfilename,pr_table);
    if pr_table == 1
        assignin('base','SAGE_KR_attribute_labels',labels);
    end
    fprintf(' ... Done\n');
end

function AA = local_add_hydroatlas(AA,H)
% Add the complete 195-variable HydroATLAS inventory in source order.
    [tf,loc] = ismember(AA.station_id,H.STAID);
    if ~all(tf)
        error('read_attr_KR:incompleteHydroATLAS', ...
            'HydroATLAS is missing %d CAMELSH-KR basins.',sum(~tf));
    end
    names = H.Properties.VariableNames;
    names(strcmp(names,'STAID')) = [];
    for j = 1:numel(names)
        AA.(names{j}) = double(H.(names{j})(loc));
    end
end

function T = local_read(fname)
    if ~isfile(fname)
        error('read_attr_KR:missingFile', ...
            'Missing CAMELSH-KR file: %s',fname);
    end
    o = detectImportOptions(fname, ...
        'VariableNamingRule','preserve');
    T = readtable(fname,o);
end

function AA = local_add(AA,T,oldNames, ...
    newNames,makePositive)
    [tf,loc] = ismember(AA.station_id,T.STAID);
    if ~all(tf)
        error('read_attr_KR:incompleteJoin', ...
            ['An attribute table is missing ' ...
            '%d CAMELSH-KR basins.'],sum(~tf));
    end
    for j = 1:numel(oldNames)
        if ~ismember(oldNames{j}, ...
                T.Properties.VariableNames)
            error('read_attr_KR:missingVariable', ...
                ['Missing CAMELSH-KR attribute ' ...
                'variable: %s'],oldNames{j});
        end
        x = double(T.(oldNames{j})(loc));
        if ismember(newNames{j},makePositive)
            x = abs(x);
        end
        AA.(newNames{j}) = x;
    end
end

function [gname,gname_kr] = local_kr_gauge_names(id)
% Official WAMIS gauge names matched to CAMELSH-KR STAID.
% English display labels are compact Romanized forms for SAGE GUI;
% gname_kr preserves the official Korean WAMIS station name.

    key = [ ...
        "1001620";
        "1001625";
        "1001630";
        "1001655";
        "1001660";
        "1001670";
        "1002605";
        "1002610";
        "1002615";
        "1002625";
        "1002635";
        "1002640";
        "1002650";
        "1002675";
        "1002685";
        "1002687";
        "1002698";
        "1003620";
        "1005640";
        "1005695";
        "1005697";
        "1006650";
        "1006660";
        "1006665";
        "1006672";
        "1006680";
        "1006690";
        "1007605";
        "1007615";
        "1007617";
        "1007625";
        "1007635";
        "1007640";
        "1007645";
        "1007650";
        "1007655";
        "1007680";
        "1007685";
        "1012630";
        "1013645";
        "1013655";
        "1014620";
        "1014630";
        "1014640";
        "1014650";
        "1014680";
        "1015644";
        "1015645";
        "1016650";
        "1016660";
        "1018610";
        "1018620";
        "1018623";
        "1018625";
        "1018630";
        "1018635";
        "1018640";
        "1018650";
        "1018655";
        "1018662";
        "1018665";
        "1018670";
        "1018675";
        "1018680";
        "1018683";
        "1018690";
        "1018693";
        "1018695";
        "1018697";
        "1019630";
        "1021650";
        "1021680";
        "1022630";
        "1022640";
        "1022648";
        "1022650";
        "1022655";
        "1022670";
        "1022680";
        "1023660";
        "1023670";
        "2001630";
        "2001658";
        "2002655";
        "2002685";
        "2002692";
        "2003610";
        "2003640";
        "2003670";
        "2003690";
        "2004605";
        "2004625";
        "2004635";
        "2004640";
        "2004650";
        "2004655";
        "2004668";
        "2004675";
        "2004680";
        "2004695";
        "2005660";
        "2005680";
        "2006625";
        "2006630";
        "2006665";
        "2007620";
        "2007640";
        "2007660";
        "2008630";
        "2008635";
        "2008645";
        "2008650";
        "2008690";
        "2009620";
        "2009670";
        "2010650";
        "2010690";
        "2011640";
        "2011650";
        "2011660";
        "2012625";
        "2012628";
        "2012640";
        "2012645";
        "2012648";
        "2012650";
        "2012652";
        "2012653";
        "2012660";
        "2012665";
        "2012670";
        "2012690";
        "2012695";
        "2012696";
        "2013615";
        "2013650";
        "2013685";
        "2013690";
        "2014620";
        "2014640";
        "2014660";
        "2014680";
        "2014690";
        "2015635";
        "2016650";
        "2016680";
        "2017620";
        "2017685";
        "2018620";
        "2018630";
        "2018635";
        "2018645";
        "2018655";
        "2018665";
        "2018674";
        "2018680";
        "2018685";
        "2019610";
        "2019615";
        "2019635";
        "2019655";
        "2019695";
        "2020603";
        "2020615";
        "2020650";
        "2020675";
        "2021640";
        "2021665";
        "2021675";
        "2021677";
        "2021685";
        "2021690";
        "2022610";
        "2022640";
        "2022655";
        "2022660";
        "2022670";
        "2022680"];
    native = [ ...
        "정선군(송계교)";
        "정선군(송천교)";
        "정선군(나전교)";
        "정선군(정선제1교)";
        "정선군(낙동교)";
        "영월군(거운교)";
        "평창군(이목정교)";
        "평창군(장평교)";
        "평창군(진전교)";
        "평창군(선애교)";
        "평창군(사초교)";
        "평창군(상방림교)";
        "평창군(평창교)";
        "횡성군(안흥교)";
        "영월군(주천교)";
        "영월군(신천교)";
        "영월군(팔괴교)";
        "영월군(옥동교)";
        "충주시(목계교)";
        "원주시(법천교)";
        "원주시(남한강대교)";
        "횡성군(횡성교)";
        "횡성군(전천교)";
        "원주시(원주교)";
        "원주시(장현교)";
        "원주시(지정대교)";
        "원주시(문막교)";
        "이천시(장호원교)";
        "여주시(원부교)";
        "여주시(삼합교)";
        "여주시(남한강교)";
        "여주시(여주대교)";
        "여주시(율극교)";
        "이천시(복하교)";
        "여주시(흥천대교)";
        "여주시(양촌교)";
        "양평군(흑천교)";
        "양평군(양평교)";
        "인제군(왕성동교)";
        "춘천시(강촌교)";
        "가평군(가평교)";
        "홍천군(용선교)";
        "홍천군(주음치교)";
        "홍천군(굴운교)";
        "홍천군(홍천교)";
        "홍천군(반곡교)";
        "가평군(청평교)";
        "가평군(신청평대교)";
        "광주시(경안교)";
        "광주시(섬뜰교)";
        "남양주시(팔당대교)";
        "남양주시(부평교)";
        "남양주시(연평대교)";
        "남양주시(내곡교)";
        "남양주시(진관교)";
        "남양주시(퇴계원리)";
        "서울시(광진교)";
        "성남시(궁내교)";
        "서울시(대곡교)";
        "서울시(청담대교)";
        "의정부시(신곡교)";
        "서울시(월계2교)";
        "서울시(중랑교)";
        "서울시(잠수교)";
        "서울시(한강대교)";
        "안양시(충훈1교)";
        "광명시(시흥대교)";
        "서울시(너부대교)";
        "서울시(오금교)";
        "서울시(행주대교)";
        "연천군(필승교)";
        "연천군(임진교)";
        "철원군(삼합교)";
        "포천시(용담교)";
        "포천시(은현교)";
        "포천시(영평교)";
        "포천시(신백의교)";
        "연천군(신천교)";
        "연천군(사랑교)";
        "파주시(비룡대교)";
        "파주시(통일대교)";
        "봉화군(임기리)";
        "봉화군(양삼교)";
        "청송군(덕천교)";
        "안동시(묵계교)";
        "안동시(포진교)";
        "안동시(안동대교)";
        "안동시(운산리)";
        "예천군(구담교)";
        "의성군(풍지교)";
        "봉화군(봉화대교)";
        "영주시(송리원)";
        "영주시(월호교)";
        "영주시(석탑교)";
        "예천군(미호교)";
        "예천군(고평교)";
        "예천군(신예천교)";
        "예천군(신음리)";
        "예천군(회룡교)";
        "예천군(산양교)";
        "문경시(김용리)";
        "상주시(이안교)";
        "상주시(병성교)";
        "상주시(소천2교)";
        "상주시(후천교)";
        "문경시(말응리)";
        "문경시(이목리)";
        "예천군(상풍교)";
        "군위군(미성교)";
        "군위군(병수리)";
        "군위군(효령교)";
        "군위군(무성리)";
        "의성군(위중리)";
        "의성군(낙단교)";
        "구미시(일선교)";
        "김천시(김천교)";
        "구미시(선주교)";
        "구미시(구미대교)";
        "칠곡군(호국의다리)";
        "성주군(성주대교)";
        "영천시(단포교)";
        "영천시(영동교)";
        "영천시(금창교)";
        "봉화군(풍호리)";
        "경산시(압량교)";
        "경산시(환상리)";
        "대구시(성동교)";
        "대구시(안심교)";
        "대구시(신암동)";
        "대구시(동화교)";
        "대구시(산격대교)";
        "대구시(성북교)";
        "대구시(강창교)";
        "대구시(매곡리)";
        "성주군(가천교)";
        "고령군(회천교)";
        "고령군(사촌리)";
        "고령군(도진교)";
        "대구시(사문진교)";
        "고령군(고령교)";
        "대구시(성하리)";
        "대구시(내리)";
        "합천군(율지교)";
        "거창군(거열교)";
        "합천군(남정교)";
        "합천군(황강교)";
        "합천군(적포교)";
        "의령군(세간교)";
        "함양군(용평리)";
        "함양군(의탄리)";
        "함양군(화촌리)";
        "산청군(경호교)";
        "합천군(소오리)";
        "산청군(하정리)";
        "산청군(묵곡교)";
        "산청군(창촌리)";
        "하동군(대곡리)";
        "고성군(두문교)";
        "진주시(장대동)";
        "진주시(덕오리)";
        "의령군(정암교)";
        "의령군(성산리)";
        "밀양시(판곡교)";
        "함안군(계내리)";
        "창녕군(청암리)";
        "창원시(수산대교)";
        "청도군(원리)";
        "밀양시(상동교)";
        "밀양시(용평동)";
        "밀양시(남천교)";
        "밀양시(남포동)";
        "밀양시(삼상교)";
        "밀양시(삼랑진교)";
        "김해시(월촌리)";
        "양산시(효충교)";
        "양산시(양산교)";
        "양산시(호포대교)";
        "부산시(구포대교)"];
    displayName = [ ...
        "Jeongseon County (Songgye Bridge)";
        "Jeongseon County (Songcheon Bridge)";
        "Jeongseon County (Najeon Bridge)";
        "Jeongseon County (Jeongseon 1 Bridge)";
        "Jeongseon County (Nakdong Bridge)";
        "Yeongwol County (Geoun Bridge)";
        "Pyeongchang County (Imokjeong Bridge)";
        "Pyeongchang County (Jangpyeong Bridge)";
        "Pyeongchang County (Jinjeon Bridge)";
        "Pyeongchang County (Seonae Bridge)";
        "Pyeongchang County (Sacho Bridge)";
        "Pyeongchang County (Sangbangrim Bridge)";
        "Pyeongchang County (Pyeongchang Bridge)";
        "Hoengseong County (Anheung Bridge)";
        "Yeongwol County (Jucheon Bridge)";
        "Yeongwol County (Sincheon Bridge)";
        "Yeongwol County (Palgoe Bridge)";
        "Yeongwol County (Okdong Bridge)";
        "Chungju (Mokgye Bridge)";
        "Wonju (Beopcheon Bridge)";
        "Wonju (Namhangang Bridge)";
        "Hoengseong County (Hoengseong Bridge)";
        "Hoengseong County (Jeoncheon Bridge)";
        "Wonju (Wonju Bridge)";
        "Wonju (Janghyeon Bridge)";
        "Wonju (Jijeong Bridge)";
        "Wonju (Munmak Bridge)";
        "Icheon (Janghowon Bridge)";
        "Yeoju (Wonbu Bridge)";
        "Yeoju (Samhap Bridge)";
        "Yeoju (Namhangang Bridge)";
        "Yeoju (Yeoju Bridge)";
        "Yeoju (Yulgeuk Bridge)";
        "Icheon (Bokha Bridge)";
        "Yeoju (Heungcheon Bridge)";
        "Yeoju (Yangchon Bridge)";
        "Yangpyeong County (Heukcheon Bridge)";
        "Yangpyeong County (Yangpyeong Bridge)";
        "Inje County (Wangseongdong Bridge)";
        "Chuncheon (Gangchon Bridge)";
        "Gapyeong County (Gapyeong Bridge)";
        "Hongcheon County (Yongseon Bridge)";
        "Hongcheon County (Jueumchi Bridge)";
        "Hongcheon County (Gulun Bridge)";
        "Hongcheon County (Hongcheon Bridge)";
        "Hongcheon County (Bangok Bridge)";
        "Gapyeong County (Cheongpyeong Bridge)";
        "Gapyeong County (Sincheongpyeong Bridge)";
        "Gwangju (Gyeongan Bridge)";
        "Gwangju (Seomtteul Bridge)";
        "Namyangju (Paldang Bridge)";
        "Namyangju (Bupyeong Bridge)";
        "Namyangju (Yeonpyeong Bridge)";
        "Namyangju (Naegok Bridge)";
        "Namyangju (Jingwan Bridge)";
        "Namyangju (Toegyewon-ri)";
        "Seoul (Gwangjin Bridge)";
        "Seongnam (Gungnae Bridge)";
        "Seoul (Daegok Bridge)";
        "Seoul (Cheongdam Bridge)";
        "Uijeongbu (Singok Bridge)";
        "Seoul (Wolgye 2 Bridge)";
        "Seoul (Jungrang Bridge)";
        "Seoul (Jamsu Bridge)";
        "Seoul (Hangang Bridge)";
        "Anyang (Chunghun 1 Bridge)";
        "Gwangmyeong (Siheung Bridge)";
        "Seoul (Neobu Bridge)";
        "Seoul (Ogeum Bridge)";
        "Seoul (Haengju Bridge)";
        "Yeoncheon County (Pilseung Bridge)";
        "Yeoncheon County (Imjin Bridge)";
        "Cheolwon County (Samhap Bridge)";
        "Pocheon (Yongdam Bridge)";
        "Pocheon (Eunhyeon Bridge)";
        "Pocheon (Yeongpyeong Bridge)";
        "Pocheon (Sinbaekui Bridge)";
        "Yeoncheon County (Sincheon Bridge)";
        "Yeoncheon County (Sarang Bridge)";
        "Paju (Biryong Bridge)";
        "Paju (Tongil Bridge)";
        "Bonghwa County (Imgi-ri)";
        "Bonghwa County (Yangsam Bridge)";
        "Cheongsong County (Deokcheon Bridge)";
        "Andong (Mukgye Bridge)";
        "Andong (Pojin Bridge)";
        "Andong (Andong Bridge)";
        "Andong (Unsan-ri)";
        "Yecheon County (Gudam Bridge)";
        "Uiseong County (Pungji Bridge)";
        "Bonghwa County (Bonghwa Bridge)";
        "Yeongju (Songriwon)";
        "Yeongju (Wolho Bridge)";
        "Yeongju (Seoktap Bridge)";
        "Yecheon County (Miho Bridge)";
        "Yecheon County (Gopyeong Bridge)";
        "Yecheon County (Sinyecheon Bridge)";
        "Yecheon County (Sineum-ri)";
        "Yecheon County (Hoeryong Bridge)";
        "Yecheon County (Sanyang Bridge)";
        "Mungyeong (Gimyong-ri)";
        "Sangju (Ian Bridge)";
        "Sangju (Byeongseong Bridge)";
        "Sangju (Socheon 2 Bridge)";
        "Sangju (Hucheon Bridge)";
        "Mungyeong (Maleung-ri)";
        "Mungyeong (Imok-ri)";
        "Yecheon County (Sangpung Bridge)";
        "Gunwi County (Miseong Bridge)";
        "Gunwi County (Byeongsu-ri)";
        "Gunwi County (Hyoryeong Bridge)";
        "Gunwi County (Museong-ri)";
        "Uiseong County (Wijung-ri)";
        "Uiseong County (Nakdan Bridge)";
        "Gumi (Ilseon Bridge)";
        "Gimcheon (Gimcheon Bridge)";
        "Gumi (Seonju Bridge)";
        "Gumi (Gumi Bridge)";
        "Chilgok County (Hoguk Bridge)";
        "Seongju County (Seongju Bridge)";
        "Yeongcheon (Danpo Bridge)";
        "Yeongcheon (Yeongdong Bridge)";
        "Yeongcheon (Geumchang Bridge)";
        "Bonghwa County (Pungho-ri)";
        "Gyeongsan (Apryang Bridge)";
        "Gyeongsan (Hwansang-ri)";
        "Daegu (Seongdong Bridge)";
        "Daegu (Ansim Bridge)";
        "Daegu (Sinam-dong)";
        "Daegu (Donghwa Bridge)";
        "Daegu (Sangyeok Bridge)";
        "Daegu (Seongbuk Bridge)";
        "Daegu (Gangchang Bridge)";
        "Daegu (Maegok-ri)";
        "Seongju County (Gacheon Bridge)";
        "Goryeong County (Hoecheon Bridge)";
        "Goryeong County (Sachon-ri)";
        "Goryeong County (Dojin Bridge)";
        "Daegu (Samunjin Bridge)";
        "Goryeong County (Goryeong Bridge)";
        "Daegu (Seongha-ri)";
        "Daegu (Nae-ri)";
        "Hapcheon County (Yulji Bridge)";
        "Geochang County (Geoyeol Bridge)";
        "Hapcheon County (Namjeong Bridge)";
        "Hapcheon County (Hwanggang Bridge)";
        "Hapcheon County (Jeokpo Bridge)";
        "Uiryeong County (Segan Bridge)";
        "Hamyang County (Yongpyeong-ri)";
        "Hamyang County (Uitan-ri)";
        "Hamyang County (Hwachon-ri)";
        "Sancheong County (Gyeongho Bridge)";
        "Hapcheon County (Soo-ri)";
        "Sancheong County (Hajeong-ri)";
        "Sancheong County (Mukgok Bridge)";
        "Sancheong County (Changchon-ri)";
        "Hadong County (Daegok-ri)";
        "Goseong County (Dumun Bridge)";
        "Jinju (Jangdae-dong)";
        "Jinju (Deoko-ri)";
        "Uiryeong County (Jeongam Bridge)";
        "Uiryeong County (Seongsan-ri)";
        "Milyang (Pangok Bridge)";
        "Haman County (Gyenae-ri)";
        "Changnyeong County (Cheongam-ri)";
        "Changwon (Susan Bridge)";
        "Cheongdo County (Won-ri)";
        "Milyang (Sangdong Bridge)";
        "Milyang (Yongpyeong-dong)";
        "Milyang (Namcheon Bridge)";
        "Milyang (Nampo-dong)";
        "Milyang (Samsang Bridge)";
        "Milyang (Samrangjin Bridge)";
        "Gimhae (Wolchon-ri)";
        "Yangsan (Hyochung Bridge)";
        "Yangsan (Yangsan Bridge)";
        "Yangsan (Hopo Bridge)";
        "Busan (Gupo Bridge)"];

    id = local_id(id(:));
    [tf,loc] = ismember(id,key);
    if ~all(tf)
        error('read_attr_KR:missingGaugeName', ...
            ['No CAMELSH-KR/WAMIS station-name ' ...
            'mapping for gauge %s.'], ...
            id(find(~tf,1)));
    end
    gname = displayName(loc);
    gname_kr = native(loc);
end

function local_ensure_kr_gauge_information(dirD,AA,id,gname,gname_kr)
% Write/refresh the compact metadata file used throughout SAGE.
    fout = fullfile(dirD,'gauge_information.txt');
    T = table(id(:),gname(:),double(AA.gauge_lat), ...
        double(AA.gauge_lon),double(AA.area),gname_kr(:), ...
        'VariableNames',{'gauge_id','gauge_name','gauge_lat', ...
        'gauge_lon','area_km2','gauge_name_kr'});
    try
        writetable(T,fout,'Delimiter','\t','FileType','text');
    catch ME
        warning('read_attr_KR:gaugeInformationWrite', ...
            'Could not write %s: %s',fout,ME.message);
    end
end

function id = local_id(x)
    id = strip(string(x));
    id = regexprep(id,'\.0+$','');
end

function x = local_field_or(S,name,defaultValue)
    x = defaultValue;
    if isfield(S,name) ...
            && ~isempty(S.(name))
        x = S.(name);
    end
end
