function dat = read_Q_KR(dirQ,mdl,dat,bas,split,aux)            %#ok
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%READ_Q_KR Read discharge data for each watershed in South Korea
%
% SYNOPSIS: [dat,aux] = read_Q_KR(dirQ,mdl,dat,bas,split,aux)
%   dirQ        string with main directory of discharge data
%   mdl         model state/parameter info
%   dat         cell structure with meteorological/model information
%   bas         structure basin information
%   split       structure with training/evaluation time split
%   aux         Kx3 matrix with basin metadata
%   dat         OUTPUT: cell structure with discharge information added
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% © Written by Jasper A. Vrugt, Apr. 2026                                 %
% University of California Irvine                                         %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

prt = reader_progress('start', ...
    '... Reading hourly CAMELSH-KR discharge data',bas.K);
reader_progress('finish',prt,bas.K);

end