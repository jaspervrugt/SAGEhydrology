function R = region_config_KR()
%REGION_CONFIG_KR Regional defaults for hourly CAMELSH-KR.

    R = struct();
    R.code = 'CAMELSH_KR';
    R.acronym = 'KR';
    R.name = 'South Korea';
    R.dataset = 'CAMELSH-KR';
    R.data_root = 'CAMELSH_KR';
    R.resolutions = {'Hourly'};
    R.default_resolution = 'Hourly';
    R.basin_file_pattern = 'KR_%d_basins.txt';

    X = struct();
    X.label = 'Hourly';
    X.dt = 24;
    % Thirteen source basins are excluded from the default periods:
    % eight have insufficient observed-Q coverage and five contain severe
    % source-data defects documented in CAMELSH_KR_discharge_audit.md.
    X.basins.universe = 165;
    X.basins.training = 140;
    X.basins.evaluation = 25;
    X.period.spinup_days = 365;
    X.period.manual.train_start = '01/10/2015';
    X.period.manual.train_end = '30/09/2019';
    X.period.manual.eval_start = '01/10/2010';
    X.period.manual.eval_end = '30/09/2015';
    X.period.common_start = '01/10/2010';
    X.period.common_end = '30/09/2019';
    X.paths.run_root = '';
    X.paths.meteo = fullfile('hourly','timeseries');
    X.paths.discharge = fullfile('hourly','timeseries');

    X.meteo.product.items = {'CAMELSH-KR [hourly]'};
    X.meteo.product.default = 'CAMELSH-KR [hourly]';
    X.meteo.product.enabled = false;
    X.meteo.precipitation.items = { ...
        '1 ERA5-Land precipitation','2 observed precipitation'};
    X.meteo.precipitation.default = '1 ERA5-Land precipitation';
    X.meteo.precipitation.enabled = true;
    X.meteo.temperature.items = { ...
        '1 ERA5-Land temperature','2 observed temperature'};
    X.meteo.temperature.default = '1 ERA5-Land temperature';
    X.meteo.temperature.enabled = true;
    X.meteo.pet.items = {'1 ERA5-Land potential evaporation'};
    X.meteo.pet.default = '1 ERA5-Land potential evaporation';
    X.meteo.pet.enabled = false;

    C = repmat(struct('name','','type','','path','','pattern','', ...
        'minimum_count',1,'required',true),0,1);
    C(1).name = 'Hourly forcing and streamflow';
    C(1).type = 'folder';
    C(1).path = fullfile('hourly','timeseries');
    C(1).pattern = '*.csv';
    C(1).minimum_count = 178;
    C(2).name = 'General attributes';
    C(2).type = 'file';
    C(2).path = 'attributes_general.csv';
    C(3).name = 'Observed climate attributes';
    C(3).type = 'file';
    C(3).path = 'attributes_climate_obs.csv';
    C(4).name = 'ERA5-Land climate attributes';
    C(4).type = 'file';
    C(4).path = 'attributes_climate_ERA5Land.csv';
    C(5).name = 'HydroATLAS attributes';
    C(5).type = 'file';
    C(5).path = 'attributes_HydroATLAS.csv';
    C(6).name = 'Dam attributes';
    C(6).type = 'file';
    C(6).path = 'attributes_dam.csv';
    X.checks = C;
    R.by_resolution.Hourly = X;
end
