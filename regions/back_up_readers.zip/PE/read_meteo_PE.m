function [dat,aux] = read_meteo_PE(dirM,bas,split,meteo)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%READ_METEO_PE Read CAMELS-PE v1.0.1 daily hydrometeorological data.
%
% Expected directory:
%   Data/CAMELS_PE/daily/timeseries/PE_*.csv
%
% Columns used:
%   prec     precipitation (mm/day)
%   pet      potential evapotranspiration (mm/day)
%   tmean    mean air temperature (deg C)
%   flow_obs observed streamflow (mm/day)
%
% Optional source choices:
%   meteo.temp = 1 tmean [default], 2 mean(tmin,tmax)
%   meteo.flow = 1 flow_obs [default], 2 flow_sim
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    if nargin < 1 ...
            || isempty(dirM)
        error('read_meteo_PE:missingDir', ...
            'dirM must be provided.');
    end
    if nargin < 2 ...
            || ~isstruct(bas) ...
            || ~isfield(bas,'id_gauge') ...
            || isempty(bas.id_gauge)
        error('read_meteo_PE:missingBasins', ...
            'bas.id_gauge must be provided.');
    end
    if nargin < 3 ...
            || isempty(split)
        error('read_meteo_PE:missingSplit', ...
            'split must be provided.');
    end
    if nargin < 4 ...
            || isempty(meteo)
        meteo = struct(); 
    end
    if ~isfield(split,'dt') ...
            || isempty(split.dt)
        split.dt = 1; 
    end
    if double(split.dt) ~= 1
        error('read_meteo_PE:dailyOnly', ...
            ['CAMELS-PE supports daily ' ...
            'data only; split.dt must equal 1.']);
    end

    dirM = local_pe_timeseries_dir(dirM);
    if ~isfolder(dirM)
        error('read_meteo_PE:missingDir', ...
            ['CAMELS-PE daily timeseries ' ...
            'directory does not exist: %s'],dirM);
    end

    tChoice = local_choice(meteo,'temp',1,1:2);
    qChoice = local_choice(meteo,'flow',1,1:2);
    ids = local_normalize_pe_id(bas.id_gauge(:));
    K = numel(ids);
    dat = cell(K,1);
    aux = nan(K,3);

    rootPE = fileparts(fileparts(dirM));
    station = local_read_table(fullfile(rootPE, ...
        'stations.csv'));
    topo = local_read_table(fullfile(rootPE, ...
        'topographic_attributes.csv'));
    station = outerjoin(station,topo(:, ...
        {'gauge_id','area'}), ...
        'Keys','gauge_id', ...
        'MergeKeys',true, ...
        'Type','left');

    cacheDir = fullfile(dirM,'_cache_PE_daily');
    if ~isfolder(cacheDir), mkdir(cacheDir); end
    fprintf(['... Reading daily CAMELS-PE ' ...
        'meteorological data files %3d%%'],0);

    for k = 1:K
        gid = ids(k);
        fname = fullfile(dirM,['PE_' char(gid) '.csv']);
        if ~isfile(fname)
            error('read_meteo_PE:missingFile', ...
                'Missing CAMELS-PE file: %s',fname);
        end
        cacheFile = fullfile(cacheDir, ...
            sprintf('%s_PE_daily_t%d_q%d.mat', ...
            matlab.lang.makeValidName( ...
            char(gid)),tChoice,qChoice));

        [Pfull,Epfull,Tfull,Qfull,badM,badQ,fileStartDT,fileEndDT, ...
            fileStartN,fileEndN] = local_load_or_build( ...
            fname,cacheFile,tChoice,qChoice);

        req = local_requested_window(split,fileStartN,fileEndN);
        if req.read_start_N < fileStartN ...
                || req.read_end_N > fileEndN
            fprintf('\n');
            error('read_meteo_PE:periodOutsideFile', ...
                ['Requested period lies ' ...
                'outside CAMELS-PE file for %s. ' ...
                 'File covers %s to %s.'],char(gid), ...
                string(fileStartDT),string(fileEndDT));
        end
        i0 = double(req.read_start_N-fileStartN)+1;
        i1 = double(req.read_end_N-fileStartN)+1;
        ir = i0:i1;

        Pall = double(Pfull(ir)); 
        Eall = double(Epfull(ir));
        Tall = double(Tfull(ir)); 
        Qall = double(Qfull(ir));
        if isfield(split,'idx') ...
                && ~isempty(split.idx)
            idxScore = double(split.idx(:));
        else
            idxScore = (1:numel(Qall))';
        end
        idxScore = idxScore(idxScore>=1 ...
            & idxScore<=numel(Qall));

        dat{k}.meteo.P = single(Pall);
        dat{k}.meteo.Ep = single(Eall);
        dat{k}.meteo.T = single(Tall);
        dat{k}.y_n = single(Qall(idxScore));
        dat{k}.gauge = gid;
        dat{k}.fname = {fname};

        bm = double(badM(:)); 
        bm = bm(bm>=i0 ...
            & bm<=i1)-i0+1;
        dat{k}.meteo.bad = bm(:)';
        bq = double(badQ(:)); 
        bq = bq(bq>=i0 ...
            & bq<=i1)-i0+1;
        mask = false(1,numel(Qall));
        bq = bq(bq>=1 ...
            & bq<=numel(Qall)); 
        mask(round(bq)) = true;
        dat{k}.bad = mask(idxScore);

        j = find(station.gauge_id==gid,1);
        if ~isempty(j)
            aux(k,1) = double(station.gauge_lat(j));
            aux(k,2) = double(station.gauge_elev(j));
            aux(k,3) = double(station.area(j))*1e6;
        end

        if mod(k,5)==0 ...
                || k==K
            fprintf('\b\b\b\b%3d%%',floor(100*k/K)); 
            drawnow;
        end

        if isfield(meteo,'progressFcn') ...
                && ~isempty(meteo.progressFcn)
            try
                meteo.progressFcn(k);
            catch MEprogress
                warning('read_meteo_PE:progressFcn', ...
                    'GUI progress callback failed: %s', ...
                    MEprogress.message);
            end
        end
    end
    
    fprintf('\b\b\b\b%s\n','... Done');

    if isfield(split,'local') ...
            && split.local ...
            && isfield(split,'rainfall_block') ...
            && split.rainfall_block
        dat = rainfall_rank_split(dat,split);
    end
end

function [P,Ep,T,Q,badM,badQ,d0,d1,n0,n1] = ...
        local_load_or_build(fname,cacheFile,tChoice,qChoice)
    if isfile(cacheFile)
        S = load(cacheFile);
        P = S.P; Ep = S.Ep; 
        T = S.T; Q = S.Q; 
        badM = S.badM; badQ = S.badQ;
        d0 = S.d0; d1 = S.d1; 
        n0 = S.n0; n1 = S.n1; 
        return
    end
    X = readtable(fname,'VariableNamingRule','preserve');
    X.Properties.VariableNames = ...
        matlab.lang.makeValidName( ...
        X.Properties.VariableNames, ...
        'ReplacementStyle','delete');
    need = {'date','prec','pet', ...
        'tmin','tmean','tmax', ...
        'flow_obs','flow_sim'};
    miss = setdiff(need,X.Properties.VariableNames);
    if ~isempty(miss)
        error('read_meteo_PE:missingColumns', ...
            'Missing columns in %s: %s', ...
            fname,strjoin(miss,', '));
    end
    date = datetime(string(X.date), ...
        'InputFormat','yyyy-MM-dd');
    if any(isnat(date)) ...
            || any(diff(date)~=days(1))
        error('read_meteo_PE:badDates', ...
            ['Dates in %s are invalid or ' ...
            'not consecutive daily values.'],fname);
    end
    % CAMELS-PE contains text missing-value markers such as N/A in some
    % columns. Convert mixed numeric/text table variables safely.
    P = single(local_numeric_column(X.prec,'prec',fname));
    Ep = single(local_numeric_column(X.pet,'pet',fname));
    if tChoice == 1
        T = single(local_numeric_column(X.tmean,'tmean',fname));
    else
        Tmin = local_numeric_column(X.tmin,'tmin',fname);
        Tmax = local_numeric_column(X.tmax,'tmax',fname);
        T = single((Tmin + Tmax)/2);
    end
    if qChoice == 1
        Q = single(local_numeric_column(X.flow_obs,'flow_obs',fname));
    else
        Q = single(local_numeric_column(X.flow_sim,'flow_sim',fname));
    end
    badM = int64(find(~isfinite(P)|P<0|~isfinite(Ep)|Ep<0|~isfinite(T)));
    badQ = int64(find(~isfinite(Q)|Q<0));
    d0 = date(1); 
    d1 = date(end); 
    n0 = int64(datenum(d0));    %#ok<DATNM>
    n1 = int64(datenum(d1));    %#ok<DATNM>
    save(cacheFile,'P','Ep', ...
        'T','Q','badM','badQ', ...
        'd0','d1','n0','n1','-v7.3');
end


function x = local_numeric_column(v,varName,fname)
%LOCAL_NUMERIC_COLUMN Convert numeric or mixed text columns to double.
% Missing markers are converted to NaN.

    if isnumeric(v) || islogical(v)
        x = double(v(:));
        return
    end

    if iscell(v)
        s = string(v(:));
    elseif isstring(v) || ischar(v) || iscategorical(v)
        s = string(v(:));
    else
        try
            s = string(v(:));
        catch
            error('read_meteo_PE:badColumnType', ...
                ['Column %s in %s has unsupported MATLAB type %s.'], ...
                varName,fname,class(v));
        end
    end

    s = strip(s);
    missing = ismissing(s) ...
        | strcmpi(s,'N/A') ...
        | strcmpi(s,'NA') ...
        | strcmpi(s,'NAN') ...
        | strcmpi(s,'NULL') ...
        | strcmpi(s,'NONE') ...
        | strcmpi(s,'-');

    % Be tolerant of decimal commas if they occur in a text column.
    s = replace(s,',','.');
    x = str2double(s);
    x(missing) = NaN;

    bad = ~missing & isnan(x);
    if any(bad)
        j = find(bad,1,'first');
        error('read_meteo_PE:nonNumericValue', ...
            ['Column %s in %s contains a nonnumeric value at row %d: %s'], ...
            varName,fname,j,char(s(j)));
    end
end

function dirM = local_pe_timeseries_dir(dirM)
    dirM = char(string(dirM)); 
    [~,n] = fileparts(dirM);
    if strcmpi(n,'timeseries')
        candidates = {dirM};
    elseif strcmpi(n,'daily')
        candidates = {fullfile(dirM,'timeseries')};
    else
        candidates = {fullfile(dirM,'daily','timeseries')}; 
    end
    for k=1:numel(candidates)
        if isfolder(candidates{k}) ...
                && ~isempty(dir(fullfile(candidates{k},'PE_*.csv')))
            dirM = candidates{k}; 
            return
        end
    end
end

function req = local_requested_window(split,fileStartN,fileEndN)
    if isfield(split,'dt0') ...
            && ~isempty(split.dt0)
        t0 = datetime(split.dt0); 
        n = [];
        if isfield(split,'tout') ...
                && ~isempty(split.tout)
            n = numel(split.tout)-1;
        elseif isfield(split,'idx') ...
                && ~isempty(split.idx)
            n = max(double(split.idx)); 
        end
        if isempty(n) ...
                || n < 1 
            n = double(fileEndN-fileStartN)+1;
        end
        req.read_start_N = int64(datenum(t0)); %#ok<DATNM>
        req.read_end_N = req.read_start_N+int64(n-1); 
        return
    end
    ds = []; 
    de = [];
    for f = {'ds','dstart','start_date'}
        if isfield(split,f{1}) ...
                && ~isempty(split.(f{1}))
            ds = datetime(split.(f{1})); 
            break
        end
    end
    for f = {'de','dend','end_date'}
        if isfield(split,f{1}) ...
                && ~isempty(split.(f{1}))
            de = datetime(split.(f{1})); 
            break
        end
    end
    if isempty(ds) || isempty(de)
        req.read_start_N = fileStartN; 
        req.read_end_N = fileEndN;
    else
        req.read_start_N = int64(datenum(ds));  %#ok<DATNM>
        req.read_end_N = int64(datenum(de));    %#ok<DATNM>
    end 
end

function v=local_choice(S,name,defaultValue,allowed)
    v = defaultValue;
    if isstruct(S) ...
            && isfield(S,name) ...
            && ~isempty(S.(name))
        v = double(S.(name)(1)); 
    end
    if ~isfinite(v) ...
            || v ~= round(v) ...
            || ~ismember(v,allowed)
        error('read_meteo_PE:badChoice', ...
            'meteo.%s has an invalid value.',name);
    end
end

function T=local_read_table(fname)
    if ~isfile(fname)
        error('read_meteo_PE:missingMetadata', ...
            'Missing %s.',fname); 
    end
    T = readtable(fname,'VariableNamingRule','preserve');
    T.Properties.VariableNames = ...
        matlab.lang.makeValidName( ...
        T.Properties.VariableNames, ...
        'ReplacementStyle','delete');
    T.gauge_id = local_normalize_pe_id(T.gauge_id);
end

function id = local_normalize_pe_id(x)
    id = upper(strtrim(string(x(:)))); 
    id = erase(id,'\"'); 
    id = erase(id,"'");
    % Internal SAGE IDs do not include the PE_ filename prefix.
    id = regexprep(id,'^PE_','', 'ignorecase');
end
