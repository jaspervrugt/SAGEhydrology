function R = region_config_PE()
%REGION_CONFIG_PE Regional defaults for CAMELS-PE.
%
% All X.paths fields are relative to Data/<R.data_root>.
% Dates use dd/MM/yyyy and water-year boundaries.

    R = struct();
    R.code = 'CAMELS_PE';
    R.acronym = 'PE';
    R.name = 'Peru';
    R.dataset = 'CAMELS-PE';
    R.data_root = 'CAMELS_PE';
    R.resolutions = {'Daily'};
    R.default_resolution = 'Daily';
    R.basin_file_pattern = 'PE_%d_basins.txt';

    X = struct();
    X.label = 'Daily';
    X.dt = 1;
    X.basins.universe = 57;
    X.basins.training = 45;
    X.basins.evaluation = 12;
    X.period.spinup_days = 365;
    X.period.manual.train_start = '01/10/2006';
    X.period.manual.train_end = '30/09/2016';
    X.period.manual.eval_start = '01/10/1997';
    X.period.manual.eval_end = '30/09/2006';
    X.period.common_start = '01/10/1997';
    X.period.common_end = '30/09/2016';
    X.paths.run_root = '';
    X.paths.meteo = fullfile('daily','timeseries');
    X.paths.discharge = fullfile('daily','timeseries');
    % Meteorological/PET controls shown by SAGE-GUI.
    X.meteo.product.items = {'CAMELS-PE [daily]'};
    X.meteo.product.default = 'CAMELS-PE [daily]';
    X.meteo.product.enabled = false;
    X.meteo.precipitation.items = {'1 Precipitation'};
    X.meteo.precipitation.default = '1 Precipitation';
    X.meteo.precipitation.enabled = false;
    X.meteo.temperature.items = { ...
        '1 Mean temperature', ...
        '2 (Tmin+Tmax)/2' ...
        };
    X.meteo.temperature.default = '1 Mean temperature';
    X.meteo.temperature.enabled = true;
    X.meteo.pet.items = {'1 Supplied PET'};
    X.meteo.pet.default = '1 Supplied PET';
    X.meteo.pet.enabled = false;
    C = repmat(struct('name','','type','','path','','pattern','', ...
        'minimum_count',1,'required',true),0,1);
    C(1).name = 'Meteorological data';
    C(1).type = 'folder';
    C(1).path = fullfile('daily','timeseries');
    C(1).pattern = '*';
    C(1).minimum_count = 1;
    X.checks = C;
    R.by_resolution.Daily = X;

end