function [dat,aux] = read_meteo_SE(dirM,bas,split,meteo)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%READ_METEO_SE Read CAMELS-SE daily meteorology and discharge for SAGE
%
% SYNOPSIS:
%   [dat,aux] = read_meteo_SE(dirM,bas,split,meteo)
%
% INPUT:
%   dirM        Directory with CAMELS-SE daily catchment time-series files:
%                 Data/CAMELS_SE/daily
%   bas         Basin structure with fields .K and .id_gauge
%   split       Training/evaluation split structure
%   meteo       Meteorological settings structure. Optional field:
%                 .progressFcn  GUI/log progress callback
%
% OUTPUT:
%   dat         Kx1 cell structure. This reader fills both meteorology and
%               discharge because CAMELS-SE stores them in the same file.
%   aux         Kx3 matrix: latitude, elevation, area [m^2]
%
% DESCRIPTION:
%   Each CAMELS-SE catchment file contains daily columns:
%
%     Year, Month, Day, Qobs_m3s, Qobs_mm, Pobs_mm, Tobs_C
%
%   The reader returns precipitation P, temperature T, and an estimated PET
%   using the Oudin temperature/latitude method because PET is not supplied
%   in the CAMELS-SE time-series files.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% © Written by Jasper A. Vrugt, May 2026                                  %
% University of California, Irvine                                        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    if nargin < 1 || isempty(dirM)
        error('read_meteo_SE:missingDir', ...
            ['Error:read_meteo_SE: ' ...
            'dirM must be provided.']);
    end
    
    if ~isfolder(dirM)
        error('read_meteo_SE:missingDir', ...
            ['Error:read_meteo_SE: ' ...
            'Timeseries directory ' ...
             'does not exist: %s'],dirM);
    end
    
    if nargin < 4 || isempty(meteo)
        meteo = struct();
    end
    
    split = prepare_split(split);
    dt = double(split.dt);
    
    if dt ~= 1
        error('read_meteo_SE:unsupportedDt', ...
            ['Error:read_meteo_SE: ' ...
            'CAMELS-SE reader currently ' ...
             'supports daily data ' ...
             'only [split.dt = 1].']);
    end
    
    K = bas.K;
    id_GAUGE = double(string(bas.id_gauge(:)));
    
    dat = cell(K,1);
    aux = nan(K,3);
    
    rootSE = fileparts(dirM);
    Tphys = local_read_physical_table(rootSE);
    
    cache_dir = fullfile(dirM, ...
        '_cache_SE_daily');
    if ~isfolder(cache_dir)
        mkdir(cache_dir);
    end
    
    fprintf(['... Reading daily CAMELS-SE ' ...
        'meteorological data files %3d%%'],0);
    flag_progress = true;
    
    req = build_requested_window(split,true);
    
    for k = 1:K
    
        gid = id_GAUGE(k);
        fname = local_find_se_timeseries_file(dirM,gid);
    
        cache_file = fullfile(cache_dir, ...
            sprintf('%d_SE_daily_oudin.mat',round(gid)));
    
        lat = local_aux_value(Tphys,gid, ...
            'Latitude_WGS84');
        elev = local_aux_value(Tphys,gid, ...
            'Elevation_mabsl');
        area_km2 = local_aux_value(Tphys,gid, ...
            'Area_km2');
    
        [Pfull,Epfull,Tfull,Qfull,bad_meteo_full,bad_q_full, ...
            fileStartN,fileEndN,fileStartDT,fileEndDT] = ...
            local_load_or_build_se_cache(fname, ...
            cache_file,gid,lat);
    
        if req.read_start_N < fileStartN ...
                || req.read_end_N > fileEndN
            if flag_progress
                fprintf('\n');
            end
            error('read_meteo_SE:periodOutsideFile', ...
                ['Error:read_meteo_SE: ' ...
                'requested period outside ' ...
                 'CAMELS-SE file for basin %d.\n' ...
                 'File covers %s to %s.'], ...
                gid,string(fileStartDT), ...
                string(fileEndDT));
        end
    
        id_read0 = int64(req.read_start_N ...
            - fileStartN) + 1;
        id_read1 = int64(req.read_end_N ...
            - fileStartN) + 1;
        id_r = double(id_read0:id_read1);
    
        P = double(Pfull(id_r));
        Ep = double(Epfull(id_r));
        Temp = double(Tfull(id_r));
        Qall = double(Qfull(id_r));
    
        dat{k}.meteo.P = single(P);
        dat{k}.meteo.Ep = single(Ep);
        dat{k}.meteo.T = single(Temp);
    
        idx_score = double(split.idx(:));
        idx_score = idx_score(idx_score >= 1 ...
            & idx_score <= numel(Qall));
    
        Q = Qall(idx_score);
        dat{k}.y_n = single(Q);
        dat{k}.gauge = gid;
        dat{k}.fname{1} = fname;
        dat{k}.fname{2} = fname;
    
        id0d = double(id_read0);
        id1d = double(id_read1);
    
        bad_meteo_full = double(bad_meteo_full(:));
        bad_q_full = double(bad_q_full(:));
    
        bad_meteo = bad_meteo_full( ...
            bad_meteo_full >= id0d & ...
            bad_meteo_full <= id1d) - id0d + 1;
        bad_q_all = bad_q_full( ...
            bad_q_full >= id0d & ...
            bad_q_full <= id1d) - id0d + 1;
    
        dat{k}.meteo.bad = bad_meteo(:).';
    
        badmask_all = false(1,numel(Qall));
        bad_q_all = bad_q_all(isfinite(bad_q_all) ...
            & bad_q_all >= 1 ...
            & bad_q_all <= numel(Qall));
        badmask_all(round(bad_q_all)) = true;
        dat{k}.bad = badmask_all(idx_score);
    
        if isfinite(area_km2)
            area_m2 = 1e6 * area_km2;
        else
            area_m2 = NaN;
        end
        aux(k,:) = [lat elev area_m2];
    
        if mod(k,5)==0 ...
                || k==K
            pct = floor(100*k/K);
            fprintf('\b\b\b\b%3d%%',pct);
            drawnow;
        end
    
        if isfield(meteo,'progressFcn') ...
                && ~isempty(meteo.progressFcn)
            try
                meteo.progressFcn(k,K);
            catch
                try
                    meteo.progressFcn(k);
                catch
                end
            end
        end
    end
    
    if flag_progress
        fprintf('\b\b\b\b%s\n','... Done');
    end
    
    if isfield(split,'local') ...
            && split.local ...
            && isfield(split,'rainfall_block') ...
            && split.rainfall_block
    
        dat = rainfall_rank_split(dat,split);
    end

end

% ======================
% Local helper functions
% ======================

function fname = local_find_se_timeseries_file(dirM,gid)

    pat = sprintf('catchment_id_%d_*.csv', ...
        round(gid));
    D = dir(fullfile(dirM,pat));
    
    if isempty(D)
        pat = sprintf('*%d*.csv',round(gid));
        D = dir(fullfile(dirM,pat));
    end
    
    if isempty(D)
        error('read_meteo_SE:missingFile', ...
            ['Error:read_meteo_SE: ' ...
            'Missing CAMELS-SE time-series ' ...
             'file for basin %d in %s.'],gid,dirM);
    end
    
    fname = fullfile(D(1).folder,D(1).name);
end

function Tphys = local_read_physical_table(rootSE)

    f = fullfile(rootSE, ...
        'catchments_physical_properties.csv');
    if isfile(f)
        Tphys = readtable(f, ...
            'VariableNamingRule','preserve');
        Tphys.Properties.VariableNames = ...
            matlab.lang.makeValidName( ...
            Tphys.Properties.VariableNames, ...
            'ReplacementStyle','underscore');
    else
        Tphys = table();
        fprintf(['      Warning:read_meteo_SE: ' ...
            'Could not find ' ...
            'catchments_physical_properties.csv. ' ...
            'aux and PET latitude ' ...
            'will use fallback values.\n']);
    end
end

function val = local_aux_value(Tphys,gid,varName)

    val = NaN;
    if isempty(Tphys) || height(Tphys) == 0 ...
            || ~ismember('ID', ...
            Tphys.Properties.VariableNames) ...
            || ~ismember(varName, ...
            Tphys.Properties.VariableNames)
        return
    end
    
    ids = double(Tphys.ID(:));
    j = find(ids == double(gid),1,'first');
    if isempty(j)
        return
    end
    
    val = double(Tphys.(varName)(j));
end

function [P,Ep,Tair,Q,bad_meteo,bad_q, ...
    fileStartN,fileEndN,fileStartDT,fileEndDT] = ...
    local_load_or_build_se_cache(fname, ...
    cache_file,gid,lat)

    use_cache = false;
    if isfile(cache_file)
        try
            info_src = dir(fname);
            info_cch = dir(cache_file);
            use_cache = ...
                info_cch.datenum >= info_src.datenum;
        catch
            use_cache = false;
        end
    end
    
    if use_cache
        S = load(cache_file, ...
            'P','Ep','Tair','Q', ...
            'bad_meteo','bad_q', ...
            'fileStartN','fileEndN', ...
            'fileStartDT','fileEndDT');
        P = S.P;
        Ep = S.Ep;
        Tair = S.Tair;
        Q = S.Q;
        bad_meteo = S.bad_meteo;
        bad_q = S.bad_q;
        fileStartN = S.fileStartN;
        fileEndN = S.fileEndN;
        fileStartDT = S.fileStartDT;
        fileEndDT = S.fileEndDT;
        return
    end
    
    [P,Ep,Tair,Q,bad_meteo,bad_q, ...
        fileStartN,fileEndN,fileStartDT,fileEndDT] = ...
        local_read_se_timeseries_full(fname,gid,lat);
    
    save(cache_file, ...
        'P','Ep','Tair','Q', ...
        'bad_meteo','bad_q', ...
        'fileStartN','fileEndN', ...
        'fileStartDT','fileEndDT', ...
        'gid','lat','-v7.3');
end

function [P,Ep,Tair,Q,bad_meteo,bad_q, ...
    fileStartN,fileEndN,fileStartDT,fileEndDT] = ...
    local_read_se_timeseries_full(fname,gid,lat)

    Traw = readtable(fname, ...
        'VariableNamingRule','preserve');
    Traw.Properties.VariableNames = ...
        matlab.lang.makeValidName( ...
        Traw.Properties.VariableNames, ...
        'ReplacementStyle','underscore');
    
    need = {'Year','Month','Day', ...
        'Qobs_mm','Pobs_mm','Tobs_C'};
    for j = 1:numel(need)
        if ~ismember(need{j}, ...
                Traw.Properties.VariableNames)
            error('read_meteo_SE:missingColumn', ...
                ['      Error:read_meteo_SE: ' ...
                'Required column "%s" ' ...
                 'not found in %s.'], ...
                 need{j},fname);
        end
    end
    
    t = datetime(double(Traw.Year), ...
        double(Traw.Month),double(Traw.Day));
    
    fileStartDT = t(1);
    fileEndDT = t(end);
    fileStartN = int64(days(fileStartDT ...
        - datetime(1950,10,1)));
    fileEndN = int64(days(fileEndDT ...
        - datetime(1950,10,1)));
    
    P = single(double(Traw.Pobs_mm(:)));
    Tair = single(double(Traw.Tobs_C(:)));
    Q = single(double(Traw.Qobs_mm(:)));
    
    if ~isfinite(lat)
        fprintf(['\n      Warning:read_meteo_SE: ' ...
            'Latitude missing for basin %d; ' ...
            'using 60 deg N for Oudin PET.\n'],gid);
        lat = 60;
    end
    
    Ep = single(local_oudin_pet(datetime(t), ...
        double(Tair),lat));
    Ep(~isfinite(Ep) | Ep < 0) = 0;
    
    bad_meteo = int64(find(~isfinite(double(P)) ...
        | ~isfinite(double(Ep)) ...
        | ~isfinite(double(Tair))));
    bad_q = int64(find(~isfinite(double(Q))));

end

function Ep = local_oudin_pet(t,Tair,latDeg)
%LOCAL_OUDIN_PET Temperature/latitude PET estimate [mm/day].
%
% Uses the Oudin et al. temperature-based form:
%   PET = 0.408 * Ra * max(T + 5,0) / 100
% where Ra is extraterrestrial radiation [MJ m-2 day-1].

    doy = day(t,'dayofyear');
    phi = deg2rad(latDeg);
    Gsc = 0.0820;               % MJ m-2 min-1
    
    dr = 1 + 0.033*cos(2*pi*doy/365);
    delta = 0.409*sin(2*pi*doy/365 - 1.39);
    ws = acos(max(-1,min(1,-tan(phi).*tan(delta))));
    
    Ra = (24*60/pi) * Gsc .* dr .* ...
        (ws.*sin(phi).*sin(delta) + ...
         cos(phi).*cos(delta).*sin(ws));
    
    Ep = 0.408 .* Ra(:) .* max(Tair(:) + 5,0) ./ 100;
    Ep(~isfinite(Ep)) = NaN;

end
