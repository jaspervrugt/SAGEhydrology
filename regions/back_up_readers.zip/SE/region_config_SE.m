function R = region_config_SE()
%REGION_CONFIG_SE Regional defaults for CAMELS-SE.
%
% All X.paths fields are relative to Data/<R.data_root>.
% Dates use dd/MM/yyyy and water-year boundaries.

    R = struct();
    R.code = 'CAMELS_SE';
    R.acronym = 'SE';
    R.name = 'Sweden';
    R.dataset = 'CAMELS-SE';
    R.data_root = 'CAMELS_SE';
    R.resolutions = {'Daily'};
    R.default_resolution = 'Daily';
    R.basin_file_pattern = 'SE_%d_basins.txt';

    X = struct();
    X.label = 'Daily';
    X.dt = 1;
    X.basins.universe = 50;
    X.basins.training = 40;
    X.basins.evaluation = 10;
    X.period.spinup_days = 365;
    X.period.manual.train_start = '01/10/2000';
    X.period.manual.train_end = '30/09/2010';
    X.period.manual.eval_start = '01/10/1990';
    X.period.manual.eval_end = '30/09/2000';
    X.period.common_start = '01/10/1990';
    X.period.common_end = '30/09/2010';
    X.paths.run_root = '';
    X.paths.meteo = fullfile('daily');
    X.paths.discharge = fullfile('daily');
    % Meteorological/PET controls shown by SAGE-GUI.
    X.meteo.product.items = {'CAMELS-SE [daily]'};
    X.meteo.product.default = 'CAMELS-SE [daily]';
    X.meteo.product.enabled = false;
    X.meteo.precipitation.items = {'1 Observed'};
    X.meteo.precipitation.default = '1 Observed';
    X.meteo.precipitation.enabled = false;
    X.meteo.temperature.items = {'1 Observed air'};
    X.meteo.temperature.default = '1 Observed air';
    X.meteo.temperature.enabled = false;
    X.meteo.pet.items = {'1 Oudin et al.'};
    X.meteo.pet.default = '1 Oudin et al.';
    X.meteo.pet.enabled = false;
    C = repmat(struct('name','','type','','path','','pattern','', ...
        'minimum_count',1,'required',true),0,1);
    C(1).name = 'Meteorological data';
    C(1).type = 'folder';
    C(1).path = fullfile('daily');
    C(1).pattern = '*';
    C(1).minimum_count = 1;
    X.checks = C;
    R.by_resolution.Daily = X;

end