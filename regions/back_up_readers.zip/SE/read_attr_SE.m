function [A,id_gauge,gname,zone] = read_attr_SE(dirD,bas)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%READ_ATTR_SE Read CAMELS-SE catchment attributes for SAGE
%
% SYNOPSIS:
%   [A,id_gauge,gname,zone] = read_attr_SE(dirD)
%   [A,id_gauge,gname,zone] = read_attr_SE(dirD,bas)
%
% INPUT:
%   dirD        Root directory of CAMELS-SE data, normally:
%                 Data/CAMELS_SE
%   bas         Optional basin structure with field .id_gauge. If supplied,
%               attributes are returned in the same basin order.
%
% OUTPUT:
%   A           K x r numeric attribute matrix
%   id_gauge    K x 1 numeric catchment identifiers
%   gname       K x 1 string array with catchment names
%   zone        structure with simple Sweden hydroclimatic classes
%
% DESCRIPTION:
%   CAMELS-SE stores catchment attributes in several CSV files keyed by ID:
%
%     catchments_physical_properties.csv
%     catchments_landcover.csv
%     catchments_soil_classes.csv
%
%   Optional hydrological-signature CSV files are also read when present and
%   appended to A. They are included in the returned attribute matrix for
%   inspection, but attr_catalog('CAMELS_SE') keeps the default SAGE
%   selection limited to physical, land-cover, and soil-class attributes.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% © Written by Jasper A. Vrugt, May 2026                                  %
% University of California, Irvine                                        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    if nargin < 1 ...
            || isempty(dirD)
        error('read_attr_SE:missingDir', ...
            ['      Error:read_attr_SE: ' ...
            'dirD must be provided.']);
    end
    
    if ~isfolder(dirD)
        error('read_attr_SE:missingDir', ...
            ['      Error:read_attr_SE: Attribute ' ...
            'directory does not exist: %s'],dirD);
    end
    
    if nargin < 2 ...
            || isempty(bas)
        bas = struct();
    end
    
    if ~isstruct(bas)
        error('read_attr_SE:badBas', ...
            ['      Error:read_attr_SE: ' ...
            'bas must be a structure.']);
    end

    pr_table = 1;
    if isfield(bas,'pr_attr') ...
            && ~isempty(bas.pr_attr)
        pr_table = bas.pr_attr;
    end
    % =========================================
    % ZONE CONTROL PARAMETERS (GLOBAL DEFAULTS)
    % =========================================
    if ~isfield(bas,'min_per_zone') ...
            || isempty(bas.min_per_zone)
        min_per_zone = 5;
    else
        min_per_zone = bas.min_per_zone;
    end    
    if ~isfield(bas,'max_zones') ...
            || isempty(bas.max_zones)
        max_zones = 8;
    else
        max_zones = bas.max_zones;
    end
    
    f_phys = fullfile(dirD, ...
        'catchments_physical_properties.csv');
    f_land = fullfile(dirD, ...
        'catchments_landcover.csv');
    f_soil = fullfile(dirD, ...
        'catchments_soil_classes.csv');
    
    if ~isfile(f_phys)
        error('read_attr_SE:missingFile', ...
            ['Error:read_attr_SE: ' ...
            'Missing file: %s'],f_phys);
    end
    if ~isfile(f_land)
        error('read_attr_SE:missingFile', ...
            ['Error:read_attr_SE: ' ...
            'Missing file: %s'],f_land);
    end
    if ~isfile(f_soil)
        error('read_attr_SE:missingFile', ...
            ['Error:read_attr_SE: ' ...
            'Missing file: %s'],f_soil);
    end
    
    Tphys = readtable(f_phys, ...
        'VariableNamingRule','preserve');
    Tland = readtable(f_land, ...
        'VariableNamingRule','preserve');
    Tsoil = readtable(f_soil, ...
        'VariableNamingRule','preserve');
    
    Tphys = local_clean_table(Tphys);
    Tland = local_clean_table(Tland);
    Tsoil = local_clean_table(Tsoil);
    
    local_require_id(Tphys,f_phys);
    local_require_id(Tland,f_land);
    local_require_id(Tsoil,f_soil);
    
    Tphys = local_unique_id_rows( ...
        Tphys,f_phys);
    Tland = local_unique_id_rows( ...
        Tland,f_land);
    Tsoil = local_unique_id_rows( ...
        Tsoil,f_soil);
    
    T = outerjoin(Tphys,Tland, ...
        'Keys','ID','MergeKeys',true, ...
        'Type','left');
    T = outerjoin(T,Tsoil, ...
        'Keys','ID','MergeKeys',true, ...
        'Type','left');
    
    % Optional hydrologic signatures. These are appended, not used by default.
    Dsig = dir(fullfile(dirD, ...
        'catchments_hydrological_signatures*.csv'));
    for j = 1:numel(Dsig)
        f_sig = fullfile(Dsig(j).folder,Dsig(j).name);
        try
            Ts = readtable(f_sig, ...
                'VariableNamingRule','preserve');
            Ts = local_clean_table(Ts);
            if ~ismember('ID', ...
                    Ts.Properties.VariableNames)
                continue
            end
            Ts = local_unique_id_rows(Ts,f_sig);
            Ts = local_prefix_non_id_columns( ...
                Ts,local_signature_prefix(Dsig(j).name));
            T = outerjoin(T,Ts, ...
                'Keys','ID','MergeKeys',true, ...
                'Type','left');
        catch ME
            fprintf(['      Warning:read_attr_SE: ' ...
                'Could not read hydrological ' ...
                'signature file %s.\n      %s\n'], ...
                f_sig,ME.message);
        end
    end
    
    % Sort by ID unless a basin list is supplied.
    id_all = double(T.ID(:));
    
    if ~isempty(bas) ...
            && isstruct(bas) ...
            && isfield(bas,'id_gauge') ...
            && ~isempty(bas.id_gauge)
    
        req = double(string(bas.id_gauge(:)));
        [tf,loc] = ismember(req,id_all);
    
        if any(~tf)
            miss = req(~tf);
            error('read_attr_SE:missingRequestedBasin', ...
                ['      Error:read_attr_SE: ' ...
                '%d requested CAMELS-SE ' ...
                 'basins were not found. ' ...
                 'First missing ID: %g'], ...
                nnz(~tf),miss(1));
        end
    
        T = T(loc,:);
        id_all = id_all(loc);
    else
        [id_all,ord] = sort(id_all);
        T = T(ord,:);
    end
    
    if height(T) ~= numel(unique(T.ID))
        error('read_attr_SE:duplicateJoinRows', ...
            ['Attribute table has %d rows ' ...
            'but only %d unique IDs after joins.'], ...
            height(T),numel(unique(T.ID)));
    end
    
    id_gauge = id_all(:);
    
    if ismember('Name', ...
            T.Properties.VariableNames)
        gname = string(T.Name(:));
    else
        gname = "catchment " + string(id_gauge);
    end

    gname = standardize_camels_gauge_names(gname, ...
        'CAMELS_SE',id_gauge);
    
    region = erase(mfilename,'read_attr_');
    zone = classify_camels_all_zones(region,T, ...
        min_per_zone,max_zones);

    % ------------------
    % Generic attributes
    % ------------------
    [A,labels] = build_attr_matrix(T,bas, ...
        mfilename,pr_table);

    if pr_table == 1
        assignin('base', ...
            'SAGE_SE_attribute_labels',labels);
    end
    
    % Write gauge-information file for downstream plotting/map support.
    try
        vn = T.Properties.VariableNames;
    
        lat = nan(height(T),1);
        lon = nan(height(T),1);
        area_km2 = nan(height(T),1);
    
        if ismember('Latitude_WGS84',vn)
            lat = double(T.Latitude_WGS84(:));
        end
        if ismember('Longitude_WGS84',vn)
            lon = double(T.Longitude_WGS84(:));
        end
        if ismember('Area_km2',vn)
            area_km2 = double(T.Area_km2(:));
        end
    
        G = table(id_gauge,gname,lat,lon,area_km2, ...
            'VariableNames', ...
            {'gauge_id','gauge_name', ...
            'lat','lon','area_km2'});
    
        writetable(G,fullfile(dirD, ...
            'gauge_information.txt'), ...
            'Delimiter','\t');
    catch ME
        warning('read_attr_SE:gaugeInfoWriteFailed', ...
            ['Could not write CAMELS-SE ' ...
            'gauge_information.txt: ' ...
            ME.message]);
    end
    
end

% ======================
% Local helper functions
% ======================
function T = local_clean_table(T)

    vn = T.Properties.VariableNames;
    vn = matlab.lang.makeValidName(vn, ...
        'ReplacementStyle','underscore');
    T.Properties.VariableNames = vn;
    
    % Remove completely empty columns sometimes produced by spreadsheet exports.
    keep = true(1,width(T));
    for j = 1:width(T)
        x = T.(j);
        if isnumeric(x)
            keep(j) = ~all(isnan(x));
        elseif iscellstr(x) ...
                || isstring(x)
            keep(j) = any(strlength(strtrim(string(x))) > 0);
        end
    end
    T = T(:,keep);

end

% ================================
function local_require_id(T,fname)
% ================================
    if ~ismember('ID',T.Properties.VariableNames)
        error('read_attr_SE:missingID', ...
            ['Error:read_attr_SE: ' ...
            'File %s has no ID column.'],fname);
    end
end

% ================================================
function T = local_prefix_non_id_columns(T,prefix)
% ================================================
    vn = T.Properties.VariableNames;
    for j = 1:numel(vn)
        if strcmp(vn{j},'ID')
            continue
        end
        vn{j} = matlab.lang.makeValidName( ...
            [prefix '_' vn{j}]);
    end
    T.Properties.VariableNames = vn;
end

% ========================================
function p = local_signature_prefix(fname)
% ========================================
    [~,b] = fileparts(fname);
    b = regexprep(b, ...
        '^catchments_hydrological_signatures_?','hs_');
    b = regexprep(b,'[^A-Za-z0-9]+','_');
    b = regexprep(b,'_+$','');
    p = matlab.lang.makeValidName(b);

end

% ========================================
function T = local_unique_id_rows(T,fname)
% ========================================

    [~,ia] = unique(T.ID,'stable');
    
    if numel(ia) ~= height(T)
        warning('read_attr_SE:duplicateIDs', ...
            ['File %s has duplicate IDs. ', ...
            'Keeping first row for each ID.'],fname);
        T = T(ia,:);
    end

end
