function dat = read_Q_IS(dirQ,mdl,dat,bas,split,aux) %#ok<INUSD>
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%READ_Q_IS Read LamaH-Ice discharge.
%
% Expected folders:
%   Data/CAMELS_IS/daily/discharge
%   Data/CAMELS_IS/hourly/discharge
%
% qobs is read in m3/s and converted to:
%   daily  -> mm/day
%   hourly -> mm/hour
%
% Quality control:
%   qc_flag <= 100 is retained:
%       40  good
%       80  fair
%       100 estimated
%   qc_flag > 100, missing qc_flag, negative qobs, and missing qobs are
%   assigned NaN and excluded through dat{k}.bad.
%
% Hourly discharge files do not contain an hour column. Their timestamps
% are therefore taken from the matching LamaH-Ice hourly forcing file.
% For each calendar day, discharge rows are aligned to the explicit forcing
% timestamps only when both files contain the same number of rows that day.
% Days with inconsistent row counts are left missing rather than shifted.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    dt = double(split.dt);
    qcMax = 100;

    if ~any(dt == [1 24])
        error('read_Q_IS:badDt', ...
            'LamaH-Ice requires split.dt = 1 or 24.');
    end

    if dt == 24
        stream = 'hourly';
        secondsPerStep = 3600;
    else
        stream = 'daily';
        secondsPerStep = 86400;
    end

    dirD = local_resolve_dir( ...
        dirQ,stream,'discharge');

    ids = local_ids(bas.id_gauge);
    K = bas.K;

    tReq = local_window(split,dt,false);
    n = numel(tReq);

    cacheDir = fullfile(dirD, ...
        sprintf('_cache_IS_%s_Q_v2',stream));

    if ~isfolder(cacheDir)
        mkdir(cacheDir);
    end

    fprintf(['... Reading %s CAMELS-IS ' ...
        'discharge files %3d%%'], ...
        stream,0);

    for k = 1:K
        fname = fullfile( ...
            dirD,"ID_" + ids(k) + ".csv");

        if ~isfile(fname)
            error('read_Q_IS:missingFile', ...
                'Missing Iceland discharge file: %s', ...
                fname);
        end

        area_km2 = local_area_km2( ...
            k,bas,aux,dirD,ids(k));

        if ~isfinite(area_km2) || area_km2 <= 0
            error('read_Q_IS:area', ...
                ['Missing positive catchment area ' ...
                 'for Iceland basin %s.'], ...
                ids(k));
        end

        cacheFile = local_cache_file( ...
            cacheDir,ids(k),stream, ...
            tReq,'Q');

        useCache = false;

        if isfile(cacheFile)
            try
                S = load(cacheFile, ...
                    'y','badQ','src_datenum', ...
                    'area_km2','qcMaxUsed');

                info = dir(fname);

                if isfield(S,'src_datenum') ...
                        && S.src_datenum >= info.datenum ...
                        && isfield(S,'area_km2') ...
                        && abs(S.area_km2-area_km2) < 1e-10 ...
                        && isfield(S,'qcMaxUsed') ...
                        && isequal(double(S.qcMaxUsed),double(qcMax)) ...
                        && numel(S.y) == n

                    y = S.y;
                    badQ = S.badQ;
                    useCache = true;
                end
            catch
                useCache = false;
            end
        end

        if ~useCache
            T = local_read_table(fname);

            Y = local_col(T,{'YYYY'});
            M = local_col(T,{'MM'});
            D = local_col(T,{'DD'});

            day = datetime(Y,M,D);

            if dt == 24
                tf = local_hourly_time(T,day,fname);
            else
                tf = day;
            end

            q = local_col(T,{'qobs'});
            qc = local_col(T,{'qc_flag','qcflag','quality_code', ...
                'qualitycode'});

            % Retain good, fair, and estimated discharge observations.
            % Suspect, unchecked, missing, or unclassified values are NaN.
            badSource = ~isfinite(q) | q < 0 ...
                | ~isfinite(qc) | qc > qcMax;
            q(badSource) = NaN;

            [tf,ia] = unique(tf,'stable');
            q = q(ia);
            qc = qc(ia); %#ok<NASGU>

            % qobs is m^3 s^-1 and area_km2 is km^2.
            % This yields:
            %   daily  : qobs * 86.4 / area_km2  [mm day^-1]
            %   hourly : qobs *  3.6 / area_km2  [mm hour^-1]
            qmm = q ...
                * secondsPerStep ...
                * 1000 ...
                / (area_km2 * 1e6);

            y = nan(n,1);

            [ok,loc] = ismember(tReq,tf);
            y(ok) = qmm(loc(ok));

            badQ = ~isfinite(y);

            try
                info = dir(fname);
                src_datenum = info.datenum;
                qcMaxUsed = qcMax;
                save(cacheFile, ...
                    'y','badQ','src_datenum', ...
                    'area_km2','qcMaxUsed','-v7.3');
            catch
            end
        end

        dat{k}.y_n = single(y);
        dat{k}.bad = badQ(:)';
        dat{k}.fname{2} = char(fname);
        dat{k}.gauge = ids(k);

        if mod(k,10) == 0 || k == K
            fprintf('\b\b\b\b%3d%%', ...
                floor(100*k/K));
            drawnow
        end
        
        if isfield(bas,'progressFcn') ...
                && ~isempty(bas.progressFcn)
            try
                bas.progressFcn(k);
            catch MEprogress
                warning('read_Q_IS:progressFcn', ...
                    'GUI progress callback failed: %s', ...
                    MEprogress.message);
            end
        end
    end

    fprintf('\b\b\b\b... Done\n');
end

function tf = local_hourly_time(T,day,fname)
% Construct hourly timestamps directly from the discharge row order.
%
% LamaH-Ice hourly discharge files contain YYYY/MM/DD but no hour column.
% Rows are chronological. The number of rows on the first source day
% determines the starting hour:
%
%   24 rows -> starts at 00:00
%   18 rows -> starts at 06:00
%    1 row  -> starts at 23:00
%
% After the first day, each source day normally contains 24 rows and is
% assigned 00:00--23:00. A partial final day is assigned from 00:00 onward.
% No forcing file is needed to define the discharge clock.

    names = lower(string(T.Properties.VariableNames));
    hasHour = any(ismember(names,{'hh','hour','hod'}));
    hasMinute = any(ismember(names,{'mm','minute'}));

    if hasHour
        H = local_col(T,{'hh','hour','HOD'});
        if hasMinute
            MN = local_col(T,{'mm','minute'});
        else
            MN = zeros(height(T),1);
        end
        tf = dateshift(day + hours(H) + minutes(MN),'start','hour');
        return
    end

    day = dateshift(day(:),'start','day');
    nRow = numel(day);
    tf = NaT(nRow,1);

    % Find contiguous source-day blocks without repeatedly scanning the
    % complete file. This is O(number of rows), rather than O(days*rows).
    isNewDay = [true; diff(day) ~= days(0)];
    blockStart = find(isNewDay);
    blockEnd = [blockStart(2:end)-1; nRow];
    nBlock = numel(blockStart);

    badBlock = false(nBlock,1);
    blockCount = blockEnd - blockStart + 1;

    for b = 1:nBlock
        idx = blockStart(b):blockEnd(b);
        nThis = blockCount(b);

        if b == 1
            % A partial first day represents the final nThis hours.
            startHour = 24 - nThis;
        else
            % Subsequent days start at midnight. This also handles a
            % partial final day naturally.
            startHour = 0;
        end

        if nThis < 1 || nThis > 24 || startHour < 0
            badBlock(b) = true;
            continue
        end

        tf(idx) = day(idx) + hours(startHour + (0:nThis-1)');
    end

    if any(badBlock)
        ib = find(badBlock);
        nShow = min(5,numel(ib));
        details = strings(nShow,1);
        for j = 1:nShow
            b = ib(j);
        
            d = day(blockStart(b));
            d.Format = 'yyyy-MM-dd';
        
            details(j) = sprintf('%s: %d rows', ...
                string(d), blockCount(b));
        end
        more = '';
        if numel(ib) > nShow
            more = sprintf(' (+%d more day(s))',numel(ib)-nShow);
        end
        warning('read_Q_IS:hourAlignment', ...
            ['Invalid hourly discharge row count in %d source day(s) of ' ...
             '%s. A day may contain at most 24 hourly rows. %s%s'], ...
            numel(ib),fname,strjoin(cellstr(details),'; '),more);
    end
end

function area_km2 = local_area_km2(k,bas,aux,dirD,gaugeID)
% Return catchment area strictly in km^2.
%
% read_meteo_IS stores aux(:,3) in m^2. LamaH-Ice area_calc and
% gauge_information.txt store area in km^2. Keeping this distinction
% explicit prevents an accidental second multiplication by 10^6.

    % Fields whose units are explicitly km^2.
    explicitKm2 = {'area_km2','area_calc'};
    for i = 1:numel(explicitKm2)
        name = explicitKm2{i};
        if isfield(bas,name) && numel(bas.(name)) >= k
            value = double(bas.(name)(k));
            if isfinite(value) && value > 0
                area_km2 = value;
                return
            end
        end
    end

    % Generic area field: accept either m^2 or km^2.
    if isfield(bas,'area') && numel(bas.area) >= k
        value = double(bas.area(k));
        if isfinite(value) && value > 0
            if value >= 1e7
                area_km2 = value / 1e6;
            else
                area_km2 = value;
            end
            return
        end
    end

    % read_meteo_IS documents aux(:,3) as area in m^2.
    if nargin >= 3 && ~isempty(aux) ...
            && size(aux,1) >= k && size(aux,2) >= 3
        value = double(aux(k,3));
        if isfinite(value) && value > 0
            area_km2 = value / 1e6;
            return
        end
    end

    % Catchment_attributes.csv area_calc is in km^2.
    area_km2 = local_area_from_file(dirD,gaugeID);
end

function area = local_area_from_file(startDir,gaugeID)
% Read area_calc [km^2] from the root Iceland attribute file.

    area = NaN;
    attrFile = local_find_attr_file( ...
        startDir);

    if isempty(attrFile)
        return
    end

    persistent cachedFile
    persistent cachedID
    persistent cachedArea

    if isempty(cachedFile) ...
            || ~strcmp(cachedFile,attrFile)

        T = local_read_table(attrFile);

        idName = local_find_column( ...
            T,{'id','gauge_id'});

        areaName = local_find_column( ...
            T,{'area_calc','area','area_km2'});

        if isempty(idName) ...
                || isempty(areaName)
            return
        end

        cachedID = local_ids( ...
            T.(idName));

        values = T.(areaName);

        if isnumeric(values)
            cachedArea = double(values);
        else
            cachedArea = str2double( ...
                strrep(string(values), ...
                ',','.'));
        end

        cachedArea = cachedArea(:);
        cachedFile = attrFile;
    end

    target = local_ids(gaugeID);
    j = find(cachedID == target, ...
        1,'first');

    if isempty(j)
        return
    end

    value = cachedArea(j);

    if isfinite(value) ...
            && value > 0
        area = value;
    end
end

function attrFile = local_find_attr_file(startDir)

    attrFile = '';
    p = char(string(startDir));

    for level = 1:6
        f = fullfile( ...
            p,'Catchment_attributes.csv');

        if isfile(f)
            attrFile = f;
            return
        end

        parent = fileparts(p);

        if isempty(parent) ...
                || strcmp(parent,p)
            break
        end

        p = parent;
    end
end

function name = local_find_column(T,candidates)

    name = '';
    names = string( ...
        T.Properties.VariableNames);

    keys = local_column_keys(names);
    targets = local_column_keys( ...
        string(candidates));

    j = find(ismember( ...
        keys,targets),1);

    if ~isempty(j)
        name = char(names(j));
    end
end

function keys = local_column_keys(names)

    keys = lower(strtrim( ...
        string(names)));

    keys = regexprep( ...
        keys,'[^a-z0-9]','');

    generatedX = ~cellfun( ...
        'isempty',regexp( ...
        cellstr(keys), ...
        '^x[0-9]','once'));

    keys(generatedX) = ...
        extractAfter( ...
        keys(generatedX),1);
end

function dirOut = local_resolve_dir(pathIn,stream,leaf)

    pathIn = char(string(pathIn));

    candidates = local_candidates( ...
        pathIn,stream,leaf);

    for i = 1:numel(candidates)
        d = candidates{i};

        if isfolder(d) ...
                && ~isempty(dir( ...
                fullfile(d,'ID_*.csv')))
            dirOut = d;
            return
        end
    end

    msg = strjoin(candidates,newline);

    error('read_Q_IS:dir', ...
        ['Cannot resolve Iceland %s directory.' ...
         newline 'Checked:' newline '%s'], ...
        leaf,msg);
end

function c = local_candidates( ...
        pathIn,stream,leaf)

    c = {};
    p = pathIn;

    for level = 1:6
        c{end+1} = p; %#ok<AGROW>
        c{end+1} = fullfile(p,leaf); %#ok<AGROW>
        c{end+1} = fullfile( ...
            p,stream,leaf); %#ok<AGROW>
        c{end+1} = fullfile( ...
            p,'CAMELS_IS',stream,leaf); %#ok<AGROW>
        c{end+1} = fullfile( ...
            p,'Data','CAMELS_IS', ...
            stream,leaf); %#ok<AGROW>

        parent = fileparts(p);

        if isempty(parent) ...
                || strcmp(parent,p)
            break
        end

        p = parent;
    end

    c = unique(c,'stable');
end

function ids = local_ids(x)

    ids = regexprep( ...
        strtrim(string(x(:))), ...
        '[^0-9]','');
end

function T = local_read_table(fname)

    opts = detectImportOptions( ...
        fname,'FileType','text', ...
        'Delimiter',';', ...
        'VariableNamingRule','preserve');

    T = readtable(fname,opts);

    if width(T) == 1
        opts = detectImportOptions( ...
            fname,'FileType','text', ...
            'Delimiter',',', ...
            'VariableNamingRule','preserve');

        T = readtable(fname,opts);
    end

    names = strtrim(string( ...
        T.Properties.VariableNames));

    names = matlab.lang.makeValidName(names);
    names = matlab.lang.makeUniqueStrings(names);

    T.Properties.VariableNames = names;
end

function x = local_col(T,candidates)

    names = string( ...
        T.Properties.VariableNames);

    nameKeys = local_column_keys(names);
    targetKeys = local_column_keys( ...
        string(candidates));

    j = find(ismember( ...
        nameKeys,targetKeys),1);

    if isempty(j)
        error('read_Q_IS:column', ...
            ['Missing column: %s.' newline ...
             'Available columns: %s'], ...
            strjoin(candidates,', '), ...
            strjoin(cellstr(names),', '));
    end

    value = T{:,j};

    if isnumeric(value)
        x = double(value);

    elseif islogical(value)
        x = double(value);

    elseif iscell(value)
        x = local_cell_to_double(value);

    elseif isstring(value) ...
            || ischar(value) ...
            || iscategorical(value)
        x = local_text_to_double(value);

    else
        try
            x = double(value);
        catch
            x = local_text_to_double( ...
                string(value));
        end
    end

    x = x(:);
end

function x = local_cell_to_double(value)

    x = nan(numel(value),1);

    for i = 1:numel(value)
        v = value{i};

        if isempty(v)
            continue
        end

        if isnumeric(v) ...
                || islogical(v)
            if isscalar(v)
                x(i) = double(v);
            end
        else
            x(i) = local_text_scalar( ...
                string(v));
        end
    end
end

function x = local_text_to_double(value)

    s = string(value);
    x = nan(numel(s),1);

    for i = 1:numel(s)
        x(i) = local_text_scalar(s(i));
    end
end

function x = local_text_scalar(value)

    s = strtrim(string(value));

    if ismissing(s) ...
            || s == "" ...
            || strcmpi(s,'NA') ...
            || strcmpi(s,'NaN') ...
            || strcmpi(s,'null')
        x = NaN;
        return
    end

    s = replace(s,',','.');
    x = str2double(s);
end

function cacheFile = local_cache_file( ...
        cacheDir,gid,stream,tReq,kind)

    t0 = tReq(1);
    t1 = tReq(end);

    t0.Format = 'yyyyMMddHHmm';
    t1.Format = 'yyyyMMddHHmm';

    key = sprintf('%s_%s', ...
        char(t0),char(t1));

    cacheFile = fullfile(cacheDir, ...
        sprintf('%s_IS_%s_%s_%s.mat', ...
        char(gid),stream,kind,key));
end

function t = local_window(split,dt,includeSpinup)

    if exist('build_requested_window', ...
            'file') == 2
        try
            req = build_requested_window( ...
                split,includeSpinup);

            if isfield(req,'read_start_N') ...
                    && isfield(req,'read_end_N')

                ref = datetime( ...
                    1950,10,1,0,0,0);

                if dt == 24
                    t0 = ref + hours( ...
                        double(req.read_start_N));
                    t1 = ref + hours( ...
                        double(req.read_end_N));
                    t = (t0:hours(1):t1)';
                else
                    t0 = ref + days( ...
                        double(req.read_start_N));
                    t1 = ref + days( ...
                        double(req.read_end_N));

                    t = ( ...
                        dateshift(t0,'start','day'): ...
                        days(1): ...
                        dateshift(t1,'start','day'))';
                end

                return
            end

            if isfield(req,'time') ...
                    && ~isempty(req.time)

                t = datetime(req.time(:));

                if dt == 24
                    t = dateshift( ...
                        t,'start','hour');
                else
                    t = dateshift( ...
                        t,'start','day');
                end

                return
            end
        catch
        end
    end

    starts = local_collect_dates( ...
        split,{ ...
        'ds','dts','des','d1', ...
        'dt_train0','dt_eval0'});

    ends = local_collect_dates( ...
        split,{ ...
        'de','dte','dee','d2', ...
        'dt_train1','dt_eval1'});

    if isempty(starts) ...
            || isempty(ends)
        error('read_Q_IS:window', ...
            'Cannot determine requested time window.');
    end

    t0 = min(starts);
    t1 = max(ends);

    if dt == 24
        t0 = dateshift(t0,'start','hour');
        t1 = dateshift(t1,'start','hour');
        t = (t0:hours(1):t1)';
    else
        t0 = dateshift(t0,'start','day');
        t1 = dateshift(t1,'start','day');
        t = (t0:days(1):t1)';
    end
end

function dates = local_collect_dates(split,names)

    dates = NaT(0,1);

    for i = 1:numel(names)
        name = names{i};

        if isfield(split,name) ...
                && ~isempty(split.(name))

            value = local_to_datetime( ...
                split.(name));

            dates = [dates; value(:)]; %#ok<AGROW>
        end
    end

    dates = dates(~isnat(dates));
end

function t = local_to_datetime(value)

    if isdatetime(value)
        t = value(:);
        return
    end

    if isnumeric(value)
        value = double(value);

        if isvector(value) ...
                && numel(value) >= 3 ...
                && numel(value) <= 6

            value = value(:)';

            if value(1) <= 31 ...
                    && value(2) <= 12 ...
                    && value(3) >= 1000
                t = datetime( ...
                    value(3),value(2),value(1));
            else
                t = datetime( ...
                    value(1),value(2),value(3));
            end
        else
            t = datetime( ...
                value(:), ...
                'ConvertFrom','datenum');
        end
        return
    end
    t = datetime(string(value(:)));
end
