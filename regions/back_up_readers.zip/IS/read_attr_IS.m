function [A,id_gauge,gname,zone] = read_attr_IS(dirD,bas)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%READ_ATTR_IS Read LamaH-Ice gauge and catchment attributes.
%
% Expected files:
%   Data/CAMELS_IS/Catchment_attributes.csv
%   Data/CAMELS_IS/Gauge_attributes.csv
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    if nargin<2 ...
            || isempty(bas)
        bas=struct(); 
    end
    if ~isfolder(dirD)
        error('read_attr_IS:missingDir', ...
            'Missing %s',dirD); 
    end
    fC = fullfile(dirD,'Catchment_attributes.csv');
    fG = fullfile(dirD,'Gauge_attributes.csv');
    must_exist(fC,'Catchment_attributes.csv',mfilename);
    must_exist(fG,'Gauge_attributes.csv',mfilename);
    fprintf('... Reading CAMELS-IS / LamaH-Ice basin attributes ');
    C = local_read(fC); 
    G = local_read(fG);
    C.id = local_id(C.id); 
    G.id = local_id(G.id);
    ids = intersect(string(G.id),string(C.id),'stable');
    [~,o] = sort(str2double(ids)); 
    ids = ids(o);
    [~,ig] = ismember(ids,string(G.id)); 
    [~,ic] = ismember(ids,string(C.id));
    G = G(ig,:); 
    C = C(ic,:);
    AA = G;
    cv = C.Properties.VariableNames; 
    cv(strcmp(cv,'id')) = [];
    for j=1:numel(cv)
        nm=cv{j}; nn=nm;
        if ismember(nn,AA.Properties.VariableNames)
            nn = [nn '_catch'];  %#ok
        end
        AA.(nn) = C.(nm);
    end
    % Gauge coordinates are ISN93 / Lambert 1993 (EPSG:3057).
    if all(ismember({'lon','lat'},AA.Properties.VariableNames))
        x = double(AA.lon); 
        y = double(AA.lat);
        try
            if any(abs(x)>180 | abs(y)>90)
                p = projcrs(3057); 
                [la,lo]=projinv(p,x,y);
                AA.gauge_lat = la; 
                AA.gauge_lon = lo;
            else
                AA.gauge_lat = y; 
                AA.gauge_lon = x;
            end
        catch ME
            error('read_attr_IS:coordTransformFailed', ...
                ['Could not transform Iceland ' ...
                'coordinates: %s'],ME.message);
        end
    end
    if ismember('elevation',AA.Properties.VariableNames)
        AA.gauge_elev=double(AA.elevation); 
    end
    if ismember('area_calc',AA.Properties.VariableNames)
        AA.area=double(AA.area_calc); 
    end
    if isfield(bas,'id_gauge') ...
            && ~isempty(bas.id_gauge)
        req=local_id(bas.id_gauge(:)); 
        [tf,loc]=ismember(req,ids);
        if ~all(tf)
            error('read_attr_IS:missingGauge', ...
                'Missing Iceland basin %s.',req(find(~tf,1))); 
        end
        AA=AA(loc,:); id_gauge=req;
    else
        id_gauge=ids(:);
    end
    gname="IS_"+id_gauge;
    if all(ismember({'name','river'}, ...
            AA.Properties.VariableNames))
        nm=strtrim(string(AA.name)); 
        rv=strtrim(string(AA.river));
        good=nm~="" & ~ismissing(nm); 
        gname(good)=nm(good);
        both=good & rv~="" & ~ismissing(rv); 
        gname(both)=nm(both)+": "+rv(both);
    end

    gname = standardize_camels_gauge_names(gname, ...
        'CAMELS_IS',id_gauge);
    local_gauge_info(dirD,AA,id_gauge,gname);
    minz = 5; maxz = 8;
    if isfield(bas,'min_per_zone')
        minz = bas.min_per_zone; 
    end
    if isfield(bas,'max_zones')
        maxz = bas.max_zones; 
    end
    zone = classify_camels_all_zones('IS',AA,minz,maxz);
    pr=1; 
    if isfield(bas,'pr_attr')
        pr = bas.pr_attr; 
    end
    [A,labels]=build_attr_matrix(AA,bas,mfilename,pr);
    if pr==1
        assignin('base','SAGE_IS_attribute_labels',labels); 
    end
    fprintf(' ... Done\n');
end
% Prepare
function T=local_read(f)
    opts = detectImportOptions(f,'FileType', ...
        'text','Delimiter', ...
        ';','VariableNamingRule','preserve');
    T = readtable(f,opts); 
    if width(T)==1
        opts = detectImportOptions(f,'FileType', ...
            'text','Delimiter',',', ...
            'VariableNamingRule','preserve'); 
        T = readtable(f,opts);
    end
    T.Properties.VariableNames = ...
        matlab.lang.makeUniqueStrings( ...
        matlab.lang.makeValidName( ...
        strtrim(string(T.Properties.VariableNames))));
end

function id = local_id(x)
    id=regexprep(strtrim(string(x(:))),'[^0-9]','');
end

function local_gauge_info(dirD,A,id,nm)
    f = fullfile(dirD,'gauge_information.txt'); 
    if isfile(f)
        return
    end
    T = table(id(:),nm(:),'VariableNames', ...
        {'gauge_id','gauge_name'});
    for q = {'gauge_lat','gauge_lon','gauge_elev','area'}
        if ismember(q{1},A.Properties.VariableNames)
            T.(q{1}) = double(A.(q{1})); 
        else
            T.(q{1})=nan(height(A),1);
        end
    end
    try
        writetable(T,f, ...
            'Delimiter','\t', ...
            'FileType','text'); 
    catch
    end
end
