function R = region_config_IS()
%REGION_CONFIG_IS Regional defaults for LamaH-Ice.
%
% All X.paths fields are relative to Data/<R.data_root>.
% Dates use dd/MM/yyyy and water-year boundaries.

    R = struct();
    R.code = 'CAMELS_IS';
    R.acronym = 'IS';
    R.name = 'Iceland';
    R.dataset = 'LamaH-Ice';
    R.data_root = 'CAMELS_IS';
    R.resolutions = {'Daily','Hourly'};
    R.default_resolution = 'Daily';
    R.basin_file_pattern = 'IS_%d_basins.txt';

    X = struct();
    X.label = 'Daily';
    X.dt = 1;
    X.basins.universe = 111;
    X.basins.file = 'IS_111_basins.txt';
    X.basins.training = 90;
    X.basins.evaluation = 21;
    X.period.spinup_days = 365;
    X.period.manual.train_start = '01/10/2012';
    X.period.manual.train_end = '30/09/2020';
    X.period.manual.eval_start = '01/10/2005';
    X.period.manual.eval_end = '30/09/2012';
    X.period.common_start = '01/10/2005';
    X.period.common_end = '30/09/2020';
    X.paths.run_root = '';
    X.paths.meteo = fullfile('daily','forcing');
    X.paths.discharge = fullfile('daily','discharge');
    % Meteorological/PET controls shown by SAGE-GUI.
    X.meteo.product.items = {'LamaH-Ice [daily]'};
    X.meteo.product.default = 'LamaH-Ice [daily]';
    X.meteo.product.enabled = false;
    X.meteo.precipitation.items = {'1 Precipitation'};
    X.meteo.precipitation.default = '1 Precipitation';
    X.meteo.precipitation.enabled = false;
    X.meteo.temperature.items = {'1 Mean'};
    X.meteo.temperature.default = '1 Mean';
    X.meteo.temperature.enabled = false;
    X.meteo.pet.items = { ...
        '0 Zero PET', ...
        '1 Penman-Monteith', ...
        '2 Priestley-Taylor', ...
        '3 Makkink', ...
        '4 LamaH-Ice PET', ...
        '5 LamaH-Ice total ET' ...
        };
    X.meteo.pet.default = '1 Penman-Monteith';
    X.meteo.pet.enabled = true;
    C = repmat(struct('name','','type','','path','','pattern','', ...
        'minimum_count',1,'required',true),0,1);
    C(1).name = 'Meteorological data';
    C(1).type = 'folder';
    C(1).path = fullfile('daily','forcing');
    C(1).pattern = '*';
    C(1).minimum_count = 1;
    X.checks = C;
    R.by_resolution.Daily = X;

    X = struct();
    X.label = 'Hourly';
    X.dt = 24;
    X.basins.universe = 76;
    X.basins.file = 'IS_76_basins.txt';
    X.basins.training = 65;
    X.basins.evaluation = 11;
    X.period.spinup_days = 365;
    X.period.manual.train_start = '01/10/2012';
    X.period.manual.train_end = '30/09/2020';
    X.period.manual.eval_start = '01/10/2005';
    X.period.manual.eval_end = '30/09/2012';
    X.period.common_start = '01/10/2005';
    X.period.common_end = '30/09/2020';
    X.paths.run_root = '';
    X.paths.meteo = fullfile('hourly','forcing');
    X.paths.discharge = fullfile('hourly','discharge');
    % Meteorological/PET controls shown by SAGE-GUI.
    X.meteo.product.items = {'LamaH-Ice [hourly]'};
    X.meteo.product.default = 'LamaH-Ice [hourly]';
    X.meteo.product.enabled = false;
    X.meteo.precipitation.items = {'1 Precipitation'};
    X.meteo.precipitation.default = '1 Precipitation';
    X.meteo.precipitation.enabled = false;
    X.meteo.temperature.items = {'1 Mean'};
    X.meteo.temperature.default = '1 Mean';
    X.meteo.temperature.enabled = false;
    X.meteo.pet.items = { ...
        '0 Zero PET', ...
        '1 Penman-Monteith', ...
        '2 Priestley-Taylor', ...
        '3 Makkink', ...
        '4 LamaH-Ice PET', ...
        '5 LamaH-Ice total ET' ...
        };
    X.meteo.pet.default = '1 Penman-Monteith';
    X.meteo.pet.enabled = true;
    C = repmat(struct('name','','type','','path','','pattern','', ...
        'minimum_count',1,'required',true),0,1);
    C(1).name = 'Meteorological data';
    C(1).type = 'folder';
    C(1).path = fullfile('hourly','forcing');
    C(1).pattern = '*';
    C(1).minimum_count = 1;
    X.checks = C;
    R.by_resolution.Hourly = X;

end