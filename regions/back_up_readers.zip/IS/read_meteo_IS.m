function [dat,aux] = read_meteo_IS(dirM,bas,split,meteo)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%READ_METEO_IS Read LamaH-Ice meteorological forcing.
%
% Expected folders:
%   Data/CAMELS_IS/daily/forcing
%   Data/CAMELS_IS/hourly/forcing
%
% split.dt:
%   1  = daily
%   24 = hourly
%
% PET options:
%   0 = zero PET
%   1 = Penman-Monteith
%   2 = Priestley-Taylor
%   3 = Makkink
%   4 = LamaH-Ice supplied PET (open-water potential evaporation)
%   5 = LamaH-Ice supplied total_et
%
% LamaH-Ice time conventions:
%   - all timestamps are GMT;
%   - an hourly value indexed at hour h represents the mean or sum over
%     [h,h+1), e.g. 00:00 represents 00:00--01:00;
%   - radiation is supplied as W m^-2;
%   - precipitation, PET and total_et are supplied as mm per time step;
%   - positive total_et denotes evapotranspiration and negative total_et
%     denotes condensation.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    if nargin < 4 ...
            || isempty(meteo)
        meteo = struct();
    end
    if nargin < 3
        error('read_meteo_IS:inputs', ...
            ['Expected [dat,aux] = read_meteo_IS(' ...
             'dirM,bas,split,meteo).']);
    end

    split = local_prepare_split(split);
    dt = double(split.dt);

    if ~any(dt == [1 24])
        error('read_meteo_IS:badDt', ...
            'LamaH-Ice requires split.dt = 1 or 24.');
    end

    stream = local_stream(dt);
    petopt = local_get_pet_option(meteo);
    dirF = local_resolve_dir(dirM,stream,'forcing');
    dirIS = local_root_from_forcing(dirF);

    ids = local_ids(bas.id_gauge);
    K = bas.K;

    tReq = local_window(split,dt,true);
    n = numel(tReq);
    if n == 0
        error('read_meteo_IS:emptyWindow', ...
            'The requested meteorological time window is empty.');
    end

    dat = cell(K,1);
    aux = nan(K,3);              % latitude [deg], elevation [m], area [m2]
    aux = local_aux_from_bas(bas,aux);
    try
        aux = local_aux_from_attributes(dirIS,bas,aux);
    catch ME
        fprintf(['\n      Warning:read_meteo_IS: could not read ' ...
            'Iceland attributes for latitude/elevation/area.\n']);
        fprintf('      Cause: %s\n',ME.message);
    end

    % gauge_information.txt is the authoritative fallback used by SAGE
    % for Iceland gauge latitude, elevation, and catchment area.
    try
        aux = local_aux_from_gauge_information(dirIS,bas,aux);
    catch ME
        fprintf(['\n      Warning:read_meteo_IS: could not read ' ...
            'gauge_information.txt for Iceland metadata.\n']);
        fprintf('      Cause: %s\n',ME.message);
    end

    cacheDir = fullfile(dirF, ...
        sprintf('_cache_IS_%s_meteo_pet%d_v3',stream,petopt));
    if ~isfolder(cacheDir)
        mkdir(cacheDir);
    end

    fprintf(['... Reading %s CAMELS-IS ' ...
        'meteorological files %3d%%'],stream,0);

    for k = 1:K
        fname = fullfile(dirF,"ID_" + ids(k) + ".csv");

        if ~isfile(fname)
            fprintf('\n');
            error('read_meteo_IS:missingFile', ...
                'Missing Iceland forcing file: %s',fname);
        end

        cacheFile = local_cache_file(cacheDir,ids(k),stream, ...
            petopt,tReq,'meteo');
        useCache = false;

        if isfile(cacheFile)
            try
                S = load(cacheFile,'p','tt','tmin','tmax','ep','bad', ...
                    'src_datenum');
                info = dir(fname);
                if isfield(S,'src_datenum') ...
                        && S.src_datenum >= info.datenum ...
                        && numel(S.p) == n ...
                        && numel(S.tt) == n ...
                        && numel(S.tmin) == n ...
                        && numel(S.tmax) == n ...
                        && numel(S.ep) == n
                    p = S.p;
                    tt = S.tt;
                    tmin = S.tmin;
                    tmax = S.tmax;
                    ep = S.ep;
                    bad = S.bad;
                    useCache = true;
                end
            catch
                useCache = false;
            end
        end

        if ~useCache
            [tf,P,Temp,Tmin,Tmax,E] = local_read_forcing_file( ...
                fname,dt,petopt,aux(k,1),aux(k,2));

            p = nan(n,1);
            tt = nan(n,1);
            tmin = nan(n,1);
            tmax = nan(n,1);
            ep = nan(n,1);

            [ok,loc] = ismember(tReq,tf);
            p(ok) = P(loc(ok));
            tt(ok) = Temp(loc(ok));
            tmin(ok) = Tmin(loc(ok));
            tmax(ok) = Tmax(loc(ok));
            ep(ok) = E(loc(ok));

            bad = ~isfinite(p) | ~isfinite(tt) | ~isfinite(ep);

            try
                info = dir(fname);
                src_datenum = info.datenum;
                save(cacheFile,'p','tt','tmin','tmax','ep','bad', ...
                    'src_datenum','-v7.3');
            catch
            end
        end

        dat{k}.meteo.P = single(p);
        dat{k}.meteo.T = single(tt);
        dat{k}.meteo.Tmin = single(tmin);
        dat{k}.meteo.Tmax = single(tmax);
        dat{k}.meteo.Ep = single(ep);
        dat{k}.meteo.bad = int64(find(bad))';
        dat{k}.gauge = ids(k);
        dat{k}.fname = {char(fname),char(fname)};

        if mod(k,10) == 0 || k == K
            fprintf('\b\b\b\b%3d%%',floor(100*k/K));
            drawnow
        end

        if isfield(meteo,'progressFcn') ...
                && ~isempty(meteo.progressFcn)
            try
                meteo.progressFcn(k);
            catch MEprogress
                warning('read_meteo_IS:progressFcn', ...
                    'GUI progress callback failed: %s', ...
                    MEprogress.message);
            end
        end
    end

    fprintf('\b\b\b\b... Done\n');

    if isfield(split,'local') && split.local ...
            && isfield(split,'rainfall_block') && split.rainfall_block
        dat = rainfall_rank_split(dat,split);
    end
end

% =======================================================================
function [t,P,Tmean,Tmin,Tmax,Ep] = local_read_forcing_file( ...
        fname,dt,petopt,latDeg,zM)
% =======================================================================

    T = local_read_table(fname);
    Y = local_col(T,{'YYYY','year'});
    M = local_col(T,{'MM','month'});
    D = local_col(T,{'DD','day'});

    if dt == 24
        H = local_col(T,{'hh','HH','HOD','hour'});
        MN = local_col_optional(T,{'mm','minute'});
        if isempty(MN)
            MN = zeros(height(T),1);
        end
        t = datetime(Y,M,D,H,MN,zeros(height(T),1));
        t = dateshift(t,'start','hour');
    else
        t = dateshift(datetime(Y,M,D),'start','day');
    end

    P = local_col(T,{'prec','prec_sum','precipitation'});

    if dt == 24
        Tmean = local_col(T,{'2m_temp','2m_temp_mean','tmean'});
        Tmin = Tmean;
        Tmax = Tmean;
    else
        Tmean = local_col_optional(T, ...
            {'2m_temp_mean','2m_temp','tmean','temp_mean'});
        Tmin = local_col_optional(T, ...
            {'2m_temp_min','tmin','temp_min'});
        Tmax = local_col_optional(T, ...
            {'2m_temp_max','tmax','temp_max'});

        if isempty(Tmean) && ~isempty(Tmin) && ~isempty(Tmax)
            Tmean = 0.5*(Tmin + Tmax);
        end
        if isempty(Tmean)
            error('read_meteo_IS:temperature', ...
                'No usable air-temperature column found in %s.',fname);
        end
        if isempty(Tmin)
            Tmin = Tmean;
        end
        if isempty(Tmax)
            Tmax = Tmean;
        end
    end

    switch petopt
        case 0
            Ep = zeros(height(T),1);

        case 4
            Ep = local_col(T,{'pet','pet_sum', ...
                'potential_evapotranspiration'});
            % The supplied LamaH-Ice PET is open-water potential
            % evaporation in mm per time step. Negative values are not
            % physically meaningful as PET and are treated as missing.
            Ep(Ep < 0) = NaN;

        case 5
            Ep = local_col(T,{'total_et','total_et_sum', ...
                'total_evaporation'});
            % LamaH-Ice defines positive values as evapotranspiration and
            % negative values as condensation. For hydrologic-model PET,
            % condensation is set to zero rather than sign-reversed.
            Ep = max(Ep,0);

        case {1,2,3}
            if dt == 24
                Td = local_col(T,{'2m_dp_temp','2m_dp_temp_mean', ...
                    'dewpoint','dew_point_temperature'});
                U = local_col(T,{'10m_wind_u','10m_wind_u_mean','u10'});
                V = local_col(T,{'10m_wind_v','10m_wind_v_mean','v10'});
                Rns = local_col(T,{'surf_net_solar_rad', ...
                    'surf_net_solar_rad_mean','net_solar_radiation'});
                Rnt = local_col(T,{'surf_net_therm_rad', ...
                    'surf_net_therm_rad_mean','net_thermal_radiation'});
                Press = local_col(T,{'surf_press','surf_press_mean', ...
                    'surface_pressure'});

                % Hourly LamaH convention: W m^-2 radiation and each row
                % represents the indexed hour to the following hour.
                Ep = et0_lamah_hourly(Tmean,Td,U,V,Rns,Rnt,Press,petopt);
            else
                Td = local_col_optional(T,{'2m_dp_temp_mean', ...
                    '2m_dp_temp','dewpoint_mean','dewpoint'});
                if isempty(Td)
                    Tdmin = local_col_optional(T,{'2m_dp_temp_min'});
                    Tdmax = local_col_optional(T,{'2m_dp_temp_max'});
                    if ~isempty(Tdmin) && ~isempty(Tdmax)
                        Td = 0.5*(Tdmin + Tdmax);
                    else
                        error('read_meteo_IS:dewpoint', ...
                            ['Computed PET option %d requires daily ' ...
                             'dew-point temperature in %s.'],petopt,fname);
                    end
                end

                U = local_col(T,{'10m_wind_u_mean','10m_wind_u','u10'});
                V = local_col(T,{'10m_wind_v_mean','10m_wind_v','v10'});
                Rns = local_col(T,{'surf_net_solar_rad_mean', ...
                    'surf_net_solar_rad','net_solar_radiation'});

                if ~isfinite(latDeg) || ~isfinite(zM)
                    error('read_meteo_IS:aux', ...
                        ['Computed daily PET option %d requires finite ' ...
                         'latitude and elevation for %s.'],petopt,fname);
                end

                eaPa = local_vapor_pressure_from_dewpoint(Td);
                u10 = hypot(U,V);
                u2 = local_wind10_to_wind2(u10);
                doy = day(t,'dayofyear');

                % Rns is the documented daily mean net solar flux in
                % W m^-2. et0_fao56_daily is the same SAGE helper used by
                % the Austria reader and performs the time-step conversion.
                Ep = et0_fao56_daily(Tmax,Tmin,Rns,eaPa,doy, ...
                    latDeg,zM,u2,petopt);
            end

        otherwise
            error('read_meteo_IS:pet', ...
                'Unknown PET option %d. Use 0, 1, 2, 3, 4, or 5.',petopt);
    end

    Ep(~isfinite(Ep) | Ep < 0) = NaN;

    good = ~isnat(t);
    t = t(good);
    P = P(good);
    Tmean = Tmean(good);
    Tmin = Tmin(good);
    Tmax = Tmax(good);
    Ep = Ep(good);

    [t,isrt] = sort(t);
    P = P(isrt);
    Tmean = Tmean(isrt);
    Tmin = Tmin(isrt);
    Tmax = Tmax(isrt);
    Ep = Ep(isrt);

    [t,ia] = unique(t,'stable');
    P = P(ia);
    Tmean = Tmean(ia);
    Tmin = Tmin(ia);
    Tmax = Tmax(ia);
    Ep = Ep(ia);
end

function split = local_prepare_split(split)
    if exist('prepare_split','file') == 2
        split = prepare_split(split);
    end
end

function stream = local_stream(dt)
    if dt == 24
        stream = 'hourly';
    else
        stream = 'daily';
    end
end

function pet = local_get_pet_option(meteo)
    pet = 4; % default: supplied LamaH-Ice open-water PET

    if isstruct(meteo)
        if isfield(meteo,'pet') && ~isempty(meteo.pet)
            pet = meteo.pet;
        elseif isfield(meteo,'id_pet') && ~isempty(meteo.id_pet)
            pet = meteo.id_pet;
        elseif isfield(meteo,'PET') && ~isempty(meteo.PET)
            pet = meteo.PET;
        end
    end

    if ischar(pet) || isstring(pet)
        s = lower(strtrim(string(pet)));
        tok = regexp(s,'^\s*(\d+)','tokens','once');
        if ~isempty(tok)
            pet = str2double(tok{1});
        elseif contains(s,'zero')
            pet = 0;
        elseif contains(s,'monteith')
            pet = 1;
        elseif contains(s,'priestley') || contains(s,'taylor')
            pet = 2;
        elseif contains(s,'makkink')
            pet = 3;
        elseif contains(s,'total') || contains(s,'total_et')
            pet = 5;
        elseif contains(s,'native') || contains(s,'supplied') ...
                || contains(s,'open-water') || contains(s,'pet')
            pet = 4;
        else
            pet = 4;
        end
    end

    pet = round(double(pet));
    if ~isscalar(pet) || ~isfinite(pet) ...
            || ~any(pet == [0 1 2 3 4 5])
        error('read_meteo_IS:pet', ...
            'PET option must be 0, 1, 2, 3, 4, or 5.');
    end
end

function dirOut = local_resolve_dir(pathIn,stream,leaf)
    pathIn = char(string(pathIn));
    candidates = local_candidates(pathIn,stream,leaf);

    for i = 1:numel(candidates)
        d = candidates{i};
        if isfolder(d) && ~isempty(dir(fullfile(d,'ID_*.csv')))
            dirOut = d;
            return
        end
    end

    error('read_meteo_IS:dir', ...
        ['Cannot resolve Iceland %s directory.' newline ...
         'Checked:' newline '%s'],leaf,strjoin(candidates,newline));
end

function c = local_candidates(pathIn,stream,leaf)
    c = {};
    p = pathIn;
    for level = 1:6
        c{end+1} = p; %#ok<AGROW>
        c{end+1} = fullfile(p,leaf); %#ok<AGROW>
        c{end+1} = fullfile(p,stream,leaf); %#ok<AGROW>
        c{end+1} = fullfile(p,'CAMELS_IS',stream,leaf); %#ok<AGROW>
        c{end+1} = fullfile(p,'Data','CAMELS_IS',stream,leaf); %#ok<AGROW>
        parent = fileparts(p);
        if isempty(parent) || strcmp(parent,p)
            break
        end
        p = parent;
    end
    c = unique(c,'stable');
end

function dirIS = local_root_from_forcing(dirF)
    dirIS = char(string(dirF));
    [p,nm] = fileparts(dirIS);
    if strcmpi(nm,'forcing')
        dirIS = p;
    end
    [p,nm] = fileparts(dirIS);
    if strcmpi(nm,'daily') || strcmpi(nm,'hourly')
        dirIS = p;
    end
end

function ids = local_ids(x)
    ids = regexprep(strtrim(string(x(:))),'[^0-9]','');
    if any(ids == "")
        error('read_meteo_IS:id','Empty Iceland basin ID.');
    end
end

function aux = local_aux_from_bas(bas,aux)
    K = bas.K;

    latNames = {'lat','gauge_lat','latitude','lat_deg'};
    elevNames = {'elev_mean','gauge_elev','elev','elevation'};
    areaNames = {'area_calc','area_km2','area'};

    for i = 1:numel(latNames)
        f = latNames{i};
        if isfield(bas,f) && numel(bas.(f)) >= K
            aux(:,1) = double(bas.(f)(1:K));
            break
        end
    end
    for i = 1:numel(elevNames)
        f = elevNames{i};
        if isfield(bas,f) && numel(bas.(f)) >= K
            aux(:,2) = double(bas.(f)(1:K));
            break
        end
    end
    for i = 1:numel(areaNames)
        f = areaNames{i};
        if isfield(bas,f) && numel(bas.(f)) >= K
            a = double(bas.(f)(1:K));
            if median(a,'omitnan') < 1e7
                a = 1e6*a;
            end
            aux(:,3) = a;
            break
        end
    end
end

function aux = local_aux_from_attributes(dirIS,bas,aux)
    f = fullfile(dirIS,'Catchment_attributes.csv');
    if ~isfile(f)
        return
    end

    A = local_read_table(f);
    idName = local_find_column(A,{'ID','gauge_id'});
    if isempty(idName)
        return
    end

    aid = local_ids(A.(idName));
    bid = local_ids(bas.id_gauge(:));
    [tf,loc] = ismember(bid,aid);

    latName = local_find_column(A, ...
        {'lat','latitude','lat_mean','centroid_lat','gauge_lat'});
    elevName = local_find_column(A, ...
        {'elev_mean','elevation_mean','gauge_elev','elev'});
    areaName = local_find_column(A,{'area_calc','area_km2','area'});

    if ~isempty(latName)
        x = local_to_double(A.(latName));
        bad = tf & ~isfinite(aux(:,1));
        aux(bad,1) = x(loc(bad));
    end
    if ~isempty(elevName)
        x = local_to_double(A.(elevName));
        bad = tf & ~isfinite(aux(:,2));
        aux(bad,2) = x(loc(bad));
    end
    if ~isempty(areaName)
        x = local_to_double(A.(areaName));
        if median(x,'omitnan') < 1e7
            x = 1e6*x;
        end
        bad = tf & ~isfinite(aux(:,3));
        aux(bad,3) = x(loc(bad));
    end
end

function aux = local_aux_from_gauge_information(dirIS,bas,aux)
% Fill missing latitude, elevation, and area from gauge_information.txt.
%
% Supported layouts:
%   - named columns such as id/gauge_id, lat, elev, area;
%   - the LamaH-Ice/SAGE six-column layout:
%       ID, name, latitude, longitude, elevation_m, area_km2.

    f = local_find_upward_file(dirIS,'gauge_information.txt',6);
    if isempty(f)
        return
    end

    % Try header-aware import first.
    try
        G = readtable(f,'FileType','text', ...
            'Delimiter','\t', ...
            'VariableNamingRule','preserve');
    catch
        G = table();
    end

    if isempty(G) || width(G) < 5
        % Fallback for files without a header.
        opts = detectImportOptions(f,'FileType','text', ...
            'Delimiter','\t', ...
            'VariableNamingRule','preserve');
        opts.ReadVariableNames = false;
        G = readtable(f,opts);
    end

    names = string(G.Properties.VariableNames);

    idName = local_find_column(G, ...
        {'ID','id','gauge_id','gauge','basin_id','station_id'});
    latName = local_find_column(G, ...
        {'lat','latitude','gauge_lat','lat_deg'});
    elevName = local_find_column(G, ...
        {'elev','elevation','gauge_elev','elevation_m','elev_m'});
    areaName = local_find_column(G, ...
        {'area','area_calc','area_km2','catchment_area'});

    % When the file has no usable header, use the known SAGE Iceland
    % layout demonstrated by:
    % 66, name, 63.780..., -19.417..., 423, 516.163
    if isempty(idName) && width(G) >= 1
        idName = char(names(1));
    end
    if isempty(latName) && width(G) >= 3
        latName = char(names(3));
    end
    if isempty(elevName) && width(G) >= 5
        elevName = char(names(5));
    end
    if isempty(areaName) && width(G) >= 6
        areaName = char(names(6));
    end

    if isempty(idName)
        return
    end

    gid = local_ids(G.(idName));
    bid = local_ids(bas.id_gauge(:));
    [tf,loc] = ismember(bid,gid);

    if ~isempty(latName)
        x = local_to_double(G.(latName));
        use = tf & ~isfinite(aux(:,1));
        aux(use,1) = x(loc(use));
    end

    if ~isempty(elevName)
        x = local_to_double(G.(elevName));
        use = tf & ~isfinite(aux(:,2));
        aux(use,2) = x(loc(use));
    end

    if ~isempty(areaName)
        x = local_to_double(G.(areaName));

        % gauge_information.txt normally stores km^2. Keep aux(:,3) in m^2.
        finiteX = x(isfinite(x) & x > 0);
        if ~isempty(finiteX) && median(finiteX,'omitnan') < 1e7
            x = 1e6*x;
        end

        use = tf & ~isfinite(aux(:,3));
        aux(use,3) = x(loc(use));
    end
end

function f = local_find_upward_file(startDir,fileName,maxLevels)
    f = '';
    p = char(string(startDir));

    for level = 1:maxLevels
        candidate = fullfile(p,fileName);
        if isfile(candidate)
            f = candidate;
            return
        end

        % Also accept metadata subfolders commonly used by SAGE.
        candidate = fullfile(p,'metadata',fileName);
        if isfile(candidate)
            f = candidate;
            return
        end

        parent = fileparts(p);
        if isempty(parent) || strcmp(parent,p)
            break
        end
        p = parent;
    end
end

function T = local_read_table(fname)
    delim = local_detect_delimiter(fname);
    opts = detectImportOptions(char(fname),'FileType','text', ...
        'Delimiter',delim,'VariableNamingRule','preserve');
    T = readtable(char(fname),opts);

    names = strtrim(string(T.Properties.VariableNames));
    names = matlab.lang.makeUniqueStrings( ...
        matlab.lang.makeValidName(names));
    T.Properties.VariableNames = names;
end

function delim = local_detect_delimiter(fname)
    fid = fopen(char(fname),'r');
    if fid < 0
        error('read_meteo_IS:open','Cannot open %s.',fname);
    end
    c = onCleanup(@() fclose(fid));
    line = fgetl(fid);
    if ~ischar(line)
        error('read_meteo_IS:empty','Empty file: %s.',fname);
    end
    counts = [count(string(line),";"),count(string(line),","), ...
        count(string(line),sprintf('\t'))];
    [~,j] = max(counts);
    choices = {';',',','\t'};
    delim = choices{j};
end

function x = local_col(T,candidates)
    x = local_col_optional(T,candidates);
    if isempty(x)
        error('read_meteo_IS:column', ...
            ['Missing column: %s.' newline 'Available columns: %s'], ...
            strjoin(candidates,', '), ...
            strjoin(cellstr(string(T.Properties.VariableNames)),', '));
    end
end

function x = local_col_optional(T,candidates)
    names = string(T.Properties.VariableNames);
    keys = local_column_keys(names);
    targetKeys = local_column_keys(string(candidates));
    j = find(ismember(keys,targetKeys),1);
    if isempty(j)
        x = [];
    else
        x = local_to_double(T{:,j});
    end
end

function name = local_find_column(T,candidates)
    name = '';
    names = string(T.Properties.VariableNames);
    keys = local_column_keys(names);
    targetKeys = local_column_keys(string(candidates));
    j = find(ismember(keys,targetKeys),1);
    if ~isempty(j)
        name = char(names(j));
    end
end

function keys = local_column_keys(names)
    keys = lower(strtrim(string(names)));
    keys = regexprep(keys,'[^a-z0-9]','');
    generatedX = ~cellfun('isempty', ...
        regexp(cellstr(keys),'^x[0-9]','once'));
    keys(generatedX) = extractAfter(keys(generatedX),1);
end

function x = local_to_double(value)
    if isnumeric(value) || islogical(value)
        x = double(value(:));
    elseif iscell(value)
        x = nan(numel(value),1);
        for i = 1:numel(value)
            if isnumeric(value{i}) && isscalar(value{i})
                x(i) = double(value{i});
            else
                x(i) = str2double(replace(strtrim(string(value{i})),',','.'));
            end
        end
    else
        s = string(value(:));
        s = replace(strtrim(s),',','.');
        s(ismissing(s) | s == "" | strcmpi(s,"NA") ...
            | strcmpi(s,"null")) = "NaN";
        x = str2double(s);
    end
    x(x <= -999) = NaN;
end

function eaPa = local_vapor_pressure_from_dewpoint(TdC)
    eaPa = 1000 .* 0.6108 .* exp(17.27 .* TdC ./ (TdC + 237.3));
end

function u2 = local_wind10_to_wind2(u10)
    u2 = u10 .* (4.87 ./ log(67.8*10 - 5.42));
end

function cacheFile = local_cache_file(cacheDir,gid,stream,option,tReq,kind)
    t0 = tReq(1);
    t1 = tReq(end);
    t0.Format = 'yyyyMMddHHmm';
    t1.Format = 'yyyyMMddHHmm';
    key = sprintf('%s_%s',char(t0),char(t1));
    cacheFile = fullfile(cacheDir,sprintf( ...
        '%s_IS_%s_%s_opt%d_%s.mat',char(gid),stream,kind,option,key));
end

function t = local_window(split,dt,includeSpinup)
    if exist('build_requested_window','file') == 2
        try
            req = build_requested_window(split,includeSpinup);
            if isfield(req,'read_start_N') && isfield(req,'read_end_N')
                ref = datetime(1950,10,1,0,0,0);
                if dt == 24
                    t0 = ref + hours(double(req.read_start_N));
                    t1 = ref + hours(double(req.read_end_N));
                    t = (t0:hours(1):t1)';
                else
                    t0 = ref + days(double(req.read_start_N));
                    t1 = ref + days(double(req.read_end_N));
                    t = (dateshift(t0,'start','day'):days(1): ...
                        dateshift(t1,'start','day'))';
                end
                return
            elseif isfield(req,'time') && ~isempty(req.time)
                t = datetime(req.time(:));
                if dt == 24
                    t = dateshift(t,'start','hour');
                else
                    t = dateshift(t,'start','day');
                end
                return
            end
        catch
        end
    end

    stepHours = 24/dt;
    spinup = 0;
    if includeSpinup
        if isfield(split,'spinup') && ~isempty(split.spinup)
            spinup = max(0,round(double(split.spinup(1))));
        elseif isfield(split,'n_spin') && ~isempty(split.n_spin)
            spinup = max(0,round(double(split.n_spin(1))));
        end
    end

    starts = local_collect_dates(split, ...
        {'ds','dts','des','d1','dt_train0','dt_eval0'});
    ends = local_collect_dates(split, ...
        {'de','dte','dee','d2','dt_train1','dt_eval1'});

    if isempty(starts) || isempty(ends)
        error('read_meteo_IS:window', ...
            'Cannot determine requested time window.');
    end

    t0 = min(starts);
    t1 = max(ends);
    if includeSpinup && isfield(split,'dt_spin0') ...
            && ~isempty(split.dt_spin0)
        spinDate = local_to_datetime(split.dt_spin0);
        spinDate = spinDate(~isnat(spinDate));
        if ~isempty(spinDate)
            t0 = min(t0,min(spinDate));
            spinup = 0;
        end
    end
    t0 = t0 - hours(spinup*stepHours);

    if dt == 24
        t = (dateshift(t0,'start','hour'):hours(1): ...
            dateshift(t1,'start','hour'))';
    else
        t = (dateshift(t0,'start','day'):days(1): ...
            dateshift(t1,'start','day'))';
    end
end

function dates = local_collect_dates(split,names)
    dates = NaT(0,1);
    for i = 1:numel(names)
        name = names{i};
        if isfield(split,name) && ~isempty(split.(name))
            dates = [dates; local_to_datetime(split.(name))]; %#ok<AGROW>
        end
    end
    dates = dates(~isnat(dates));
end

function t = local_to_datetime(value)
    if isdatetime(value)
        t = value(:);
        return
    end
    if isnumeric(value)
        value = double(value);
        if isvector(value) && numel(value) >= 3 && numel(value) <= 6
            value = value(:)';
            if value(1) <= 31 && value(2) <= 12 && value(3) >= 1000
                t = datetime(value(3),value(2),value(1));
            else
                t = datetime(value(1),value(2),value(3));
            end
        else
            t = datetime(value(:),'ConvertFrom','datenum');
        end
        return
    end
    t = datetime(string(value(:)));
end
