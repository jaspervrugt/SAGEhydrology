function [dat,aux] = read_meteo_AU(dirM,bas,split,meteo)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%READ_METEO_AU Read CAMELS-AU daily meteorological data for SAGE.
%
% SYNOPSIS:
%   [dat,aux] = read_meteo_AU(dirM,bas,split,meteo)
%
% INPUT:
%   dirM        CAMELS-AU data directory, normally .../Data/CAMELS_AU
%   bas         basin structure with fields
%    .K          number of selected basins
%    .id_gauge   Kx1 station IDs ina final basin order
%   split       SAGE split structure. Supports daily dt = 1 only.
%               Uses spinup-aware requested window from ds/de or dts/dte.
%   meteo       options structure
%    .data       precipitation source:
%                 1 precipitation_SILO.csv [default]
%                 2 precipitation_AWAP.csv
%    .pet        evaporative-demand/PET source, SILO only:
%                 1 evap_syn_SILO.csv [default; recommended first choice]
%                 2 evap_pan_SILO.csv
%                 3 evap_morton_lake_SILO.csv
%                 4 et_tall_crop_SILO.csv
%                 5 et_short_crop_SILO.csv
%                 6 et_morton_wet_SILO.csv
%                 7 et_morton_point_SILO.csv
%                 8 et_morton_actual_SILO.csv [actual ET; not PET]
%    .temp       temperature source:
%                 1 mean(tmin_SILO,tmax_SILO) [default]
%                 2 mean(tmin_AWAP,tmax_AWAP)
%    .progressFcn OPTIONAL function handle called progressFcn(k)
%
% OUTPUT:
%   dat         OUTPUT: Kx1 cell array.
%    {k}.meteo.P    nx1 precipitation vector [mm/day]
%    {k}.meteo.Ep   nx1 evaporative demand/PET vector [mm/day]
%    {k}.meteo.T    nx1 mean air temperature vector [deg C]
%    {k}.meteo.bad  row vector of indices with invalid meteo values
%    {k}.gauge      station ID
%    {k}.fname      cache/source files
%   aux         Kx3 matrix [lat,elev,area_m2] if metadata are available.
%
% NOTES:
%   CAMELS-AU stores all basins in wide CSV files:
%        year month day basin1 basin2 ... basin222
%        1951 1 1  ...
%   This reader builds MAT caches for each wide CSV source. The first run
%   parses the CSV files; subsequent runs load binary MAT caches and slice
%   the requested basins/date window.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% © Written by Jasper A. Vrugt / updated for CAMELS-AU, May 2026          %
% University of California, Irvine                                        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if nargin < 1 ...
        || isempty(dirM)
    error('read_meteo_AU:missingDir', ...
        ['      Error:read_meteo_AU: ' ...
        'dirM must be provided.']);
end
if ~isfolder(dirM)
    error('read_meteo_AU:missingDir', ...
        ['      Error:read_meteo_AU: ' ...
        'Directory does not exist: %s'], ...
        dirM);
end
if nargin < 2 ...
        || ~isstruct(bas) ...
        || ~isfield(bas,'id_gauge')
    error('read_meteo_AU:missingBasins', ...
        ['      Error:read_meteo_AU: ' ...
        'bas.id_gauge must be provided.']);
end
if nargin < 3 ...
        || isempty(split)
    error('read_meteo_AU:missingSplit', ...
        ['      Error:read_meteo_AU: ' ...
        'split must be provided.']);
end
if nargin < 4 ...
        || isempty(meteo)
    meteo = struct();
end

split = prepare_split_AU(split);
dt = double(split.dt);
if dt ~= 1
    error('read_meteo_AU:dailyOnly', ...
        ['      Error:read_meteo_AU: ' ...
        'CAMELS-AU currently ' ...
        'supports daily data only.']);
end

id_gauge = string(bas.id_gauge(:));
id_gauge = strtrim(id_gauge);
K = numel(id_gauge);
if isfield(bas,'K') ...
        && ~isempty(bas.K)
    K = double(bas.K);
    id_gauge = id_gauge(1:K);
end

[p_file,~,p_label] = ...
    precipitation_source_AU(meteo);
[pet_file,~,pet_label] = ...
    pet_source_AU(meteo);
[tmin_file,tmax_file,~,t_label] = ...
    temperature_source_AU(meteo);

req = build_requested_window_AU(split,true);

[~,dailyAU] = local_au_data_roots(dirM);
precDir = fullfile(dailyAU,'precipitation');
petDir = fullfile(dailyAU,'evaporative_demand');

if ~isfolder(precDir)
    error('read_meteo_AU:missingPrecipDir', ...
        ['      Error:read_meteo_AU: ' ...
        'Missing folder: %s'],precDir);
end
if ~isfolder(petDir)
    error('read_meteo_AU:missingPETDir', ...
        ['      Error:read_meteo_AU: ' ...
        'Missing folder: %s'],petDir);
end

fP = fullfile(precDir,p_file);
fE = fullfile(petDir,pet_file);

tempDir = fullfile(dailyAU,'temperature');
if ~isfolder(tempDir)
    error('read_meteo_AU:missingTempDir', ...
        ['      Error:read_meteo_AU: ' ...
        'Missing folder: %s'],tempDir);
end

fTmin = fullfile(tempDir,tmin_file);
fTmax = fullfile(tempDir,tmax_file);

must_exist_AU(fP);
must_exist_AU(fE);
must_exist_AU(fTmin);
must_exist_AU(fTmax);

cacheDir = fullfile(dailyAU, ...
    'timeseries_cache');
if ~isfolder(cacheDir)
    mkdir(cacheDir);
end

fprintf(['... Reading CAMELS-AU ' ...
    'daily meteorological data ' ...
    'P=%s, PET=%s, T=%s ... %3d%%'], ...
    p_label,pet_label,t_label,0);

% Build/load wide-file caches once per product.
CP = load_wide_cache_AU(fP, ...
    cacheDir,'P');
CE = load_wide_cache_AU(fE, ...
    cacheDir,'Ep');
CTn = load_wide_cache_AU(fTmin, ...
    cacheDir,'Tmin');
CTx = load_wide_cache_AU(fTmax, ...
    cacheDir,'Tmax');

% Common overlap among selected meteo files.
fileStartDT = max([CP.fileStartDT,CE.fileStartDT, ...
    CTn.fileStartDT,CTx.fileStartDT]);
fileEndDT = min([CP.fileEndDT,CE.fileEndDT, ...
    CTn.fileEndDT,CTx.fileEndDT]);

if fileEndDT < fileStartDT
    fprintf('\n');
    error('read_meteo_AU:noOverlap', ...
        ['      Error:read_meteo_AU: ' ...
        'selected meteo files ' ...
        'do not overlap in time.']);
end

fileStartN = int64(datenum(fileStartDT)); %#ok<DATNM>
fileEndN = int64(datenum(fileEndDT));     %#ok<DATNM>

if req.read_start_N < fileStartN ...
        || req.read_end_N > fileEndN
    fprintf('\n');
    error(['      Error:read_meteo_AU: ' ...
        'requested period outside ' ...
        'CAMELS-AU meteo files.\nFile ' ...
        'overlap covers %s to %s.'], ...
        string(fileStartDT),string(fileEndDT));
end

% Translate requested rows to each cache's own start date.
idxP = local_row_index_AU(req, ...
    CP.fileStartN);
idxE = local_row_index_AU(req, ...
    CE.fileStartN);
idxTn = local_row_index_AU(req, ...
    CTn.fileStartN);
idxTx = local_row_index_AU(req, ...
    CTx.fileStartN);

[~,colP] = match_station_columns_AU( ...
    id_gauge,CP.ids,'precipitation');
[~,colE] = match_station_columns_AU( ...
    id_gauge,CE.ids,'PET');
[~,colTn] = match_station_columns_AU( ...
    id_gauge,CTn.ids,'temperature minimum');
[~,colTx] = match_station_columns_AU( ...
    id_gauge,CTx.ids,'temperature maximum');

dat = cell(K,1);
aux = read_aux_AU(dirM,id_gauge);

for k = 1:K
    P = single(CP.X(idxP,colP(k)));
    Ep = single(CE.X(idxE,colE(k)));
    Tn = single(CTn.X(idxTn,colTn(k)));
    Tx = single(CTx.X(idxTx,colTx(k)));
    T = single(0.5*(double(Tn) + double(Tx)));

    dat{k}.meteo.bad = find( ...
        ~isfinite(P) ...
        | ~isfinite(Ep) ...
        | ~isfinite(T) ...
        | P < 0 ...
        | Ep < 0).';
    % bad = find(~isfinite(P) ...
    %     | ~isfinite(Ep) ...
    %     | ~isfinite(T) ...
    %     | P < 0 ...
    %     | Ep < 0);

    dat{k}.meteo.P = P(:);
    dat{k}.meteo.Ep = Ep(:);
    dat{k}.meteo.T = T(:);
    %dat{k}.meteo.bad = bad(:)';
    dat{k}.gauge = char(id_gauge(k));
    dat{k}.fname = {CP.cacheFile,CE.cacheFile, ...
        CTn.cacheFile,CTx.cacheFile};

    if mod(k,5) == 0 ...
            || k == K
        pct = floor(100*k/K);
        fprintf('\b\b\b\b%3d%%',pct);
        drawnow;
    end

    if isfield(meteo,'progressFcn') ...
            && ~isempty(meteo.progressFcn)
        try
            meteo.progressFcn(k);
        catch
        end
    end
end

fprintf('\b\b\b\bDone\n');

if isfield(split,'local') ...
        && split.local ...
        && isfield(split,'rainfall_block') ...
        && split.rainfall_block
    dat = rainfall_rank_split(dat,split);
end

end

% =================================================
function C = load_wide_cache_AU(fname,cacheDir,tag)
% =================================================

[~,base,~] = fileparts(fname);
cacheFile = fullfile(cacheDir, ...
    sprintf('%s_%s_cache.mat',base,tag));

srcInfo = dir(fname);
srcBytes = srcInfo.bytes;
srcDatenum = srcInfo.datenum;

if isfile(cacheFile)
    try
        C = load(cacheFile,'X','ids','fileStartDT', ...
            'fileEndDT','fileStartN','fileEndN', ...
            'sourceFile','sourceBytes','sourceDatenum', ...
            'cacheFile');

        if isfield(C,'sourceBytes') ...
                && C.sourceBytes == srcBytes ...
                && isfield(C,'sourceDatenum') ...
                && abs(C.sourceDatenum - srcDatenum) < 1e-8
            C.cacheFile = cacheFile;
            return
        end
    catch
    end
end

% opts = detectImportOptions(fname, ...
%     'FileType','text', ...
%     'VariableNamingRule','preserve');

opts = delimitedTextImportOptions( ...
    'Delimiter',',', ...
    'VariableNamingRule','preserve');

opts.DataLines = [2 Inf];

fid = fopen(fname,'r');
hdr = fgetl(fid);
fclose(fid);

rawNames = string(strsplit(hdr,','));
rawNames = strtrim(erase(rawNames,char(65279)));

names = matlab.lang.makeValidName( ...
    lower(regexprep(rawNames,'[^a-zA-Z0-9]','')), ...
    'ReplacementStyle','delete');

opts.VariableNames = cellstr(names);
opts.VariableTypes = repmat({'double'},1,numel(names));

T = readtable(fname,opts);

% Accept year/month/day or yyyy/mm/dd style headers
iy = find(ismember(names, ...
    {'year','yyyy','yr'}),1);
im = find(ismember(names, ...
    {'month','mon','mm'}),1);
id = find(ismember(names, ...
    {'day','dd'}),1);

if isempty(iy) ...
        || isempty(im) ...
        || isempty(id)
    error('read_meteo_AU:badWideFile', ...
        ['      Error:read_meteo_AU: ' ...
        '%s lacks recognizable ' ...
        'year/month/day columns.'],fname);
end

yr = double(T.(names{iy}));
mo = double(T.(names{im}));
dy = double(T.(names{id}));

t = datetime(yr,mo,dy);
fileStartDT = min(t);
fileEndDT = max(t);
fileStartN = int64(datenum(fileStartDT)); %#ok<DATNM>
fileEndN = int64(datenum(fileEndDT));     %#ok<DATNM>

dataCols = setdiff(1:width(T), ...
    [iy im id],'stable');
ids = rawNames(dataCols);
ids = strtrim(ids);

X = nan(height(T), ...
    numel(dataCols),'single');
for j = 1:numel(dataCols)
    v = T.(names{dataCols(j)});
    if isnumeric(v) ...
            || islogical(v)
        x = double(v);
    else
        x = str2double(string(v));
    end
    x(x <= -99 ...
        | abs(x + 99.99) < 1e-8) = NaN;
    X(:,j) = single(x);
end

sourceFile = fname;
sourceBytes = srcBytes;
sourceDatenum = srcDatenum;

save(cacheFile,'X','ids', ...
    'fileStartDT','fileEndDT', ...
    'fileStartN','fileEndN','sourceFile', ...
    'sourceBytes','sourceDatenum', ...
    'cacheFile','-v7.3');

C = struct();
C.X = X;
C.ids = ids;
C.fileStartDT = fileStartDT;
C.fileEndDT = fileEndDT;
C.fileStartN = fileStartN;
C.fileEndN = fileEndN;
C.sourceFile = sourceFile;
C.sourceBytes = sourceBytes;
C.sourceDatenum = sourceDatenum;
C.cacheFile = cacheFile;

end

% ===============================================
function idx = local_row_index_AU(req,fileStartN)
% ===============================================

id0 = double(req.read_start_N - fileStartN) + 1;
id1 = double(req.read_end_N   - fileStartN) + 1;
idx = id0:id1;

end

% ===============================================================
function [tf,loc] = match_station_columns_AU(reqIDs,fileIDs,kind)
% ===============================================================

reqIDs = string(reqIDs(:));
fileIDs = string(fileIDs(:));
reqClean = clean_station_id_AU(reqIDs);
fileClean = clean_station_id_AU(fileIDs);

[tf,loc] = ismember(reqClean,fileClean);
if ~all(tf)
    missing = reqIDs(~tf);
    error('read_meteo_AU:missingStation', ...
        ['      Error:read_meteo_AU: ' ...
        'Missing %s columns for %d ' ...
        'requested stations, e.g. %s.'], ...
        kind,numel(missing),char(missing(1)));
end

end

% =================================
function s = clean_station_id_AU(s)
% =================================

s = upper(strtrim(string(s)));
s = regexprep(s,'\.0+$','');

end

% ===========================================================
function [rootAU,dailyAU] = local_au_data_roots(dirM)
    p = char(string(dirM));
    [parent,nm] = fileparts(p);
    if strcmpi(nm,'daily')
        rootAU = parent;
        dailyAU = p;
    elseif any(strcmpi(nm,{'streamflow','precipitation', ...
            'evaporative_demand','temperature'}))
        [dailyAU,nm2] = fileparts(p); %#ok<ASGLU>
        [rootAU,nmDaily] = fileparts(dailyAU);
        if ~strcmpi(nmDaily,'daily')
            rootAU = p;
            dailyAU = fullfile(p,'daily');
        end
    else
        rootAU = p;
        dailyAU = fullfile(p,'daily');
    end
end

function [fileName,id,label] = precipitation_source_AU(meteo)
% ===========================================================

id = 1;
if isfield(meteo,'data') ...
        && ~isempty(meteo.data)
    id = double(meteo.data);
end

switch id
    case 1
        fileName = 'precipitation_SILO.csv';
        label = 'SILO';
    case 2
        fileName = 'precipitation_AWAP.csv';
        label = 'AWAP';
    otherwise
        error('read_meteo_AU:badPrecipSource', ...
            ['      Error:read_meteo_AU: ' ...
            'meteo.data must ' ...
            'be 1=SILO or 2=AWAP.']);
end

end

% =================================================
function [fileName,id,label] = pet_source_AU(meteo)
% =================================================

id = 1;
if isfield(meteo,'pet') ...
        && ~isempty(meteo.pet)
    id = double(meteo.pet);
end

switch id
    case 1
        fileName = 'evap_syn_SILO.csv';
        label = 'evap\_syn SILO';
    case 2
        fileName = 'evap_pan_SILO.csv';
        label = 'pan evaporation SILO';
    case 3
        fileName = 'evap_morton_lake_SILO.csv';
        label = 'Morton lake evaporation SILO';
    case 4
        fileName = 'et_tall_crop_SILO.csv';
        label = 'tall-crop reference ET SILO';
    case 5
        fileName = 'et_short_crop_SILO.csv';
        label = 'short-crop reference ET SILO';
    case 6
        fileName = 'et_morton_wet_SILO.csv';
        label = 'Morton wet-environment ET SILO';
    case 7
        fileName = 'et_morton_point_SILO.csv';
        label = 'Morton point ET SILO';
    case 8
        fileName = 'et_morton_actual_SILO.csv';
        label = 'Morton actual ET SILO';
        warning('read_meteo_AU:actualETSelected', ...
            ['meteo.pet = 8 selects actual ET, ' ...
            'not potential evapotranspiration.']);
    otherwise
        error('read_meteo_AU:badPETSource', ...
            ['      Error:read_meteo_AU: ' ...
            'meteo.pet must be ' ...
            '1..8 for CAMELS-AU.']);
end

end

% ==================================================================
function [tminFile,tmaxFile,id,label] = temperature_source_AU(meteo)
% ==================================================================

id = 1;
if isfield(meteo,'temp') ...
        && ~isempty(meteo.temp)
    id = double(meteo.temp);
end

switch id
    case 1
        tminFile = 'tmin_SILO.csv';
        tmaxFile = 'tmax_SILO.csv';
        label = 'SILO';
    case 2
        tminFile = 'tmin_AWAP.csv';
        tmaxFile = 'tmax_AWAP.csv';
        label = 'AWAP';
    otherwise
        error('read_meteo_AU:badTempSource', ...
            ['      Error:read_meteo_AU: ' ...
            'meteo.temp must be ' ...
            '1=SILO or 2=AWAP.']);
end

end

% ======================================
function split = prepare_split_AU(split)
% ======================================

if ~isfield(split,'dt') ...
        || isempty(split.dt)
    split.dt = 1;
end
if ~isfield(split,'spinup') ...
        || isempty(split.spinup)
    split.spinup = 0;
end

end

% ===========================================================
function req = build_requested_window_AU(split,includeSpinup)
% ===========================================================

if nargin < 2
    includeSpinup = true;
end

spinup = max(0,round(double(split.spinup)));

if isfield(split,'ds') ...
        && isfield(split,'de') ...
        && ~isempty(split.ds) ...
        && ~isempty(split.de)
    d0 = as_datetime_AU(split.ds);
    d1 = as_datetime_AU(split.de);

elseif isfield(split,'dts') ...
        && isfield(split,'dte') ...
        && ~isempty(split.dts) ...
        && ~isempty(split.dte)
    d0 = as_datetime_AU(split.dts);
    d1 = as_datetime_AU(split.dte);

    if isfield(split,'des') ...
            && isfield(split,'dee') ...
            && ~isempty(split.des) ...
            && ~isempty(split.dee)
        d0 = min(d0,as_datetime_AU(split.des));
        d1 = max(d1,as_datetime_AU(split.dee));
    end

elseif isfield(split,'d1') ...
        && isfield(split,'d2')
    d0 = as_datetime_AU(split.d1);
    d1 = as_datetime_AU(split.d2);

else
    error('read_meteo_AU:badSplit', ...
        ['      Error:read_meteo_AU: ' ...
        'Could not determine ' ...
        'requested dates from split.']);
end

if includeSpinup
    d0 = d0 - days(spinup);
end

req.read_start_DT = d0;
req.read_end_DT = d1;
req.read_start_N = int64(datenum(d0)); %#ok<DATNM>
req.read_end_N = int64(datenum(d1));   %#ok<DATNM>

end

% ============================
function d = as_datetime_AU(x)
% ============================

if isdatetime(x)
    d = x(1);

elseif isnumeric(x)
    x = double(x(:).');

    if numel(x) == 3
        if x(1) > 1800
            d = datetime(x(1),x(2),x(3));
        elseif x(3) > 1800
            d = datetime(x(3),x(2),x(1));
        else
            error('read_meteo_AU:badDate', ...
                ['Cannot determine ' ...
                'date-vector order.']);
        end

    elseif isscalar(x) ...
            && x > 1e7 ...
            && x < 1e8
        y = floor(x/10000);
        mo = floor((x - 10000*y)/100);
        da = x - 10000*y - 100*mo;
        d = datetime(y,mo,da);

    elseif isscalar(x)
        d = datetime(x, ...
            'ConvertFrom','datenum');

    else
        error('read_meteo_AU:badDate', ...
            ['Unsupported numeric ' ...
            'date format.']);
    end

elseif ischar(x) ...
        || isstring(x)
    s = strtrim(string(x));
    try
        d = datetime(s, ...
            'InputFormat','d/M/yyyy');
    catch
        try
            d = datetime(s, ...
                'InputFormat','dd/MM/yyyy');
        catch
            d = datetime(s);
        end
    end
    d = d(1);

else
    error('read_meteo_AU:badDate', ...
        'Unsupported date input type.');
end

end

% =======================================
function aux = read_aux_AU(dirM,id_gauge)
% =======================================

K = numel(id_gauge);
aux = nan(K,3);

dirD = dirM;
candidates = { ...
    fullfile(dirD,'gauge_information.txt'), ...
    fullfile(dirD,['CAMELS_AUS_Attributes&' ...
    'Indices_MasterTable.csv']), ...
    fullfile(dirD,['CAMELS_AUS_Attributes&' ...
    'Indicates_MasterTable.csv']), ...
    fullfile(dirD,'id_name_metadata.csv')};

fname = '';
for i = 1:numel(candidates)
    if isfile(candidates{i})
        fname = candidates{i};
        break
    end
end

if isempty(fname)
    return
end

try
    opts = detectImportOptions(fname, ...
        'FileType','text', ...
        'VariableNamingRule','preserve');
    T = readtable(fname,opts);
    raw = string(T.Properties.VariableNames);
    valid = matlab.lang.makeValidName(raw, ...
        'ReplacementStyle','delete');
    T.Properties.VariableNames = valid;

    idVar = find_var_AU(valid, ...
        {'station_id','stationid', ...
        'gauge_id','gage_id','id'});
    latVar = find_var_AU(valid, ...
        {'lat_outlet','latitude', ...
        'lat','gauge_lat'});
    elevVar = find_var_AU(valid, ...
        {'elev_mean','elevation', ...
        'gauge_elev','elev'});
    areaVar = find_var_AU(valid, ...
        {'catchment_area','area', ...
        'area_km2','drainage_area'});

    if isempty(idVar)
        return
    end

    ids = clean_station_id_AU(string(T.(idVar)));
    req = clean_station_id_AU(id_gauge);

    [tf,loc] = ismember(req,ids);

    for k = 1:K
        if ~tf(k)
            continue
        end
        j = loc(k);

        if ~isempty(latVar)
            aux(k,1) = double(T.(latVar)(j));
        end
        if ~isempty(elevVar)
            aux(k,2) = double(T.(elevVar)(j));
        end
        if ~isempty(areaVar)
            area_km2 = double(T.(areaVar)(j));
            aux(k,3) = area_km2 * 1e6;
        end
    end
catch
    aux = nan(K,3);
end

end

% =============================================
function v = find_var_AU(validNames,candidates)
% =============================================

v = '';
validLower = lower(string(validNames));
for i = 1:numel(candidates)
    c = lower(string(matlab.lang.makeValidName( ...
        candidates{i}, ...
        'ReplacementStyle','delete')));
    j = find(validLower == c,1);
    if ~isempty(j)
        v = char(validNames(j));
        return
    end
end

end

% ===========================
function must_exist_AU(fname)
% ===========================

if ~isfile(fname)
    error('read_meteo_AU:missingFile', ...
        ['      Error:read_meteo_AU: ' ...
        'Required file not found: %s'],fname);
end

end
