function [A,id_gauge,gname,zone] = read_attr_AU(dirD,bas)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%READ_ATTR_AU Read catchment attributes of CAMELS-AUS dataset.
%
% SYNOPSIS:
%   [A,id_gauge,gname,zone] = read_attr_AU(dirD,bas)
%
% INPUT:
%   dirD        Directory with CAMELS-AU attribute master table
%   bas         OPTIONAL: structure with basin and attribute information
%    .id_gauge   OPTIONAL: vector/string array/cell array of requested
%                 station identifiers, e.g. "912101A"
%    .id_attr    rx1 vector of integer attribute IDs
%    .pr_attr    OPTIONAL: print attribute table [1/0]
%
% OUTPUT:
%   A           r x K matrix of standardized selected attributes
%   id_gauge    K x 1 string array with CAMELS-AU station identifiers
%   gname       K x 1 string array with standardized station names
%   zone        structure with CAMELS-AUS basin classification
%    .id            K x 1 string array with zone labels per basin
%    .long          K x 1 string array with descriptive zone labels
%    .num           K x 1 numeric vector with integer zone identifiers
%    .codes         mx1 string array with unique compact zone codes
%    .names         mx1 string array with unique zone names
%    .lat           K x 1 vector with outlet latitude
%    .lon           K x 1 vector with outlet longitude
%    .area          K x 1 vector with catchment area [km^2]
%    .division      K x 1 string array with drainage division
%    .river_region  K x 1 string array with river region
%    .aridity       K x 1 vector with aridity index
%    .frac_snow     K x 1 vector with snow fraction
%
% DESCRIPTION:
%   This function reads the CAMELS-AU master attribute/index table
%       CAMELS_AU_Attributes&Indices_MasterTable.csv
%   and uses it as the single source for station metadata, location,
%   catchment area, climate, hydrologic signatures, geology/soils,
%   topography/geometry, land cover/vegetation, anthropogenic influence,
%   and other indices.
%
% NOTES:
%   If bas is omitted, a small default attribute set is used. The default
%   set avoids discharge-derived hydrologic signatures and uses only basic
%   location, basin size, topography, and climate attributes.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% © Written by Jasper A. Vrugt, May 2026                                  %
% University of California, Irvine                                        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    if nargin < 1 ...
            || isempty(dirD)
        error('read_attr_AU:missingDir', ...
            ['      Error:read_attr_AU: ' ...
            'dirD must be provided.']);
    end
    
    if ~isfolder(dirD)
        error('read_attr_AU:missingDir', ...
            ['      Error:read_attr_AU: ' ...
            'Attribute directory ' ...
            'does not exist: %s'],dirD);
    end
    
    if nargin < 2
        bas = struct();
    end
    
    if ~isstruct(bas)
        error('read_attr_AU:badBas', ...
            ['      Error:read_attr_AU: ' ...
            'bas must be a structure.']);
    end
    % =========================================
    % ZONE CONTROL PARAMETERS (GLOBAL DEFAULTS)
    % =========================================
    if ~isfield(bas,'min_per_zone') ...
            || isempty(bas.min_per_zone)
        min_per_zone = 5;
    else
        min_per_zone = bas.min_per_zone;
    end    
    if ~isfield(bas,'max_zones') ...
            || isempty(bas.max_zones)
        max_zones = 8;
    else
        max_zones = bas.max_zones;
    end
    
    pr_table = 1;
    if isfield(bas,'pr_attr') ...
            && ~isempty(bas.pr_attr)
        pr_table = bas.pr_attr;
    end
    
    f_master = fullfile(dirD, ...
        'CAMELS_AUS_Attributes&Indices_MasterTable.csv');
    
    caller = mfilename;
    must_exist(f_master, ...
        'CAMELS_AUS_Attributes&Indices_MasterTable.csv',caller);
    
    fprintf(['... Reading CAMELS-AUS ' ...
        'basin attributes ']);
    
    AA = read_au_master_table(f_master);
    
    % -------------------------
    % Required metadata columns
    % -------------------------
    needVars = {'station_id','station_name', ...
        'lat_outlet','long_outlet', ...
        'catchment_area'};
    for j = 1:numel(needVars)
        if ~ismember(needVars{j}, ...
                AA.Properties.VariableNames)
            error('read_attr_AU:missingMetadata', ...
                ['      Error:read_attr_AU: ' ...
                'Master table is missing ' ...
                'required column: %s'], ...
                needVars{j});
        end
    end
    
    id_all = normalize_au_station_id(AA.station_id);
    AA.station_id = id_all;
    
    % ---------------------------
    % Optional requested stations
    % ---------------------------
    if isfield(bas,'id_gauge') ...
            && ~isempty(bas.id_gauge)
        id_req = normalize_au_station_id( ...
            bas.id_gauge(:));
        [tf,locid] = ismember(id_req,id_all);
    
        if ~all(tf)
            missing = id_req(~tf);
            error('read_attr_AU:missingRequestedGauge', ...
                ['      Error:read_attr_AU: ' ...
                'Missing CAMELS-AUS ' ...
                'attributes for %d requested ' ...
                'station IDs, e.g. %s.'], ...
                numel(missing),char(missing(1)));
        end
    
        AA = AA(locid,:);
        id_gauge = id_req(:);
    else
        id_gauge = id_all(:);
    end
    
    % -----------
    % Gauge names
    % -----------
    gname = string(AA.station_name);
    gname = standardize_camels_gauge_names( ...
        gname(:),'CAMELS_AU',id_gauge);
    
    % Write gauge_information.txt for shared SAGE plotting/name utilities.
    ensure_au_gauge_information(dirD,AA);
    
    % -----
    % Zones
    % -----
    region = erase(mfilename,'read_attr_');
    zone = classify_camels_all_zones(region,AA, ...
        min_per_zone,max_zones);

    % ------------------
    % Generic attributes
    % ------------------
    [A,labels] = build_attr_matrix(AA,bas, ...
        mfilename,pr_table);
    
    if pr_table == 1
        assignin('base', ...
            'SAGE_AU_attribute_labels', ...
            labels);
    end
    
    fprintf(' ... Done\n');

end

% ======================================
function T = read_au_master_table(fname)
% ======================================

    opts = detectImportOptions(fname, ...
        'FileType','text');
    opts.VariableNamingRule = 'preserve';
    
    if any(strcmp(opts.VariableNames, ...
            'station_id'))
        opts = setvartype(opts, ...
            'station_id','char');
    end
    
    T = readtable(fname,opts);
    
    T.Properties.VariableNames = ...
        matlab.lang.makeValidName( ...
        T.Properties.VariableNames, ...
        'ReplacementStyle','delete');
    
    if ~ismember('station_id',T.Properties.VariableNames)
        error('read_attr_AU:missingStationID', ...
            ['      Error:read_attr_AU: ' ...
            'File %s does not contain station_id.'],fname);
    end
    
    T.station_id = normalize_au_station_id(T.station_id);
    T = sortrows(T,'station_id');

end

% ===========================================
function ensure_au_gauge_information(dirD,AA)
% ===========================================

    fout = fullfile(dirD, ...
        'gauge_information.txt');
    
    if isfile(fout)
        delete(fout)
    end
    
    needVars = {'station_id','station_name', ...
        'lat_outlet','long_outlet', ...
        'catchment_area'};
    for j = 1:numel(needVars)
        if ~ismember(needVars{j}, ...
                AA.Properties.VariableNames)
            error('read_attr_AU:missingGaugeInfoVar', ...
                ['      Error:read_attr_AU: ' ...
                'Cannot create gauge_information.txt ' ...
                'because %s is missing.'], ...
                needVars{j});
        end
    end
    
    fid = fopen(fout,'w');
    if fid < 0
        error('read_attr_AU:gaugeInfoWriteFailed', ...
            ['      Error:read_attr_AU: ' ...
            'Could not write gauge_information.txt ' ...
            'to %s.'],dirD);
    end
    
    cleanup = onCleanup(@() fclose(fid));
    
    fprintf(fid,['HUC_02\tGAGE_ID\' ...
        'tGAGE_NAME\tLAT\tLONG\tAREA_KM2\n']);
    
    for k = 1:height(AA)
    
        gid = normalize_au_station_id(AA.station_id(k));
        gnm = string(AA.station_name(k));
        if ismissing(gnm) || strlength(strtrim(gnm)) == 0
            gnm = "Station " + gid;
        end
    
        gnm = replace(gnm,char(9),' ');
        gnm = replace(gnm,newline,' ');
        gnm = standardize_camels_gauge_names( ...
            gnm,'CAMELS_AU');
        
        lat = double(AA.lat_outlet(k));
        lon = double(AA.long_outlet(k));
        area = double(AA.catchment_area(k));
    
        fprintf(fid,'AU\t%s\t%s\t%.6f\t%.6f\t%.6f\n', ...
            gid,char(gnm),lat,lon,area);
    end
    
    fprintf(['\n      Wrote CAMELS-AUS gauge ' ...
        'information file: %s'],fout);

end

% =======================================
function id = normalize_au_station_id(id)
% =======================================

    id = string(id);
    id = strtrim(id);
    id = regexprep(id,'\.0+$','');
    id = upper(id);

end