function R = region_config_AU()
%REGION_CONFIG_AU Regional defaults for CAMELS-AU.
%
% All X.paths fields are relative to Data/<R.data_root>.
% Dates use dd/MM/yyyy and water-year boundaries.

    R = struct();
    R.code = 'CAMELS_AU';
    R.acronym = 'AU';
    R.name = 'Australia';
    R.dataset = 'CAMELS-AU';
    R.data_root = 'CAMELS_AU';
    R.resolutions = {'Daily'};
    R.default_resolution = 'Daily';
    R.basin_file_pattern = 'AU_%d_basins.txt';

    X = struct();
    X.label = 'Daily';
    X.dt = 1;
    X.basins.universe = 222;
    X.basins.training = 170;
    X.basins.evaluation = 52;
    X.period.spinup_days = 365;
    X.period.manual.train_start = '01/10/1999';
    X.period.manual.train_end = '30/09/2014';
    X.period.manual.eval_start = '01/10/1984';
    X.period.manual.eval_end = '30/09/1999';
    X.period.common_start = '01/10/1984';
    X.period.common_end = '30/09/2014';
    X.paths.run_root = '';
    X.paths.meteo = fullfile('daily');
    X.paths.discharge = fullfile('daily','streamflow');
    % Meteorological/PET controls shown by SAGE-GUI.
    X.meteo.product.items = {'CAMELS-AU [daily]'};
    X.meteo.product.default = 'CAMELS-AU [daily]';
    X.meteo.product.enabled = false;
    X.meteo.precipitation.items = { ...
        '1 SILO precipitation', ...
        '2 AWAP precipitation' ...
        };
    X.meteo.precipitation.default = '1 SILO precipitation';
    X.meteo.precipitation.enabled = true;
    X.meteo.temperature.items = { ...
        '1 Mean Tmin/Tmax (SILO)', ...
        '2 Mean Tmin/Tmax (AWAP)' ...
        };
    X.meteo.temperature.default = '1 Mean Tmin/Tmax (SILO)';
    X.meteo.temperature.enabled = true;
    X.meteo.pet.items = { ...
        '1 Synthetic evaporation (SILO)', ...
        '2 Pan evaporation (SILO)', ...
        '3 Morton lake evaporation (SILO)', ...
        '4 Tall crop ET (SILO)', ...
        '5 Short crop ET (SILO)', ...
        '6 Morton wet ET (SILO)', ...
        '7 Morton point ET (SILO)', ...
        '8 Morton actual ET (SILO)' ...
        };
    X.meteo.pet.default = '1 Synthetic evaporation (SILO)';
    X.meteo.pet.enabled = true;
    C = repmat(struct('name','','type','','path','','pattern','', ...
        'minimum_count',1,'required',true),0,1);
    C(1).name = 'Precipitation';
    C(1).type = 'folder';
    C(1).path = fullfile('daily','precipitation');
    C(1).pattern = '*';
    C(1).minimum_count = 1;
    C(2).name = 'Temperature';
    C(2).type = 'folder';
    C(2).path = fullfile('daily','temperature');
    C(2).pattern = '*';
    C(2).minimum_count = 1;
    C(3).name = 'Evaporative demand';
    C(3).type = 'folder';
    C(3).path = fullfile('daily','evaporative_demand');
    C(3).pattern = '*';
    C(3).minimum_count = 1;
    C(4).name = 'Streamflow';
    C(4).type = 'folder';
    C(4).path = fullfile('daily','streamflow');
    C(4).pattern = '*';
    C(4).minimum_count = 1;
    X.checks = C;
    R.by_resolution.Daily = X;

end