function dat = read_Q_AU(dirQ,mdl,dat,bas,split,aux) %#ok<INUSD>
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%READ_Q_AU Read CAMELS-AU daily streamflow data for SAGE.
%
% SYNOPSIS:
%   dat = read_Q_AU(dirQ,mdl,dat,bas,split)
%   dat = read_Q_AU(dirQ,mdl,dat,bas,split,aux)
%
% INPUT:
%   dirQ        Directory with CAMELS-AU streamflow file, normally
%               Data/CAMELS_AU/daily/streamflow
%   mdl         model/run structure with fields mode, id_train, id_eval
%   dat         Kx1 cell structure to which discharge is added
%   bas         basin structure with fields K, K_t, id_gauge
%   split       time-split structure
%   aux         unused; retained for interface compatibility
%
% OUTPUT:
%   dat{k}.y_n       daily discharge depth [mm/day]
%   dat{k}.bad       1xn logical mask for invalid/missing discharge
%   dat{k}.fname{2}  source streamflow file
%   dat{k}.gid       CAMELS-AU station identifier
%   dat{k}.use       'training' or 'evaluation'
%
% CAMELS-AU streamflow is stored in one file:
%   streamflow_mmd.csv
% with columns:
%   year month day station_1 station_2 ... station_N
%
% Values are already discharge depth [mm/day]. Missing values are coded as
% -99.99 and are converted to NaN with bad = true.
%
% CACHE:
%   On the first run, the full CSV is converted to a binary MAT cache:
%       streamflow_mmd_cache.mat
%   The cache stores dates, station IDs, and the full daily discharge matrix
%   as single precision. On later runs, this cache is used when it is newer
%   than the CSV and has matching file size/time metadata. This should be
%   substantially faster than reparsing the wide CSV for repeated SAGE runs.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% © Written by Jasper A. Vrugt, Apr. 2026 / updated May 2026              %
% University of California, Irvine                                        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if nargin < 1 || isempty(dirQ)
    error('read_Q_AU:missingDir', ...
        ['      Error:read_Q_AU: ' ...
        'dirQ must be provided.']);
end

if ~isfolder(dirQ)
    error('read_Q_AU:missingDir', ...
        ['      Error:read_Q_AU: ' ...
        'Streamflow directory ' ...
        'does not exist: %s'],dirQ);
end

split = local_prepare_split(split);

dt = double(split.dt);
if dt ~= 1
    error('read_Q_AU:dailyOnly', ...
        ['      Error:read_Q_AU: ' ...
        'CAMELS-AU streamflow reader ' ...
        'supports daily data only.']);
end

K = bas.K;
K_t = bas.K_t;
id_GAUGE = local_id_strings(bas.id_gauge(:));

mode = mdl.mode;
hasEval = ismember(mode,[2 4]);

id_train = expand_index( ...
    mdl.id_train);
if hasEval && isfield(mdl,'id_eval') ...
        && ~isempty(mdl.id_eval)
    id_eval = expand_index( ...
        mdl.id_eval);
else
    id_eval = [];
end

req = local_build_requested_window(split);
timeGrid = (req.read_start_N:req.read_end_N).';
nGrid = numel(timeGrid);

fname = fullfile(dirQ,'streamflow_mmd.csv');
if ~isfile(fname)
    error('read_Q_AU:missingFile', ...
        ['      Error:read_Q_AU: ' ...
        'Required file not found: %s'], ...
        fname);
end

fprintf(['... Reading daily ' ...
    'CAMELS-AU streamflow data ']);

[tFileN,station_id,Qall] = local_load_au_cache( ...
    fname,dirQ);

[tf,icol] = ismember(id_GAUGE,station_id);
if ~all(tf)
    missing = id_GAUGE(~tf);
    error('read_Q_AU:missingRequestedGauge', ...
        ['      Error:read_Q_AU: ' ...
        'Missing CAMELS-AU streamflow ' ...
        'columns for %d requested ' ...
        'station IDs, e.g. %s.'], ...
        numel(missing),char(missing(1)));
end

% Map file dates to requested daily grid once, then reuse for all basins.
[tfDate,locDate] = ismember(tFileN,timeGrid);
iiFile = find(tfDate);
iiGrid = locDate(tfDate);

static_name = fullfile(dirQ, ...
    'CAMELS_AU_discharge_summary_daily.csv');
run_stamp = char(datetime('now', ...
    'Format','yyyyMMdd_HHmmss'));
run_name = fullfile(dirQ, ...
    sprintf(['CAMELS_AU_discharge_' ...
    'run_daily_%s.csv'],run_stamp));

if hasEval
    Qrun = table('Size',[K 10], ...
        'VariableTypes',{'string','string','string','string', ...
        'double','double','string','string','double','double'}, ...
        'VariableNames',{'gauge','use','start_train','end_train', ...
        'n_train','n_bad_train','start_eval','end_eval', ...
        'n_eval','n_bad_eval'});
else
    Qrun = table('Size',[K 6], ...
        'VariableTypes',{'string','string','string','string', ...
        'double','double'}, ...
        'VariableNames',{'gauge','use','start_train','end_train', ...
        'n_train','n_bad_train'});
end

summaryRows = table('Size',[K 7], ...
    'VariableTypes',{'string','string','string', ...
    'double','double','double','double'}, ...
    'VariableNames',{'gauge','start_record','end_record', ...
    'n_all','n_bad_all','n_requested','n_bad_requested'});

fprintf('... %3d%%',0);

for k = 1:K
    gid = id_GAUGE(k);
    q = Qall(:,icol(k));

    badFile = ~isfinite(q) | q <= single(-99);
    q(badFile) = single(NaN);

    Qmm = nan(nGrid,1,'single');
    badmask = true(nGrid,1);
    Qmm(iiGrid) = q(iiFile);
    badmask(iiGrid) = badFile(iiFile);
    badmask = badmask | ~isfinite(Qmm);

    spinup = 0;
    if isfield(split,'spinup') ...
            && ~isempty(split.spinup)
        spinup = max(0,round(double(split.spinup)));
    end
    if spinup > 0
        Qmm = Qmm(spinup+1:end);
        badmask = badmask(spinup+1:end);
    end

    dat{k}.y_n = single(Qmm);
    dat{k}.bad = badmask(:)';
    dat{k}.fname{2} = fname;
    dat{k}.gid = gid;

    if k <= K_t
        dat{k}.use = 'training';
    else
        dat{k}.use = 'evaluation';
    end

    n_train = numel(id_train);
    n_bad_train = sum(badmask(id_train));

    if hasEval
        n_eval = numel(id_eval);
        n_bad_eval = sum(badmask(id_eval));
    else
        n_eval = 0;
        n_bad_eval = 0;
    end

    Qrun.gauge(k) = gid;
    if k <= K_t
        Qrun.use(k) = "training";
    else
        Qrun.use(k) = "evaluation";
    end

    Qrun.start_train(k) = string( ...
        datetime(split.dt_train0, ...
        'ConvertFrom','datenum', ...
        'Format','dd/MM/yyyy'));
    Qrun.end_train(k) = string( ...
        datetime(split.dt_train1, ...
        'ConvertFrom','datenum', ...
        'Format','dd/MM/yyyy'));
    Qrun.n_train(k) = n_train;
    Qrun.n_bad_train(k) = n_bad_train;

    if hasEval
        Qrun.start_eval(k) = string( ...
            datetime(split.dt_eval0, ...
            'ConvertFrom','datenum', ...
            'Format','dd/MM/yyyy'));
        Qrun.end_eval(k) = string( ...
            datetime(split.dt_eval1, ...
            'ConvertFrom','datenum', ...
            'Format','dd/MM/yyyy'));
        Qrun.n_eval(k) = n_eval;
        Qrun.n_bad_eval(k) = n_bad_eval;
    end

    summaryRows.gauge(k) = gid;
    summaryRows.start_record(k) = string( ...
        datetime(tFileN(1), ...
        'ConvertFrom','datenum', ...
        'Format','dd/MM/yyyy'));
    summaryRows.end_record(k) = string( ...
        datetime(tFileN(end), ...
        'ConvertFrom','datenum', ...
        'Format','dd/MM/yyyy'));
    summaryRows.n_all(k) = numel(tFileN);
    summaryRows.n_bad_all(k) = sum(badFile);
    summaryRows.n_requested(k) = numel(Qmm);
    summaryRows.n_bad_requested(k) = sum(badmask);

    if mod(k,20)==0 ...
            || k==K
        pct = floor(100*k/K);
        fprintf('\b\b\b\b%3d%%',pct);
    end

    % Graphical User Interface
    if isfield(bas,'progressFcn') ...
            && ~isempty(bas.progressFcn)
        try
            bas.progressFcn(k,K);
        catch
            try
                bas.progressFcn(k);
            catch
            end
        end
    end
end

fprintf('\b\b\b\bDone\n');

try
    writetable(summaryRows,static_name);
catch ME
    warning('read_Q_AU:summaryWriteFailed', ...
        ['Could not write AU ' ...
        'discharge summary: %s'], ...
        ME.message);
end

try
    writetable(Qrun,run_name);
catch ME
    warning('read_Q_AU:runWriteFailed', ...
        ['Could not write AU ' ...
        'discharge run summary: %s'], ...
        ME.message);
end

end

% =====================================
function [tFileN,station_id,Qall] = ...
    local_load_au_cache(fname,dirQ)
% =====================================

cacheFile = fullfile(dirQ, ...
    'streamflow_mmd_cache.mat');
info = dir(fname);

if isfile(cacheFile)
    try
        S = load(cacheFile,'tFileN', ...
            'station_id','Qall', ...
            'srcBytes','srcDatenum', ...
            'srcFile');
        if isfield(S,'srcBytes') ...
                && isfield(S,'srcDatenum') ...
                && isfield(S,'srcFile') ...
                && strcmp(char(S.srcFile),fname) ...
                && S.srcBytes == info.bytes ...
                && abs(S.srcDatenum ...
                - info.datenum) < 1e-8
            tFileN = S.tFileN;
            station_id = S.station_id;
            Qall = S.Qall;
            return
        end
    catch
        % Fall through and rebuild cache.
    end
end

fprintf(['\n      Building CAMELS-AU ' ...
    'streamflow cache from CSV ...\n']);

fid = fopen(fname,'r');
if fid < 0
    error('read_Q_AU:openFailed', ...
        ['      Error:read_Q_AU: ' ...
        'Could not open %s'],fname);
end
cleanup = onCleanup(@() fclose(fid));
header = fgetl(fid);
if ~ischar(header)
    error('read_Q_AU:emptyFile', ...
        ['      Error:read_Q_AU: ' ...
        'Empty streamflow file: %s'],fname);
end

if contains(header,char(9))
    delim = '\t';
    parts = strsplit(header,char(9));
else
    delim = ',';
    parts = strsplit(header,',');
end

if numel(parts) < 4
    error('read_Q_AU:badHeader', ...
        ['      Error:read_Q_AU: ' ...
        'Expected year/month/day plus ' ...
        'station columns in %s.'],fname);
end

station_id = string(strtrim(parts(4:end))).';

M = readmatrix(fname,'FileType','text', ...
    'Delimiter',delim,'NumHeaderLines',1);

if size(M,2) ~= numel(station_id) + 3
    error('read_Q_AU:badSize', ...
        ['      Error:read_Q_AU: ' ...
        'Number of numeric columns ' ...
        'does not match header ' ...
        'station count in %s.'],fname);
end

tFileN = datenum(datetime( ...
    M(:,1),M(:,2),M(:,3))); %#ok<DATNM>
Qall = single(M(:,4:end));

srcFile = fname;
srcBytes = info.bytes;
srcDatenum = info.datenum;

try
    save(cacheFile,'tFileN', ...
        'station_id','Qall', ...
        'srcFile','srcBytes', ...
        'srcDatenum','-v7.3');
    fprintf(['      Wrote CAMELS-AU ' ...
        'cache: %s\n'],cacheFile);
catch ME
    warning('read_Q_AU:cacheWriteFailed', ...
        ['Could not write AU ' ...
        'streamflow cache: %s'],ME.message);
end

end

% =========================================
function split = local_prepare_split(split)
% =========================================

if ~isfield(split,'dt') ...
        || isempty(split.dt)
    split.dt = 1;
end

names = {'dt_train0','dt_train1', ...
    'dt_eval0','dt_eval1'};
for j = 1:numel(names)
    nm = names{j};
    if isfield(split,nm) ...
            && ~isempty(split.(nm))
        split.(nm) = local_to_datenum(split.(nm));
    end
end

if ~isfield(split,'dt_eval0') ...
        || isempty(split.dt_eval0)
    split.dt_eval0 = split.dt_train0;
end
if ~isfield(split,'dt_eval1') ...
        || isempty(split.dt_eval1)
    split.dt_eval1 = split.dt_train1;
end
end

% ================================================
function req = local_build_requested_window(split)
% ================================================

if isfield(split,'read_start_N') ...
        && isfield(split,'read_end_N') ...
        && ~isempty(split.read_start_N) ...
        && ~isempty(split.read_end_N)
    req.read_start_N = local_to_datenum( ...
        split.read_start_N);
    req.read_end_N = local_to_datenum( ...
        split.read_end_N);
    return
end

starts = [];
ends = [];
if isfield(split,'dt_train0')
    starts(end+1) = split.dt_train0;
end
if isfield(split,'dt_eval0')
    starts(end+1) = split.dt_eval0;
end
if isfield(split,'dt_train1')
    ends(end+1) = split.dt_train1;
end
if isfield(split,'dt_eval1')
    ends(end+1) = split.dt_eval1;
end

if isempty(starts) || isempty(ends)
    error('read_Q_AU:badSplit', ...
        ['      Error:read_Q_AU: ' ...
        'Could not determine requested ' ...
        'date window from split.']);
end

req.read_start_N = min(starts);
req.read_end_N = max(ends);

if isfield(split,'spinup') ...
        && ~isempty(split.spinup)
    spinup = max(0,round(double( ...
        split.spinup)));
    req.read_start_N = ...
        req.read_start_N - spinup;
end
end

% ===============================
function xN = local_to_datenum(x)
% ===============================

if isdatetime(x)
    d = x(1);

elseif ischar(x) ...
        || isstring(x)
    s = strtrim(string(x));
    try
        d = datetime(s, ...
            'InputFormat','d/M/yyyy');
    catch
        d = datetime(s);
    end

elseif isnumeric(x)
    x = double(x(:).');

    if numel(x) == 3
        if x(1) > 1800
            d = datetime(x(1),x(2),x(3));
        elseif x(3) > 1800
            d = datetime(x(3),x(2),x(1));
        else
            error('read_Q_AU:badDate', ...
                ['Cannot determine ' ...
                'date-vector order.']);
        end

    elseif isscalar(x) ...
            && x > 1e7 ...
            && x < 1e8
        y = floor(x/10000);
        mo = floor((x - 10000*y)/100);
        da = x - 10000*y - 100*mo;
        d = datetime(y,mo,da);

    elseif isscalar(x)
        d = datetime(x, ...
            'ConvertFrom','datenum');

    else
        error('read_Q_AU:badDate', ...
            ['Unsupported numeric ' ...
            'date format.']);
    end
else
    error('read_Q_AU:badDate', ...
        ['Unsupported date ' ...
        'input type.']);
end

xN = datenum(d); %#ok<DATNM>
end

% ===============================
function id = local_id_strings(x)
% ===============================

if isnumeric(x)
    id = strings(numel(x),1);
    for i = 1:numel(x)
        id(i) = string(sprintf( ...
            '%.0f',double(x(i))));
    end
    return
end

if iscell(x)
    id = string(x(:));
elseif isstring(x)
    id = x(:);
elseif ischar(x)
    id = string(cellstr(x));
else
    id = string(x(:));
end

id = strtrim(id);
id = regexprep(id,'\.0+$','');
end
