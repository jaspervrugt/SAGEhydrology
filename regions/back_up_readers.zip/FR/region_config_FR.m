function R = region_config_FR()
%REGION_CONFIG_FR Regional defaults for CAMELS-FR.
%
% All X.paths fields are relative to Data/<R.data_root>.
% Dates use dd/MM/yyyy and water-year boundaries.

    R = struct();
    R.code = 'CAMELS_FR';
    R.acronym = 'FR';
    R.name = 'France';
    R.dataset = 'CAMELS-FR';
    R.data_root = 'CAMELS_FR';
    R.resolutions = {'Daily'};
    R.default_resolution = 'Daily';
    R.basin_file_pattern = 'FR_%d_basins.txt';

    X = struct();
    X.label = 'Daily';
    X.dt = 1;
    X.basins.universe = 654;
    X.basins.training = 500;
    X.basins.evaluation = 154;
    X.period.spinup_days = 365;
    X.period.manual.train_start = '01/10/1999';
    X.period.manual.train_end = '30/09/2008';
    X.period.manual.eval_start = '01/10/1989';
    X.period.manual.eval_end = '30/09/1999';
    X.period.common_start = '01/10/1989';
    X.period.common_end = '30/09/2008';
    X.paths.run_root = '';
    X.paths.meteo = fullfile('daily','timeseries');
    X.paths.discharge = fullfile('daily','timeseries');
    % Meteorological/PET controls shown by SAGE-GUI.
    X.meteo.product.items = {'CAMELS-FR [daily]'};
    X.meteo.product.default = 'CAMELS-FR [daily]';
    X.meteo.product.enabled = false;
    X.meteo.precipitation.items = {'1 Precipitation'};
    X.meteo.precipitation.default = '1 Precipitation';
    X.meteo.precipitation.enabled = false;
    X.meteo.temperature.items = { ...
        '1 Mean', ...
        '2 (Tmin+Tmax)/2', ...
        '3 Tmin', ...
        '4 Tmax' ...
        };
    X.meteo.temperature.default = '1 Mean';
    X.meteo.temperature.enabled = true;
    X.meteo.pet.items = { ...
        '1 Penman-Monteith', ...
        '2 Penman', ...
        '3 Oudin et al.' ...
        };
    X.meteo.pet.default = '1 Penman-Monteith';
    X.meteo.pet.enabled = true;
    C = repmat(struct('name','','type','','path','','pattern','', ...
        'minimum_count',1,'required',true),0,1);
    C(1).name = 'Meteorological data';
    C(1).type = 'folder';
    C(1).path = fullfile('daily','timeseries');
    C(1).pattern = '*';
    C(1).minimum_count = 1;
    X.checks = C;
    R.by_resolution.Daily = X;

end