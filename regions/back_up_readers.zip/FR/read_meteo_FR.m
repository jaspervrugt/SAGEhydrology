function [dat,aux] = read_meteo_FR(dirM,bas,split,meteo)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%READ_METEO_FR Read CAMELS-FR daily hydrometeorological data for SAGE.
%
% SYNOPSIS:
%   [dat,aux] = read_meteo_FR(dirM,bas,split,meteo)
%
% INPUT:
%   dirM        CAMELS-FR timeseries directory, normally
%               Data/CAMELS_FR/daily/timeseries, or the root Data/CAMELS_FR
%   bas         basin structure with fields K and id_gauge
%   split       SAGE split structure. Daily dt = 1 only. Meteo includes
%               the spin-up period; discharge is returned for split.idx.
%   meteo       optional structure
%    .pet        1 = tsd_pet_pm [default]
%                2 = tsd_pet_pe
%                3 = tsd_pet_ou
%    .temp       1 = tsd_temp [default]
%                2 = mean(tsd_temp_min,tsd_temp_max)
%                3 = tsd_temp_min
%                4 = tsd_temp_max
%    .progressFcn optional GUI progress callback
%
% OUTPUT:
%   dat{k}.meteo.P   precipitation [mm/day]
%   dat{k}.meteo.Ep  potential evapotranspiration [mm/day]
%   dat{k}.meteo.T   temperature [deg C]
%   dat{k}.y_n       observed discharge depth [mm/day], spin-up removed
%   dat{k}.bad       logical discharge bad mask, same length as y_n
%   aux              Kx3 [lat, elev, area_m2] when available
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% © Written by Jasper A. Vrugt, June 2026                                 %
% University of California, Irvine                                        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    if nargin < 1 ...
            || isempty(dirM)
        error('read_meteo_FR:missingDir', ...
            ['      Error:read_meteo_FR: ' ...
            'dirM must be provided.']);
    end

    if isfolder(fullfile(dirM,'daily','timeseries'))
        rootFR = dirM;
        dirM = fullfile(dirM,'daily','timeseries');
    elseif isfolder(fullfile(dirM,'timeseries'))
        rootFR = dirM;
        dirM = fullfile(dirM,'timeseries');
    else
        rootFR = fileparts(dirM);
        [pDaily,nmDaily] = fileparts(rootFR);
        if strcmpi(nmDaily,'daily')
            rootFR = pDaily;
        end
    end

    if ~isfolder(dirM)
        error('read_meteo_FR:missingDir', ...
            ['      Error:read_meteo_FR: ' ...
            'Timeseries directory ' ...
            'does not exist: %s'],dirM);
    end

    if nargin < 4 ...
            || isempty(meteo)
        meteo = struct();
    end

    split = prepare_split_FR(split);
    if double(split.dt) ~= 1
        error('read_meteo_FR:dailyOnly', ...
            ['      Error:read_meteo_FR: ' ...
            'CAMELS-FR supports daily data only.']);
    end

    K = bas.K;
    id_gauge = normalize_fr_gauge_id(bas.id_gauge(:));
    if numel(id_gauge) ~= K
        K = numel(id_gauge);
    end

    [petName,petID] = pet_source_FR(meteo);
    [tempName,tempID] = temp_source_FR(meteo);
    req = build_requested_window_FR(split,true);

    cacheDir = fullfile(dirM,'_cache_FR_daily');
    if ~isfolder(cacheDir)
        mkdir(cacheDir);
    end

    dat = cell(K,1);
    aux = nan(K,3);
    G = read_fr_gauge_info(rootFR);

    fprintf(['... Reading daily CAMELS-FR ' ...
        'hydrometeorological data files %3d%%'],0);
    flag_progress = true;

    for k = 1:K
        gid = id_gauge(k);
        gidstr = char(gid);
        fname = local_find_fr_timeseries_file(dirM,gidstr);
        cacheFile = fullfile(cacheDir, ...
            sprintf('%s_FR_daily_pet%d_t%d.mat', ...
            gidstr,petID,tempID));

        [Pfull,Epfull,Tfull,Qfull,bad_meteo_full,bad_q_full, ...
            fileStartN,fileEndN,fileStartDT,fileEndDT] = ...
            local_load_or_build_fr_cache(fname,cacheFile, ...
            petName,tempName,gidstr);

        if req.read_start_N < fileStartN ...
                || req.read_end_N > fileEndN
            if flag_progress
                fprintf('\n');
            end
            error('read_meteo_FR:periodOutsideFile', ...
                ['      Error:read_meteo_FR: ' ...
                'requested period outside ' ...
                'CAMELS-FR file for basin %s.\n' ...
                'File covers %s to %s.'], ...
                gidstr,string(fileStartDT), ...
                string(fileEndDT));
        end

        id0 = double(req.read_start_N - fileStartN) + 1;
        id1 = double(req.read_end_N - fileStartN) + 1;
        idxRead = id0:id1;

        P = double(Pfull(idxRead));
        Ep = double(Epfull(idxRead));
        Tair = double(Tfull(idxRead));
        Qall = double(Qfull(idxRead));

        dat{k}.meteo.P = single(P);
        dat{k}.meteo.Ep = single(Ep);
        dat{k}.meteo.T = single(Tair);
        dat{k}.gauge = gid;
        dat{k}.fname{1} = fname;
        dat{k}.fname{2} = fname;

        idx_score = double(split.idx(:));
        idx_score = idx_score(idx_score >= 1 ...
            & idx_score <= numel(Qall));
        dat{k}.y_n = single(Qall(idx_score));
        dat{k}.gid = gid;

        bad_meteo_full = double(bad_meteo_full(:));
        bad_q_full = double(bad_q_full(:));
        bad_meteo = bad_meteo_full( ...
            bad_meteo_full >= id0 ...
            & bad_meteo_full <= id1) - id0 + 1;
        bad_q_all = bad_q_full( ...
            bad_q_full >= id0 ...
            & bad_q_full <= id1) - id0 + 1;

        dat{k}.meteo.bad = bad_meteo(:).';
        badmask_all = false(1,numel(Qall));
        bad_q_all = bad_q_all(isfinite(bad_q_all) ...
            & bad_q_all >= 1 ...
            & bad_q_all <= numel(Qall));
        badmask_all(round(bad_q_all)) = true;
        dat{k}.bad = badmask_all(idx_score);

        if ~isempty(G)
            j = find(G.id == gid,1);
            if ~isempty(j)
                aux(k,1) = G.lat(j);
                aux(k,2) = G.elev(j);
                aux(k,3) = G.area_m2(j);
            end
        end

        if mod(k,5) == 0 ...
                || k == K
            pct = floor(100*k/K);
            fprintf('\b\b\b\b%3d%%',pct);
            drawnow;
        end

        if isstruct(meteo) ...
                && isfield(meteo,'progressFcn') ...
                && ~isempty(meteo.progressFcn)
            meteo.progressFcn(k);
        end
    end

    if flag_progress
        fprintf('\b\b\b\b%s\n','... Done');
    end

    if isfield(split,'local') ...
            && split.local ...
            && isfield(split,'rainfall_block') ...
            && split.rainfall_block
        dat = rainfall_rank_split(dat,split);
    end

end

% ============================================================
function [P,Ep,Tair,Q,bad_meteo,bad_q,fileStartN,fileEndN, ...
    fileStartDT,fileEndDT] = local_load_or_build_fr_cache( ...
    fname,cacheFile,petName,tempName,gid)
% ============================================================

    use_cache = false;
    if isfile(cacheFile)
        try
            info_src = dir(fname);
            info_cch = dir(cacheFile);
            use_cache = info_cch.datenum ...
                >= info_src.datenum;
        catch
            use_cache = false;
        end
    end

    if use_cache
        S = load(cacheFile,'P','Ep', ...
            'Tair','Q','bad_meteo','bad_q', ...
            'fileStartN','fileEndN', ...
            'fileStartDT','fileEndDT');
        P = S.P; 
        Ep = S.Ep; 
        Tair = S.Tair; 
        Q = S.Q;
        bad_meteo = S.bad_meteo; 
        bad_q = S.bad_q;
        fileStartN = S.fileStartN; 
        fileEndN = S.fileEndN;
        fileStartDT = S.fileStartDT; 
        fileEndDT = S.fileEndDT;
        return
    end

    T = read_fr_timeseries_table(fname);
    t = parse_fr_dates(T.tsd_date);
    fileStartDT = min(t);
    fileEndDT = max(t);
    tFull = (fileStartDT:days(1):fileEndDT).';

    P0 = column_by_date_FR(T, ...
        t,tFull,'tsd_prec',fname);
    Ep0 = column_by_date_FR(T, ...
        t,tFull,petName,fname);
    T0 = temperature_by_date_FR(T, ...
        t,tFull,tempName,fname);
    Q0 = column_by_date_FR(T, ...
        t,tFull,'tsd_q_mm',fname);

    P = single(P0(:));
    Ep = single(Ep0(:));
    Tair = single(T0(:));
    Q = single(Q0(:));

    bad_meteo = int64(find(~isfinite(P) ...
        | ~isfinite(Ep) ...
        | ~isfinite(Tair) ...
        | P < 0 ...
        | Ep < 0));
    bad_q = int64(find(~isfinite(Q) ...
        | Q < 0));

    fileStartN = int64(datenum(fileStartDT)); %#ok<DATNM>
    fileEndN = int64(datenum(fileEndDT));     %#ok<DATNM>

    save(cacheFile,'P','Ep','Tair','Q','bad_meteo','bad_q', ...
        'fileStartN','fileEndN','fileStartDT','fileEndDT', ...
        'petName','tempName','gid','-v7.3');
end

function T = read_fr_timeseries_table(fname)
    opts = detectImportOptions(fname, ...
        'FileType','text', ...
        'Delimiter',';','NumHeaderLines',7);
    opts.VariableNamingRule = 'preserve';
    T = readtable(fname,opts);
    T.Properties.VariableNames = ...
        matlab.lang.makeValidName( ...
        T.Properties.VariableNames, ...
        'ReplacementStyle','delete');

    need = {'tsd_date','tsd_prec', ...
        'tsd_temp','tsd_q_mm'};
    for i = 1:numel(need)
        if ~ismember(need{i}, ...
                T.Properties.VariableNames)
            error('read_meteo_FR:missingColumn', ...
                ['      Error:read_meteo_FR: ' ...
                'Required column %s ' ...
                'not found in %s.'],need{i},fname);
        end
    end
end

function d = parse_fr_dates(x)
    x = local_to_numeric_column(x);
    y = floor(x/10000);
    m = floor((x - 10000*y)/100);
    da = x - 10000*y - 100*m;
    d = datetime(y,m,da);
end

function x = column_by_date_FR(T,tFile,tReq,varName,fname)
    if ~ismember(varName, ...
            T.Properties.VariableNames)
        error('read_meteo_FR:missingVariable', ...
            ['      Error:read_meteo_FR: ' ...
            '%s lacks column %s.'], ...
            fname,varName);
    end
    [tf,loc] = ismember(tReq,tFile);
    if ~all(tf)
        error('read_meteo_FR:missingDates', ...
            ['      Error:read_meteo_FR: ' ...
            '%s lacks %d requested dates, ' ...
            'e.g. %s.'],fname,sum(~tf), ...
            string(tReq(find(~tf,1))));
    end
    col = local_to_numeric_column(T.(varName));
    x = col(loc);
end

function x = temperature_by_date_FR(T, ...
    tFile,tReq,tempName,fname)
    switch tempName
        case 'tsd_temp'
            x = column_by_date_FR(T, ...
                tFile,tReq,'tsd_temp',fname);
        case 'mean_minmax'
            tmin = column_by_date_FR(T, ...
                tFile,tReq,'tsd_temp_min',fname);
            tmax = column_by_date_FR(T, ...
                tFile,tReq,'tsd_temp_max',fname);
            x = 0.5*(tmin + tmax);
        case 'tsd_temp_min'
            x = column_by_date_FR(T, ...
                tFile,tReq,'tsd_temp_min',fname);
        case 'tsd_temp_max'
            x = column_by_date_FR(T, ...
                tFile,tReq,'tsd_temp_max',fname);
        otherwise
            error('read_meteo_FR:badTempSource', ...
                ['Unknown temperature ' ...
                'source: %s'],tempName);
    end
end

function fname = local_find_fr_timeseries_file(dirM,gid)
    gid = char(normalize_fr_gauge_id(gid));
    pats = {sprintf('CAMELS_FR_tsd_%s.csv',gid), ...
        sprintf('*%s*.csv',gid)};
    for i = 1:numel(pats)
        q = dir(fullfile(dirM,pats{i}));
        q = q(~[q.isdir]);
        if ~isempty(q)
            fname = fullfile(q(1).folder,q(1).name);
            return
        end
    end
    error('read_meteo_FR:missingFile', ...
        ['      Error:read_meteo_FR: ' ...
        'Missing CAMELS-FR ' ...
        'timeseries file ' ...
        'for basin %s in %s.'],gid,dirM);
end

function [name,id] = pet_source_FR(meteo)
    id = 1;
    if isstruct(meteo) ...
            && isfield(meteo,'pet') ...
            && ~isempty(meteo.pet)
        id = double(meteo.pet(1));
    end
    switch id
        case {0,1}
            id = 1; name = 'tsd_pet_pm';
        case 2
            name = 'tsd_pet_pe';
        case 3
            name = 'tsd_pet_ou';
        otherwise
            error('read_meteo_FR:badPETSource', ...
                ['meteo.pet must be ' ...
                '0, 1, 2, or 3 for CAMELS-FR.']);
    end
end

function [name,id] = temp_source_FR(meteo)
    id = 1;
    if isstruct(meteo) ...
            && isfield(meteo,'temp') ...
            && ~isempty(meteo.temp)
        id = double(meteo.temp(1));
    end
    switch id
        case {0,1}
            id = 1; name = 'tsd_temp';
        case 2
            name = 'mean_minmax';
        case 3
            name = 'tsd_temp_min';
        case 4
            name = 'tsd_temp_max';
        otherwise
            error('read_meteo_FR:badTempSource', ...
                ['meteo.temp must be ' ...
                '0,1,2,3,or 4 for CAMELS-FR.']);
    end
end

function split = prepare_split_FR(split)
    if ~isfield(split,'dt') ...
            || isempty(split.dt)
        split.dt = 1;
    end
    if ~isfield(split,'spinup') ...
            || isempty(split.spinup)
        split.spinup = 0;
    end
    if ~isfield(split,'idx') ...
            || isempty(split.idx)
        n = days(as_datetime_FR(split.de) ...
            - as_datetime_FR(split.ds)) + 1;
        split.idx = ...
            (double(split.spinup)+1): ...
            (double(split.spinup)+n);
    end
end

function req = build_requested_window_FR(split, ...
    includeSpinup)
    if nargin < 2
        includeSpinup = true;
    end
    spinup = max(0,round(double(split.spinup)));
    if isfield(split,'ds') ...
            && isfield(split,'de') ...
            && ~isempty(split.ds) ...
            && ~isempty(split.de)
        d0 = as_datetime_FR(split.ds);
        d1 = as_datetime_FR(split.de);
    elseif isfield(split,'dts') ...
            && isfield(split,'dte') ...
            && ~isempty(split.dts) ...
            && ~isempty(split.dte)
        d0 = as_datetime_FR(split.dts);
        d1 = as_datetime_FR(split.dte);
        if isfield(split,'des') ...
                && isfield(split,'dee') ...
                && ~isempty(split.des) ...
                && ~isempty(split.dee)
            d0 = min(d0,as_datetime_FR(split.des));
            d1 = max(d1,as_datetime_FR(split.dee));
        end
    elseif isfield(split,'d1') && isfield(split,'d2')
        d0 = as_datetime_FR(split.d1);
        d1 = as_datetime_FR(split.d2);
    else
        error('read_meteo_FR:badSplit', ...
            ['      Error:read_meteo_FR: ' ...
            'Could not determine ' ...
            'requested dates from split.']);
    end
    if includeSpinup
        d0 = d0 - days(spinup);
    end
    req.read_start_DT = d0;
    req.read_end_DT = d1;
    req.read_start_N = int64(datenum(d0)); %#ok<DATNM>
    req.read_end_N = int64(datenum(d1));   %#ok<DATNM>
end

function d = as_datetime_FR(x)
    if isdatetime(x)
        d = x(1);
    elseif isnumeric(x)
        x = double(x(:).');
        if numel(x) == 3
            if x(1) > 1800
                d = datetime(x(1),x(2),x(3));
            elseif x(3) > 1800
                d = datetime(x(3),x(2),x(1));
            else
                d = datetime(x, ...
                    'ConvertFrom','datenum');
            end
        elseif isscalar(x) ...
                && x > 1e7 ...
                && x < 1e8
            y = floor(x/10000);
            m = floor((x - 10000*y)/100);
            da = x - 10000*y - 100*m;
            d = datetime(y,m,da);
        else
            d = datetime(x(1), ...
                'ConvertFrom','datenum');
        end
    else
        s = strtrim(string(x));
        try
            d = datetime(s, ...
                'InputFormat','dd/MM/yyyy');
        catch
            d = datetime(s);
        end
        d = d(1);
    end
end

function G = read_fr_gauge_info(rootFR)
    G = [];
    f_site = fullfile(rootFR, ...
        'CAMELS_FR_site_general_attributes.csv');
    f_station = fullfile(rootFR, ...
        'CAMELS_FR_station_general_attributes.csv');
    f_topo = fullfile(rootFR, ...
        'CAMELS_FR_topography_general_attributes.csv');
    try
        if isfile(f_station)
            S = read_fr_attr_table(f_station);
        else
            S = table();
        end
        if isfile(f_site)
            Site = read_fr_attr_table(f_site);
            if ismember('sit_code_h3', ...
                    Site.Properties.VariableNames) ...
                    && ismember('sit_code_h3', ...
                    S.Properties.VariableNames)
                S = outerjoin(S,Site, ...
                    'Keys','sit_code_h3', ...
                    'MergeKeys',true, ...
                    'Type','left');
            end
        end
        if isfile(f_topo)
            Topo = read_fr_attr_table(f_topo);
            S = outerjoin(S,Topo, ...
                'Keys','sta_code_h3', ...
                'MergeKeys',true, ...
                'Type','left');
        end
        if isempty(S) ...
                || ~ismember('sta_code_h3', ...
                S.Properties.VariableNames)
            return
        end
        G.id = normalize_fr_gauge_id(S.sta_code_h3);
        Y = local_get_col(S, ...
            {'sit_latitude'});
        X = local_get_col(S, ...
            {'sit_longitude'});
        [lat,lon] = local_fr_lambert93_to_wgs84(X,Y);
        G.lat = lat;
        G.lon = lon; 
        G.elev = local_get_col(S, ...
            {'sit_altitude','top_altitude_mean'});
        area_km2 = local_get_col(S, ...
            {'sit_area_topo','sit_area_hydro'});
        G.area_m2 = area_km2 * 1e6;
    catch
        G = [];
    end
end

function T = read_fr_attr_table(fname)
    opts = detectImportOptions(fname, ...
        'FileType','text','Delimiter',';');
    opts.VariableNamingRule = 'preserve';
    T = readtable(fname,opts);
    T.Properties.VariableNames = ...
        matlab.lang.makeValidName( ...
        T.Properties.VariableNames, ...
        'ReplacementStyle','delete');
end

function x = local_get_col(T,names)
    x = nan(height(T),1);
    for i = 1:numel(names)
        nm = names{i};
        if ismember(nm,T.Properties.VariableNames)
            x = local_to_numeric_column(T.(nm));
            return
        end
    end
end

function [lat,lon] = local_fr_lambert93_to_wgs84(X,Y)
%LOCAL_FR_LAMBERT93_TO_WGS84 Convert EPSG:2154 Lambert-93 to WGS84.
    X = double(X(:));
    Y = double(Y(:));
    lat = nan(size(X));
    lon = nan(size(X));
    good = isfinite(X) ...
        & isfinite(Y);
    if ~any(good)
        return
    end

    % If coordinates already look like degrees, keep them.
    degLike = good ...
        & abs(X) <= 20 ...
        & abs(Y) <= 60;
    lon(degLike) = X(degLike);
    lat(degLike) = Y(degLike);

    good = good & ~degLike;
    if ~any(good)
        return
    end

    a = 6378137.0; %#ok<NASGU>
    e = sqrt(0.00669438002290);
    n = 0.7256077650532670;
    C = 11754255.426096;
    xs = 700000.0;
    ys = 12655612.049876;
    lon0 = 3*pi/180;

    x = X(good);
    y = Y(good);
    gamma = atan((x - xs) ./ (ys - y));
    R = sqrt((x - xs).^2 + (y - ys).^2);
    L = -(1/n) .* log(R ./ C);

    phi = 2*atan(exp(L)) - pi/2;
    for it = 1:8
        phi = 2*atan(((1 + e*sin(phi)) ./ ...
            (1 - e*sin(phi))).^(e/2) .* exp(L)) - pi/2;
    end

    lam = lon0 + gamma ./ n;
    lat(good) = phi * 180/pi;
    lon(good) = lam * 180/pi;
end

function id = normalize_fr_gauge_id(v)
    s = string(v);
    s = strip(s);
    s = erase(s,'"');
    s(ismissing(s)) = "";
    id = upper(s(:));
end

function x = local_to_numeric_column(v)
    if isnumeric(v) ...
            || islogical(v)
        x = double(v(:));
        return
    end
    if iscell(v)
        v = string(v);
    elseif ischar(v)
        v = string(cellstr(v));
    else
        v = string(v);
    end
    v = strtrim(v);
    v(ismissing(v) ...
        | v == "" ...
        | strcmpi(v,"NA") ...
        | strcmpi(v,"NAN") ...
        | strcmpi(v,"NULL")) = missing;
    x = str2double(v(:));
end
