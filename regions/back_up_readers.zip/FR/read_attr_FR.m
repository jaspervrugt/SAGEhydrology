function [A,id_gauge,gname,zone] = read_attr_FR(dirD,bas)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%READ_ATTR_FR Read catchment attributes of CAMELS-FR dataset.
%
% SYNOPSIS:
%   [A,id_gauge,gname,zone] = read_attr_FR(dirD,bas)
%
% INPUT:
%   dirD        Directory with CAMELS-FR static attribute CSV files,
%               normally Data/CAMELS_FR
%   bas         OPTIONAL structure with fields
%    .id_gauge   requested station IDs, e.g. "A105003001"
%    .id_attr    selected attribute IDs
%    .pr_attr    print attribute table [1/0]
%
% OUTPUT:
%   A           r x K matrix of standardized selected attributes
%   id_gauge    K x 1 string array with CAMELS-FR station codes
%   gname       K x 1 string array with station names
%   zone        structure with a simple CAMELS-FR hydroclimatic grouping
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% © Written by Jasper A. Vrugt, June 2026                                 %
% University of California, Irvine                                        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    if nargin < 1 || isempty(dirD)
        error('read_attr_FR:missingDir', ...
            ['      Error:read_attr_FR: ' ...
            'dirD must be provided.']);
    end
    if ~isfolder(dirD)
        error('read_attr_FR:missingDir', ...
            ['      Error:read_attr_FR: ' ...
            'Attribute directory ' ...
            'does not exist: %s'],dirD);
    end
    if nargin < 2 || isempty(bas)
        bas = struct();
    end
    if ~isstruct(bas)
        error('read_attr_FR:badBas', ...
            ['      Error:read_attr_FR: ' ...
            'bas must be a structure.']);
    end
    % =========================================
    % ZONE CONTROL PARAMETERS (GLOBAL DEFAULTS)
    % =========================================
    if ~isfield(bas,'min_per_zone') ...
            || isempty(bas.min_per_zone)
        min_per_zone = 5;
    else
        min_per_zone = bas.min_per_zone;
    end    
    if ~isfield(bas,'max_zones') ...
            || isempty(bas.max_zones)
        max_zones = 8;
    else
        max_zones = bas.max_zones;
    end

    pr_table = 1;
    if isfield(bas,'pr_attr') ...
            && ~isempty(bas.pr_attr)
        pr_table = bas.pr_attr;
    elseif ~isfield(bas,'id_attr') ...
            || isempty(bas.id_attr)
        pr_table = 0;
    end

    files = local_fr_attribute_files();
    caller = mfilename;
    for i = 1:numel(files)
        must_exist(fullfile(dirD, ...
            files{i}),files{i},caller);
    end

    fprintf('... Reading CAMELS-FR basin attributes ');

    station = read_fr_table(fullfile(dirD, ...
        'CAMELS_FR_station_general_attributes.csv'));
    site = read_fr_table(fullfile(dirD, ...
        'CAMELS_FR_site_general_attributes.csv'));
    topoGen = read_fr_table(fullfile(dirD, ...
        'CAMELS_FR_topography_general_attributes.csv'));
    topoQ = read_fr_table(fullfile(dirD, ...
        'CAMELS_FR_topography_quantiles_attributes.csv'));
    soilGen = read_fr_table(fullfile(dirD, ...
        'CAMELS_FR_soil_general_attributes.csv'));
    soilQ = read_fr_table(fullfile(dirD, ...
        'CAMELS_FR_soil_quantiles_attributes.csv'));
    land = read_fr_table(fullfile(dirD, ...
        'CAMELS_FR_land_cover_attributes.csv'));
    hgeo = read_fr_table(fullfile(dirD, ...
        'CAMELS_FR_hydrogeology_attributes.csv'));
    geol = read_fr_table(fullfile(dirD, ...
        'CAMELS_FR_geology_attributes.csv'));
    dams = read_fr_table(fullfile(dirD, ...
        'CAMELS_FR_human_influences_dams.csv'));

    topoQ = widen_repeated_fr_table( ...
        topoQ,'sta_code_h3', ...
        {'top_qnt_quant'});
    soilGen = widen_repeated_fr_table( ...
        soilGen,'sta_code_h3', ...
        {'sol_stat','sol_agg_level'});
    soilQ = widen_repeated_fr_table( ...
        soilQ,'sta_code_h3', ...
        {'sol_qnt_agg_level','sol_qnt_quant'});

    station.sta_code_h3 = ...
        normalize_fr_gauge_id( ...
        station.sta_code_h3);
    if ismember('sit_code_h3', ...
            station.Properties.VariableNames)
        station.sit_code_h3 = ...
            normalize_fr_site_id( ...
            station.sit_code_h3);
    end
    if ismember('sit_code_h3', ...
            site.Properties.VariableNames)
        site.sit_code_h3 = ...
            normalize_fr_site_id(site.sit_code_h3);
    end

    AA = station;
    if ismember('sit_code_h3', ...
            AA.Properties.VariableNames) ...
            && ismember('sit_code_h3', ...
            site.Properties.VariableNames)
        AA = outerjoin(AA,site, ...
            'Keys','sit_code_h3', ...
            'MergeKeys',true,'Type','left');
    end
    AA = join_fr_attributes(AA,topoGen);
    AA = join_fr_attributes(AA,topoQ);
    AA = join_fr_attributes(AA,soilGen);
    AA = join_fr_attributes(AA,soilQ);
    AA = join_fr_attributes(AA,land);
    AA = join_fr_attributes(AA,hgeo);
    AA = join_fr_attributes(AA,geol);
    AA = join_fr_attributes(AA,dams);

    AA.sta_code_h3 = normalize_fr_gauge_id( ...
        AA.sta_code_h3);
    [~,isrt] = sort(AA.sta_code_h3);
    AA = AA(isrt,:);
    id_all = AA.sta_code_h3;

    if isfield(bas,'id_gauge') ...
            && ~isempty(bas.id_gauge)
        id_req = ...
            normalize_fr_gauge_id(bas.id_gauge(:));
        [tf,loc] = ismember(id_req,id_all);
        if ~all(tf)
            missing = id_req(~tf);
            error('read_attr_FR:missingRequestedGauge', ...
                ['      Error:read_attr_FR: ' ...
                'Missing CAMELS-FR ' ...
                'attributes for %d requested ' ...
                'station IDs, e.g. %s.'], ...
                numel(missing),char(missing(1)));
        end
        AA = AA(loc,:);
        id_gauge = id_req(:);
    else
        id_gauge = id_all(:);
    end

    if ismember('sta_label', ...
            AA.Properties.VariableNames)
        gname = string(AA.sta_label);
    elseif ismember('sit_label', ...
            AA.Properties.VariableNames)
        gname = string(AA.sit_label);
    else
        gname = "Gauge " + id_gauge;
    end
    % gname = local_standardize_fr_names(gname(:));
    gname = standardize_camels_gauge_names(gname, ...
        'CAMELS_FR',id_gauge);

    ensure_fr_gauge_information(dirD,AA);

    % Join optional precomputed climatic attributes used by the global
    % hydroclimatic zone classifier.  This cache avoids reading hundreds
    % of daily CAMELS-FR time-series files during Prepare Basins.
    AA = local_add_fr_climate_zone_attributes(dirD,AA);

    region = erase(mfilename,'read_attr_');
    zone = classify_camels_all_zones(region,AA, ...
        min_per_zone,max_zones);

    % ------------------
    % Generic attributes
    % ------------------
    [A,labels] = build_attr_matrix(AA,bas, ...
        mfilename,pr_table);

    if pr_table == 1
        assignin('base', ...
            'SAGE_FR_attribute_labels', ...
            labels);
    end
    fprintf(' ... Done\n');
    
end

% ===============================
function T = read_fr_table(fname)
% ===============================
    opts = detectImportOptions(fname, ...
        'FileType','text','Delimiter',';');
    opts.VariableNamingRule = ...
        'preserve';
    T = readtable(fname,opts);
    T.Properties.VariableNames = ...
        matlab.lang.makeValidName( ...
        T.Properties.VariableNames, ...
        'ReplacementStyle','delete');
    T.Properties.VariableNames = ...
        matlab.lang.makeUniqueStrings( ...
        T.Properties.VariableNames);

    if ismember('sta_code_h3', ...
            T.Properties.VariableNames)
        T.sta_code_h3 = ...
            normalize_fr_gauge_id(T.sta_code_h3);
    end
    if ismember('sit_code_h3', ...
            T.Properties.VariableNames)
        T.sit_code_h3 = ...
            normalize_fr_site_id(T.sit_code_h3);
    end
end

% ====================================
function AA = join_fr_attributes(AA,T)
% ====================================
    if ~ismember('sta_code_h3', ...
            T.Properties.VariableNames)
        return
    end
    T.sta_code_h3 = ...
        normalize_fr_gauge_id(T.sta_code_h3);
    T = local_unique_fr_rows(T,'sta_code_h3');

    dup = intersect(AA.Properties.VariableNames, ...
        T.Properties.VariableNames);
    dup(strcmp(dup,'sta_code_h3')) = [];
    if ~isempty(dup)
        T(:,dup) = [];
    end
    AA = outerjoin(AA,T,'Keys','sta_code_h3', ...
        'MergeKeys',true,'Type','left');
end

% =====================================================
function W = widen_repeated_fr_table(T,idName,keyNames)
% =====================================================
    if ~ismember(idName,T.Properties.VariableNames)
        W = T;
        return
    end
    T.(idName) = normalize_fr_gauge_id(T.(idName));
    ids = T.(idName);
    [uids,~,grp] = unique(ids);
    if numel(uids) == height(T)
        W = T;
        return
    end

    keyNames = keyNames(ismember(keyNames, ...
        T.Properties.VariableNames));
    vars = T.Properties.VariableNames;
    dataVars = setdiff(vars,[{idName},keyNames],'stable');

    suffix = strings(height(T),1);
    for i = 1:height(T)
        parts = strings(1,numel(keyNames));
        for j = 1:numel(keyNames)
            v = T.(keyNames{j});
            parts(j) = string(v(i));
        end
        suffix(i) = clean_suffix(strjoin(parts,"_"));
    end

    rawNames = strings(height(T)*numel(dataVars),1);
    c = 0;
    for i = 1:height(T)
        for j = 1:numel(dataVars)
            c = c + 1;
            rawNames(c) = string(dataVars{j}) + "_" + suffix(i);
        end
    end
    rawNames = rawNames(1:c);
    [rawUnique,~,rawMap] = unique(rawNames);

    colNames = matlab.lang.makeUniqueStrings( ...
        matlab.lang.makeValidName(cellstr(rawUnique), ...
        'ReplacementStyle','delete'));

    W = table(uids,'VariableNames',{idName});
    for j = 1:numel(colNames)
        W.(colNames{j}) = nan(numel(uids),1);
    end

    c = 0;
    for i = 1:height(T)
        r = grp(i);
        for j = 1:numel(dataVars)
            c = c + 1;
            col = colNames{rawMap(c)};
            x = get_numeric_attribute( ...
                T.(dataVars{j})(i),dataVars{j});
            if ~isempty(x)
                W.(col)(r) = x(1);
            end
        end
    end
end

% ==========================================================
function AA = local_add_fr_climate_zone_attributes(dirD,AA)
% ==========================================================
% Join a precomputed climate-zone cache when available.
%
% Expected file:
%   CAMELS_FR_climate_zone_attributes.csv
%
% Required identifier column:
%   gauge_id  or sta_code_h3
%
% Optional recognized classifier columns:
%   aridity
%   frac_snow
%   temp_mean
%
% Missing cache files are allowed. In that case the global classifier will
% use its documented regional fallbacks and may issue an explanatory
% warning.

    fclim = fullfile(dirD, ...
        'CAMELS_FR_climate_zone_attributes.csv');

    if ~isfile(fclim)
        return
    end

    try
        opts = detectImportOptions(fclim, ...
            'FileType','text');
        opts.VariableNamingRule = 'preserve';
        C = readtable(fclim,opts);

        C.Properties.VariableNames = ...
            matlab.lang.makeUniqueStrings( ...
            matlab.lang.makeValidName( ...
            strtrim(string(C.Properties.VariableNames)), ...
            'ReplacementStyle','delete'));

        vars = string(C.Properties.VariableNames);

        if any(vars == "gauge_id")
            C.gauge_id = normalize_fr_gauge_id(C.gauge_id);
            C.Properties.VariableNames{ ...
                strcmp(C.Properties.VariableNames,'gauge_id')} = ...
                'sta_code_h3';
        elseif any(vars == "sta_code_h3")
            C.sta_code_h3 = ...
                normalize_fr_gauge_id(C.sta_code_h3);
        else
            warning('read_attr_FR:climateCacheMissingID', ...
                ['      Warning:read_attr_FR: ' ...
                '%s lacks gauge_id or sta_code_h3. ' ...
                'The climate cache was ignored.'],fclim);
            return
        end

        keep = {'sta_code_h3'};
        wanted = {'aridity','frac_snow','temp_mean'};

        for j = 1:numel(wanted)
            vn = wanted{j};
            if ismember(vn,C.Properties.VariableNames)
                C.(vn) = local_fr_numeric(C.(vn));
                keep{end+1} = vn; %#ok<AGROW>
            end
        end

        if numel(keep) == 1
            warning('read_attr_FR:climateCacheNoVariables', ...
                ['      Warning:read_attr_FR: ' ...
                '%s contains no recognized climate variables. ' ...
                'Expected aridity, frac_snow, or temp_mean.'],fclim);
            return
        end

        C = C(:,keep);
        C = local_unique_fr_rows(C,'sta_code_h3');

        % Remove same-named variables from AA before joining so the cache
        % values are used directly rather than being renamed with suffixes.
        dup = intersect(AA.Properties.VariableNames, ...
            C.Properties.VariableNames);
        dup(strcmp(dup,'sta_code_h3')) = [];
        if ~isempty(dup)
            AA(:,dup) = [];
        end

        AA = outerjoin(AA,C, ...
            'Keys','sta_code_h3', ...
            'MergeKeys',true, ...
            'Type','left');

    catch ME
        warning('read_attr_FR:climateCacheReadFailed', ...
            ['      Warning:read_attr_FR: ' ...
            'Could not read climate-zone cache %s.\n%s'], ...
            fclim,ME.message);
    end
end

% ===================================
function x = local_fr_numeric(x)
% ===================================
    if isnumeric(x) || islogical(x)
        x = double(x);
        return
    end

    s = string(x);
    s = strtrim(s);
    s = erase(s,'"');
    s = replace(s,',','.');
    s = regexprep(s, ...
        '^(NA|NaN|null|NULL|-9999)$', ...
        'NaN','ignorecase');
    x = str2double(s);
end

% ===========================================
function ensure_fr_gauge_information(dirD,AA)
% ===========================================
    f_info = fullfile(dirD, ...
        'gauge_information.txt');
    if isfile(f_info)
        return
    end

    id = normalize_fr_gauge_id(AA.sta_code_h3);
    if ismember('sta_label', ...
            AA.Properties.VariableNames)
        nm = string(AA.sta_label);
    else
        nm = "Gauge " + id;
    end
    [lat,lon] = local_fr_coordinates(AA);
    area = get_numeric_column(AA, ...
        {"sit_area_topo", ...
        "sit_area_hydro"});

    try
        Tout = table(id(:),nm(:),lat(:), ...
            lon(:),area(:), ...
            'VariableNames',{'gauge_id', ...
            'gauge_name', ...
            'lat','lon','area'});
        writetable(Tout,f_info,'Delimiter', ...
            '\t','FileType','text');
    catch ME
        warning('read_attr_FR:gaugeInfoWriteFailed', ...
            ['      Warning:read_attr_FR: ' ...
            'Could not write %s.\n%s'], ...
            f_info,ME.message);
    end
end

% ===========================================
function [lat,lon] = local_fr_coordinates(AA)
% ===========================================

    lat = get_numeric_column(AA, ...
        {"sit_latitude","sta_y_w84", ...
        "sta_y_w84_snap"});

    lon = get_numeric_column(AA, ...
        {"sit_longitude","sta_x_w84", ...
        "sta_x_w84_snap"});

    bad = lat < 40 ...
        | lat > 52 ...
        | lon < -6 ...
        | lon > 10;

    if any(bad)
        lat2 = get_numeric_column(AA, ...
            {"sta_y_w84","sta_y_w84_snap", ...
            "sit_latitude"});

        lon2 = get_numeric_column(AA, ...
            {"sta_x_w84","sta_x_w84_snap", ...
            "sit_longitude"});

        ok2 = lat2 >= 40 ...
            & lat2 <= 52 ...
            & lon2 >= -6 ...
            & lon2 <= 10;

        lat(bad & ok2) = lat2(bad & ok2);
        lon(bad & ok2) = lon2(bad & ok2);
    end

end

% ====================================
function id = normalize_fr_gauge_id(v)
% ====================================
    s = string(v);
    s = strip(s);
    s = erase(s,'"');
    s(ismissing(s)) = "";
    id = upper(s(:));
end

% ===================================
function id = normalize_fr_site_id(v)
% ===================================
    s = string(v);
    s = strip(s);
    s = erase(s,'"');
    s(ismissing(s)) = "";
    id = upper(s(:));
end

% =========================================
function T = local_unique_fr_rows(T,idName)
% =========================================
    [u,ia] = unique(T.(idName),'stable');
    if numel(u) ~= height(T)
        T = T(ia,:);
    end
end

% ==========================
function s = clean_suffix(x)
% ==========================
    s = lower(char(string(x)));
    s = regexprep(s,'[^a-zA-Z0-9]+','_');
    s = regexprep(s,'(^_+|_+$)','');
    if isempty(s)
        s = 'x';
    end
end

% =========================================
function files = local_fr_attribute_files()
% =========================================
    files = { ...
        'CAMELS_FR_geology_attributes.csv', ...
        'CAMELS_FR_human_influences_dams.csv', ...
        'CAMELS_FR_hydrogeology_attributes.csv', ...
        'CAMELS_FR_land_cover_attributes.csv', ...
        'CAMELS_FR_site_general_attributes.csv', ...
        'CAMELS_FR_soil_general_attributes.csv', ...
        'CAMELS_FR_soil_quantiles_attributes.csv', ...
        'CAMELS_FR_station_general_attributes.csv', ...
        'CAMELS_FR_topography_general_attributes.csv', ...
        'CAMELS_FR_topography_quantiles_attributes.csv'};
end
