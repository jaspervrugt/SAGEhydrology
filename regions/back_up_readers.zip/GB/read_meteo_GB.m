function [dat,aux] = read_meteo_GB(dirM,bas,split,meteo)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%READ_METEO_GB Read original daily or v2 hourly CAMELS-GB data.
%
% FOLDER LAYOUT
%   Data/CAMELS_GB/daily
%       CAMELS_GB_*_attributes.csv
%   Data/CAMELS_GB/daily/timeseries
%       CAMELS_GB_hydromet_timeseries_<ID>_*.csv
%       or camels_gb_v2_hydromet_daily_timeseries_<ID>_*.csv
%   Data/CAMELS_GB/hourly
%       camels_gb_v2_hydromet_hourly_timeseries_<ID>_*.csv
%
% SAGE RESOLUTION
%   split.dt = 1   daily
%   split.dt = 24  hourly
%
% METEOROLOGICAL OPTIONS
%   Daily original CAMELS-GB:
%     meteo.precip = 1  -> precipitation
%     meteo.temp   = 1  -> temperature
%     meteo.pet    = 1  -> pet
%     meteo.pet    = 2  -> peti
%
%   Hourly CAMELS-GB v2:
%     meteo.precip = 1  -> precipitation_cehgear
%     meteo.precip = 2  -> precipitation_gradgb
%     meteo.temp   = 1  -> temperature from original daily file
%     meteo.pet    = 1  -> pet from original daily file / 24
%     meteo.pet    = 2  -> peti from original daily file / 24
%
% Hourly CAMELS-GB v2 files do not contain PET or temperature. PET (pet or
% peti) and temperature are read from the matching original daily file.
% Daily PET is divided uniformly over the 24 hours of the same calendar day;
% daily temperature is repeated over those same hourly rows.
%
% OUTPUT UNITS
%   Daily:  P, Ep, Q in mm/day
%   Hourly: P, Ep, Q in mm/hour
%   T is degrees C for both resolutions.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% © Written by Jasper A. Vrugt, May 2026 / updated Jul. 2026              %
% University of California, Irvine                                        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    if nargin < 1 ...
            || isempty(dirM)
        error('read_meteo_GB:missingDir', ...
            ['      Error:read_meteo_GB: ' ...
            'dirM must be provided.']);
    end
    if nargin < 2 ...
            || ~isstruct(bas) ...
            || ~isfield(bas,'id_gauge') ...
            || isempty(bas.id_gauge)
        error('read_meteo_GB:missingBasins', ...
            ['      Error:read_meteo_GB: ' ...
            'bas.id_gauge must be provided.']);
    end
    if nargin < 4 ...
            || isempty(meteo)
        meteo = struct();
    end

    split = prepare_split(split);
    dt = double(split.dt);
    if abs(dt-1) < 1e-8
        stream = 'daily';
        step = days(1);
    elseif abs(dt-24) < 1e-8
        stream = 'hourly';
        step = hours(1);
    else
        error('read_meteo_GB:unsupportedDt', ...
            ['      Error:read_meteo_GB: ' ...
            'CAMELS-GB supports daily ' ...
             '(split.dt = 1) and hourly ' ...
             '(split.dt = 24) data.']);
    end

    [~,dirDaily,dirHourly] = local_gb_directories(dirM);
    if strcmp(stream,'daily')
        dirTS = dirDaily;
    else
        dirTS = dirHourly;
    end
    if ~isfolder(dirTS)
        error('read_meteo_GB:missingTimeseriesDir', ...
            ['      Error:read_meteo_GB: ' ...
            'Missing %s folder: %s'], ...
            stream,dirTS);
    end
    if ~isfolder(dirDaily)
        error('read_meteo_GB:missingDailyTimeseriesDir', ...
            ['      Error:read_meteo_GB: ' ...
            'Daily CAMELS-GB files are ' ...
             'required for attributes, ' ...
             'PET, and temperature: %s'],dirDaily);
    end

    precipChoice = local_option(meteo,'precip',1);
    petChoice = local_option(meteo,'pet',1);
    tempChoice = local_option(meteo,'temp',1);
    local_validate_options(stream, ...
        precipChoice,petChoice,tempChoice);

    K = double(bas.K);
    idGauge = double(bas.id_gauge(:));
    dat = cell(K,1);
    aux = nan(K,3);

    dailyRoot = fileparts(dirDaily);
    topoCandidates = { ...
        fullfile(dailyRoot,'CAMELS_GB_topographic_attributes.csv'), ...
        fullfile(dailyRoot,'camels_gb_v2_topographic_attributes.csv')};
    topoFile = '';
    for it = 1:numel(topoCandidates)
        if isfile(topoCandidates{it})
            topoFile = topoCandidates{it};
            break
        end
    end
    if ~isempty(topoFile)
        Ttopo = readtable(topoFile, ...
            'VariableNamingRule','preserve');
    else
        Ttopo = table();
        fprintf(['\n      Warning:read_meteo_GB: ' ...
            'topographic attributes not found; ' ...
            'aux will contain NaN. Checked: %s\n'], ...
            strjoin(topoCandidates,', '));
    end

    reqTime = local_requested_time(split,stream,step);
    cacheDir = fullfile(dirTS,['_cache_GB_' stream]);
    if ~isfolder(cacheDir)
        mkdir(cacheDir); 
    end

    fprintf(['... Reading %s CAMELS-GB ' ...
        'meteorological data files %3d%%'], ...
        stream,0);
    flagProgress = true;

    for k = 1:K
        gid = idGauge(k);
        dailyFile = local_find_gb_file( ...
            dirDaily,gid,'daily');
        if strcmp(stream,'hourly')
            sourceFile = local_find_gb_file( ...
                dirHourly,gid,'hourly');
        else
            sourceFile = dailyFile;
        end

        cacheFile = fullfile(cacheDir,sprintf( ...
            '%d_GB_%s_p%d_pet%d_t%d.mat', ...
            round(gid),stream,precipChoice, ...
            petChoice,tempChoice));

        [timeFull,Pfull,Epfull,Tfull,Qfull,badMFull,badQFull] = ...
            local_load_or_build_cache(sourceFile, ...
            dailyFile,cacheFile, ...
            stream,precipChoice,petChoice, ...
            tempChoice,gid);

        reqTimeUse = reqTime;
        if strcmp(stream,'hourly')
            % CAMELS-GB v2 hourly files are anchored at 09:00 and end at
            % 08:00 on the following day. Preserve the requested number
            % of hourly steps, but align the clock anchor to the file.
            reqTimeUse = local_align_hourly_request( ...
                reqTime,timeFull);
        end

        [tf,loc] = ismember(reqTimeUse,timeFull);
        if ~all(tf)
            missing = reqTimeUse(~tf);
            error('read_meteo_GB:periodOutsideFile', ...
                ['      Error:read_meteo_GB: ' ...
                'Requested %s period is not ' ...
                 'fully available for basin %d. ' ...
                 'First missing step: %s. ' ...
                 'File covers %s to %s.'], ...
                stream,gid,string(missing(1)), ...
                string(timeFull(1)),string(timeFull(end)));
        end

        P = double(Pfull(loc));
        Ep = double(Epfull(loc));
        Temp = double(Tfull(loc));
        Qall = double(Qfull(loc));

        dat{k}.meteo.P = single(P);
        dat{k}.meteo.Ep = single(Ep);
        dat{k}.meteo.T = single(Temp);

        idxScore = double(split.idx(:));
        idxScore = idxScore(idxScore >= 1 ...
            & idxScore <= numel(Qall));
        dat{k}.y_n = single(Qall(idxScore));
        dat{k}.gauge = gid;
        dat{k}.fname{1} = sourceFile;
        dat{k}.fname{2} = sourceFile;
        if strcmp(stream,'hourly')
            dat{k}.fname{3} = dailyFile;
        end

        badM = logical(badMFull(loc));
        badQ = logical(badQFull(loc));
        dat{k}.meteo.bad = find(badM(:)).';
        dat{k}.bad = badQ(idxScore).';

        aux(k,:) = local_gb_aux(Ttopo,gid);

        if mod(k,5)==0 ...
                || k==K
            pct = floor(100*k/K);
            fprintf('\b\b\b\b%3d%%',pct);
            drawnow;
        end
        if isfield(meteo,'progressFcn') ...
                && ~isempty(meteo.progressFcn)
            meteo.progressFcn(k);
        end
    end

    if flagProgress
        fprintf('\b\b\b\b%s\n','... Done');
    end

    if isfield(split,'local') ...
            && split.local ...
            && isfield(split,'rainfall_block') ...
            && split.rainfall_block
        dat = rainfall_rank_split(dat,split);
    end
end

% ==============================================================
function [dirGB,dirDaily,dirHourly] = local_gb_directories(dirM)
% ==============================================================
    d0 = char(string(dirM));
    cands = {d0,fileparts(d0),fileparts(fileparts(d0)), ...
        fileparts(fileparts(fileparts(d0)))};
    dirGB = '';
    for i = 1:numel(cands)
        d = cands{i};
        if isempty(d), continue; end
        if isfolder(fullfile(d,'daily','timeseries')) ...
                || isfolder(fullfile(d,'hourly','timeseries'))
            dirGB = d;
            break
        end
        if strcmpi(local_basename(d),'CAMELS_GB')
            dirGB = d;
            break
        end
    end
    if isempty(dirGB)
        % Accept direct daily/hourly folders during first installation.
        if strcmpi(local_basename(d0),'timeseries') ...
                && any(strcmpi(local_basename(fileparts(d0)), ...
                {'daily','hourly'}))
            dirGB = fileparts(fileparts(d0));
        elseif any(strcmpi(local_basename(d0),{'daily','hourly'}))
            dirGB = fileparts(d0);
        else
            dirGB = d0;
        end
    end
    dirDaily = fullfile(dirGB,'daily','timeseries');
    dirHourly = fullfile(dirGB,'hourly','timeseries');
end

function b = local_basename(d)
    [~,b] = fileparts(d);
end

% ====================================================
function req = local_requested_time(split,stream,step)
% ====================================================
% prepare_split guarantees the complete model-window boundaries:
%   split.dt0    first time step, including spin-up
%   split.dt_end final required time step
%
% split.tout is a numerical model-time/index vector and must not be
% interpreted as MATLAB serial dates.

    if ~isfield(split,'dt0') || isempty(split.dt0)
        error('read_meteo_GB:missingSplitStart', ...
            ['      Error:read_meteo_GB: split.dt0 is missing. ' ...
             'prepare_split must provide the complete period start.']);
    end
    if ~isfield(split,'dt_end') || isempty(split.dt_end)
        error('read_meteo_GB:missingSplitEnd', ...
            ['      Error:read_meteo_GB: split.dt_end is missing. ' ...
             'prepare_split must provide the complete period end.']);
    end

    t0 = local_gb_datetime(split.dt0);
    t1 = local_gb_datetime(split.dt_end);

    if strcmp(stream,'hourly')
        t0 = dateshift(t0,'start','hour');
        t1 = dateshift(t1,'start','hour');

        % Some split builders store a date-only final boundary. For an
        % hourly simulation, include the complete final calendar day.
        if hour(t1) == 0 && minute(t1) == 0 && second(t1) == 0
            expectedN = [];
            if isfield(split,'tout') && ~isempty(split.tout)
                expectedN = numel(split.tout);
            end
            nThroughMidnight = hours(t1 - t0) + 1;
            nThroughEndOfDay = hours( ...
                (dateshift(t1,'start','day') + hours(23)) - t0) + 1;
            if ~isempty(expectedN) ...
                    && abs(expectedN - nThroughEndOfDay) ...
                    < abs(expectedN - nThroughMidnight)
                t1 = dateshift(t1,'start','day') + hours(23);
            end
        end
    else
        t0 = dateshift(t0,'start','day');
        t1 = dateshift(t1,'start','day');
    end

    if t1 < t0
        error('read_meteo_GB:badSplitPeriod', ...
            ['      Error:read_meteo_GB: Requested period end (%s) ' ...
             'precedes period start (%s).'],string(t1),string(t0));
    end

    req = (t0:step:t1).';
end

function d = local_gb_datetime(x)
% Convert the date formats used by SAGE without confusing index vectors
% with serial dates.

    if isdatetime(x)
        d = x(1);
        return
    end

    if ischar(x) || isstring(x) || iscellstr(x)
        d = datetime(string(x(1)));
        return
    end

    if ~isnumeric(x)
        error('read_meteo_GB:badDate', ...
            'Unsupported split date type: %s.',class(x));
    end

    x = double(x(:).');

    if numel(x) >= 3
        % Accept [year month day ...] and [day month year ...].
        if x(1) > 1800
            y = x(1); m = x(2); da = x(3);
        elseif x(3) > 1800
            y = x(3); m = x(2); da = x(1);
        else
            error('read_meteo_GB:badDateVector', ...
                ['Cannot determine date-vector order from [%s].'], ...
                strtrim(sprintf('%g ',x)));
        end

        hh = 0; mm = 0; ss = 0;
        if numel(x) >= 4, hh = x(4); end
        if numel(x) >= 5, mm = x(5); end
        if numel(x) >= 6, ss = x(6); end
        d = datetime(y,m,da,hh,mm,ss);
        return
    end

    if isscalar(x) && x >= 1e7 && x < 1e8
        y = floor(x/10000);
        m = floor((x - 10000*y)/100);
        da = x - 10000*y - 100*m;
        d = datetime(y,m,da);
        return
    end

    if isscalar(x) && x > 5e5
        d = datetime(x,'ConvertFrom','datenum');
        return
    end

    error('read_meteo_GB:badDateScalar', ...
        ['Numeric split date %g is not a recognized date. ' ...
         'It appears to be a model-time/index value.'],x);
end

% ====================================================
function req = local_align_hourly_request(req,timeFull)
% ====================================================
% CAMELS-GB v2 hourly timestamps use a 09:00-to-08:00 daily anchor.
% SAGE period controls are date based and therefore normally produce a
% midnight-to-23:00 sequence. Shift the sequence to the file anchor while
% preserving exactly the same number of hourly model steps.

    req = req(:);
    timeFull = timeFull(:);

    if isempty(req) || isempty(timeFull)
        return
    end

    anchor = timeofday(timeFull(1));
    reqAnchor = timeofday(req(1));

    if anchor == reqAnchor
        return
    end

    reqStart = dateshift(req(1),'start','day') + anchor;
    req = reqStart + hours((0:numel(req)-1).');
end

% ====================================================
function fname = local_find_gb_file(folder,gid,stream)
% ====================================================
    if strcmp(stream,'hourly')
        pats = { ...
            sprintf(['camels_gb_v2_hydromet_' ...
            'hourly_timeseries_%d_*.csv'],round(gid)), ...
            sprintf('*hourly*_%d_*.csv',round(gid))};
    else
        pats = { ...
            sprintf(['camels_gb_v2_hydromet_' ...
            'daily_timeseries_%d_*.csv'],round(gid)), ...
            sprintf('CAMELS_GB_hydromet_timeseries_%d_*.csv', ...
            round(gid)), ...
            sprintf('*daily*_%d_*.csv',round(gid))};
    end
    D = [];
    for i = 1:numel(pats)
        D = dir(fullfile(folder,pats{i}));
        if ~isempty(D), break; end
    end
    if isempty(D)
        error('read_meteo_GB:missingFile', ...
            ['      Error:read_meteo_GB: Missing %s ' ...
            'file for basin %d in %s.'], ...
            stream,gid,folder);
    end
    fname = fullfile(D(1).folder,D(1).name);
end

% ======================================================================
function [time,P,Ep,Tair,Q,badM,badQ] = local_load_or_build_cache( ...
    sourceFile,dailyFile,cacheFile,stream,pChoice,petChoice,tChoice,gid)
% ======================================================================
    useCache = false;
    if isfile(cacheFile)
        try
            c = dir(cacheFile);
            s = dir(sourceFile);
            d = dir(dailyFile);
            useCache = c.datenum >= max(s.datenum,d.datenum);
        catch
            useCache = false;
        end
    end
    if useCache
        S = load(cacheFile,'time','P','Ep','Tair','Q','badM','badQ');
        time=S.time; P=S.P; Ep=S.Ep; Tair=S.Tair;
        Q=S.Q; badM=S.badM; badQ=S.badQ;
        return
    end

    if strcmp(stream,'daily')
        T = readtable(sourceFile,'VariableNamingRule','preserve');
        T = local_standardize_names(T);
        time = datetime(string(T.date),'InputFormat','yyyy-MM-dd');
        P = single(local_daily_precip(T,pChoice,sourceFile));
        Ep = single(max(local_daily_pet(T,petChoice,sourceFile),0));
        Tair = single(local_daily_temp(T,tChoice,sourceFile));
        Q = single(local_required_column(T,'discharge_spec',sourceFile));
    else
        H = readtable(sourceFile,'VariableNamingRule','preserve');
        H = local_standardize_names(H);
        needH = {'date','precipitation_cehgear', ...
            'precipitation_gradgb','discharge_spec'};
        local_require_columns(H,needH,sourceFile);
        time = datetime(string(H.date), ...
            'InputFormat','yyyy-MM-dd HH:mm:ss');

        if pChoice == 1
            P = single(double(H.precipitation_cehgear(:)));
        else
            P = single(double(H.precipitation_gradgb(:)));
        end
        Q = single(double(H.discharge_spec(:)));

        D = readtable(dailyFile,'VariableNamingRule','preserve');
        D = local_standardize_names(D);
        local_require_columns(D,{'date'},dailyFile);
        dayTime = datetime(string(D.date),'InputFormat','yyyy-MM-dd');
        petDaily = local_daily_pet(D,petChoice,dailyFile);
        tempDaily = local_daily_temp(D,tChoice,dailyFile);

        [tf,loc] = ismember(dateshift(time,'start','day'),dayTime);
        Ep = nan(size(time),'single');
        Tair = nan(size(time),'single');
        Ep(tf) = single(max(petDaily(loc(tf)),0)/24);
        Tair(tf) = single(tempDaily(loc(tf)));
        if any(~tf)
            fprintf(['\n      Warning:read_meteo_GB: ' ...
                '%d hourly rows ' ...
                'for basin %d have no matching ' ...
                'daily PET/temperature.\n'], ...
                sum(~tf),gid);
        end
    end

    time = time(:);
    P=P(:); Ep=Ep(:); Tair=Tair(:); Q=Q(:);
    badM = ~isfinite(double(P)) ...
        | ~isfinite(double(Ep)) ...
        | ~isfinite(double(Tair));
    badQ = ~isfinite(double(Q));

    save(cacheFile,'time','P','Ep','Tair','Q','badM','badQ', ...
        'stream','pChoice','petChoice','tChoice','gid','-v7.3');
end

% =====================================
function T = local_standardize_names(T)
% =====================================
    T.Properties.VariableNames = ...
        matlab.lang.makeValidName( ...
        T.Properties.VariableNames, ...
        'ReplacementStyle','delete');
end

function local_require_columns(T,names,fname)
    for i=1:numel(names)
        if ~ismember(names{i},T.Properties.VariableNames)
            error('read_meteo_GB:missingColumn', ...
                ['Required column "%s" ' ...
                'not found in %s.'],names{i},fname);
        end
    end
end

function x = local_required_column(T,name,fname)
    local_require_columns(T,{name},fname);
    x = double(T.(name)(:));
end

function x = local_daily_precip(T,choice,fname)
% Original CAMELS-GB daily files contain one precipitation column.
    if choice ~= 1
        error('read_meteo_GB:badDailyPrecipChoice', ...
            ['Daily CAMELS-GB has one precipitation source. ' ...
             'meteo.precip must equal 1.']);
    end
    x = local_required_column(T,'precipitation',fname);
end

function x = local_daily_pet(T,choice,fname)
% Original CAMELS-GB daily files contain pet and peti.
    switch choice
        case 1
            x = local_required_column(T,'pet',fname);
        case 2
            x = local_required_column(T,'peti',fname);
        otherwise
            error('read_meteo_GB:badDailyPetChoice', ...
                ['CAMELS-GB PET must be 1 (pet) or 2 (peti).']);
    end
end

function x = local_daily_temp(T,choice,fname)
% Original CAMELS-GB daily files contain one temperature column.
    if choice ~= 1
        error('read_meteo_GB:badDailyTempChoice', ...
            ['Daily CAMELS-GB has one temperature source. ' ...
             'meteo.temp must equal 1.']);
    end
    x = local_required_column(T,'temperature',fname);
end

function value = local_option(S,name,defaultValue)
    value = defaultValue;
    if isstruct(S) && isfield(S,name) ...
            && ~isempty(S.(name))
        value = round(double(S.(name)(1)));
    end
end

function local_validate_options(stream, ...
    pChoice,petChoice,tChoice)

    if strcmp(stream,'daily')
        if pChoice ~= 1
            error('read_meteo_GB:badPrecipChoice', ...
                ['Daily CAMELS-GB contains one precipitation column; ' ...
                 'meteo.precip must equal 1.']);
        end
    else
        if ~ismember(pChoice,1:2)
            error('read_meteo_GB:badPrecipChoice', ...
                ['Hourly CAMELS-GB v2 meteo.precip must be 1 ' ...
                 '(CEH-GEAR) or 2 (Grid-to-Grid).']);
        end
    end

    if ~ismember(petChoice,1:2)
        error('read_meteo_GB:badPetChoice', ...
            ['CAMELS-GB meteo.pet must be 1 (pet) or 2 (peti).']);
    end

    if tChoice ~= 1
        error('read_meteo_GB:badTempChoice', ...
            ['CAMELS-GB contains one daily temperature column; ' ...
             'meteo.temp must equal 1.']);
    end
end

% ====================================
function aux = local_gb_aux(Ttopo,gid)
% ====================================
    aux = [NaN NaN NaN];
    if isempty(Ttopo) ...
            || height(Ttopo)==0
        return; 
    end
    Ttopo = local_standardize_names(Ttopo);
    vn = Ttopo.Properties.VariableNames;
    idcol = local_find_var(vn,{'gauge_id','gaugeid','id'});
    latcol = local_find_var(vn,{'gauge_lat','lat','latitude'});
    elevcol = local_find_var(vn, ...
        {'elev_mean','gauge_elev','elevation','elev'});
    areacol = local_find_var(vn,{'area','area_km2','catchment_area'});
    if isempty(idcol), return; end
    ids = double(Ttopo{:,idcol});
    j = find(ids==double(gid),1,'first');
    if isempty(j), return; end
    if ~isempty(latcol), aux(1)=double(Ttopo{j,latcol}); end
    if ~isempty(elevcol), aux(2)=double(Ttopo{j,elevcol}); end
    if ~isempty(areacol)
        a=double(Ttopo{j,areacol});
        if isfinite(a) && a<1e7, a=a*1e6; end
        aux(3)=a;
    end
end

function idx = local_find_var(vn,cands)
    normf=@(s) lower(regexprep(char(s),'[^a-z0-9]',''));
    vnn=cellfun(normf,vn,'UniformOutput',false);
    idx=[];
    for k=1:numel(cands)
        hit=find(strcmp(vnn,normf(cands{k})),1,'first');
        if ~isempty(hit), idx=hit; return; end
    end
end
