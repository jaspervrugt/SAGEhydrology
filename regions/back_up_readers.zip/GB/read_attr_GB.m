function [A,id_gauge,gname,zone] = read_attr_GB(dirD,bas)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%READ_ATTR_GB Read catchment attributes of CAMELS-GB dataset.
%
% SYNOPSIS:
%   [A,id_gauge,gname,zone] = read_attr_GB(dirD,bas)
%
% INPUT:
%   dirD        Directory with CAMELS-GB catchment-attribute files
%   bas         OPTIONAL: structure with basin and attribute information
%    .id_gauge   OPTIONAL: vector of requested NRFA gauge identifiers
%    .id_attr    rx1 vector of integer attribute IDs
%    .pr_attr    OPTIONAL: print attribute table [1/0]
%
% OUTPUT:
%   A           r x K matrix of standardized selected attributes
%   id_gauge    K x 1 vector with NRFA gauge identifiers
%   gname       K x 1 string array with standardized gauge names
%   zone        structure with CAMELS-GB hydroclimatic classification
%    .id          K x 1 string array with zone labels per basin
%    .num         K x 1 numeric vector with integer zone identifiers
%    .names       m x 1 string array with unique zone names
%    .aridity     K x 1 vector with aridity-index values
%    .frac_snow   K x 1 vector with snow-fraction values
%
% DESCRIPTION:
%   This function reads and joins CAMELS-GB topographic, climatic,
%   hydrologic, hydrogeology, soil, land-cover, human-influence, and
%   hydrometry attributes by gauge_id. The topographic table is used as the
%   master table because it contains gauge_id, gauge_name, gauge location,
%   elevation, and basin area. The attribute order mirrors the internal
%   joins:
%   topographic -> climatic -> hydrologic -> hydrogeology -> soil
%   -> land-cover -> human-influence -> hydrometry.
%
% NOTES:
%   If bas is omitted, a small default attribute set is used. Default
%   attributes should include only basic watershed and climate information,
%   not discharge-derived hydrologic signatures.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% © Written by Jasper A. Vrugt, Apr. 2026                                 %
% University of California, Irvine                                        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    if nargin < 1 ...
            || isempty(dirD)
        error('read_attr_GB:missingDir', ...
            ['      Error:read_attr_GB: ' ...
            'dirD must be provided.']);
    end
    
    if ~isfolder(dirD)
        error('read_attr_GB:missingDir', ...
            ['      Error:read_attr_GB: ' ...
            'Attribute directory ' ...
            'does not exist: %s'],dirD);
    end
    
    if nargin < 2 ...
            || isempty(bas)
        bas = struct();
    end
    
    if ~isstruct(bas)
        error('read_attr_GB:badBas', ...
            ['      Error:read_attr_GB: ' ...
            'bas must be a structure.']);
    end
    % =========================================
    % ZONE CONTROL PARAMETERS (GLOBAL DEFAULTS)
    % =========================================
    if ~isfield(bas,'min_per_zone') ...
            || isempty(bas.min_per_zone)
        min_per_zone = 5;
    else
        min_per_zone = bas.min_per_zone;
    end    
    if ~isfield(bas,'max_zones') ...
            || isempty(bas.max_zones)
        max_zones = 8;
    else
        max_zones = bas.max_zones;
    end
    
    do_attr = ~isempty(bas);
    % If bas is omitted as input argument, use a small default 
    % climate-only attribute set.

    pr_table = 1;
    if do_attr ...
            && isstruct(bas) ...
            && isfield(bas,'pr_attr') ...
            && ~isempty(bas.pr_attr)
        pr_table = bas.pr_attr;
    end
    
    if do_attr
        if ~isstruct(bas) ...
                || ~isfield(bas,'id_attr') ...
                || isempty(bas.id_attr)
            error('read_attr_GB:missingIdAttr', ...
                ['      Error:read_attr_GB: ' ...
                'bas.id_attr must be provided.']);
        end
    end

    % CAMELS-GB uses two attribute releases:
    %   daily  -> original CAMELS_GB_*.csv tables
    %   hourly -> CAMELS-GB v2 camels_gb_v2_*.csv tables
    %
    % Both releases are normalized to the same attr_catalog names/order.
    % Static hourly/v2 gaps are filled from the original daily table for
    % the same gauge_id. This is especially important for soil attributes
    % such as attribute 94 (soil_depth_pelletier_50).
    leaf = lower(local_basename(dirD));
    if any(strcmpi(leaf,{'daily','hourly'}))
        stream = leaf;
        attrDir = dirD;
        rootGB = fileparts(dirD);
    else
        stream = 'daily';
        rootGB = dirD;
        attrDir = fullfile(rootGB,'daily');
    end
    dailyDir = fullfile(rootGB,'daily');

    kinds = {'climatic','humaninfluence','hydrogeology', ...
        'hydrologic','hydrometry','landcover','soil','topographic'};

    files = struct();
    for iFile = 1:numel(kinds)
        kind = kinds{iFile};
        files.(kind) = local_resolve_gb_attribute_file( ...
            attrDir,dailyDir,stream,kind);
    end

    fprintf('... Reading CAMELS-GB %s basin attributes ',stream);

    clim = read_gb_table(files.climatic);
    hinf = read_gb_table(files.humaninfluence);
    hgeo = read_gb_table(files.hydrogeology);
    hydro = read_gb_table(files.hydrologic);
    hmet = read_gb_table(files.hydrometry);
    land = read_gb_table(files.landcover);
    soil = read_gb_table(files.soil);
    topo = read_gb_table(files.topographic);

    if strcmp(stream,'hourly')
        clim = local_coalesce_from_daily(clim,dailyDir,'climatic');
        hinf = local_coalesce_from_daily(hinf,dailyDir,'humaninfluence');
        hgeo = local_coalesce_from_daily(hgeo,dailyDir,'hydrogeology');
        hydro = local_coalesce_from_daily(hydro,dailyDir,'hydrologic');
        hmet = local_coalesce_from_daily(hmet,dailyDir,'hydrometry');
        land = local_coalesce_from_daily(land,dailyDir,'landcover');
        soil = local_coalesce_from_daily(soil,dailyDir,'soil');
        topo = local_coalesce_from_daily(topo,dailyDir,'topographic');
    end

    % Preserve the established attr_catalog names while reading v2 tables.
    % Hourly uses the latest available land-cover year (2022 first).
    land = local_add_v2_landcover_aliases(land,stream);
    hmet = local_add_v2_hydrometry_aliases(hmet,stream);

    % CAMELS-US has a metadata/gauge_information.txt file that some later
    % SAGE routines expect. CAMELS-GB does not ship this file, so create a
    % resolution-specific copy in the active attribute directory:
    %   Data/CAMELS_GB/daily/gauge_information.txt
    %   Data/CAMELS_GB/hourly/gauge_information.txt
    ensure_gb_gauge_information(attrDir,topo);
    
    % Use the topographic table as the master because it contains names,
    % location, elevation, and basin area.
    AA = topo;
    AA = join_gb_attributes(AA,clim);
    AA = join_gb_attributes(AA,hydro);
    AA = join_gb_attributes(AA,hgeo);
    AA = join_gb_attributes(AA,soil);
    AA = join_gb_attributes(AA,land);
    AA = join_gb_attributes(AA,hinf);
    AA = join_gb_attributes(AA,hmet);
    
    id_gauge_all = double(AA.gauge_id);
    
    % Optional selected basin order. This keeps compatibility with the SAGE
    % basin selection/sampling code, which may pass bas.id_gauge.
    if isstruct(bas) ...
            && isfield(bas,'id_gauge') ...
            && ~isempty(bas.id_gauge)
        id_req = double(string_to_double(bas.id_gauge(:)));
        [tf,loc] = ismember(id_req,id_gauge_all);
        if ~all(tf)
            missing = id_req(~tf);
            error('read_attr_GB:missingRequestedGauge', ...
                ['      Error:read_attr_GB: ' ...
                'Missing CAMELS-GB attributes ' ...
                'for %d requested gauge IDs ' ...
                '(e.g., %s).'],numel(missing), ...
                local_id_str(missing(1)));
        end
        AA = AA(loc,:);
        id_gauge = id_req(:);
    else
        id_gauge = id_gauge_all(:);
    end
    
    % Gauge names
    if ismember('gauge_name',AA.Properties.VariableNames)
        gname = string(AA.gauge_name);
    else
        gname = "Gauge " + string(id_gauge);
    end
    gname = standardize_camels_gauge_names( ...
        gname(:),'CAMELS_GB',id_gauge);
    
    % Hydroclimatic classification
    region = erase(mfilename,'read_attr_');
    zone = classify_camels_all_zones(region,AA, ...
        min_per_zone,max_zones);
    
    % ------------------
    % Generic attributes
    % ------------------
    local_check_requested_gb_attributes(AA,bas,stream);
    [A,labels] = build_attr_matrix(AA,bas, ...
        mfilename,pr_table);

    if pr_table == 1
        assignin('base', ...
            'SAGE_GB_attribute_labels', ...
            labels);
    end
    
    fprintf(' ... Done\n');

end

% =============
% Local helpers
% =============
function T = read_gb_table(fname)
    opts = detectImportOptions(fname,'FileType','text');
    opts.VariableNamingRule = 'preserve';
    T = readtable(fname,opts);
    T.Properties.VariableNames = matlab.lang.makeValidName( ...
        T.Properties.VariableNames,'ReplacementStyle','delete');
    if ~ismember('gauge_id',T.Properties.VariableNames)
        error('read_attr_GB:missingGaugeID', ...
            ['      Error:read_attr_GB: ' ...
            'File %s does not contain gauge_id.'],fname);
    end
    T.gauge_id = double(string_to_double(T.gauge_id));
    T = sortrows(T,'gauge_id');
    end
    
    function T = join_gb_attributes(T,U)
    % Join by gauge_id while avoiding duplicate variable names.
    varsT = string(T.Properties.VariableNames);
    varsU = string(U.Properties.VariableNames);
    varsU = varsU(varsU ~= "gauge_id");
    
    for j = 1:numel(varsU)
        if any(varsT == varsU(j))
            newName = char(varsU(j) + "_gb");
            U.Properties.VariableNames{varsU(j) ...
               == string(U.Properties.VariableNames)} = newName;
        end
    end
    
    T = outerjoin(T,U, ...
        'Keys','gauge_id', ...
        'MergeKeys',true, ...
        'Type','left');
end

function ensure_gb_gauge_information(dirD,topo)
%ENSURE_GB_GAUGE_INFORMATION Write CAMELS-GB gauge_information.txt if absent.
%
% The file mimics the CAMELS-US metadata/gauge_information.txt layout:
%   HUC_02  GAGE_ID  GAGE_NAME  LAT  LONG  DRAINAGE AREA (KM^2)
%
% CAMELS-GB has no HUC_02 code, so this field is filled with "GB".
% This keeps later SAGE code that reads columns 2, 4, 5 and 6 working.

    fout = fullfile(dirD,'gauge_information.txt');
    
    if isfile(fout)
        return
    end
    
    needVars = {'gauge_id','gauge_name', ...
        'gauge_lat','gauge_lon','area'};
    for j = 1:numel(needVars)
        if ~ismember(needVars{j}, ...
                topo.Properties.VariableNames)
            error('read_attr_GB:missingGaugeInfoVar', ...
                ['      Error:read_attr_GB: ' ...
                'Cannot create ' ...
                 'gauge_information.txt ' ...
                 'because %s is missing from ' ...
                 'CAMELS_GB_topographic_attributes.csv.'], ...
                 needVars{j});
        end
    end
    
    fid = fopen(fout,'w');
    if fid < 0
        error('read_attr_GB:gaugeInfoWriteFailed', ...
            ['      Error:read_attr_GB: ' ...
            'Could not write ' ...
             'gauge_information.txt to %s.'],dirD);
    end
    cleanup = onCleanup(@() fclose(fid));
    
    fprintf(fid,['HUC_02\tGAGE_ID\tGAGE_NAME\tLAT\tLONG\t' ...
        'DRAINAGE AREA (KM^2)\n']);
    
    for k = 1:height(topo)
        gid = string(topo.gauge_id(k));
        gid = regexprep(gid,'\.0+$','');
    
        gnm = string(topo.gauge_name(k));
        gnm = replace(gnm,char(9),' ');   % protect tab-delimited format
        gnm = replace(gnm,newline,' ');
    
        lat = double(topo.gauge_lat(k));
        lon = double(topo.gauge_lon(k));
        area = double(topo.area(k));
    
        fprintf(fid,'GB\t%s\t%s\t%.6f\t%.6f\t%.6f\n', ...
            char(gid),char(gnm),lat,lon,area);
    end
    fprintf(['\n      Wrote CAMELS-GB gauge ' ...
        'information file: %s'],fout);

end

function b = local_basename(d)
    [~,b] = fileparts(char(string(d)));
end

function T = local_add_v2_landcover_aliases(T,stream)
    bases = {'dwood','ewood','grass','shrub','crop','urban','inwater','bares'};
    years = [2022 2021 2020 2019 2018 2017 2015 1990];
    if strcmpi(stream,'daily')
        years = [1990 years(years ~= 1990)];
    end

    for i = 1:numel(bases)
        oldName = [bases{i} '_perc'];
        if ismember(oldName,T.Properties.VariableNames)
            continue
        end
        for iy = 1:numel(years)
            v2Name = sprintf('%s_perc_%d',bases{i},years(iy));
            if ismember(v2Name,T.Properties.VariableNames)
                T.(oldName) = T.(v2Name);
                break
            end
        end
    end

    if ~ismember('dom_land_cover',T.Properties.VariableNames)
        vars = cellstr(string(bases) + "_perc");
        if all(ismember(vars,T.Properties.VariableNames))
            X = nan(height(T),numel(vars));
            for j = 1:numel(vars)
                X(:,j) = double(T.(vars{j}));
            end
            [~,ix] = max(X,[],2,'omitnan');
            labels = ["deciduous woodland","evergreen woodland", ...
                "grass/pasture","shrub","crop","urban", ...
                "inland water","bare soil/rock"];
            dom = strings(height(T),1);
            good = any(isfinite(X),2);
            dom(good) = labels(ix(good));
            T.dom_land_cover = dom;
        end
    end
end

function T = local_add_v2_hydrometry_aliases(T,stream)
    prefix = 'daily';
    if strcmpi(stream,'hourly')
        prefix = 'hourly';
    end

    aliases = { ...
        'flow_period_start',[prefix '_flow_period_start']; ...
        'flow_period_end',[prefix '_flow_period_end']; ...
        'flow_perc_complete',[prefix '_flow_perc_complete']};

    for i = 1:size(aliases,1)
        oldName = aliases{i,1};
        v2Name = aliases{i,2};
        if ~ismember(oldName,T.Properties.VariableNames) ...
                && ismember(v2Name,T.Properties.VariableNames)
            T.(oldName) = T.(v2Name);
        end
    end
end

function local_check_requested_gb_attributes(AA,bas,stream)
% Report the raw attribute name and gauge before standardization.

    if ~isstruct(bas) || ~isfield(bas,'id_attr') || isempty(bas.id_attr)
        return
    end

    C = attr_catalog('CAMELS_GB');
    ids = double(bas.id_attr(:));
    ids = ids(ids >= 1 & ids <= numel(C.names));

    for i = 1:numel(ids)
        id = ids(i);
        name = C.names{id};

        if ~ismember(name,AA.Properties.VariableNames)
            error('read_attr_GB:missingCatalogAttribute', ...
                ['      Error:read_attr_GB: CAMELS-GB %s attribute ID %d ' ...
                 '(%s) is missing after schema normalization.'], ...
                stream,id,name);
        end

        x = AA.(name);
        if isnumeric(x) || islogical(x)
            bad = ~isfinite(double(x));
            if any(bad)
                gids = AA.gauge_id(bad);
                error('read_attr_GB:nonfiniteCatalogAttribute', ...
                    ['      Error:read_attr_GB: CAMELS-GB %s attribute ' ...
                     'ID %d (%s) contains NaN/Inf for %d basin(s), ' ...
                     'for example gauge %s.'], ...
                    stream,id,name,sum(bad),local_id_str(gids(1)));
            end
        end
    end
end

function fname = local_resolve_gb_attribute_file( ...
    attrDir,dailyDir,stream,kind)
% Daily prefers CAMELS_GB_*. Hourly prefers camels_gb_v2_*.

    originalName = sprintf('CAMELS_GB_%s_attributes.csv',kind);
    v2Name = sprintf('camels_gb_v2_%s_attributes.csv',kind);

    if strcmpi(stream,'hourly')
        candidates = { ...
            fullfile(attrDir,v2Name), ...
            fullfile(attrDir,originalName), ...
            fullfile(dailyDir,originalName), ...
            fullfile(dailyDir,v2Name)};
    else
        candidates = { ...
            fullfile(attrDir,originalName), ...
            fullfile(attrDir,v2Name)};
    end

    fname = '';
    for i = 1:numel(candidates)
        if isfile(candidates{i})
            fname = candidates{i};
            break
        end
    end

    if isempty(fname)
        error('read_attr_GB:missingAttributeFile', ...
            ['      Error:read_attr_GB: Required %s attribute file ' ...
             'not found. Checked:\n      %s'], ...
            kind,strjoin(candidates,sprintf('\n      ')));
    end
end

function T = local_coalesce_from_daily(T,dailyDir,kind)
% Fill missing v2 columns and values from the original daily static table.

    fDaily = fullfile(dailyDir, ...
        sprintf('CAMELS_GB_%s_attributes.csv',kind));
    if ~isfile(fDaily)
        return
    end

    D = read_gb_table(fDaily);
    [tf,loc] = ismember(T.gauge_id,D.gauge_id);
    if ~any(tf)
        return
    end

    varsD = D.Properties.VariableNames;
    varsD(strcmp(varsD,'gauge_id')) = [];

    for j = 1:numel(varsD)
        name = varsD{j};
        dval = D.(name);

        if ~ismember(name,T.Properties.VariableNames)
            if isnumeric(dval) || islogical(dval)
                x = nan(height(T),1);
                x(tf) = double(dval(loc(tf)));
                T.(name) = x;
            else
                x = strings(height(T),1);
                x(tf) = string(dval(loc(tf)));
                T.(name) = x;
            end
            continue
        end

        tval = T.(name);
        rows = find(tf);

        if isnumeric(tval) || islogical(tval)
            x = double(tval);
            y = double(dval(loc(tf)));
            bad = ~isfinite(x(rows)) & isfinite(y);
            x(rows(bad)) = y(bad);
            T.(name) = x;
        else
            x = string(tval);
            y = string(dval(loc(tf)));
            bad = ismissing(x(rows)) | strlength(strtrim(x(rows))) == 0;
            goodY = ~ismissing(y) & strlength(strtrim(y)) > 0;
            use = bad & goodY;
            x(rows(use)) = y(use);
            T.(name) = x;
        end
    end
end

function x = string_to_double(x)
    if isnumeric(x)
        x = double(x);
        return
    end
    x = string(x);
    x = strtrim(x);
    x = regexprep(x,'\.0+$','');
    x = str2double(x);
end

function s = local_id_str(x)
    if isnumeric(x) ...
            && isfinite(x)
        s = sprintf('%d',x);
    else
        s = char(string(x));
    end
end
