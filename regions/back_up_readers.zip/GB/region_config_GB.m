function R = region_config_GB()
%REGION_CONFIG_GB Regional defaults for CAMELS-GB.
%
% All X.paths fields are relative to Data/<R.data_root>.
% Dates use dd/MM/yyyy and water-year boundaries.

    R = struct();
    R.code = 'CAMELS_GB';
    R.acronym = 'GB';
    R.name = 'Great Britain';
    R.dataset = 'CAMELS-GB';
    R.data_root = 'CAMELS_GB';
    R.resolutions = {'Daily','Hourly'};
    R.default_resolution = 'Daily';
    R.basin_file_pattern = 'GB_%d_basins.txt';

    X = struct();
    X.label = 'Daily';
    X.dt = 1;
    X.basins.universe = 669;
    X.basins.training = 500;
    X.basins.evaluation = 169;
    X.period.spinup_days = 365;
    X.period.manual.train_start = '01/10/2002';
    X.period.manual.train_end = '30/09/2015';
    X.period.manual.eval_start = '01/10/1990';
    X.period.manual.eval_end = '30/09/2002';
    X.period.common_start = '01/10/1990';
    X.period.common_end = '30/09/2015';
    X.paths.run_root = fullfile('daily');
    X.paths.meteo = fullfile('daily','timeseries');
    X.paths.discharge = fullfile('daily','timeseries');
    % Meteorological/PET controls shown by SAGE-GUI.
    X.meteo.product.items = {'CAMELS-GB [daily]'};
    X.meteo.product.default = 'CAMELS-GB [daily]';
    X.meteo.product.enabled = false;
    X.meteo.precipitation.items = {'1 Precipitation'};
    X.meteo.precipitation.default = '1 Precipitation';
    X.meteo.precipitation.enabled = false;
    X.meteo.temperature.items = {'1 Temperature'};
    X.meteo.temperature.default = '1 Temperature';
    X.meteo.temperature.enabled = false;
    X.meteo.pet.items = { ...
        '1 PET', ...
        '2 PET with interception' ...
        };
    X.meteo.pet.default = '1 PET';
    X.meteo.pet.enabled = true;
    C = repmat(struct('name','','type','','path','','pattern','', ...
        'minimum_count',1,'required',true),0,1);
    C(1).name = 'Meteorological data';
    C(1).type = 'folder';
    C(1).path = fullfile('daily','timeseries');
    C(1).pattern = '*';
    C(1).minimum_count = 1;
    X.checks = C;
    R.by_resolution.Daily = X;

    X = struct();
    X.label = 'Hourly';
    X.dt = 24;
    X.basins.universe = 669;
    X.basins.training = 500;
    X.basins.evaluation = 169;
    X.period.spinup_days = 365;
    X.period.manual.train_start = '01/10/2002';
    X.period.manual.train_end = '30/09/2015';
    X.period.manual.eval_start = '01/10/1991';
    X.period.manual.eval_end = '30/09/2002';
    X.period.common_start = '01/10/1991';
    X.period.common_end = '30/09/2015';
    X.paths.run_root = fullfile('hourly');
    X.paths.meteo = fullfile('hourly','timeseries');
    X.paths.discharge = fullfile('hourly','timeseries');
    % Meteorological/PET controls shown by SAGE-GUI.
    X.meteo.product.items = {'CAMELS-GB v2 [hourly]'};
    X.meteo.product.default = 'CAMELS-GB v2 [hourly]';
    X.meteo.product.enabled = false;
    X.meteo.precipitation.items = { ...
        '1 CEH-GEAR', ...
        '2 Grid-to-Grid' ...
        };
    X.meteo.precipitation.default = '1 CEH-GEAR';
    X.meteo.precipitation.enabled = true;
    X.meteo.temperature.items = {'1 Daily temperature'};
    X.meteo.temperature.default = '1 Daily temperature';
    X.meteo.temperature.enabled = false;
    X.meteo.pet.items = { ...
        '1 Daily PET', ...
        '2 Daily PET with interception' ...
        };
    X.meteo.pet.default = '1 Daily PET';
    X.meteo.pet.enabled = true;
    C = repmat(struct('name','','type','','path','','pattern','', ...
        'minimum_count',1,'required',true),0,1);
    C(1).name = 'Meteorological data';
    C(1).type = 'folder';
    C(1).path = fullfile('hourly','timeseries');
    C(1).pattern = '*';
    C(1).minimum_count = 1;
    X.checks = C;
    R.by_resolution.Hourly = X;

end