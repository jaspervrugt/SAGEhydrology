function R = region_config_IL()
%REGION_CONFIG_IL Regional defaults for CAMELS-IL.
%
% All X.paths fields are relative to Data/<R.data_root>.
% Dates use dd/MM/yyyy and water-year boundaries.

    R = struct();
    R.code = 'CAMELS_IL';
    R.acronym = 'IL';
    R.name = 'Israel';
    R.dataset = 'CAMELS-IL';
    R.data_root = 'CAMELS_IL';
    R.resolutions = {'Daily'};
    R.default_resolution = 'Daily';
    R.basin_file_pattern = 'IL_%d_basins.txt';

    X = struct();
    X.label = 'Daily';
    X.dt = 1;
    X.basins.universe = 94;
    X.basins.training = 74;
    X.basins.evaluation = 20;
    X.period.spinup_days = 365;
    X.period.manual.train_start = '01/10/2004';
    X.period.manual.train_end = '30/09/2019';
    X.period.manual.eval_start = '01/10/1989';
    X.period.manual.eval_end = '30/09/2004';
    X.period.common_start = '01/10/1989';
    X.period.common_end = '30/09/2019';
    X.paths.run_root = fullfile('daily');
    X.paths.meteo = fullfile('daily','timeseries');
    X.paths.discharge = fullfile('daily','timeseries');
    % Meteorological/PET controls shown by SAGE-GUI.
    X.meteo.product.items = {'CAMELS-IL [daily]'};
    X.meteo.product.default = 'CAMELS-IL [daily]';
    X.meteo.product.enabled = false;
    X.meteo.precipitation.items = {'1 ERA5-Land'};
    X.meteo.precipitation.default = '1 ERA5-Land';
    X.meteo.precipitation.enabled = false;
    X.meteo.temperature.items = {'1 ERA5-Land'};
    X.meteo.temperature.default = '1 ERA5-Land';
    X.meteo.temperature.enabled = false;
    X.meteo.pet.items = { ...
        '0 Zero PET', ...
        '1 Penman-Monteith', ...
        '2 Priestley-Taylor', ...
        '3 Makkink', ...
        '4 Supplied FAO Penman-Monteith', ...
        '5 Supplied ERA5-Land PET' ...
        };
    X.meteo.pet.default = '1 Penman-Monteith';
    X.meteo.pet.enabled = true;
    C = repmat(struct('name','','type','','path','','pattern','', ...
        'minimum_count',1,'required',true),0,1);
    C(1).name = 'Meteorological data';
    C(1).type = 'folder';
    C(1).path = fullfile('daily','timeseries');
    C(1).pattern = '*';
    C(1).minimum_count = 1;
    X.checks = C;
    R.by_resolution.Daily = X;

end