function [A,id_gauge,gname,zone] = read_attr_IL(dirD,bas)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%READ_ATTR_IL Read CAMELS-IL catchment attributes.
%
% Canonical installation:
%   Data/CAMELS_IL/daily/
%       attributes_caravan_il.csv
%       attributes_hydroatlas_il.csv
%       attributes_other_il.csv
%
% Monthly HydroATLAS fields ending in _s01 through _s12 are deliberately
% excluded. Annual/statistical fields such as aet_mm_syr are retained.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    if nargin < 1 ...
            || isempty(dirD)
        error('read_attr_IL:missingDir', ...
            'dirD must be provided.');
    end
    dirD = local_il_attribute_dir(dirD);
    if ~isfolder(dirD)
        error('read_attr_IL:missingDir', ...
            'Attribute directory does not exist: %s',dirD);
    end
    if nargin < 2 || isempty(bas)
        bas = struct();
    end
    if ~isstruct(bas)
        error('read_attr_IL:badBas','bas must be a structure.');
    end

    min_per_zone = 5;
    max_zones = 8;
    if isfield(bas,'min_per_zone') && ~isempty(bas.min_per_zone)
        min_per_zone = bas.min_per_zone;
    end
    if isfield(bas,'max_zones') && ~isempty(bas.max_zones)
        max_zones = bas.max_zones;
    end

    pr_table = 1;
    if isfield(bas,'pr_attr') && ~isempty(bas.pr_attr)
        pr_table = bas.pr_attr;
    end

    fCar = fullfile(dirD,'attributes_caravan_il.csv');
    fHyd = fullfile(dirD,'attributes_hydroatlas_il.csv');
    fOth = fullfile(dirD,'attributes_other_il.csv');
    must_exist(fCar,'attributes_caravan_il.csv',mfilename);
    must_exist(fHyd,'attributes_hydroatlas_il.csv',mfilename);
    must_exist(fOth,'attributes_other_il.csv',mfilename);

    fprintf('... Reading CAMELS-IL basin attributes ');

    O = local_read_il_table(fOth);
    C = local_read_il_table(fCar);
    H = local_read_il_table(fHyd);

    % Retain compact annual/statistical HydroATLAS fields only.
    keep = true(1,width(H));
    for j = 1:width(H)
        nm = H.Properties.VariableNames{j};
        if ~strcmp(nm,'gauge_id') && ...
                ~isempty(regexp(nm,'_s(0[1-9]|1[0-2])$','once'))
            keep(j) = false;
        end
    end
    H = H(:,keep);

    AA = O;
    AA = local_join_il(AA,C);
    AA = local_join_il(AA,H);

    id_all = local_normalize_il_id(AA.gauge_id);
    AA.gauge_id = id_all;
    [id_all,isrt] = sort(id_all);
    AA = AA(isrt,:);

    if isfield(bas,'id_gauge') ...
            && ~isempty(bas.id_gauge)
    
        % Requested IDs may be bare Israel IDs or prefixed CAMELS-IL IDs.
        id_req_internal = local_normalize_il_id(bas.id_gauge(:));
        [tf,loc] = ismember(id_req_internal,id_all);
        if ~all(tf)
            missing = local_output_il_id(id_req_internal(~tf));
            error('read_attr_IL:missingRequestedGauge', ...
                ['Missing CAMELS-IL attributes ' ...
                'for %d requested gauges, ' ...
                 'e.g. %s.'], ...
                numel(missing),char(missing(1)));
        end
        AA = AA(loc,:);
        % Return bare uppercase IDs so sample_basins can match basin files.
        id_gauge = local_output_il_id(id_req_internal);
    else
        % Return bare uppercase IDs:
        % il_b4403000 -> 7105
        id_gauge = local_output_il_id(id_all);
    end

    if ismember('gauge_name',AA.Properties.VariableNames)
        gname = string(AA.gauge_name);
    else
        gname = id_gauge;
    end
    gname = standardize_camels_gauge_names( ...
        gname(:),'CAMELS_IL',id_gauge);

    % The Israel source table stores gauge names in all capitals.
    % Convert them to readable title case for the GUI and output tables.
    gname = local_il_title_case(gname);

    % Keep the joined table synchronized so gauge_information.txt uses
    % the same readable names.
    if ismember('gauge_name',AA.Properties.VariableNames)
        AA.gauge_name = gname;
    end

    local_ensure_il_gauge_information(dirD,AA);

    try
        zone = classify_camels_all_zones( ...
            'IL',AA,min_per_zone,max_zones);
    catch
        zone = local_il_fallback_zones(AA,max_zones);
    end

    [A,labelsOut] = build_attr_matrix( ...
        AA,bas,mfilename,pr_table);

    if pr_table == 1
        assignin('base','SAGE_IL_attribute_labels',labelsOut);
    end
    fprintf(' ... Done\n');
end

function T = local_read_il_table(fname)
    opts = detectImportOptions(fname,'FileType','text');
    opts.VariableNamingRule = 'preserve';
    T = readtable(fname,opts);
    T.Properties.VariableNames = matlab.lang.makeValidName( ...
        T.Properties.VariableNames,'ReplacementStyle','delete');
    T.Properties.VariableNames = matlab.lang.makeUniqueStrings( ...
        T.Properties.VariableNames);
    if ~ismember('gauge_id',T.Properties.VariableNames)
        error('read_attr_IL:missingGaugeID', ...
            'File %s does not contain gauge_id.',fname);
    end
    T.gauge_id = local_normalize_il_id(T.gauge_id);
end

function T = local_join_il(T,U)
    U.gauge_id = local_normalize_il_id(U.gauge_id);
    dup = intersect(T.Properties.VariableNames, ...
        U.Properties.VariableNames);
    dup(strcmp(dup,'gauge_id')) = [];
    if ~isempty(dup)
        U(:,dup) = [];
    end
    T = outerjoin(T,U,'Keys','gauge_id', ...
        'MergeKeys',true,'Type','left');
end

function id = local_normalize_il_id(x)
    id = lower(strtrim(string(x(:))));
    id = erase(id,'"');
    id = erase(id,"'");
    addPrefix = ~startsWith(id,'il_');
    id(addPrefix) = "il_" + id(addPrefix);
end

function names = local_il_title_case(names)
%LOCAL_IL_TITLE_CASE Convert uppercase Israel gauge names to title case.
%
% Capitalization occurs at the beginning of the name and after spaces,
% hyphens, slashes, and opening parentheses. Apostrophes inside words are
% retained without forcing a second capital letter, so GIV'AT becomes
% Giv'at rather than Giv'At.

    names = string(names(:));

    for k = 1:numel(names)
        c = char(lower(strtrim(names(k))));

        capitalizeNext = true;
        for j = 1:numel(c)
            if isstrprop(c(j),'alpha')
                if capitalizeNext
                    c(j) = upper(c(j));
                end
                capitalizeNext = false;
            elseif any(c(j) == [' ' '-' '/' '('])
                capitalizeNext = true;
            elseif c(j) == ''''
                % An apostrophe at the beginning of a word should still
                % allow the next alphabetic character to be capitalized.
                if j == 1 || any(c(max(1,j-1)) == [' ' '-' '/' '('])
                    capitalizeNext = true;
                end
            end
        end

        names(k) = string(c);
    end
end

function local_ensure_il_gauge_information(dirD,AA)
    fout = fullfile(dirD,'gauge_information.txt');
    if isfile(fout)
        return
    end
    need = {'gauge_id','gauge_name', ...
        'gauge_lat','gauge_lon','area'};
    for j = 1:numel(need)
        if ~ismember(need{j},AA.Properties.VariableNames)
            error('read_attr_IL:missingGaugeInfoVar', ...
                ['Cannot create gauge_information.txt ' ...
                'because %s is missing.'], ...
                need{j});
        end
    end
    fid = fopen(fout,'w');
    if fid < 0
        error('read_attr_IL:gaugeInfoWriteFailed', ...
            'Could not write %s.',fout);
    end
    cleanup = onCleanup(@() fclose(fid));
    fprintf(fid,['HUC_02\tGAGE_ID\tGAGE_NAME\tLAT\tLONG\t' ...
        'DRAINAGE AREA (KM^2)\n']);
    for k = 1:height(AA)
        nm = string(AA.gauge_name(k));
        nm = replace(nm,char(9),' ');
        nm = replace(nm,newline,' ');
        fprintf(fid,'IL\t%s\t%s\t%.7f\t%.7f\t%.6f\n', ...
            char(local_output_il_id(AA.gauge_id(k))),char(nm), ...
            double(AA.gauge_lat(k)),double(AA.gauge_lon(k)), ...
            double(AA.area(k)));
    end
end

function zone = local_il_fallback_zones(AA,max_zones)
    K = height(AA);
    if ismember('aridity_FAO_PM',AA.Properties.VariableNames)
        x = double(AA.aridity_FAO_PM);
    elseif ismember('aridity_ERA5_LAND',AA.Properties.VariableNames)
        x = double(AA.aridity_ERA5_LAND);
    else
        x = double(AA.gauge_lat);
    end
    x(~isfinite(x)) = median(x(isfinite(x)),'omitnan');
    nz = max(1,min(max_zones,max(1,round(sqrt(K/5)))));
    q = quantile(x,linspace(0,1,nz+1));
    q = unique(q);
    num = discretize(x,q);
    num(~isfinite(num)) = 1;
    names = "IL zone " + string((1:max(num))');
    zone = struct();
    zone.num = num(:);
    zone.id = "IL" + compose('%02d',num(:));
    zone.names = names;
end

function id = local_output_il_id(x)
%LOCAL_OUTPUT_IL_ID Return canonical IDs used in IL basin-list files.
%
% Examples:
%   il_b4403000  -> 7105
%   il_l8klab00  -> 8130
%   il_8140  -> 8140

    id = lower(strtrim(string(x(:))));
    id = erase(id,'"');
    id = erase(id,"'");
    id = erase(id,'il_');
    id = upper(id);
end

function dirD = local_il_attribute_dir(dirD)
    dirD = char(string(dirD));
    [p,n] = fileparts(dirD);
    if strcmpi(n,'daily')
        return
    elseif strcmpi(n,'timeseries')
        [p2,n2] = fileparts(p);
        if strcmpi(n2,'daily')
            dirD = p2;
            return
        end
    end
    if isfolder(fullfile(dirD,'daily'))
        dirD = fullfile(dirD,'daily');
    end
end
