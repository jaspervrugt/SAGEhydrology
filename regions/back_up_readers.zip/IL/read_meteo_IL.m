function [dat,aux] = read_meteo_IL(dirM,bas,split,meteo)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%READ_METEO_IL Read CAMELS-IL daily meteorology and streamflow.
%
% Canonical directory:
%   Data/CAMELS_IL/daily/timeseries/il_*.csv
%
% split.dt must be 1. Source choices:
%   meteo.precip: 1 total_precipitation_sum
%   meteo.temp:   1 temperature_2m_mean
%   meteo.pet:
%       0 zero PET
%       1 computed Penman-Monteith
%       2 computed Priestley-Taylor
%       3 computed Makkink
%       4 supplied FAO Penman-Monteith
%       5 supplied ERA5-Land PET
%
% Streamflow is converted from m3/s to mm/day using catchment area.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    if nargin < 4 || isempty(meteo)
        meteo = struct();
    end
    if nargin < 1 || isempty(dirM)
        error('read_meteo_IL:missingDir','dirM must be provided.');
    end
    dirM = local_il_timeseries_dir(dirM);
    if ~isfolder(dirM)
        error('read_meteo_IL:missingDir', ...
            'CAMELS-IL daily timeseries directory does not exist: %s',dirM);
    end
    if nargin < 2 || ~isstruct(bas) || ...
            ~isfield(bas,'id_gauge') || isempty(bas.id_gauge)
        error('read_meteo_IL:missingBasins', ...
            'bas.id_gauge must be provided.');
    end

    split = local_prepare_il_split(split);
    if double(split.dt) ~= 1
        error('read_meteo_IL:dailyOnly', ...
            'The supplied CAMELS-IL archive is daily; split.dt must equal 1.');
    end

    pChoice = local_choice(meteo,'precip',1);
    tChoice = local_choice(meteo,'temp',1);
    eChoice = local_pet_choice(meteo,1);
    if pChoice ~= 1
        error('read_meteo_IL:badPrecipChoice', ...
            ['CAMELS-IL has one precipitation source; ' ...
            'use meteo.precip = 1.']);
    end
    if tChoice ~= 1
        error('read_meteo_IL:badTempChoice', ...
            ['CAMELS-IL has one temperature source; ' ...
            'use meteo.temp = 1.']);
    end
    if ~ismember(eChoice,0:5)
        error('read_meteo_IL:badPETChoice', ...
            ['CAMELS-IL PET must be 0 (zero), 1 (computed PM), ' ...
             '2 (Priestley-Taylor), 3 (Makkink), ' ...
             '4 (supplied FAO-PM), ' ...
             'or 5 (supplied ERA5-Land).']);
    end

    ids = local_normalize_il_id(bas.id_gauge(:));
    K = numel(ids);
    dat = cell(K,1);
    aux = nan(K,3);

    rootIL = local_il_root_from_dirM(dirM);
    A = local_read_il_other_attributes(rootIL);
    cacheDir = fullfile(dirM,'_cache_IL_daily_pet_v2');
    if ~isfolder(cacheDir)
        mkdir(cacheDir);
    end

    fprintf(['... Reading daily CAMELS-IL ' ...
        'meteorological data files %3d%%'],0);

    for k = 1:K
        gid = ids(k);
        fname = local_find_il_file(dirM,gid);
        area_km2 = local_il_area(A,gid);
        aux(k,:) = local_il_aux(A,gid,bas,k);
        latDeg = aux(k,1);
        elevM = aux(k,2);
        if ~isfinite(elevM)
            elevM = local_elevation_from_forcing_file(fname);
            aux(k,2) = elevM;
        end
        cacheFile = fullfile(cacheDir,sprintf( ...
            '%s_IL_daily_pet%d.mat', ...
            matlab.lang.makeValidName(char(gid)), ...
            eChoice));

        [Pfull,Epfull,Tfull,Qfull,badM,badQ, ...
            fileStartDT,fileEndDT,fileStartN,fileEndN] = ...
            local_load_or_build_il_cache( ...
            fname,cacheFile,eChoice,area_km2,latDeg,elevM);

        req = local_requested_window(split,fileStartN,fileEndN);
        if req.read_start_N < fileStartN || req.read_end_N > fileEndN
            fprintf('\n');
            error('read_meteo_IL:periodOutsideFile', ...
                ['Requested period lies outside ' ...
                'CAMELS-IL file for %s. ' ...
                'File covers %s to %s.'], ...
                char(gid),string(fileStartDT),string(fileEndDT));
        end

        i0 = double(req.read_start_N-fileStartN)+1;
        i1 = double(req.read_end_N-fileStartN)+1;
        ir = i0:i1;

        Pall = double(Pfull(ir));
        Eall = double(Epfull(ir));
        Tall = double(Tfull(ir));
        Qall = double(Qfull(ir));

        if isfield(split,'idx') && ~isempty(split.idx)
            idxScore = double(split.idx(:));
        else
            idxScore = (1:numel(Qall))';
        end
        idxScore = idxScore(idxScore>=1 & idxScore<=numel(Qall));

        dat{k}.meteo.P = single(Pall);
        dat{k}.meteo.Ep = single(Eall);
        dat{k}.meteo.T = single(Tall);
        dat{k}.y_n = single(Qall(idxScore));
        dat{k}.gauge = local_output_il_id(gid);
        dat{k}.fname = {fname};

        bm = double(badM(:));
        bm = bm(bm>=i0 & bm<=i1)-i0+1;
        dat{k}.meteo.bad = bm(:)';

        bq = double(badQ(:));
        bq = bq(bq>=i0 & bq<=i1)-i0+1;
        mask = false(1,numel(Qall));
        bq = bq(bq>=1 & bq<=numel(Qall));
        mask(round(bq)) = true;
        dat{k}.bad = mask(idxScore);


        if mod(k,5)==0 || k==K
            fprintf('\b\b\b\b%3d%%',floor(100*k/K));
            drawnow;
        end
        
        if isfield(meteo,'progressFcn') ...
                && ~isempty(meteo.progressFcn)
            try
                meteo.progressFcn(k);
            catch MEprogress
                warning('read_meteo_IL:progressFcn', ...
                    'GUI progress callback failed: %s', ...
                    MEprogress.message);
            end
        end

    end
    fprintf('\b\b\b\b%s\n','... Done');

    if isfield(split,'local') ...
            && split.local ...
            && isfield(split,'rainfall_block') ...
            && split.rainfall_block
        dat = rainfall_rank_split(dat,split);
    end
end

function v = local_choice(S,name,defaultValue)
    v = defaultValue;
    if isstruct(S) ...
            && isfield(S,name) ...
            && ~isempty(S.(name))
        v = double(S.(name)(1));
    end
end

function dirM = local_il_timeseries_dir(dirM)
% Resolve only the canonical CAMELS-IL daily time-series location.
% Accepted inputs are:
%   Data/CAMELS_IL
%   Data/CAMELS_IL/daily
%   Data/CAMELS_IL/daily/timeseries

    dirM = char(string(dirM));
    [p1,n1] = fileparts(dirM);

    if strcmpi(n1,'timeseries')
        [~,n2] = fileparts(p1);
        if strcmpi(n2,'daily')
            candidates = {dirM};
        else
            candidates = {};
        end
    elseif strcmpi(n1,'daily')
        candidates = {fullfile(dirM,'timeseries')};
    else
        candidates = {fullfile(dirM,'daily','timeseries')};
    end

    for k = 1:numel(candidates)
        if isfolder(candidates{k}) && ...
                ~isempty(dir(fullfile(candidates{k},'il_*.csv')))
            dirM = candidates{k};
            return
        end
    end
end

function dirDaily = local_il_root_from_dirM(dirM)
%LOCAL_IL_ROOT_FROM_DIRM Resolve the canonical CAMELS-IL daily folder.
%
% Accepted inputs:
%   Data/CAMELS_IL
%   Data/CAMELS_IL/daily
%   Data/CAMELS_IL/daily/timeseries
%
% Output:
%   Data/CAMELS_IL/daily

    d = char(string(dirM));
    [p1,n1] = fileparts(d);

    if strcmpi(n1,'timeseries')
        dirDaily = p1;
    elseif strcmpi(n1,'daily')
        dirDaily = d;
    else
        dirDaily = fullfile(d,'daily');
    end
end

function A = local_read_il_other_attributes(rootIL)
    f = fullfile(rootIL,'attributes_other_il.csv');
    if ~isfile(f)
        error('read_meteo_IL:missingAttributes', ...
            'Missing attributes_other_il.csv under %s.',rootIL);
    end
    A = readtable(f,'VariableNamingRule','preserve');
    A.Properties.VariableNames = matlab.lang.makeValidName( ...
        A.Properties.VariableNames,'ReplacementStyle','delete');
    A.gauge_id = local_normalize_il_id(A.gauge_id);
end

function fname = local_find_il_file(dirM,gid)
    exact = fullfile(dirM,[char(gid) '.csv']);
    if isfile(exact)
        fname = exact;
        return
    end
    D = dir(fullfile(dirM,['il_' erase(char(gid),'il_') '.csv']));
    if isempty(D)
        error('read_meteo_IL:missingFile', ...
            'Missing CAMELS-IL timeseries file for %s.',char(gid));
    end
    fname = fullfile(D(1).folder,D(1).name);
end

function [P,Ep,T,Q,badM,badQ,fileStartDT, ...
    fileEndDT,fileStartN,fileEndN] = ...
        local_load_or_build_il_cache(fname, ...
        cacheFile,eChoice,area_km2,latDeg,elevM)

    useCache = false;
    if isfile(cacheFile)
        try
            s = dir(fname); c = dir(cacheFile);
            useCache = c.datenum >= s.datenum;
        catch
        end
    end
    if useCache
        S = load(cacheFile);
        P=S.P; Ep=S.Ep; T=S.T; Q=S.Q;
        badM=S.badM; badQ=S.badQ;
        fileStartDT=S.fileStartDT; fileEndDT=S.fileEndDT;
        fileStartN=S.fileStartN; fileEndN=S.fileEndN;
        return
    end

    R = readtable(fname,'VariableNamingRule','preserve');
    R.Properties.VariableNames = matlab.lang.makeValidName( ...
        R.Properties.VariableNames,'ReplacementStyle','delete');

    tt = datetime(string(R.date),'InputFormat','yyyy-MM-dd');
    fileStartDT = tt(1);
    fileEndDT = tt(end);
    fileStartN = int64(datenum(fileStartDT)); %#ok<DATNM>
    fileEndN = int64(datenum(fileEndDT)); %#ok<DATNM>

    need = {'total_precipitation_sum','temperature_2m_mean', ...
        'temperature_2m_min','temperature_2m_max', ...
        'dewpoint_temperature_2m_mean', ...
        'u_component_of_wind_10m_mean', ...
        'v_component_of_wind_10m_mean', ...
        'surface_net_solar_radiation_mean', ...
        'surface_pressure_mean', ...
        'potential_evaporation_sum_ERA5_LAND', ...
        'potential_evaporation_sum_FAO_PENMAN_MONTEITH'};
    for j = 1:numel(need)
        if ~ismember(need{j},R.Properties.VariableNames)
            error('read_meteo_IL:missingMeteoColumn', ...
                ['Required column %s is ' ...
                'missing from %s.'],need{j},fname);
        end
    end

    P = single(double(R.total_precipitation_sum(:)));
    Tmean = double(R.temperature_2m_mean(:));
    Tmin = double(R.temperature_2m_min(:));
    Tmax = double(R.temperature_2m_max(:));
    T = single(Tmean);

    switch eChoice
        case 0
            Ep = zeros(height(R),1,'single');

        case {1,2,3}
            Td = double(R.dewpoint_temperature_2m_mean(:));
            U = double(R.u_component_of_wind_10m_mean(:));
            V = double(R.v_component_of_wind_10m_mean(:));
            Rs = double(R.surface_net_solar_radiation_mean(:));
            pressure = double(R.surface_pressure_mean(:));

            if ~isfinite(latDeg)
                error('read_meteo_IL:missingLatitude', ...
                    ['Computed PET option %d ' ...
                    'requires latitude for %s.'], ...
                    eChoice,fname);
            end

            if ~isfinite(elevM)
                elevM = local_elevation_from_pressure(pressure);
            end
            if ~isfinite(elevM)
                error('read_meteo_IL:missingElevation', ...
                    ['Computed PET option %d ' ...
                    'requires elevation for %s.'], ...
                    eChoice,fname);
            end

            eaPa = local_vapor_pressure_from_dewpoint(Td);
            u10 = hypot(U,V);
            u2 = local_wind10_to_wind2(u10);
            doy = day(tt,'dayofyear');

            Ep = et0_fao56_daily(Tmax,Tmin,Rs,eaPa,doy, ...
                latDeg,elevM,u2,eChoice);
            Ep = single(Ep(:));

        case 4
            Ep = single(max(double( ...
                R.potential_evaporation_sum_FAO_PENMAN_MONTEITH(:)),0));

        case 5
            Ep = single(max(double( ...
                R.potential_evaporation_sum_ERA5_LAND(:)),0));
    end

    if ~ismember('streamflow',R.Properties.VariableNames)
        error('read_meteo_IL:missingStreamflow', ...
            'File %s lacks streamflow.',fname);
    end
    q_m3s = double(R.streamflow(:));
    if ~isfinite(area_km2) || area_km2 <= 0
        error('read_meteo_IL:badArea', ...
            'Invalid catchment area for %s.',fname);
    end
    Q = single(q_m3s * 86.4 / area_km2);

    badM = int64(find(~isfinite(double(P)) | ...
        ~isfinite(double(Ep)) | ~isfinite(double(T))));
    badQ = int64(find(~isfinite(double(Q)) | double(Q)<0));

    save(cacheFile,'P','Ep','T','Q','badM','badQ', ...
        'fileStartDT','fileEndDT','fileStartN','fileEndN', ...
        'eChoice','area_km2','latDeg','elevM','-v7.3');
end

function split = local_prepare_il_split(split)
    if nargin < 1 || isempty(split)
        error('read_meteo_IL:missingSplit', ...
            'split must be provided.');
    end
    if ~isfield(split,'dt') || isempty(split.dt)
        split.dt = 1;
    end
end

function req = local_requested_window(split,fileStartN,fileEndN)
    if isfield(split,'dt0') && ~isempty(split.dt0)
        t0 = datetime(split.dt0);
        n = [];
        if isfield(split,'tout') && ~isempty(split.tout)
            n = numel(split.tout)-1;
        elseif isfield(split,'idx') && ~isempty(split.idx)
            n = max(double(split.idx));
        end
        if isempty(n) || n < 1
            n = double(fileEndN-fileStartN)+1;
        end
        req.read_start_N = int64(datenum(t0)); %#ok<DATNM>
        req.read_end_N = req.read_start_N + int64(n-1);
        return
    end

    fieldsStart = {'ds','dstart','start_date'};
    fieldsEnd = {'de','dend','end_date'};
    ds = []; de = [];
    for k=1:numel(fieldsStart)
        if isfield(split,fieldsStart{k}) && ~isempty(split.(fieldsStart{k}))
            ds = datetime(split.(fieldsStart{k}));
            break
        end
    end
    for k=1:numel(fieldsEnd)
        if isfield(split,fieldsEnd{k}) ...
                && ~isempty(split.(fieldsEnd{k}))
            de = datetime(split.(fieldsEnd{k}));
            break
        end
    end
    if isempty(ds) || isempty(de)
        req.read_start_N = fileStartN;
        req.read_end_N = fileEndN;
    else
        req.read_start_N = int64(datenum(ds)); %#ok<DATNM>
        req.read_end_N = int64(datenum(de)); %#ok<DATNM>
    end
end

function id = local_normalize_il_id(x)
    id = lower(strtrim(string(x(:))));
    id = erase(id,'"'); id = erase(id,"'");
    addPrefix = ~startsWith(id,'il_');
    id(addPrefix) = "il_" + id(addPrefix);
end

function area = local_il_area(A,gid)
    j = find(A.gauge_id==gid,1);
    if isempty(j)
        area = NaN;
    else
        area = double(A.area(j));
    end
end

function aux = local_il_aux(A,gid,bas,k)
    aux = [NaN NaN NaN];

    j = find(A.gauge_id==gid,1);
    if ~isempty(j)
        aux(1) = local_first_finite_field(A,j, ...
            {'gauge_lat','lat','latitude','centroid_lat'});
        aux(2) = local_first_finite_field(A,j, ...
            {'gauge_elev','elev_mean','elevation','elev'});
        area = local_first_finite_field(A,j, ...
            {'area','area_km2','area_calc'});
        if isfinite(area)
            if area < 1e7
                aux(3) = area*1e6;
            else
                aux(3) = area;
            end
        end
    end

    aux(1) = local_bas_value(bas,k,aux(1), ...
        {'gauge_lat','lat','latitude','lat_deg'});
    aux(2) = local_bas_value(bas,k,aux(2), ...
        {'gauge_elev','elev_mean','elev','elevation'});
    areaBas = local_bas_value(bas,k,NaN, ...
        {'area','area_km2','area_calc'});
    if isfinite(areaBas)
        if areaBas < 1e7
            aux(3) = areaBas*1e6;
        else
            aux(3) = areaBas;
        end
    end
end

function value = local_first_finite_field(T,row,names)
    value = NaN;
    vars = string(T.Properties.VariableNames);
    keys = lower(regexprep(vars,'[^a-z0-9]',''));
    targets = lower(regexprep(string(names),'[^a-z0-9]',''));
    q = find(ismember(keys,targets),1);
    if isempty(q)
        return
    end
    x = T{row,q};
    if iscell(x), x = x{1}; end
    if isnumeric(x) || islogical(x)
        value = double(x);
    else
        value = str2double(replace(string(x),',','.'));
    end
    if ~isscalar(value) || ~isfinite(value)
        value = NaN;
    end
end

function value = local_bas_value(bas,k,current,names)
    value = current;
    for i = 1:numel(names)
        f = names{i};
        if isfield(bas,f) && numel(bas.(f)) >= k
            x = double(bas.(f)(k));
            if isfinite(x)
                value = x;
                return
            end
        end
    end
end

function pet = local_pet_choice(meteo,defaultValue)
    pet = defaultValue;
    if isstruct(meteo)
        if isfield(meteo,'pet') ...
                && ~isempty(meteo.pet)
            pet = meteo.pet;
        elseif isfield(meteo,'id_pet') ...
                && ~isempty(meteo.id_pet)
            pet = meteo.id_pet;
        end
    end

    if ischar(pet) || isstring(pet)
        text = lower(strtrim(string(pet)));
        token = regexp(text,'^\s*(\d+)','tokens','once');
        if ~isempty(token)
            pet = str2double(token{1});
        elseif contains(text,'zero')
            pet = 0;
        elseif contains(text,'priestley') ...
                || contains(text,'taylor')
            pet = 2;
        elseif contains(text,'makkink')
            pet = 3;
        elseif contains(text,'era5') ...
                || contains(text,'native')
            pet = 5;
        elseif contains(text,'supplied') ...
                && contains(text,'penman')
            pet = 4;
        elseif contains(text,'penman') ...
                || contains(text,'monteith')
            pet = 1;
        end
    end

    pet = round(double(pet));
end

function eaPa = local_vapor_pressure_from_dewpoint(TdC)
    eaPa = 1000 .* 0.6108 .* exp(17.27 .* TdC ./ (TdC + 237.3));
end

function u2 = local_wind10_to_wind2(u10)
    u2 = u10 .* (4.87 ./ log(67.8*10 - 5.42));
end

function zM = local_elevation_from_forcing_file(fname)
    zM = NaN;
    try
        opts = detectImportOptions(fname, ...
            'VariableNamingRule','preserve');
        vars = string(opts.VariableNames);
        key = lower(regexprep(vars,'[^a-z0-9]',''));
        target = lower(regexprep("surface_pressure_mean", ...
            '[^a-z0-9]',''));
        j = find(key == target,1);
        if isempty(j)
            return
        end
        opts.SelectedVariableNames = opts.VariableNames(j);
        T = readtable(fname,opts);
        zM = local_elevation_from_pressure(T{:,1});
    catch
        zM = NaN;
    end
end

function zM = local_elevation_from_pressure(pressure)
% Estimate elevation from long-term median surface pressure only when no
% basin or attribute elevation is available. Accept Pa, hPa, or kPa.
    p = double(pressure(:));
    p = p(isfinite(p) & p > 0);
    if isempty(p)
        zM = NaN;
        return
    end
    pMed = median(p,'omitnan');
    if pMed > 20000
        pKPa = pMed/1000;
    elseif pMed > 200
        pKPa = pMed/10;
    else
        pKPa = pMed;
    end
    if ~isfinite(pKPa) || pKPa <= 0 || pKPa > 110
        zM = NaN;
        return
    end
    zM = 44330 .* (1 - (pKPa/101.325).^0.1903);
end

function id = local_output_il_id(x)
    id = upper(erase(local_normalize_il_id(x),'il_'));
end
