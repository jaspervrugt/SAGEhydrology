function [A,id_gauge,gname,zone] = read_attr_IND(dirD,bas)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%READ_ATTR_IND Read catchment attributes of CAMELS-IND dataset.
%
% SYNOPSIS:
%   [A,id_gauge,gname,zone] = read_attr_IND(dirD,bas)
%
% INPUT:
%   dirD        Directory with CAMELS-IND attribute CSV files. This can be
%               either Data/CAMELS_IND or Data/CAMELS_IND/attributes_csv.
%   bas         OPTIONAL: structure with basin and attribute information
%    .id_gauge   OPTIONAL: vector/string/cell array of requested 5-digit
%                 CAMELS-IND gauge IDs, e.g. "03001"
%    .id_attr    rx1 vector of integer attribute IDs
%    .pr_attr    OPTIONAL: print attribute table [1/0]
%
% OUTPUT:
%   A           r x K matrix of standardized selected attributes
%   id_gauge    K x 1 string array with 5-digit CAMELS-IND gauge IDs
%   gname       K x 1 string array with standardized gauge/station names
%   zone        structure with simple CAMELS-IND basin classification
%
% DESCRIPTION:
%   This function reads and joins the CAMELS-IND static attribute files:
%       camels_ind_name.csv
%       camels_ind_topo.csv
%       camels_ind_clim.csv
%       camels_ind_hydro.csv
%       camels_ind_land.csv
%       camels_ind_soil.csv
%       camels_ind_geol.csv
%       camels_ind_anth.csv
%
%   Attribute order is:
%       topo -> clim -> hydro -> land -> soil -> geol -> anth
%   with gauge_id excluded from the selectable attribute list.
%
% NOTES:
%   If bas.id_attr is omitted, the default set is obtained from
%   attr_catalog('CAMELS_IND') when available. The default selection avoids
%   streamflow-derived hydrologic signatures where possible.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% © Written by Jasper A. Vrugt, May 2026                                  %
% University of California, Irvine                                        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    if nargin < 1 ...
            || isempty(dirD)
        error('read_attr_IND:missingDir', ...
            ['      Error:read_attr_IND: ' ...
            'dirD must be provided.']);
    end

    if ~isfolder(dirD)
        error('read_attr_IND:missingDir', ...
            ['      Error:read_attr_IND: ' ...
            'Attribute directory ' ...
            'does not exist: %s'],dirD);
    end

    if nargin < 2 ...
            || isempty(bas)
        bas = struct();
    end

    if ~isstruct(bas)
        error('read_attr_IND:badBas', ...
            ['      Error:read_attr_IND: ' ...
            'bas must be a structure.']);
    end
    % =========================================
    % ZONE CONTROL PARAMETERS (GLOBAL DEFAULTS)
    % =========================================
    if ~isfield(bas,'min_per_zone') ...
            || isempty(bas.min_per_zone)
        min_per_zone = 5;
    else
        min_per_zone = bas.min_per_zone;
    end    
    if ~isfield(bas,'max_zones') ...
            || isempty(bas.max_zones)
        max_zones = 8;
    else
        max_zones = bas.max_zones;
    end

    pr_table = 1;
    if isfield(bas,'pr_attr') ...
            && ~isempty(bas.pr_attr)
        pr_table = bas.pr_attr;
    elseif ~isfield(bas,'id_attr') ...
            || isempty(bas.id_attr)
        pr_table = 0;
    end

    % CAMELS-IND may be passed as the root folder or as attributes_csv.
    dirA = dirD;
    if ~isfile(fullfile(dirA, ...
            'camels_ind_topo.csv')) ...
            && isfolder(fullfile(dirD, ...
            'attributes_csv'))
        dirA = fullfile(dirD, ...
            'attributes_csv');
    end

    f_name = fullfile(dirA, ...
        'camels_ind_name.csv');
    f_topo = fullfile(dirA, ...
        'camels_ind_topo.csv');
    f_clim = fullfile(dirA, ...
        'camels_ind_clim.csv');
    f_hydro = fullfile(dirA, ...
        'camels_ind_hydro.csv');
    f_land = fullfile(dirA, ...
        'camels_ind_land.csv');
    f_soil = fullfile(dirA, ...
        'camels_ind_soil.csv');
    f_geol = fullfile(dirA, ...
        'camels_ind_geol.csv');
    f_anth = fullfile(dirA, ...
        'camels_ind_anth.csv');

    caller = mfilename;
    must_exist(f_name,'camels_ind_name.csv',caller);
    must_exist(f_topo,'camels_ind_topo.csv',caller);
    must_exist(f_clim,'camels_ind_clim.csv',caller);
    must_exist(f_hydro,'camels_ind_hydro.csv',caller);
    must_exist(f_land,'camels_ind_land.csv',caller);
    must_exist(f_soil,'camels_ind_soil.csv',caller);
    must_exist(f_geol,'camels_ind_geol.csv',caller);
    must_exist(f_anth,'camels_ind_anth.csv',caller);

    fprintf(['... Reading CAMELS-IND ' ...
        'basin attributes ']);

    name = read_ind_table(f_name);
    topo = read_ind_table(f_topo);
    clim = read_ind_table(f_clim);
    hydro = read_ind_table(f_hydro);
    land = read_ind_table(f_land);
    soil = read_ind_table(f_soil);
    geol = read_ind_table(f_geol);
    anth = read_ind_table(f_anth);

    % Use name as master because it contains gauge/station metadata and
    % flow-availability. Join after name defines metadata + attributes.
    AA = name;
    AA = join_ind_attributes(AA,topo);
    AA = join_ind_attributes(AA,clim);
    AA = join_ind_attributes(AA,hydro);
    AA = join_ind_attributes(AA,land);
    AA = join_ind_attributes(AA,soil);
    AA = join_ind_attributes(AA,geol);
    AA = join_ind_attributes(AA,anth);

    id_all = normalize_ind_gauge_id(AA.gauge_id);
    AA.gauge_id = id_all;

    % Sort for reproducibility.
    [~,isrt] = sort(id_all);
    AA = AA(isrt,:);
    id_all = id_all(isrt);

    if isfield(bas,'id_gauge') ...
            && ~isempty(bas.id_gauge)
        id_req = normalize_ind_gauge_id(bas.id_gauge(:));
        [tf,loc] = ismember(id_req,id_all);

        if ~all(tf)
            missing = id_req(~tf);
            error('read_attr_IND:missingRequestedGauge', ...
                ['      Error:read_attr_IND: ' ...
                'Missing CAMELS-IND ' ...
                'attributes for %d requested ' ...
                'gauge IDs, e.g. %s.'], ...
                numel(missing), ...
                char(missing(1)));
        end

        AA = AA(loc,:);
        id_gauge = id_req(:);
    else
        id_gauge = id_all(:);
    end

    % Gauge names.
    if ismember('cwc_site_name', ...
            AA.Properties.VariableNames)
        gname = string(AA.cwc_site_name);
    else
        gname = "Gauge " + id_gauge;
    end

    gname = standardize_camels_gauge_names( ...
        gname(:),'CAMELS_IND',id_gauge);

    % Simple Indian river-basin classification.
    ensure_ind_gauge_information(dirA,AA);
    region = erase(mfilename,'read_attr_');
    zone = classify_camels_all_zones(region,AA, ...
        min_per_zone,max_zones);
    
    % ------------------
    % Generic attributes
    % ------------------
    [A,labels] = build_attr_matrix(AA,bas, ...
        mfilename,pr_table);

    if pr_table == 1
        assignin('base', ...
            'SAGE_IND_attribute_labels', ...
            labels);
    end

    fprintf(' ... Done\n');

end

% ================================
function T = read_ind_table(fname)
% ================================

    opts = detectImportOptions(fname, ...
        'FileType','text');
    opts.VariableNamingRule = 'preserve';

    if any(strcmp(opts.VariableNames,'gauge_id'))
        opts = setvartype(opts,'gauge_id','char');
    end

    T = readtable(fname,opts);

    T.Properties.VariableNames = ...
        matlab.lang.makeValidName( ...
        T.Properties.VariableNames, ...
        'ReplacementStyle','delete');
    T.Properties.VariableNames = ...
        matlab.lang.makeUniqueStrings( ...
        T.Properties.VariableNames);

    if ~ismember('gauge_id',T.Properties.VariableNames)
        error('read_attr_IND:missingGaugeID', ...
            ['      Error:read_attr_IND: ' ...
            'File %s does not contain gauge_id.'],fname);
    end

    T.gauge_id = ...
        normalize_ind_gauge_id(T.gauge_id);
    T = local_unique_gauge_rows(T,fname);

end

% =====================================
function AA = join_ind_attributes(AA,T)
% =====================================

    T = local_unique_gauge_rows(T, ...
        'joined table');

    dup = intersect( ...
        AA.Properties.VariableNames, ...
        T.Properties.VariableNames);
    dup(strcmp(dup,'gauge_id')) = [];

    if ~isempty(dup)
        T(:,dup) = [];
    end

    AA = outerjoin(AA,T, ...
        'Keys','gauge_id', ...
        'MergeKeys',true, ...
        'Type','left');

end

% =====================================
function id = normalize_ind_gauge_id(v)
% =====================================

    s = string(v);
    s = strip(s);
    s = erase(s,'"');
    s(ismissing(s)) = "";

    id = strings(numel(s),1);
    for i = 1:numel(s)
        si = char(s(i));
        if isempty(si)
            id(i) = "";
            continue
        end

        x = str2double(si);
        if isfinite(x)
            id(i) = string(sprintf('%05.0f',x));
        else
            dig = regexp(si,'\d+','match');
            if ~isempty(dig)
                id(i) = string(sprintf('%05.0f', ...
                    str2double(dig{1})));
            else
                id(i) = string(upper(strtrim(si)));
            end
        end
    end

    id = id(:);

end

% =========================================
function T = local_unique_gauge_rows(T,src)
% =========================================

    T.gauge_id = normalize_ind_gauge_id(T.gauge_id);
    [u,ia] = unique(T.gauge_id,'stable');

    if numel(u) ~= height(T)
        warning('read_attr_IND:duplicateGaugeID', ...
            ['      Warning:read_attr_IND: ' ...
            'Duplicate gauge_id rows found in %s; ' ...
            'keeping first occurrence.'],src);
        T = T(ia,:);
    end

end

% ============================================
function ensure_ind_gauge_information(dirA,AA)
% ============================================

    f_info = fullfile(dirA,'gauge_information.txt');

    if isfile(f_info)
        return
    end

    id = normalize_ind_gauge_id(AA.gauge_id);

    if ismember('cwc_site_name', ...
            AA.Properties.VariableNames)
        nm = string(AA.cwc_site_name);
    else
        nm = "Gauge " + id;
    end

    lat = get_numeric_column(AA, ...
        ["cwc_lat","ghi_lat"]);
    lon = get_numeric_column(AA, ...
        ["cwc_lon","ghi_lon"]);
    area = get_numeric_column(AA, ...
        ["cwc_area","ghi_area"]);

    try
        Tout = table(id(:),nm(:),lat(:),lon(:),area(:), ...
            'VariableNames',{'gauge_id','gauge_name', ...
            'lat','lon','area'});
        writetable(Tout,f_info, ...
            'Delimiter','\t', ...
            'FileType','text');
    catch ME
        warning('read_attr_IND:gaugeInfoWriteFailed', ...
            ['      Warning:read_attr_IND: ' ...
            'Could not write %s.\n      %s'], ...
            f_info,ME.message);
    end

end
