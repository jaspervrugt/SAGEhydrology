function dat = read_Q_IND(dirQ,mdl,dat,bas,split,aux)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%READ_Q_IND Read CAMELS-IND daily streamflow data for SAGE.
%
% SYNOPSIS:
%   dat = read_Q_IND(dirQ,mdl,dat,bas,split)
%   dat = read_Q_IND(dirQ,mdl,dat,bas,split,aux)
%
% INPUT:
%   dirQ        Directory with CAMELS-IND streamflow file, normally
%               Data/CAMELS_IND
%   mdl         model/run structure with fields mode, id_train, id_eval
%   dat         Kx1 cell structure to which discharge is added
%   bas         basin structure with fields K, K_t, id_gauge
%               Optional .area can be used for drainage area [km^2]
%   split       time-split structure. Daily dt = 1 only.
%   aux         Optional basin metadata. aux(:,3) is drainage area. The
%               routine accepts area in either m^2 or km^2 and converts
%               when needed.
%
% OUTPUT:
%   dat{k}.y_n       daily discharge depth [mm/day]
%   dat{k}.bad       1xn logical mask for invalid/missing discharge
%   dat{k}.fname{2}  source streamflow file
%   dat{k}.gid       CAMELS-IND gauge identifier
%   dat{k}.use       'training' or 'evaluation'
%
% DESCRIPTION:
%   CAMELS-IND observed streamflow is stored in one wide CSV file:
%
%       streamflow_observed.csv
%
%   with columns:
%
%       year, month, day, gauge_1, gauge_2, ..., gauge_N
%
%   Streamflow values are discharge [m^3/s]. This reader converts them to
%   discharge depth [mm/day] using catchment drainage area.
%
% NOTES:
%   - Daily data only.
%   - Missing values, nonfinite values, and negative flows are marked bad.
%   - Days outside the available file record are padded with NaN and marked
%     bad. This is useful because not every Indian gauge has a complete
%     observed streamflow record.
%   - Basin IDs may be supplied as numeric values, strings with leading
%     zeros, or strings without leading zeros. Matching is done after
%     harmonizing IDs.
%
% CACHE:
%   On the first run, the full CSV is converted to:
%
%       streamflow_observed_cache.mat
%
%   The cache stores dates, gauge IDs, and full daily streamflow matrix as
%   single precision. On later runs, it is reused when source file metadata
%   match.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% © Written by Jasper A. Vrugt, May 2026                                  %
% University of California, Irvine                                        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    if nargin < 1 ...
            || isempty(dirQ)
        error('read_Q_IND:missingDir', ...
            ['      Error:read_Q_IND: ' ...
            'dirQ must be provided.']);
    end
    
    if ~isfolder(dirQ)
        error('read_Q_IND:missingDir', ...
            ['      Error:read_Q_IND: ' ...
            'Streamflow directory does not exist: %s'],dirQ);
    end
    
    if nargin < 6
        aux = [];
    end
    
    if nargin < 5 ...
            || isempty(split)
        error('read_Q_IND:missingSplit', ...
            ['      Error:read_Q_IND: ' ...
            'split structure must be provided.']);
    end
    
    split = local_prepare_split(split);
    
    dt = double(split.dt);
    if dt ~= 1
        error('read_Q_IND:dailyOnly', ...
            ['      Error:read_Q_IND: ' ...
            'CAMELS-IND streamflow reader ' ...
            'supports daily data only.']);
    end
    
    K = bas.K;
    if isfield(bas,'K_t') ...
            && ~isempty(bas.K_t)
        K_t = bas.K_t;
    else
        K_t = K;
    end
    
    id_GAUGE = local_id_strings(bas.id_gauge(:));
    if numel(id_GAUGE) ~= K
        K = numel(id_GAUGE);
    end
    
    mode = mdl.mode;
    hasEval = ismember(mode,[2 4]);
    
    id_train = expand_index(mdl.id_train);
    if hasEval ...
            && isfield(mdl,'id_eval') ...
            && ~isempty(mdl.id_eval)
        id_eval = expand_index(mdl.id_eval);
    else
        id_eval = [];
    end
    
    req = local_build_requested_window(split);
    tRef = datetime(req.read_start_N, ...
        'ConvertFrom','datenum');
    tEnd = datetime(req.read_end_N, ...
        'ConvertFrom','datenum');
    timeGrid = (tRef:days(1):tEnd).';
    nGrid = numel(timeGrid);
    
    fname = fullfile(dirQ, ...
        'streamflow_timeseries', ...
        'streamflow_observed.csv');
    
    % Backward-compatible fallback: allow dirQ to be the streamflow_timeseries
    % folder itself, or an older install with the CSV directly under dirQ.
    if ~isfile(fname)
        f2 = fullfile(dirQ,'streamflow_observed.csv');
        if isfile(f2)
            fname = f2;
        end
    end
    
    if ~isfile(fname)
        error('read_Q_IND:missingFile', ...
            ['      Error:read_Q_IND: ' ...
            'Required streamflow file not found: %s'],fname);
    end
    
    fprintf(['... Reading daily CAMELS-IND ' ...
        'streamflow data ']);
    
    [tFileN,idFile,Qm3sAll] = local_load_ind_cache(fname,dirQ);
    
    [idFileH,idGaugeH] = local_harmonize_ids(idFile,id_GAUGE);
    [tfGauge,locGauge] = ismember(idGaugeH,idFileH);
    if ~all(tfGauge)
        missing = id_GAUGE(~tfGauge);
        error('read_Q_IND:missingRequestedGauge', ...
            ['      Error:read_Q_IND: ' ...
            'Missing CAMELS-IND streamflow columns ' ...
            'for %d requested gauge IDs, e.g. %s.'], ...
            numel(missing),char(missing(1)));
    end
    
    % Map file dates to requested daily grid once, then reuse for all basins.
    [tfDate,locDate] = ismember(tFileN, ...
        datenum(timeGrid)); %#ok<DATNM>
    iiFile = find(tfDate);
    iiGrid = locDate(tfDate);
    
    static_name = fullfile(dirQ, ...
        'CAMELS_IND_discharge_summary_daily.csv');
    run_stamp = char(datetime('now', ...
        'Format','yyyyMMdd_HHmmss'));
    run_name = fullfile(dirQ, ...
        sprintf('CAMELS_IND_discharge_run_daily_%s.csv',run_stamp));
    
    if hasEval
        Qrun = table('Size',[K 10], ...
            'VariableTypes',{'string', ...
            'string','string','string', ...
            'double','double','string', ...
            'string','double','double'}, ...
            'VariableNames',{'gauge', ...
            'use','start_train','end_train', ...
            'n_train','n_bad_train', ...
            'start_eval','end_eval', ...
            'n_eval','n_bad_eval'});
    else
        Qrun = table('Size',[K 6], ...
            'VariableTypes',{'string', ...
            'string','string','string', ...
            'double','double'}, ...
            'VariableNames',{'gauge', ...
            'use','start_train','end_train', ...
            'n_train','n_bad_train'});
    end
    
    summaryRows = table('Size',[K 7], ...
        'VariableTypes',{'string', ...
        'string','string', ...
        'double','double', ...
        'double','double'}, ...
        'VariableNames',{'gauge', ...
        'start_record','end_record', ...
        'n_all','n_bad_all', ...
        'n_requested','n_bad_requested'});
    
    fprintf('... %3d%%',0);
    
    for k = 1:K
    
        gid = id_GAUGE(k);
        jFile = locGauge(k);
    
        Qm3sFile = double(Qm3sAll(:,jFile));
    
        area_m2 = local_area_m2(k,bas,aux,dirQ);
        QmmFile = 1000 * Qm3sFile * 86400 ./ area_m2;
    
        badFile = ~isfinite(QmmFile) ...
            | QmmFile < 0;
    
        Qmm = nan(nGrid,1);
        badmask = true(nGrid,1);
    
        Qmm(iiGrid) = QmmFile(iiFile);
        badmask(iiGrid) = badFile(iiFile);
        badmask = badmask ...
            | ~isfinite(Qmm);
    
        spinup = 0;
        if isfield(split,'spinup') ...
                && ~isempty(split.spinup)
            spinup = max(0,round(double(split.spinup)));
        end
        if spinup > 0
            Qmm = Qmm(spinup+1:end);
            badmask = badmask(spinup+1:end);
        end
    
        dat{k}.y_n = single(Qmm);
        dat{k}.bad = badmask(:)';
        dat{k}.fname{2} = fname;
        dat{k}.gid = gid;
    
        if k <= K_t
            dat{k}.use = 'training';
        else
            dat{k}.use = 'evaluation';
        end
    
        n_train = numel(id_train);
        n_bad_train = sum(badmask(id_train));
    
        if hasEval
            n_eval = numel(id_eval);
            n_bad_eval = sum(badmask(id_eval));
        else
            n_eval = 0;
            n_bad_eval = 0;
        end
    
        Qrun.gauge(k) = gid;
        if k <= K_t
            Qrun.use(k) = "training";
        else
            Qrun.use(k) = "evaluation";
        end
    
        Qrun.start_train(k) = string( ...
            datetime(split.dt_train0, ...
            'ConvertFrom','datenum', ...
            'Format','dd/MM/yyyy'));
        Qrun.end_train(k) = string( ...
            datetime(split.dt_train1, ...
            'ConvertFrom','datenum', ...
            'Format','dd/MM/yyyy'));
        Qrun.n_train(k) = n_train;
        Qrun.n_bad_train(k) = n_bad_train;
    
        if hasEval
            Qrun.start_eval(k) = string( ...
                datetime(split.dt_eval0, ...
                'ConvertFrom','datenum', ...
                'Format','dd/MM/yyyy'));
            Qrun.end_eval(k) = string( ...
                datetime(split.dt_eval1, ...
                'ConvertFrom','datenum', ...
                'Format','dd/MM/yyyy'));
            Qrun.n_eval(k) = n_eval;
            Qrun.n_bad_eval(k) = n_bad_eval;
        end
    
        goodRecord = isfinite(QmmFile) ...
            & QmmFile >= 0;
        if any(goodRecord)
            start_record = min(tFileN(goodRecord));
            end_record = max(tFileN(goodRecord));
            startText = string(datetime(start_record, ...
                'ConvertFrom','datenum', ...
                'Format','dd/MM/yyyy'));
            endText = string(datetime(end_record, ...
                'ConvertFrom','datenum', ...
                'Format','dd/MM/yyyy'));
        else
            startText = "";
            endText = "";
        end
    
        summaryRows.gauge(k) = gid;
        summaryRows.start_record(k) = startText;
        summaryRows.end_record(k) = endText;
        summaryRows.n_all(k) = numel(QmmFile);
        summaryRows.n_bad_all(k) = sum(badFile);
        summaryRows.n_requested(k) = nGrid;
        summaryRows.n_bad_requested(k) = sum(badmask);
    
        if mod(k,20) == 0 ...
                || k == K
            pct = floor(100*k/K);
            fprintf('\b\b\b\b%3d%%',pct);
        end
    
        % Graphical User Interface
        if isfield(bas,'progressFcn') ...
                && ~isempty(bas.progressFcn)
            try
                bas.progressFcn(k,K);
            catch
                try
                    bas.progressFcn(k);
                catch
                end
            end
        end
    end
    
    fprintf('\b\b\b\bDone\n');
    
    try
        writetable(summaryRows,static_name);
    catch ME
        warning('read_Q_IND:summaryWriteFailed', ...
            ['Could not write IND discharge ' ...
            'summary: %s'],ME.message);
    end
    
    try
        writetable(Qrun,run_name);
    catch ME
        warning('read_Q_IND:runWriteFailed', ...
            ['Could not write IND discharge ' ...
            'run summary: %s'],ME.message);
    end

end

% ==================================
function [tFileN,idFile,Qall] = ...
    local_load_ind_cache(fname,dirQ)
% ==================================

    cacheFile = fullfile(dirQ, ...
        'streamflow_observed_cache.mat');
    info = dir(fname);
    
    if isfile(cacheFile)
        try
            S = load(cacheFile,'tFileN', ...
                'idFile','Qall', ...
                'srcBytes','srcDatenum', ...
                'srcFile');
            if isfield(S,'srcBytes') ...
                    && isfield(S,'srcDatenum') ...
                    && isfield(S,'srcFile') ...
                    && strcmp(char(S.srcFile),fname) ...
                    && S.srcBytes == info.bytes ...
                    && abs(S.srcDatenum ...
                    - info.datenum) < 1e-8
                tFileN = S.tFileN;
                idFile = S.idFile;
                Qall = S.Qall;
                return
            end
        catch
            % Fall through and rebuild cache.
        end
    end
    
    fprintf(['\n      Building CAMELS-IND ' ...
        'streamflow cache from CSV ...\n']);
    
    fid = fopen(fname,'r');
    if fid < 0
        error('read_Q_IND:openFailed', ...
            ['      Error:read_Q_IND: ' ...
            'Could not open %s'],fname);
    end
    cleanup = onCleanup(@() fclose(fid));
    header = fgetl(fid);
    if ~ischar(header)
        error('read_Q_IND:emptyFile', ...
            ['      Error:read_Q_IND: ' ...
            'Empty streamflow file: %s'],fname);
    end
    
    if contains(header,char(9))
        delim = '\t';
        parts = strsplit(header,char(9));
    else
        delim = ',';
        parts = strsplit(header,',');
    end
    
    parts = strtrim(parts);
    parts = strip(string(parts),'both','"');
    
    if numel(parts) < 4 ...
            || ~strcmpi(parts(1),'year') ...
            || ~strcmpi(parts(2),'month') ...
            || ~strcmpi(parts(3),'day')
        error('read_Q_IND:badHeader', ...
            ['      Error:read_Q_IND: ' ...
            'Expected year,month,day followed ' ...
            'by gauge columns in %s.'],fname);
    end
    
    idFile = local_id_strings(parts(4:end).');
    
    M = readmatrix(fname, ...
        'FileType','text', ...
        'Delimiter',delim, ...
        'NumHeaderLines',1);
    
    if size(M,2) ~= numel(idFile) + 3
        error('read_Q_IND:badSize', ...
            ['      Error:read_Q_IND: ' ...
            'Number of numeric columns does ' ...
            'not match header gauge count in %s.'],fname);
    end
    
    tFileN = datenum(datetime( ...
        M(:,1),M(:,2),M(:,3))); %#ok<DATNM>
    Qall = single(M(:,4:end));
    
    srcFile = fname;
    srcBytes = info.bytes;
    srcDatenum = info.datenum;
    
    try
        save(cacheFile,'tFileN', ...
            'idFile','Qall', ...
            'srcFile','srcBytes', ...
            'srcDatenum','-v7.3');
        fprintf(['      Wrote CAMELS-IND ' ...
            'cache: %s\n'],cacheFile);
    catch ME
        warning('read_Q_IND:cacheWriteFailed', ...
            ['Could not write IND ' ...
            'streamflow cache: %s'],ME.message);
    end

end

% -----------------------------------------
function split = local_prepare_split(split)
% -----------------------------------------

    if ~isfield(split,'dt') ...
            || isempty(split.dt)
        split.dt = 1;
    end
    
    names = {'dt_train0','dt_train1', ...
        'dt_eval0','dt_eval1'};
    for j = 1:numel(names)
        nm = names{j};
        if isfield(split,nm) ...
                && ~isempty(split.(nm))
            split.(nm) = local_to_datenum( ...
                split.(nm));
        end
    end
    
    if ~isfield(split,'dt_eval0') ...
            || isempty(split.dt_eval0)
        split.dt_eval0 = split.dt_train0;
    end
    if ~isfield(split,'dt_eval1') ...
            || isempty(split.dt_eval1)
        split.dt_eval1 = split.dt_train1;
    end

end

% ------------------------------------------------
function req = local_build_requested_window(split)
% ------------------------------------------------

    if isfield(split,'read_start_N') ...
            && isfield(split,'read_end_N') ...
            && ~isempty(split.read_start_N) ...
            && ~isempty(split.read_end_N)
        req.read_start_N = local_to_datenum( ...
            split.read_start_N);
        req.read_end_N = local_to_datenum( ...
            split.read_end_N);
        return
    end
    
    starts = [];
    ends = [];
    if isfield(split,'dt_train0')
        starts(end+1) = split.dt_train0;
    end
    if isfield(split,'dt_eval0')
        starts(end+1) = split.dt_eval0;
    end
    if isfield(split,'dt_train1')
        ends(end+1) = split.dt_train1;
    end
    if isfield(split,'dt_eval1')
        ends(end+1) = split.dt_eval1;
    end
    
    if isempty(starts) ...
            || isempty(ends)
        error('read_Q_IND:badSplit', ...
            ['      Error:read_Q_IND: ' ...
            'Could not determine requested ' ...
            'date window from split.']);
    end
    
    req.read_start_N = min(starts);
    req.read_end_N = max(ends);
    
    if isfield(split,'spinup') ...
            && ~isempty(split.spinup)
        spinup = max(0,round( ...
            double(split.spinup)));
        req.read_start_N = ...
            req.read_start_N - spinup;
    end

end

% -------------------------------
function xN = local_to_datenum(x)
% -------------------------------

    if isdatetime(x)
        d = x(1);
    
    elseif ischar(x) ...
            || isstring(x)
        s = strtrim(string(x));
        try
            d = datetime(s, ...
                'InputFormat','d/M/yyyy');
        catch
            try
                d = datetime(s, ...
                    'InputFormat','yyyy-MM-dd');
            catch
                d = datetime(s);
            end
        end
    
    elseif isnumeric(x)
    
        x = double(x(:).');
    
        if numel(x) == 3
    
            if x(1) > 1800
                d = datetime(x(1),x(2),x(3));
    
            elseif x(3) > 1800
                d = datetime(x(3),x(2),x(1));
    
            else
                error('read_Q_IND:badDate', ...
                    ['Cannot determine ' ...
                    'date-vector order.']);
            end
    
        elseif isscalar(x) ...
                && x > 1e7 ...
                && x < 1e8
            y = floor(x/10000);
            mo = floor((x - 10000*y)/100);
            da = x - 10000*y - 100*mo;
            d = datetime(y,mo,da);
    
        elseif isscalar(x)
            d = datetime(x, ...
                'ConvertFrom','datenum');
    
        else
            error('read_Q_IND:badDate', ...
                ['Unsupported numeric ' ...
                'date format.']);
        end
    
    else
        error('read_Q_IND:badDate', ...
            'Unsupported date input type.');
    end
    
    xN = datenum(d); %#ok<DATNM>

end

% ----------------------------------------------
function area_m2 = local_area_m2(k,bas,aux,dirQ)
% ----------------------------------------------

    area = NaN;
    
    % Preferred source: aux(:,3), matching other regional readers.
    if ~isempty(aux) ...
            && size(aux,1) >= k ...
            && size(aux,2) >= 3 ...
            && isfinite(aux(k,3)) ...
            && aux(k,3) > 0
        area = double(aux(k,3));
    end
    
    % Next source: bas.area, if available.
    if ~isfinite(area) ...
            && isstruct(bas) ...
            && isfield(bas,'area') ...
            && numel(bas.area) >= k ...
            && isfinite(bas.area(k)) ...
            && bas.area(k) > 0
        area = double(bas.area(k));
    end
    
    % Last source: camels_ind_topo.csv in parent directory.
    if ~isfinite(area)
        dirD = dirQ;
        if strcmpi(string(get_last_folder_IND(dirD)),"streamflow_timeseries")
            dirD = fileparts(dirD);
        end
        if strcmpi(string(get_last_folder_IND(dirD)),"daily")
            dirD = fileparts(dirD);
        end
        fTop = fullfile(dirD, ...
            'camels_ind_topo.csv');
    
        if ~isfile(fTop)
            fTop = fullfile(dirD, ...
                'attributes_csv','camels_ind_topo.csv');
        end
    
        if isfile(fTop)
            try
                T = readtable(fTop, ...
                    'VariableNamingRule','preserve');
                T.Properties.VariableNames = ...
                    matlab.lang.makeValidName( ...
                    T.Properties.VariableNames, ...
                    'ReplacementStyle','delete');
                if ismember('gauge_id', ...
                        T.Properties.VariableNames) ...
                        && ismember('cwc_area', ...
                        T.Properties.VariableNames)
                    ids = local_id_strings(T.gauge_id);
                    gid = local_id_strings(bas.id_gauge(k));
                    [idsH,gidH] = local_harmonize_ids(ids,gid);
                    ii = idsH == gidH;
                    if any(ii)
                        area = double( ...
                            T.cwc_area(find(ii,1)));
                    end
                end
            catch
                % Keep area as NaN and let the error below explain.
            end
        end
    end
    
    if ~isfinite(area) ...
            || area <= 0
        error('read_Q_IND:badArea', ...
            ['      Error:read_Q_IND: ' ...
            'Invalid or missing drainage area ' ...
            'for basin %s. Provide aux(:,3), ' ...
            'bas.area, or camels_ind_topo.csv.'], ...
            string(bas.id_gauge(k)));
    end
    
    % Heuristic: aux may be m^2, while bas.area/topo are usually km^2.
    % Catchment areas in km^2 are normally much smaller than 1e6; m^2 values
    % are generally much larger. Convert small values to m^2.
    if area < 1e6
        area_m2 = area * 1e6;
    else
        area_m2 = area;
    end

end

% ===============================
function id = local_id_strings(x)
% ===============================

    if isnumeric(x)
        id = strings(numel(x),1);
        for i = 1:numel(x)
            id(i) = string(sprintf( ...
                '%.0f',double(x(i))));
        end
        return
    end
    
    if iscell(x)
        id = string(x(:));
    elseif isstring(x)
        id = x(:);
    elseif ischar(x)
        id = string(cellstr(x));
    else
        id = string(x(:));
    end
    
    id = strip(id,'both','"');
    id = strtrim(id);
    id = regexprep(id,'\.0+$','');
    id(ismissing(id)) = "";

end

% ===================================
function [idFileH,idReqH] = ...
    local_harmonize_ids(idFile,idReq)
% ===================================

    idFileH = local_id_strings(idFile);
    idReqH = local_id_strings(idReq);
    
    % Strip leading zeros for matching, because CAMELS-IND files may use 3001
    % while other SAGE tables may carry 03001.
    idFileH = regexprep(idFileH,'^0+','');
    idReqH = regexprep(idReqH,'^0+','');
    
    % Preserve true zero if ever present.
    idFileH(idFileH == "") = "0";
    idReqH(idReqH == "") = "0";

end

% --------------------------------
function nm = get_last_folder_IND(p)
% --------------------------------

    [~,nm] = fileparts(char(string(p)));

end
