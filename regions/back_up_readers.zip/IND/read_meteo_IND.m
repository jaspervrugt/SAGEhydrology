function [dat,aux] = read_meteo_IND(dirM,bas,split,meteo)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%READ_METEO_IND Read CAMELS-IND daily meteorological data for SAGE.
%
% SYNOPSIS:
%   [dat,aux] = read_meteo_IND(dirM,bas,split,meteo)
%
% INPUT:
%   dirM        CAMELS-IND data directory, normally .../Data/CAMELS_IND
%   bas         basin structure with fields
%    .K          number of selected basins
%    .id_gauge   Kx1 gauge IDs in final basin order
%   split       SAGE split structure. Supports daily dt = 1 only.
%               Uses the spinup-aware requested window from ds/de, dts/dte,
%               or d1/d2, following read_meteo_BR.
%   meteo       options structure
%    .data       precipitation source:
%                 1 prcp [default]
%    .pet        PET source:
%                 1 pet [default]
%                 2 pet_gleam
%    .temp       temperature source:
%                 1 tavg [default]
%                 2 mean(tmax,tmin)
%                 3 tmax
%                 4 tmin
%    .progressFcn OPTIONAL function handle called progressFcn(k)
%
% OUTPUT:
%   dat         Kx1 cell array.
%    .meteo.P    nx1 precipitation vector [mm/day]
%    .meteo.Ep   nx1 potential evapotranspiration vector [mm/day]
%    .meteo.T    nx1 temperature vector [deg C]
%    .meteo.bad  row vector with indices of bad/missing meteo records
%    .gauge      gauge identifier
%    .fname      source/cache file name
%   aux         Kx3 matrix [lat,elev,area_m2] from camels_ind_topo.csv
%               when available; otherwise NaNs.
%
% NOTES:
%   Expected forcing files:
%       Data/CAMELS_IND/daily/catchment_mean_forcings/<gauge_id>.csv
%
%   CAMELS-IND forcing columns include:
%       year, month, day, prcp(mm/day), tmax(C), tmin(C), tavg(C),
%       srad_lw(w/m2), srad_sw(w/m2), wind_u(m/s), wind_v(m/s),
%       wind(m/s), rel_hum(%), pet(mm/day), pet_gleam(mm/day),
%       aet_gleam(mm/day), evap_canopy(mm/day), evap_surface(mm/day),
%       sm_lvl1(kg/m2), ..., sm_lvl4(kg/m2).
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% © Written by Jasper A. Vrugt, May 2026                                  %
% University of California, Irvine                                        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    if nargin < 1 ...
            || isempty(dirM)
        error('read_meteo_IND:missingDir', ...
            ['      Error:read_meteo_IND: ' ...
            'dirM must be provided.']);
    end
    if ~isfolder(dirM)
        error('read_meteo_IND:missingDir', ...
            ['      Error:read_meteo_IND: ' ...
            'Directory does not exist: %s'],dirM);
    end
    if nargin < 2 ...
            || ~isstruct(bas) ...
            || ~isfield(bas,'id_gauge')
        error('read_meteo_IND:missingBasins', ...
            ['      Error:read_meteo_IND: ' ...
            'bas.id_gauge must be provided.']);
    end
    if nargin < 3 ...
            || isempty(split)
        error('read_meteo_IND:missingSplit', ...
            ['      Error:read_meteo_IND: ' ...
            'split must be provided.']);
    end
    if nargin < 4 ...
            || isempty(meteo)
        meteo = struct();
    end
    
    split = prepare_split_IND(split);
    dt = double(split.dt);
    if dt ~= 1
        error('read_meteo_IND:dailyOnly', ...
            ['      Error:read_meteo_IND: ' ...
            'CAMELS-IND supports daily data only, ' ...
            'so split.dt must be 1.']);
    end
    
    K = bas.K;
    id_gauge = normalize_ind_gauge_id(bas.id_gauge(:));
    if numel(id_gauge) ~= K
        K = numel(id_gauge);
    end
    
    [p_name,p_id] = precipitation_source_IND(meteo);
    [pet_name,pet_id] = pet_source_IND(meteo);
    [t_name,t_id] = temperature_source_IND(meteo);
    
    req = build_requested_window_IND(split,true);
    
    [~,dailyIND] = local_ind_data_roots(dirM);
    forceDir = fullfile(dailyIND, ...
        'catchment_mean_forcings');
    if ~isfolder(forceDir)
        error('read_meteo_IND:missingForcingDir', ...
            ['      Error:read_meteo_IND: ' ...
            'Missing folder: %s'],forceDir);
    end
    
    cacheDir = fullfile(dailyIND,'timeseries');
    if ~isfolder(cacheDir)
        mkdir(cacheDir);
    end
    
    dat = cell(K,1);
    aux = nan(K,3);
    ginfo = read_gauge_info_IND(dirM);
    
    msg = ['... Reading CAMELS-IND ' ...
        'daily meteorological data'];
    fprintf('%s ... %3d%%',msg,0);
    flag_progress = true;
    
    for k = 1:K
        gid = id_gauge(k);
        gidstr = ind_id_str(gid);
    
        cacheFile = fullfile(cacheDir, ...
            sprintf('%s_IND_daily_p%d_pet%d_t%d.mat', ...
            gidstr,p_id,pet_id,t_id));
    
        if isfile(cacheFile)
            S = load(cacheFile,'P','Ep','T', ...
                'bad_meteo','fileStartDT', ...
                'fileEndDT','fileStartN', ...
                'fileEndN','gid','precipSource', ...
                'petSource','tempSource');
            Pfull = S.P;
            Epfull = S.Ep;
            Tfull = S.T;
            bad_full = S.bad_meteo;
            fileStartDT = S.fileStartDT;
            fileEndDT = S.fileEndDT;
            fileStartN = S.fileStartN;
            fileEndN = S.fileEndN;
        else
            fM = resolve_ind_file(forceDir,gid);
    
            [Pfull,Epfull,Tfull,bad_full, ...
                fileStartDT,fileEndDT, ...
                fileStartN,fileEndN] = ...
                build_ind_meteo_cache( ...
                fM,p_name,pet_name,t_name);
    
            P = single(Pfull);
            Ep = single(Epfull);
            T = single(Tfull);
            bad_meteo = int64(bad_full(:));
            precipSource = p_name;
            petSource = pet_name;
            tempSource = t_name;
            save(cacheFile,'P','Ep','T', ...
                'bad_meteo','fileStartDT', ...
                'fileEndDT','fileStartN', ...
                'fileEndN','gid','precipSource', ...
                'petSource','tempSource','-v7.3');
        end
    
        if req.read_start_N < fileStartN ...
                || req.read_end_N > fileEndN
            if flag_progress
                fprintf('\n');
            end
            error(['      Error:read_meteo_IND: ' ...
                'requested period outside CAMELS-IND meteo ' ...
                'file for basin %s.\n' ...
                'File covers %s to %s.'], ...
                gidstr,string(fileStartDT), ...
                string(fileEndDT));
        end
    
        id0 = double(req.read_start_N ...
            - fileStartN) + 1;
        id1 = double(req.read_end_N ...
            - fileStartN) + 1;
        idx = id0:id1;
    
        dat{k}.meteo.P = single(Pfull(idx));
        dat{k}.meteo.Ep = single(Epfull(idx));
        dat{k}.meteo.T = single(Tfull(idx));
        dat{k}.gauge = gid;
        dat{k}.fname = {cacheFile};
    
        bad_full = double(bad_full(:));
        bad_loc = bad_full(bad_full >= id0 ...
            & bad_full <= id1) - id0 + 1;
        dat{k}.meteo.bad = bad_loc(:)';
    
        if ~isempty(ginfo)
            j = find(ginfo.gauge_id == gid,1);
            if ~isempty(j)
                aux(k,1) = ginfo.lat(j);
                aux(k,2) = ginfo.elev(j);
                aux(k,3) = ginfo.area_m2(j);
            end
        end
    
        if mod(k,5) == 0 ...
                || k == K
            pct = floor(100*k/K);
            fprintf('\b\b\b\b%3d%%',pct);
            drawnow;
        end
    
        if nargin >= 4 ...
                && isstruct(meteo) ...
                && isfield(meteo,'progressFcn') ...
                && ~isempty(meteo.progressFcn)
            meteo.progressFcn(k);
        end
    end
    
    if flag_progress
        fprintf('\b\b\b\bDone\n');
    end
    
    if isfield(split,'local') ...
            && split.local ...
            && isfield(split,'rainfall_block') ...
            && split.rainfall_block
        dat = rainfall_rank_split(dat,split);
    end

end

% ===================================================================
function [P,Ep,T,bad,fileStartDT,fileEndDT,fileStartN,fileEndN] = ...
    build_ind_meteo_cache(fM,p_name,pet_name,t_name)
% ===================================================================

    TM = read_ind_meteo_table(fM);
    tM = datetime(TM.year,TM.month,TM.day);
    
    fileStartDT = min(tM);
    fileEndDT = max(tM);
    
    t = (fileStartDT:days(1):fileEndDT)';
    
    P0 = column_by_date_IND(TM,tM,t,p_name,fM);
    E0 = column_by_date_IND(TM,tM,t,pet_name,fM);
    T0 = temperature_by_date_IND(TM,tM,t,t_name,fM);
    
    P = single(P0(:));
    Ep = single(E0(:));
    T = single(T0(:));
    
    bad = find(~isfinite(P) ...
        | ~isfinite(Ep) ...
        | ~isfinite(T));
    bad = int64(bad(:));
    
    fileStartN = int64(datenum(fileStartDT)); %#ok<DATNM>
    fileEndN = int64(datenum(fileEndDT));     %#ok<DATNM>

end

% --------------------------------------
function T = read_ind_meteo_table(fname)
% --------------------------------------

    opts = detectImportOptions(fname, ...
        'FileType','text');
    opts.VariableNamingRule = 'preserve';
    T = readtable(fname,opts);
    
    % Remove units from CAMELS-IND names while keeping readable SAGE names.
    vn0 = string(T.Properties.VariableNames);
    vn = lower(vn0);
    vn = regexprep(vn,'\(.*?\)','');
    vn = regexprep(vn,'[^a-zA-Z0-9_]+','_');
    vn = regexprep(vn,'_+','_');
    vn = regexprep(vn,'^_|_$','');
    vn = matlab.lang.makeValidName(vn, ...
        'ReplacementStyle','delete');
    vn = matlab.lang.makeUniqueStrings(vn);
    T.Properties.VariableNames = cellstr(vn);
    
    need = {'year','month','day'};
    for i = 1:numel(need)
        if ~ismember(need{i}, ...
                T.Properties.VariableNames)
            error('read_meteo_IND:badFile', ...
                ['      Error:read_meteo_IND: ' ...
                '%s lacks column %s.'], ...
                fname,need{i});
        end
    end

end

% ---------------------------------------------------------
function x = column_by_date_IND(T,tFile,tReq,varName,fname)
% ---------------------------------------------------------

    if ~ismember(varName, ...
            T.Properties.VariableNames)
        error('read_meteo_IND:missingVariable', ...
            ['      Error:read_meteo_IND: ' ...
            '%s lacks column %s.'],fname,varName);
    end
    
    [tf,loc] = ismember(tReq,tFile);
    if ~all(tf)
        error('read_meteo_IND:missingDates', ...
            ['      Error:read_meteo_IND: ' ...
            '%s lacks %d requested dates, e.g. %s.'], ...
            fname,sum(~tf),string(tReq(find(~tf,1))));
    end
    
    col = T.(varName);
    col = local_to_numeric_column(col);
    
    x = col(loc);

end

% -----------------------------------------
function x = temperature_by_date_IND(T, ...
    tFile,tReq,t_name,fname)
% -----------------------------------------

    switch t_name
        case 'tavg'
            x = column_by_date_IND(T, ...
                tFile,tReq,'tavg',fname);
        case 'tmean_from_minmax'
            tx = column_by_date_IND(T, ...
                tFile,tReq,'tmax',fname);
            tn = column_by_date_IND(T, ...
                tFile,tReq,'tmin',fname);
            x = 0.5*(tx + tn);
        case 'tmax'
            x = column_by_date_IND(T, ...
                tFile,tReq,'tmax',fname);
        case 'tmin'
            x = column_by_date_IND(T, ...
                tFile,tReq,'tmin',fname);
        otherwise
            error('read_meteo_IND:badTempSource', ...
                ['      Error:read_meteo_IND: ' ...
                'Unknown temperature source: %s'], ...
                t_name);
    end

end

% --------------------------------------
function fname = resolve_ind_file(d,gid)
% --------------------------------------

    gidstr = ind_id_str(gid);
    
    patterns = { ...
        sprintf('%s.csv',gidstr), ...
        sprintf('%d.csv',gid), ...
        sprintf('%05d.csv',gid), ...
        sprintf('%s*.csv',gidstr), ...
        sprintf('%d*.csv',gid)};
    
    fname = ''; %#ok<NASGU>
    for i = 1:numel(patterns)
        q = dir(fullfile(d,patterns{i}));
        q = q(~[q.isdir]);
        if ~isempty(q)
            fname = fullfile(q(1).folder,q(1).name);
            return
        end
    end
    
    error('read_meteo_IND:missingFile', ...
        ['      Error:read_meteo_IND: ' ...
        'Missing forcing file for basin %s in %s.'], ...
        gidstr,d);
    
    end

% --------------------------------------------------
function [rootIND,dailyIND] = local_ind_data_roots(dirM)
    p = char(string(dirM));
    [parent,nm] = fileparts(p);
    if strcmpi(nm,'daily')
        rootIND = parent;
        dailyIND = p;
    elseif any(strcmpi(nm,{'catchment_mean_forcings', ...
            'streamflow_timeseries'}))
        dailyIND = parent;
        [rootIND,nmDaily] = fileparts(dailyIND);
        if ~strcmpi(nmDaily,'daily')
            rootIND = p;
            dailyIND = fullfile(p,'daily');
        end
    else
        rootIND = p;
        dailyIND = fullfile(p,'daily');
    end
end

function [name,id] = precipitation_source_IND(meteo)
% --------------------------------------------------

    id = 1;
    if isfield(meteo,'data') ...
            && ~isempty(meteo.data)
        id = double(meteo.data);
    end
    
    switch id
        case {0,1}
            id = 1;
            name = 'prcp';
        otherwise
            error('read_meteo_IND:badPrecipSource', ...
                ['      Error:read_meteo_IND: ' ...
                'meteo.data must be ' ...
                '0 or 1 for CAMELS-IND ' ...
                '(both select prcp).']);
    end

end

% ----------------------------------------
function [name,id] = pet_source_IND(meteo)
% ----------------------------------------

    id = 1;
    if isfield(meteo,'pet') ...
            && ~isempty(meteo.pet)
        id = double(meteo.pet);
    end
    
    switch id
        case {0,1}
            id = 1;
            name = 'pet';
        case 2
            name = 'pet_gleam';
        otherwise
            error('read_meteo_IND:badPETSource', ...
                ['      Error:read_meteo_IND: ' ...
                'meteo.pet must be ' ...
                '0, 1, or 2 for CAMELS-IND.']);
    end

end

% ------------------------------------------------
function [name,id] = temperature_source_IND(meteo)
% ------------------------------------------------

    id = 1;
    if isfield(meteo,'temp') ...
            && ~isempty(meteo.temp)
        id = double(meteo.temp);
    end
    
    switch id
        case {0,1}
            id = 1;
            name = 'tavg';
        case 2
            name = 'tmean_from_minmax';
        case 3
            name = 'tmax';
        case 4
            name = 'tmin';
        otherwise
            error('read_meteo_IND:badTempSource', ...
                ['      Error:read_meteo_IND: ' ...
                'meteo.temp must be ' ...
                '0,1,2,3,or 4 for CAMELS-IND.']);
    end

end

% --------------------------------------
function split = prepare_split_IND(split)
% --------------------------------------

    if ~isfield(split,'dt') ...
            || isempty(split.dt)
        split.dt = 1;
    end
    if ~isfield(split,'spinup') ...
            || isempty(split.spinup)
        split.spinup = 0;
    end

end

% ------------------------------------------------------------
function req = build_requested_window_IND(split,includeSpinup)
% ------------------------------------------------------------

    if nargin < 2
        includeSpinup = true;
    end
    spinup = max(0,round(double(split.spinup)));
    
    if isfield(split,'ds') ...
            && isfield(split,'de') ...
            && ~isempty(split.ds) ...
            && ~isempty(split.de)
        d0 = as_datetime_IND(split.ds);
        d1 = as_datetime_IND(split.de);
    elseif isfield(split,'dts') ...
            && isfield(split,'dte') ...
            && ~isempty(split.dts) ...
            && ~isempty(split.dte)
        d0 = as_datetime_IND(split.dts);
        d1 = as_datetime_IND(split.dte);
        if isfield(split,'des') ...
                && isfield(split,'dee') ...
                && ~isempty(split.des) ...
                && ~isempty(split.dee)
            d0 = min(d0,as_datetime_IND(split.des));
            d1 = max(d1,as_datetime_IND(split.dee));
        end
    elseif isfield(split,'d1') ...
            && isfield(split,'d2')
        d0 = as_datetime_IND(split.d1);
        d1 = as_datetime_IND(split.d2);
    else
        error('read_meteo_IND:badSplit', ...
            ['      Error:read_meteo_IND: ' ...
            'Could not determine ' ...
            'requested dates from split. ' ...
            'Expected ds/de, dts/dte, or d1/d2.']);
    end
    
    if includeSpinup
        d0 = d0 - days(spinup);
    end
    
    req.read_start_DT = d0;
    req.read_end_DT = d1;
    req.read_start_N = int64(datenum(d0)); %#ok<DATNM>
    req.read_end_N = int64(datenum(d1));   %#ok<DATNM>

end

% -----------------------------
function d = as_datetime_IND(x)
% -----------------------------

    if isdatetime(x)
        d = x;
    elseif isnumeric(x)
        x = double(x(:).');
        if numel(x) == 3
            if x(1) > 1800
                d = datetime(x(1),x(2),x(3));
            elseif x(3) > 1800
                d = datetime(x(3),x(2),x(1));
            else
                error('read_meteo_IND:badDate', ...
                    ['Cannot determine ' ...
                    'date-vector order.']);
            end
        elseif isscalar(x) ...
                && x > 1e7 ...
                && x < 1e8
            y = floor(x/10000);
            mo = floor((x - 10000*y)/100);
            da = x - 10000*y - 100*mo;
            d = datetime(y,mo,da);
        elseif isscalar(x)
            d = datetime(x, ...
                'ConvertFrom','datenum');
        else
            error('read_meteo_IND:badDate', ...
                ['Unsupported numeric ' ...
                'date format.']);
        end
    elseif ischar(x) ...
            || isstring(x)
        s = strtrim(string(x));
        try
            d = datetime(s, ...
                'InputFormat', ...
                'd/M/yyyy');
        catch
            try
                d = datetime(s, ...
                    'InputFormat', ...
                    'dd/MM/yyyy');
            catch
                d = datetime(s);
            end
        end
    else
        error('read_meteo_IND:badDate', ...
            'Unsupported date input type.');
    end
    
    d = d(1);

end

% ------------------------------------
function G = read_gauge_info_IND(dirM)
% ------------------------------------

    G = [];

    % Local functions have their own workspace. Resolve the regional root
    % explicitly from the directory passed to this helper.
    [rootIND,~] = local_ind_data_roots(dirM);
    
    candidates = { ...
        fullfile(rootIND,'camels_ind_topo.csv'), ...
        fullfile(rootIND,'attributes_csv', ...
        'camels_ind_topo.csv'), ...
        fullfile(rootIND,'attributes_txt', ...
        'camels_ind_topo.txt')};
    
    f = '';
    for i = 1:numel(candidates)
        if isfile(candidates{i})
            f = candidates{i};
            break
        end
    end
    if isempty(f)
        return
    end
    
    try
        opts = detectImportOptions(f, ...
            'FileType','text', ...
            'VariableNamingRule','preserve');
        T = readtable(f,opts);
        T.Properties.VariableNames = ...
            matlab.lang.makeValidName( ...
            T.Properties.VariableNames, ...
            'ReplacementStyle','delete');
    
        if ~ismember('gauge_id', ...
                T.Properties.VariableNames)
            return
        end
    
        G.gauge_id = normalize_ind_gauge_id(T.gauge_id);
        if ismember('cwc_lat', ...
                T.Properties.VariableNames)
            G.lat = double(T.cwc_lat);
        elseif ismember('ghi_lat', ...
                T.Properties.VariableNames)
            G.lat = double(T.ghi_lat);
        else
            G.lat = nan(size(G.gauge_id));
        end
    
        if ismember('gauge_elevation', ...
                T.Properties.VariableNames)
            G.elev = double(T.gauge_elevation);
        elseif ismember('elev_mean', ...
                T.Properties.VariableNames)
            G.elev = double(T.elev_mean);
        else
            G.elev = nan(size(G.gauge_id));
        end
    
        if ismember('cwc_area', ...
                T.Properties.VariableNames)
            G.area_m2 = double(T.cwc_area) * 1e6;
        elseif ismember('ghi_area', ...
                T.Properties.VariableNames)
            G.area_m2 = double(T.ghi_area) * 1e6;
        else
            G.area_m2 = nan(size(G.gauge_id));
        end
    catch
        G = [];
    end

end

% -------------------------------------
function id = normalize_ind_gauge_id(x)
% -------------------------------------

    if isnumeric(x)
        id = double(x);
        return
    end
    x = string(x);
    x = strtrim(x);
    x = regexprep(x,'\.0+$','');
    id = str2double(x);

end

% --------------------------
function s = ind_id_str(gid)
% --------------------------

    if isstring(gid) ...
            || ischar(gid)
        gid = normalize_ind_gauge_id(gid);
    end
    
    if isnan(gid)
        s = 'NaN';
    elseif gid < 10000
        s = sprintf('%05d',round(gid));
    else
        s = sprintf('%d',round(gid));
    end

end

% -------------------------------------
function x = local_to_numeric_column(v)
% -------------------------------------

    if isnumeric(v)
        x = double(v);
        return
    end
    
    if iscell(v)
        v = string(v);
    elseif ischar(v)
        v = string(cellstr(v));
    else
        v = string(v);
    end
    
    v = strtrim(v);
    v(v == "" ...
        | lower(v) == "na" ...
        | lower(v) == "nan" ...
        | lower(v) == "null" ...
        | v == "-999" ...
        | v == "-9999") = missing;
    
    x = str2double(v);

end