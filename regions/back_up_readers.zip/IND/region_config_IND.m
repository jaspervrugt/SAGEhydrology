function R = region_config_IND()
%REGION_CONFIG_IND Regional defaults for CAMELS-IND.
%
% All X.paths fields are relative to Data/<R.data_root>.
% Dates use dd/MM/yyyy and water-year boundaries.

    R = struct();
    R.code = 'CAMELS_IND';
    R.acronym = 'IND';
    R.name = 'India';
    R.dataset = 'CAMELS-IND';
    R.data_root = 'CAMELS_IND';
    R.resolutions = {'Daily'};
    R.default_resolution = 'Daily';
    R.basin_file_pattern = 'IND_%d_basins.txt';

    X = struct();
    X.label = 'Daily';
    X.dt = 1;
    X.basins.universe = 242;
    X.basins.training = 210;
    X.basins.evaluation = 32;
    X.period.spinup_days = 365;
    X.period.manual.train_start = '01/10/2002';
    X.period.manual.train_end = '30/09/2012';
    X.period.manual.eval_start = '01/10/1992';
    X.period.manual.eval_end = '30/09/2002';
    X.period.common_start = '01/10/1992';
    X.period.common_end = '30/09/2012';
    X.paths.run_root = '';
    X.paths.meteo = fullfile('daily','catchment_mean_forcings');
    X.paths.discharge = fullfile('daily','streamflow_timeseries');
    % Meteorological/PET controls shown by SAGE-GUI.
    X.meteo.product.items = {'CAMELS-IND [daily]'};
    X.meteo.product.default = 'CAMELS-IND [daily]';
    X.meteo.product.enabled = false;
    X.meteo.precipitation.items = {'1 Precipitation'};
    X.meteo.precipitation.default = '1 Precipitation';
    X.meteo.precipitation.enabled = false;
    X.meteo.temperature.items = { ...
        '1 Mean', ...
        '2 (Tmin+Tmax)/2', ...
        '3 Tmax', ...
        '4 Tmin' ...
        };
    X.meteo.temperature.default = '1 Mean';
    X.meteo.temperature.enabled = true;
    X.meteo.pet.items = { ...
        '1 native', ...
        '2 GLEAM' ...
        };
    X.meteo.pet.default = '1 native';
    X.meteo.pet.enabled = true;
    C = repmat(struct('name','','type','','path','','pattern','', ...
        'minimum_count',1,'required',true),0,1);
    C(1).name = 'Meteorological data';
    C(1).type = 'folder';
    C(1).path = fullfile('daily','catchment_mean_forcings');
    C(1).pattern = '*';
    C(1).minimum_count = 1;
    C(2).name = 'Discharge data';
    C(2).type = 'folder';
    C(2).path = fullfile('daily','streamflow_timeseries');
    C(2).pattern = '*';
    C(2).minimum_count = 1;
    X.checks = C;
    R.by_resolution.Daily = X;

end