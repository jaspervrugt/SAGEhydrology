function R=region_config_PR()
%REGION_CONFIG_PR Defaults for Puerto Rico GRDC-Caravan.
    R=region_config_GRDC('PR','Puerto Rico',24,22,18,4, ...
        '01/10/1980','30/09/2000','01/10/2000','30/09/2020');
end
