function dat=read_Q_PR(~,~,dat,~,~,~)
%READ_Q_PR No-op: GRDC-Caravan streamflow is read with meteorology.
end
