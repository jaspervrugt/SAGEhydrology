function [dat,aux]=read_meteo_PR(dirM,bas,split,meteo)
%READ_METEO_PR Read daily Puerto Rico GRDC-Caravan forcing and discharge.
    [dat,aux]=read_meteo_NA(dirM,bas,split,meteo,'Puerto Rico');
end
