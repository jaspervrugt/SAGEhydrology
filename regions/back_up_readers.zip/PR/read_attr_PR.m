function [A,id_gauge,gname,zone]=read_attr_PR(dirD,bas)
%READ_ATTR_PR Read filtered Puerto Rico GRDC-Caravan attributes.
    [A,id_gauge,gname,zone]=read_attr_NA(dirD,bas,'CAMELS_PR','PR');
end
