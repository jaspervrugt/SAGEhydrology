function [A,id_gauge,gname,zone] = read_attr_ES(dirD,bas)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%READ_ATTR_ES Read catchment attributes of CAMELS-ES dataset.
%
% Expected files in Data/CAMELS_ES:
%   atributes_efas_hydrometeorology_camelses.csv
%   atributes_efas_static_maps_camelses.csv
%   attributes_caravan_camelses.csv
%   attributes_efas_model_parameters_camelses.csv
%   attributes_hydroatlas_camelses.csv
%   attributes_other_camelses.csv
%
% OUTPUT:
%   A         rxK standardized attribute matrix
%   id_gauge  Kx1 string array with numeric CAMELS-ES basin IDs
%   gname     Kx1 string array with basin/gauge names
%   zone      structure with id/name/label/group/lat/lon/area fields
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% © Written by Jasper A. Vrugt, Jun. 2026                                 %
% University of California, Irvine                                        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    if nargin < 1 ...
            || isempty(dirD)
        error('read_attr_ES:missingDir', ...
            ['      Error:read_attr_ES: ' ...
            'dirD must be provided.']);
    end
    if ~isfolder(dirD)
        error('read_attr_ES:missingDir', ...
            ['      Error:read_attr_ES: ' ...
            'Attribute directory ' ...
            'does not exist: %s'],dirD);
    end
    if nargin < 2 ...
            || isempty(bas)
        bas = struct();
    end
    if ~isstruct(bas)
        error('read_attr_ES:badBas', ...
            ['      Error:read_attr_ES: ' ...
            'bas must be a structure.']);
    end
    % =========================================
    % ZONE CONTROL PARAMETERS (GLOBAL DEFAULTS)
    % =========================================
    if ~isfield(bas,'min_per_zone') ...
            || isempty(bas.min_per_zone)
        min_per_zone = 5;
    else
        min_per_zone = bas.min_per_zone;
    end    
    if ~isfield(bas,'max_zones') ...
            || isempty(bas.max_zones)
        max_zones = 8;
    else
        max_zones = bas.max_zones;
    end

    pr_table = 1;
    if isfield(bas,'pr_attr') ...
            && ~isempty(bas.pr_attr)
        pr_table = bas.pr_attr;
    end

    fprintf(['... Reading CAMELS-ES ' ...
        'basin attributes ']);

    AA = read_camels_es_attribute_tables(dirD);

    needVars = {'gauge_id','gauge_lat', ...
        'gauge_lon','area'};
    for j = 1:numel(needVars)
        if ~ismember(needVars{j}, ...
                AA.Properties.VariableNames)
            error('read_attr_ES:missingMetadata', ...
                ['      Error:read_attr_ES: ' ...
                'missing required ' ...
                'variable: %s'],needVars{j});
        end
    end

    id_all = normalize_es_gauge_id(AA.gauge_id);
    AA.gauge_id = id_all;

    idNum = str2double(id_all);
    if any(isnan(idNum))
        [~,isrt] = sort(id_all);
    else
        [~,isrt] = sort(idNum);
    end
    AA = AA(isrt,:);
    id_all = id_all(isrt);

    if isfield(bas,'id_gauge') ...
            && ~isempty(bas.id_gauge)
        id_req = normalize_es_gauge_id(bas.id_gauge(:));
        [tf,locid] = ismember(id_req,id_all);
        if ~all(tf)
            missing = id_req(~tf);
            error('read_attr_ES:missingRequestedGauge', ...
                ['      Error:read_attr_ES: ' ...
                'Missing CAMELS-ES ' ...
                'attributes for %d requested ' ...
                'gauge IDs, e.g. %s.'], ...
                numel(missing),char(missing(1)));
        end
        AA = AA(locid,:);
        id_gauge = id_req(:);
    else
        id_gauge = id_all(:);
    end

    if ismember('gauge_name', ...
            AA.Properties.VariableNames)
        gname = string(AA.gauge_name);
    else
        gname = "ES_" + id_gauge;
    end

    gname = standardize_camels_gauge_names(gname, ...
        'CAMELS_ES',id_gauge);

    ensure_es_gauge_information(dirD,AA,gname);
    region = erase(mfilename,'read_attr_');
    zone = classify_camels_all_zones(region,AA, ...
        min_per_zone,max_zones);

    % ------------------
    % Generic attributes
    % ------------------
    [A,labels] = build_attr_matrix(AA,bas, ...
        mfilename,pr_table);

    if pr_table == 1
        assignin('base','SAGE_ES_attribute_labels', ...
            labels);
    end

    fprintf(' ... Done\n');
end

% =================================================
function AA = read_camels_es_attribute_tables(dirD)
% =================================================

    files = { ...
        'attributes_other_camelses.csv', ...
        'attributes_caravan_camelses.csv', ...
        'atributes_efas_hydrometeorology_camelses.csv', ...
        'atributes_efas_static_maps_camelses.csv', ...
        'attributes_efas_model_parameters_camelses.csv', ...
        'attributes_hydroatlas_camelses.csv'};

    caller = mfilename;
    for i = 1:numel(files)
        must_exist(fullfile(dirD,files{i}), ...
            files{i},caller);
    end

    AA = read_es_csv(fullfile(dirD,files{1}));

    for i = 2:numel(files)
        U = read_es_csv(fullfile(dirD,files{i}));
        AA = join_es_attributes(AA,U);
    end
end

% =============================
function T = read_es_csv(fname)
% =============================
    opts = detectImportOptions(fname, ...
        'FileType','text', ...
        'Delimiter',',', ...
        'VariableNamingRule','preserve');
    T = readtable(fname,opts);

    T.Properties.VariableNames = ...
        matlab.lang.makeUniqueStrings( ...
        matlab.lang.makeValidName( ...
        strtrim(string(T.Properties.VariableNames))));

    if ~ismember('gauge_id',T.Properties.VariableNames)
        error('read_attr_ES:missingGaugeID', ...
            ['      Error:read_attr_ES: ' ...
            '%s has no gauge_id column.'],fname);
    end

    T.gauge_id = normalize_es_gauge_id(T.gauge_id);

    for j = 1:width(T)
        vn = T.Properties.VariableNames{j};
        if any(strcmp(vn,{'gauge_id', ...
                'gauge_name','country'}))
            continue
        end
        T.(vn) = local_to_double_or_keep(T.(vn));
    end
end

% ==================================
function T = join_es_attributes(T,U)
% ==================================
    varsT = string(T.Properties.VariableNames);
    varsU = string(U.Properties.VariableNames);
    varsU = varsU(varsU ~= "gauge_id");

    for j = 1:numel(varsU)
        if any(varsT == varsU(j))
            old = char(varsU(j));
            new = char(varsU(j) + "_es");
            U.Properties.VariableNames{strcmp( ...
                U.Properties.VariableNames,old)} = new;
        end
    end

    T = outerjoin(T,U, ...
        'Keys','gauge_id', ...
        'MergeKeys',true, ...
        'Type','left');
end

% ====================================
function id = normalize_es_gauge_id(x)
% ====================================
    x = string(x(:));
    x = strtrim(x);
    x = lower(x);
    x = regexprep(x,'^camelses[_-]*','');
    x = regexprep(x,'\.0+$','');
    x = regexprep(x,'[^0-9]','');

    id = x;
    if any(id == "")
        error('read_attr_ES:badGaugeID', ...
            ['      Error:read_attr_ES: ' ...
            'empty gauge_id after normalization.']);
    end
end

% =====================================
function x = local_to_double_or_keep(x)
% =====================================
    if isnumeric(x) ...
            || islogical(x)
        return
    end
    if iscell(x)
        xs = string(x);
    elseif ischar(x)
        xs = string(cellstr(x));
    elseif isstring(x) ...
            || iscategorical(x)
        xs = string(x);
    else
        return
    end

    xs = strtrim(xs);
    xs = erase(xs,'"');
    xs = strrep(xs,',','.');
    xs = regexprep(xs,'^(NA|NaN|null|NULL|None|-9999)$', ...
        'NaN','ignorecase');
    xs(xs == "") = "NaN";

    y = str2double(xs);
    good = ~(ismissing(xs) ...
        | xs == "");
    if ~any(good) ...
            || sum(isfinite(y(good)) ...
            | isnan(y(good))) >= 0.9*sum(good)
        x = y;
    end
end

% % ===================================================
% function gname = local_clean_es_gname(gname,id_gauge)
% % ===================================================
%     gname = string(gname(:));
%     id_gauge = string(id_gauge(:));
%     gname = strrep(gname,'_',' ');
%     gname = strtrim(gname);
% 
%     bad = ismissing(gname) ...
%         | strlength(gname) == 0;
%     gname(bad) = "ES_" + id_gauge(bad);
% end

% =================================================
function ensure_es_gauge_information(dirD,AA,gname)
% =================================================
    fname = fullfile(dirD, ...
        'gauge_information.txt');
    if isfile(fname)
        return
    end

    T = table();
    T.gauge_id = normalize_es_gauge_id(AA.gauge_id);

    if nargin >= 3 && ~isempty(gname)
        T.gauge_name = string(gname(:));
    elseif ismember('gauge_name', ...
            AA.Properties.VariableNames)
        T.gauge_name = string(AA.gauge_name);
    else
        T.gauge_name = "ES_" + T.gauge_id;
    end

    T.lat = double(AA.gauge_lat(:));
    T.lon = double(AA.gauge_lon(:));
    T.area = double(AA.area(:));

    try
        writetable(T,fname,'Delimiter','\t');
    catch
    end
end
