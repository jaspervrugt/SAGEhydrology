function [dat,aux] = read_meteo_ES(dirM,bas,split,meteo)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%READ_METEO_ES Read CAMELS-ES daily hydrometeorological data for SAGE.
%
% Expected folder:
%   Data/CAMELS_ES/daily/timeseries/camelses_####.csv
%
% Available meteorological forcing products (meteo.data):
%   1 = EMO-1
%       pr_emo1  daily areal precipitation [mm/day]
%       ta_emo1  daily mean air temperature [deg C]
%       e0_emo1  daily reference evapotranspiration [mm/day]
%   2 = ERA5-Land
%       total_precipitation_sum   daily precipitation [mm/day]
%       temperature_2m_mean      daily mean air temperature [deg C]
%       potential_evaporation_sum daily potential evaporation [mm/day]
%
% Streamflow is always read from the common streamflow column [mm/day].
% The EFAS variable dis_efas5 is model-derived specific discharge and is
% not used for calibration.
%
% Output follows the standard SAGE meteorological-reader interface:
%   dat{k}.meteo.P
%   dat{k}.meteo.Ep
%   dat{k}.meteo.T
%   dat{k}.meteo.bad
%   dat{k}.y_n       scored period only, spin-up removed [mm/day]
%   dat{k}.bad       logical mask, same length as y_n
%
%   aux(:,1) = latitude  [deg]
%   aux(:,2) = elevation [m]
%   aux(:,3) = area      [m2]
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% © Written by Jasper A. Vrugt, Jun. 2026                                 %
% University of California, Irvine                                        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    if nargin < 4
        meteo = struct();
    end
    if nargin < 3
        error(['      Error:read_meteo_ES: ' ...
            'Expected input signature ' ...
            '[dat,aux] = read_meteo_ES(' ...
            'dirM,bas,split,meteo).']);
    end
    if nargin < 1 ...
            || isempty(dirM)
        error(['      Error:read_meteo_ES: ' ...
            'dirM must be provided.']);
    end

    split = local_prepare_split(split);

    if double(split.dt) ~= 1
        error(['      Error:read_meteo_ES: ' ...
            'CAMELS-ES ' ...
            'hydrometeorological data ' ...
            'are daily only.']);
    end

    [meteo_id,meteo_name] = local_es_meteo_source(meteo);

    K = bas.K;
    id_GAUGE = local_es_id_strings(bas.id_gauge(:));

    dirTs = local_es_timeseries_dir(dirM);
    dirES = local_es_root_from_timeseries(dirTs);

    dat = cell(K,1);
    aux = nan(K,3);

    try
        aux = local_aux_from_bas(bas,aux);
    catch
    end
    try
        aux = local_aux_from_gauge_information( ...
            dirES,bas,aux);
    catch MEaux
        fprintf('\n');
        fprintf(['      Warning:read_meteo_ES: ' ...
            'could not read ' ...
            'Spain gauge information ' ...
            'for aux fields.\n']);
        fprintf('      Cause: %s\n',MEaux.message);
    end

    req = local_requested_daily_window(split);
    tReq = dateshift(datetime(req.time(:)), ...
        'start','day');
    nReq = numel(tReq);

    if nReq == 0
        error(['      Error:read_meteo_ES: ' ...
            'requested daily time ' ...
            'window is empty. ' ...
            'Check split settings.']);
    end

    % Discharge is stored for the scored period only. split.idx is the
    % standard SAGE index vector after removing spin-up from the read window.
    if isfield(split,'idx') ...
            && ~isempty(split.idx)
        idx_score = double(split.idx(:));
    else
        idx_score = (1:nReq).';
    end
    idx_score = idx_score(isfinite(idx_score) ...
        & idx_score >= 1 ...
        & idx_score <= nReq);
    idx_score = round(idx_score(:));

    if isempty(idx_score)
        error(['      Error:read_meteo_ES: ' ...
            'scored-period index ' ...
            'split.idx is empty or ' ...
            'outside the requested read window.']);
    end

    cache_dir = fullfile(dirTs, ...
        sprintf('_cache_ES_daily_%s',lower(meteo_name)));
    if ~isfolder(cache_dir)
        mkdir(cache_dir);
    end

    fprintf(['... Reading daily CAMELS-ES %s ' ...
        'meteorological data files %3d%%'],meteo_name,0);
    flag_progress = true;

    for k = 1:K

        gid = id_GAUGE(k);
        fname = fullfile(dirTs, ...
            sprintf('camelses_%s.csv',gid));

        if ~isfile(fname)
            fprintf('\n');
            error(['      Error:read_meteo_ES: ' ...
                'Missing ' ...
                'hydrometeorological ' ...
                'file for basin %s: %s'],gid,fname);
        end

        win_key = sprintf('%s_%s', ...
            char(tReq(1),'yyyyMMdd'), ...
            char(tReq(end),'yyyyMMdd'));
        cache_file = fullfile(cache_dir, ...
            sprintf('%s_ES_daily_%s_%s.mat', ...
            gid,lower(meteo_name),win_key));

        use_cache = false;
        if isfile(cache_file)
            try
                S = load(cache_file,'P','Ep','Tmean', ...
                    'Qmm','badrows','src_datenum');
                info = dir(fname);
                if isfield(S,'src_datenum') ...
                        && S.src_datenum >= info.datenum
                    P = S.P;
                    Ep = S.Ep;
                    Tmean = S.Tmean;
                    Qmm = S.Qmm;
                    badrows = S.badrows;
                    use_cache = true;
                end
            catch
                use_cache = false;
            end
        end

        if ~use_cache
            [tFile,Pfile,Epfile,Tfile,QmmFile] = ...
                local_read_es_hydromet_file(fname,meteo_id);

            P = nan(nReq,1);
            Ep = nan(nReq,1);
            Tmean = nan(nReq,1);
            Qmm = nan(nReq,1);

            [tf,loc] = ismember(tReq,tFile);
            P(tf) = Pfile(loc(tf));
            Ep(tf) = Epfile(loc(tf));
            Tmean(tf) = Tfile(loc(tf));
            Qmm(tf) = QmmFile(loc(tf));

            badmask = ~isfinite(P) ...
                | ~isfinite(Ep) ...
                | ~isfinite(Tmean);
            badrows = int64(find(badmask));

            try
                info = dir(fname);
                src_datenum = info.datenum;
                save(cache_file,'P','Ep','Tmean', ...
                    'Qmm','badrows','src_datenum','-v7.3');
            catch
            end
        end

        % Meteorological forcing keeps the full requested read window,
        % including spin-up, consistent with the other regional readers.
        dat{k}.meteo.P = single(P);
        dat{k}.meteo.Ep = single(Ep);
        dat{k}.meteo.T = single(Tmean);
        dat{k}.meteo.bad = badrows(:)';

        % Discharge is in the same CAMELS-ES file. The streamflow column
        % is already basin-average runoff depth [mm/day], so no area-based
        % conversion is applied. Spin-up is removed by retaining split.idx.
        Qmm_all = double(Qmm);
        bad_q_all = ~isfinite(Qmm_all);

        Q = Qmm_all(idx_score);
        dat{k}.y_n = single(Q);
        dat{k}.bad = bad_q_all(idx_score).';

        % Keep full-window streamflow for diagnostics.
        dat{k}.Q_mm_ES = single(Qmm);

        dat{k}.gauge = gid;
        dat{k}.meteo_source = meteo_name;
        dat{k}.fname{1} = fname;
        dat{k}.fname{2} = fname;

        if ~isempty(badrows)
            if flag_progress
                fprintf('\n');
            end
            fprintf(['      Warning:read_meteo_ES: ' ...
                'basin %s has ' ...
                '%d invalid/missing daily ' ...
                'meteo rows in requested window.\n'], ...
                gid,numel(badrows));
            pct = floor(100*k/K);
            fprintf(['... Reading daily CAMELS-ES %s ' ...
                'meteorological data files %3d%%'],meteo_name,pct);
            flag_progress = true;
        end

        if mod(k,20) == 0 ...
                || k == K
            pct = floor(100*k/K);
            fprintf('\b\b\b\b%3d%%',pct);
            drawnow;
        end
    
        if isfield(meteo,'progressFcn') ...
                && ~isempty(meteo.progressFcn)
            try
                meteo.progressFcn(k);
            catch MEprogress
                warning('read_meteo_ES:progressFcn', ...
                    'GUI progress callback failed: %s', ...
                    MEprogress.message);
            end
        end
    end

    if flag_progress
        fprintf('\b\b\b\b%s\n','... Done');
    end

    if isfield(split,'local') ...
            && split.local ...
            && isfield(split,'rainfall_block') ...
            && split.rainfall_block
        dat = rainfall_rank_split(dat,split);
    end
end

% =========================================
function split = local_prepare_split(split)
% =========================================
    if exist('prepare_split','file') == 2
        split = prepare_split(split);
        return
    end

    flds = {'dt_spin0','dt_train0', ...
        'dt_train1','dt_eval0','dt_eval1'};
    for i = 1:numel(flds)
        f = flds{i};
        if isfield(split,f) ...
                && ~isempty(split.(f))
            split.(f) = local_to_datetime(split.(f));
        end
    end
end

% ================================================
function req = local_requested_daily_window(split)
% ================================================
    if exist('build_requested_window','file') == 2
        try
            req0 = build_requested_window(split,true);
            if isfield(req0,'read_start_N') ...
                    && isfield(req0,'read_end_N')
                tRef = datetime(1950,10,1);
                t0 = tRef + days(double(req0.read_start_N));
                t1 = tRef + days(double(req0.read_end_N));
                req.time = (dateshift(t0,'start','day'):days(1): ...
                    dateshift(t1,'start','day')).';
                return
            end
            if isfield(req0,'time') ...
                    && ~isempty(req0.time)
                req.time = dateshift(datetime(req0.time(:)), ...
                    'start','day');
                return
            end
        catch
        end
    end

    spinup = 0;
    if isfield(split,'spinup') ...
            && ~isempty(split.spinup)
        spinup = max(0,round(double(split.spinup)));
    elseif isfield(split,'n_spin') ...
            && ~isempty(split.n_spin)
        spinup = max(0,round(double(split.n_spin)));
    end

    starts = NaT(0,1);
    ends = NaT(0,1);

    sf = {'ds','dts','des','d1', ...
        'dt_train0','dt_eval0','dt_spin0'};
    ef = {'de','dte','dee','d2', ...
        'dt_train1','dt_eval1'};

    for i = 1:numel(sf)
        if isfield(split,sf{i}) ...
                && ~isempty(split.(sf{i}))
            starts(end+1,1) = ...
                local_to_datetime(split.(sf{i})); %#ok
        end
    end
    for i = 1:numel(ef)
        if isfield(split,ef{i}) ...
                && ~isempty(split.(ef{i}))
            ends(end+1,1) = ...
                local_to_datetime(split.(ef{i})); %#ok
        end
    end

    starts = starts(~isnat(starts));
    ends = ends(~isnat(ends));

    if isempty(starts) || isempty(ends)
        error(['      Error:read_meteo_ES: ' ...
            'could not determine ' ...
            'requested daily time ' ...
            'window from split.']);
    end

    t0 = dateshift(min(starts), ...
        'start','day') - days(spinup);
    t1 = dateshift(max(ends), ...
        'start','day');

    if t1 < t0
        error(['      Error:read_meteo_ES: ' ...
            'requested period is empty: ' ...
            '%s to %s.'],string(t0),string(t1));
    end

    req.time = (t0:days(1):t1).';
end

% ============================================
function dirTs = local_es_timeseries_dir(dirM)
% ============================================
    dirM = char(string(dirM));
    cands = { ...
        dirM, ...
        fullfile(dirM,'daily','timeseries'), ...
        fullfile(dirM, ...
        'timeseries'), ...
        fullfile(dirM,'CAMELS_ES','daily','timeseries'), ...
        fullfile(dirM, ...
        'CAMELS_ES','timeseries'), ...
        fullfile(dirM,'Data','CAMELS_ES','daily','timeseries'), ...
        fullfile(dirM,'Data', ...
        'CAMELS_ES','timeseries')};

    for i = 1:numel(cands)
        d = cands{i};
        if isfolder(d) ...
                && ~isempty(dir( ...
                fullfile(d,'camelses_*.csv')))
            dirTs = d;
            return
        end
    end

    error(['      Error:read_meteo_ES: ' ...
        'Cannot resolve CAMELS_ES ' ...
        'timeseries directory from: %s'],dirM);
end

% ===================================================
function dirES = local_es_root_from_timeseries(dirTs)
% ===================================================
    dirES = fileparts(dirTs);
    [~,nm] = fileparts(dirTs);
    if strcmpi(nm,'timeseries')
        [pDaily,nmDaily] = fileparts(dirES);
        if strcmpi(nmDaily,'daily')
            dirES = pDaily;
        end
        % dirES already parent
    else
        dirES = dirTs;
    end
end

% ===============================================================
function [t,P,Ep,Tmean,Qmm] = local_read_es_hydromet_file(fname,meteo_id)
% ===============================================================
    info = dir(fname);
    if isempty(info) ...
            || info.bytes == 0
        error(['      Error:read_meteo_ES: ' ...
            'Empty file: %s'],fname);
    end

    opts = detectImportOptions(char(fname), ...
        'FileType','text', ...
        'Delimiter',',', ...
        'VariableNamingRule','preserve');

    if isempty(opts.VariableNames) ...
            || numel(opts.VariableNames) < 40
        error(['      Error:read_meteo_ES: ' ...
            'Expected at least 40 ' ...
            'columns in: %s'],fname);
    end

    opts = setvartype(opts,opts.VariableNames{1},'char');
    T = readtable(char(fname),opts);

    vn = string(T.Properties.VariableNames);

    jDate = local_find_var(vn,["date","time"],1);

    switch meteo_id
        case 1
            jP = local_require_var(vn,"pr_emo1",fname);
            jT = local_require_var(vn,"ta_emo1",fname);
            jEp = local_require_var(vn,"e0_emo1",fname);
        case 2
            jP = local_require_var(vn, ...
                "total_precipitation_sum",fname);
            jT = local_require_var(vn, ...
                "temperature_2m_mean",fname);
            jEp = local_require_var(vn, ...
                "potential_evaporation_sum",fname);
        otherwise
            error(['      Error:read_meteo_ES: ' ...
                'Unsupported meteorological dataset: %d.'],meteo_id);
    end

    jQ = local_require_var(vn,"streamflow",fname);

    t = local_parse_es_date(T{:,jDate});
    Tmean = local_to_double(T{:,jT});
    P = local_to_double(T{:,jP});
    Ep = local_to_double(T{:,jEp});
    Qmm = local_to_double(T{:,jQ});

    t = t(:);
    P = P(:);
    Ep = Ep(:);
    Tmean = Tmean(:);
    Qmm = Qmm(:);

    good = ~isnat(t);
    t = t(good);
    P = P(good);
    Ep = Ep(good);
    Tmean = Tmean(good);
    Qmm = Qmm(good);

    if isempty(t)
        error(['      Error:read_meteo_ES: ' ...
            'No valid dates ' ...
            'found in: %s'],fname);
    end

    [t,isrt] = sort(t);
    P = P(isrt);
    Ep = Ep(isrt);
    Tmean = Tmean(isrt);
    Qmm = Qmm(isrt);

    [t,ia] = unique(t,'stable');
    P = P(ia);
    Ep = Ep(ia);
    Tmean = Tmean(ia);
    Qmm = Qmm(ia);
end

% ==================================================
function [data_id,data_name] = local_es_meteo_source(meteo)
% ==================================================
    data_id = 1;
    if isstruct(meteo) ...
            && isfield(meteo,'data') ...
            && ~isempty(meteo.data)
        data_id = round(double(meteo.data(1)));
    elseif isnumeric(meteo) ...
            && ~isempty(meteo)
        data_id = round(double(meteo(1)));
    end

    switch data_id
        case 1
            data_name = 'EMO1';
        case 2
            data_name = 'ERA5Land';
        otherwise
            error(['      Error:read_meteo_ES: ' ...
                'meteo.data must be 1 (EMO-1) or 2 (ERA5-Land).']);
    end
end

% ==============================================
function j = local_require_var(vn,name,fname)
% ==============================================
    key = lower(regexprep(string(name),'[^a-zA-Z0-9]',''));
    vnl = lower(regexprep(vn,'[^a-zA-Z0-9]',''));
    j = find(vnl == key,1,'first');
    if isempty(j)
        error(['      Error:read_meteo_ES: Missing required ' ...
            'column %s in: %s'],char(name),fname);
    end
end

% ============================================
function j = local_find_var(vn,cands,fallback)
% ============================================
    vnl = lower(regexprep(vn, ...
        '[^a-zA-Z0-9]',''));
    for i = 1:numel(cands)
        c = lower(regexprep(string(cands(i)), ...
            '[^a-zA-Z0-9]',''));
        jj = find(vnl == c,1,'first');
        if ~isempty(jj)
            j = jj;
            return
        end
    end
    for i = 1:numel(cands)
        c = lower(regexprep(string(cands(i)), ...
            '[^a-zA-Z0-9]',''));
        jj = find(contains(vnl,c),1,'first');
        if ~isempty(jj)
            j = jj;
            return
        end
    end
    j = fallback;
end

% =================================
function t = local_parse_es_date(x)
% =================================
    if isdatetime(x)
        t = dateshift(x(:), ...
            'start','day');
        return
    end

    x = string(x(:));
    x = strip(x);
    x = erase(x,'"');

    fmts = {'yyyy-MM-dd','yyyy/MM/dd', ...
        'dd/MM/yyyy','d/MM/yyyy', ...
        'dd/M/yyyy','d/M/yyyy', ...
        'MM/dd/yyyy'};

    for i = 1:numel(fmts)
        try
            t = datetime(x,'InputFormat', ...
                fmts{i});
            if ~any(isnat(t))
                t = dateshift(t,'start','day');
                return
            end
        catch
        end
    end

    t = datetime(x);
    t = dateshift(t,'start','day');
end

% =============================
function x = local_to_double(x)
% =============================
    if isnumeric(x)
        x = double(x(:));
        return
    end
    if iscell(x)
        x = string(x);
    end
    if ischar(x)
        x = string(cellstr(x));
    end
    if isstring(x) ...
            || iscategorical(x)
        xs = string(x(:));
        xs = strip(xs);
        xs = erase(xs,'"');
        xs = strrep(xs,',','.');
        xs = regexprep(xs, ...
            '^(NA|NaN|null|NULL|nan|None|-9999)$', ...
            'NaN','ignorecase');
        xs(xs == "") = "NaN";
        x = str2double(xs);
        return
    end
    error(['      Error:read_meteo_ES: ' ...
        'Unable to convert column to double.']);
end

% ==================================
function id = local_es_id_strings(x)
% ==================================
    x = string(x(:));
    x = strtrim(x);
    x = lower(x);
    x = regexprep(x,'^camelses[_-]*','');
    x = regexprep(x,'\.0+$','');
    x = regexprep(x,'[^0-9]','');

    if any(x == "")
        error(['      Error:read_meteo_ES: ' ...
            'Empty CAMELS-ES basin ID ' ...
            'after normalization.']);
    end
    id = x;
end

% ===============================
function t = local_to_datetime(x)
% ===============================
    if isdatetime(x)
        t = x(1);
    elseif isnumeric(x)
        if numel(x) >= 3
            t = datetime(x(1),x(2),x(3));
        else
            t = datetime(x(1), ...
                'ConvertFrom','datenum');
        end
    else
        x = string(x);
        t = datetime(x(1));
    end
    t = dateshift(t,'start','day');
end

% ========================================
function aux = local_aux_from_bas(bas,aux)
% ========================================

    K = bas.K;

    if isfield(bas,'lat')
        aux(1:K,1) = double(bas.lat(1:K));
    elseif isfield(bas,'gauge_lat')
        aux(1:K,1) = double(bas.gauge_lat(1:K));
    end

    if isfield(bas,'elev')
        aux(1:K,2) = double(bas.elev(1:K));
    elseif isfield(bas,'gauge_elev')
        aux(1:K,2) = double(bas.gauge_elev(1:K));
    elseif isfield(bas,'elv_mean')
        aux(1:K,2) = double(bas.elv_mean(1:K));
    elseif isfield(bas,'ele_mt_sav')
        aux(1:K,2) = double(bas.ele_mt_sav(1:K));
    end

    if isfield(bas,'area')
        a = double(bas.area(1:K));
        if median(a,'omitnan') < 1e7
            a = a * 1e6;
        end
        aux(1:K,3) = a;
    elseif isfield(bas,'area_km2')
        aux(1:K,3) = 1e6 * double(bas.area_km2(1:K));
    end
end

% ============================================================
function aux = local_aux_from_gauge_information(dirES,bas,aux)
% ============================================================

    files = { ...
        fullfile(dirES, ...
        'gauge_information.txt'), ...
        fullfile(dirES, ...
        'attributes_other_camelses.csv')};

    f = '';
    for i = 1:numel(files)
        if isfile(files{i})
            f = files{i};
            break
        end
    end
    if isempty(f)
        return
    end

    opts = detectImportOptions(f, ...
        'FileType','text', ...
        'VariableNamingRule','preserve');
    T = readtable(f,opts);

    vn0 = string(T.Properties.VariableNames);
    vn = lower(regexprep(vn0, ...
        '[^a-zA-Z0-9]',''));

    iID = find(ismember(vn, ...
        ["gaugeid","gageid","id","stationid"]),1);
    if isempty(iID)
        iID = find(contains(vn,"gaugeid") ...
            | contains(vn,"gageid"),1);
    end
    if isempty(iID)
        return
    end

    iLat = find(ismember(vn,["gaugelat", ...
        "lat","latitude"]),1);
    iElev = find(contains(vn,"elev") ...
        | contains(vn,"elv") ...
        | contains(vn,"elemt"),1);
    iArea = find(contains(vn,"area"),1);

    idT = local_es_id_strings(T{:,iID});
    idReq = local_es_id_strings(bas.id_gauge(:));
    [tf,loc] = ismember(idReq,idT);

    if ~any(tf)
        fprintf('\n');
        fprintf(['      Warning:read_meteo_ES: ' ...
            'no selected basin IDs ' ...
            'matched gauge metadata file: %s\n'],f);
        return
    end

    if ~isempty(iLat)
        aux(tf,1) = double(local_to_double(T{loc(tf),iLat}));
    end
    if ~isempty(iElev)
        aux(tf,2) = double(local_to_double(T{loc(tf),iElev}));
    end
    if ~isempty(iArea)
        area = double(local_to_double(T{loc(tf),iArea}));
        if median(area,'omitnan') < 1e7
            area = area * 1e6;
        end
        aux(tf,3) = area;
    end
end
