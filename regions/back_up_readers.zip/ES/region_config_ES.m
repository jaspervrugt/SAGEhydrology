function R = region_config_ES()
%REGION_CONFIG_ES Regional defaults for CAMELS-ES.
%
% All X.paths fields are relative to Data/<R.data_root>.
% Dates use dd/MM/yyyy and water-year boundaries.

    R = struct();
    R.code = 'CAMELS_ES';
    R.acronym = 'ES';
    R.name = 'Spain';
    R.dataset = 'CAMELS-ES';
    R.data_root = 'CAMELS_ES';
    R.resolutions = {'Daily'};
    R.default_resolution = 'Daily';
    R.basin_file_pattern = 'ES_%d_basins.txt';

    X = struct();
    X.label = 'Daily';
    X.dt = 1;
    X.basins.universe = 269;
    X.basins.training = 220;
    X.basins.evaluation = 49;
    X.period.spinup_days = 365;
    X.period.manual.train_start = '01/10/2006';
    X.period.manual.train_end = '30/09/2020';
    X.period.manual.eval_start = '01/10/1992';
    X.period.manual.eval_end = '30/09/2006';
    X.period.common_start = '01/10/1992';
    X.period.common_end = '30/09/2020';
    X.paths.run_root = '';
    X.paths.meteo = fullfile('daily');
    X.paths.discharge = fullfile('daily','timeseries');
    % Meteorological/PET controls shown by SAGE-GUI.
    X.meteo.product.items = { ...
        '1 EMO-1 [daily]', ...
        '2 ERA5-Land [daily]' ...
        };
    X.meteo.product.default = '1 EMO-1 [daily]';
    X.meteo.product.enabled = true;
    X.meteo.precipitation.items = {'1 EMO-1'};
    X.meteo.precipitation.default = '1 EMO-1';
    X.meteo.precipitation.enabled = false;
    X.meteo.temperature.items = {'1 EMO-1'};
    X.meteo.temperature.default = '1 EMO-1';
    X.meteo.temperature.enabled = false;
    X.meteo.pet.items = {'1 EMO-1'};
    X.meteo.pet.default = '1 EMO-1';
    X.meteo.pet.enabled = false;
    X.meteo.linked.source = 'product';
    X.meteo.linked.labels = { ...
        '1 EMO-1', ...
        '2 ERA5-Land' ...
        };
    X.meteo.linked.targets = { ...
        'precipitation', ...
        'temperature', ...
        'pet' ...
        };
    C = repmat(struct('name','','type','','path','','pattern','', ...
        'minimum_count',1,'required',true),0,1);
    C(1).name = 'Meteorological data';
    C(1).type = 'folder';
    C(1).path = fullfile('daily');
    C(1).pattern = '*';
    C(1).minimum_count = 1;
    C(2).name = 'Discharge data';
    C(2).type = 'folder';
    C(2).path = fullfile('daily','timeseries');
    C(2).pattern = '*';
    C(2).minimum_count = 1;
    X.checks = C;
    R.by_resolution.Daily = X;

end