function dat = read_Q_CL(dirQ,mdl,dat,bas,split,aux)  %#ok
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%READ_Q_CL Read CAMELS-CL daily streamflow data for SAGE.
%
% SYNOPSIS:
%   dat = read_Q_CL(dirQ,mdl,dat,bas,split,aux)
%
% INPUT:
%   dirQ        Directory with CAMELS-CL streamflow file, normally
%               Data/CAMELS_CL/daily/streamflow
%   mdl         model/run structure with fields mode, id_train, id_eval
%   dat         Kx1 cell structure to which discharge is added
%   bas         basin structure with fields K, K_t, id_gauge
%   split       time-split structure
%   aux         unused; included for API consistency with read_Q_BR
%
% OUTPUT:
%   dat{k}.y_n       daily discharge depth [mm/day]
%   dat{k}.bad       1xn logical mask for invalid/missing discharge
%   dat{k}.fname{2}  source streamflow file
%   dat{k}.use       'training' or 'evaluation'
%
% DESCRIPTION:
%   CAMELS-CL streamflow is stored in one transposed tab-delimited file:
%
%       3_CAMELScl_streamflow_mm.txt
%
%   The first row contains gauge_id followed by all gauge identifiers.
%   Each subsequent row contains a date in the first column and daily
%   streamflow depth [mm/day] for all gauges in the remaining columns.
%
% NOTES:
%   - Daily data only.
%   - Blank cells, nonnumeric values, nonfinite values, and negative flows
%     are treated as missing/bad.
%   - Values are already in mm/day; no basin-area conversion is applied.
%   - Days outside the available record are padded with NaN and marked bad.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% © Written by Jasper A. Vrugt, May 2026                                  %
% University of California, Irvine                                        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if nargin < 1 ...
        || isempty(dirQ)
    error('read_Q_CL:missingDir', ...
        ['      Error:read_Q_CL: ' ...
        'dirQ must be provided.']);
end

if ~isfolder(dirQ)
    error('read_Q_CL:missingDir', ...
        ['      Error:read_Q_CL: ' ...
        'Streamflow directory ' ...
        'does not exist: %s'],dirQ);
end

if nargin < 5 ...
        || isempty(split)
    error('read_Q_CL:missingSplit', ...
        ['      Error:read_Q_CL: ' ...
        'split structure must be provided.']);
end

if nargin < 6
    aux = []; %#ok
end

split = local_prepare_split(split);

dt = double(split.dt);
if dt ~= 1
    error('read_Q_CL:dailyOnly', ...
        ['      Error:read_Q_CL: ' ...
        'CAMELS-CL streamflow ' ...
        'reader supports daily data only.']);
end

K = bas.K;
K_t = bas.K_t;
id_GAUGE = normalize_cl_id(bas.id_gauge(:));

mode = mdl.mode;
hasEval = ismember(mode,[2 4]);

id_train = expand_index(mdl.id_train);
if hasEval ...
        && isfield(mdl,'id_eval') ...
        && ~isempty(mdl.id_eval)
    id_eval = expand_index(mdl.id_eval);
else
    id_eval = [];
end

req = local_build_requested_window(split);
tRef = datetime(req.read_start_N, ...
    'ConvertFrom','datenum');
tEnd = datetime(req.read_end_N, ...
    'ConvertFrom','datenum');
timeGrid = (tRef:days(1):tEnd).';
nGrid = numel(timeGrid);

fname = fullfile(dirQ, ...
    '3_CAMELScl_streamflow_mm.txt');
if ~isfile(fname)
    error('read_Q_CL:missingFile', ...
        ['      Error:read_Q_CL: ' ...
        'Required streamflow file not found: %s'], ...
        fname);
end

fprintf(['... Reading daily CAMELS-CL ' ...
    'streamflow data ']);

[tFile,idFile,Qfile] = local_read_cl_streamflow_file(fname);

[tfGauge,locGauge] = ismember(id_GAUGE,idFile);
if ~all(tfGauge)
    missing = id_GAUGE(~tfGauge);
    error('read_Q_CL:missingRequestedGauge', ...
        ['      Error:read_Q_CL: ' ...
        'Missing CAMELS-CL streamflow ' ...
        'for %d requested gauge IDs, e.g. %s.'], ...
        numel(missing),char(missing(1)));
end

static_name = fullfile(dirQ, ...
    'CAMELS_CL_discharge_summary_daily.csv');
run_stamp = char(datetime('now', ...
    'Format','yyyyMMdd_HHmmss'));
run_name = fullfile(dirQ, ...
    sprintf('CAMELS_CL_discharge_run_daily_%s.csv',run_stamp));

if hasEval
    Qrun = table('Size',[K 10], ...
        'VariableTypes',{'string', ...
        'string','string','string', ...
        'double','double','string', ...
        'string','double','double'}, ...
        'VariableNames',{'gauge', ...
        'use','start_train','end_train', ...
        'n_train','n_bad_train', ...
        'start_eval','end_eval', ...
        'n_eval','n_bad_eval'});
else
    Qrun = table('Size',[K 6], ...
        'VariableTypes',{'string', ...
        'string','string','string', ...
        'double','double'}, ...
        'VariableNames',{'gauge', ...
        'use','start_train','end_train', ...
        'n_train','n_bad_train'});
end

summaryRows = table('Size',[K 7], ...
    'VariableTypes',{'string', ...
    'string','string', ...
    'double','double', ...
    'double','double'}, ...
    'VariableNames',{'gauge', ...
    'start_record','end_record', ...
    'n_all','n_bad_all', ...
    'n_requested','n_bad_requested'});

fprintf('... %3d%%',0);

for k = 1:K

    gid = id_GAUGE(k);
    jFile = locGauge(k);

    QmmFile = Qfile(:,jFile);
    badFile = ~isfinite(QmmFile) ...
        | QmmFile < 0;

    Qmm = nan(nGrid,1);
    badmask = true(nGrid,1);

    [tf,loc] = ismember(tFile,timeGrid);
    iiFile = find(tf);
    iiGrid = loc(tf);

    Qmm(iiGrid) = QmmFile(iiFile);
    badmask(iiGrid) = badFile(iiFile);
    badmask = badmask ...
        | ~isfinite(Qmm);

    spinup = 0;
    if isfield(split,'spinup') ...
            && ~isempty(split.spinup)
        spinup = max(0,round(double(split.spinup)));
    end
    if spinup > 0
        Qmm = Qmm(spinup+1:end);
        badmask = badmask(spinup+1:end);
    end

    dat{k}.y_n = single(Qmm);
    dat{k}.bad = badmask(:)';
    dat{k}.fname{2} = fname;
    dat{k}.gid = gid;

    if k <= K_t
        dat{k}.use = 'training';
    else
        dat{k}.use = 'evaluation';
    end

    n_train = numel(id_train);
    n_bad_train = sum(badmask(id_train));

    if hasEval
        n_eval = numel(id_eval);
        n_bad_eval = sum(badmask(id_eval));
    else
        n_eval = 0;
        n_bad_eval = 0;
    end

    Qrun.gauge(k) = gid;
    if k <= K_t
        Qrun.use(k) = "training";
    else
        Qrun.use(k) = "evaluation";
    end

    Qrun.start_train(k) = string( ...
        datetime(split.dt_train0, ...
        'ConvertFrom','datenum', ...
        'Format','dd/MM/yyyy'));
    Qrun.end_train(k) = string( ...
        datetime(split.dt_train1, ...
        'ConvertFrom','datenum', ...
        'Format','dd/MM/yyyy'));
    Qrun.n_train(k) = n_train;
    Qrun.n_bad_train(k) = n_bad_train;

    if hasEval
        Qrun.start_eval(k) = string( ...
            datetime(split.dt_eval0, ...
            'ConvertFrom','datenum', ...
            'Format','dd/MM/yyyy'));
        Qrun.end_eval(k) = string( ...
            datetime(split.dt_eval1, ...
            'ConvertFrom','datenum', ...
            'Format','dd/MM/yyyy'));
        Qrun.n_eval(k) = n_eval;
        Qrun.n_bad_eval(k) = n_bad_eval;
    end

    goodRecord = isfinite(QmmFile) ...
        & QmmFile >= 0;
    if any(goodRecord)
        start_record = min(tFile(goodRecord));
        end_record = max(tFile(goodRecord));
        startText = string(datetime(start_record, ...
            'Format','dd/MM/yyyy'));
        endText = string(datetime(end_record, ...
            'Format','dd/MM/yyyy'));
    else
        startText = "";
        endText = "";
    end

    summaryRows.gauge(k) = gid;
    summaryRows.start_record(k) = startText;
    summaryRows.end_record(k) = endText;
    summaryRows.n_all(k) = numel(QmmFile);
    summaryRows.n_bad_all(k) = sum(badFile);
    summaryRows.n_requested(k) = nGrid;
    summaryRows.n_bad_requested(k) = sum(badmask);

    if mod(k,20)==0 ...
            || k==K
        pct = floor(100*k/K);
        fprintf('\b\b\b\b%3d%%',pct);
    end

    % Graphical User Interface   
    if isfield(bas,'progressFcn') ...
            && ~isempty(bas.progressFcn)
        try
            bas.progressFcn(k,K);
        catch
            try
                bas.progressFcn(k);
            catch
            end
        end
    end
end

fprintf('\b\b\b\bDone\n');

try
    writetable(summaryRows,static_name);
catch ME
    warning('read_Q_CL:summaryWriteFailed', ...
        'Could not write CL discharge summary: %s', ...
        ME.message);
end

try
    writetable(Qrun,run_name);
catch ME
    warning('read_Q_CL:runWriteFailed', ...
        'Could not write CL discharge run summary: %s', ...
        ME.message);
end

end

% ==================================================================
function [tFile,idFile,Qfile] = local_read_cl_streamflow_file(fname)
% ==================================================================

L = readlines(fname);
L = string(L);
L(strlength(strtrim(L)) == 0) = [];

if numel(L) < 2
    error('read_Q_CL:emptyFile', ...
        ['      Error:read_Q_CL: ' ...
        'Streamflow file is empty or ' ...
        'does not contain data rows: %s'],fname);
end

header = local_split_tsv_line(L(1));
header = strip(header,'both','"');
header = strtrim(header);

if numel(header) < 2 ...
        || ~strcmpi(header(1),'gauge_id')
    error('read_Q_CL:badHeader', ...
        ['      Error:read_Q_CL: ' ...
        'First row of %s must start ' ...
        'with gauge_id followed by basin IDs.'],fname);
end

idFile = normalize_cl_id(header(2:end));
nt = numel(L) - 1;
K = numel(idFile);

tFile = NaT(nt,1);
Qfile = nan(nt,K);

for i = 1:nt
    parts = local_split_tsv_line(L(i+1));
    parts = strip(parts,'both','"');
    parts = strtrim(parts);

    if isempty(parts) ...
            || strlength(parts(1)) == 0
        error('read_Q_CL:badDateRow', ...
            ['      Error:read_Q_CL: ' ...
            'Missing date in row %d of %s.'], ...
            i+1,fname);
    end

    tFile(i) = local_parse_date(parts(1));

    vals = strings(1,K);
    ncopy = min(K,numel(parts)-1);
    if ncopy > 0
        vals(1:ncopy) = parts(2:(ncopy+1));
    end

    vals = strrep(vals,',','.');
    vals(vals == "" ...
        | vals == "NA" ...
        | vals == "NaN" ...
        | vals == "nan") = missing;
    Qfile(i,:) = str2double(vals);
end

% Remove duplicated dates if present; keep the first occurrence.
[tFile,ia] = unique(tFile,'stable');
Qfile = Qfile(ia,:);

end

% ======================================
function parts = local_split_tsv_line(s)
% ======================================

parts = split(string(s),sprintf('\t')).';

end

% ==============================
function id = normalize_cl_id(x)
% ==============================

id = string(x(:));
id = strip(id,'both','"');
id = strtrim(id);
id = regexprep(id,'\.0+$','');
id(ismissing(id)) = "";

end

% ==============================
function d = local_parse_date(s)
% ==============================

s = strtrim(string(s));
s = strip(s,'both','"');

fmts = {'yyyy-MM-dd','dd/MM/yyyy', ...
    'd/M/yyyy','MM/dd/yyyy','M/d/yyyy'};
for k = 1:numel(fmts)
    try
        d = datetime(s,'InputFormat',fmts{k});
        if ~isnat(d)
            return
        end
    catch
    end
end

try
    d = datetime(s);
catch
    error('read_Q_CL:badDate', ...
        'Could not parse CAMELS-CL date string: %s',char(s));
end

end

% =========================================
function split = local_prepare_split(split)
% =========================================

if ~isfield(split,'dt') ...
        || isempty(split.dt)
    split.dt = 1;
end

names = {'dt_train0','dt_train1', ...
    'dt_eval0','dt_eval1'};
for j = 1:numel(names)
    nm = names{j};
    if isfield(split,nm) && ~isempty(split.(nm))
        split.(nm) = local_to_datenum(split.(nm));
    end
end

if ~isfield(split,'dt_eval0') ...
        || isempty(split.dt_eval0)
    split.dt_eval0 = split.dt_train0;
end
if ~isfield(split,'dt_eval1') ...
        || isempty(split.dt_eval1)
    split.dt_eval1 = split.dt_train1;
end

end

% ================================================
function req = local_build_requested_window(split)
% ================================================

if isfield(split,'read_start_N') ...
        && isfield(split,'read_end_N') ...
        && ~isempty(split.read_start_N) ...
        && ~isempty(split.read_end_N)
    req.read_start_N = local_to_datenum(split.read_start_N);
    req.read_end_N = local_to_datenum(split.read_end_N);
    return
end

starts = [];
ends = [];
if isfield(split,'dt_train0')
    starts(end+1) = split.dt_train0;
end
if isfield(split,'dt_eval0')
    starts(end+1) = split.dt_eval0;
end
if isfield(split,'dt_train1')
    ends(end+1) = split.dt_train1;
end
if isfield(split,'dt_eval1')
    ends(end+1) = split.dt_eval1;
end

if isempty(starts) || isempty(ends)
    error('read_Q_CL:badSplit', ...
        ['      Error:read_Q_CL: ' ...
        'Could not determine requested ' ...
        'date window from split.']);
end

req.read_start_N = min(starts);
req.read_end_N = max(ends);

if isfield(split,'spinup') ...
        && ~isempty(split.spinup)
    spinup = max(0,round(double(split.spinup)));
    req.read_start_N = req.read_start_N - spinup;
end

end

% ===============================
function xN = local_to_datenum(x)
% ===============================

if isdatetime(x)
    d = x(1);

elseif ischar(x) || isstring(x)
    s = strtrim(string(x));
    try
        d = datetime(s,'InputFormat','d/M/yyyy');
    catch
        try
            d = datetime(s,'InputFormat','yyyy-MM-dd');
        catch
            d = datetime(s);
        end
    end

elseif isnumeric(x)

    x = double(x(:).');

    if numel(x) == 3

        if x(1) > 1800
            d = datetime(x(1),x(2),x(3));

        elseif x(3) > 1800
            d = datetime(x(3),x(2),x(1));

        else
            error('read_Q_CL:badDate', ...
                'Cannot determine date-vector order.');
        end

    elseif isscalar(x) ...
            && x > 1e7 ...
            && x < 1e8
        y = floor(x/10000);
        mo = floor((x - 10000*y)/100);
        da = x - 10000*y - 100*mo;
        d = datetime(y,mo,da);

    elseif isscalar(x)
        d = datetime(x,'ConvertFrom','datenum');

    else
        error('read_Q_CL:badDate', ...
            'Unsupported numeric date format.');
    end

else
    error('read_Q_CL:badDate', ...
        'Unsupported date input type.');
end

xN = datenum(d); %#ok<DATNM>

end
