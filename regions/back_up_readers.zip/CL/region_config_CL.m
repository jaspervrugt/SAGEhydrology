function R = region_config_CL()
%REGION_CONFIG_CL Regional defaults for CAMELS-CL.
%
% All X.paths fields are relative to Data/<R.data_root>.
% Dates use dd/MM/yyyy and water-year boundaries.

    R = struct();
    R.code = 'CAMELS_CL';
    R.acronym = 'CL';
    R.name = 'Chile';
    R.dataset = 'CAMELS-CL';
    R.data_root = 'CAMELS_CL';
    R.resolutions = {'Daily'};
    R.default_resolution = 'Daily';
    R.basin_file_pattern = 'CL_%d_basins.txt';

    X = struct();
    X.label = 'Daily';
    X.dt = 1;
    X.basins.universe = 297;
    X.basins.training = 250;
    X.basins.evaluation = 47;
    X.period.spinup_days = 365;
    X.period.manual.train_start = '01/10/2006';
    X.period.manual.train_end = '30/09/2014';
    X.period.manual.eval_start = '01/10/1998';
    X.period.manual.eval_end = '30/09/2006';
    X.period.common_start = '01/10/1998';
    X.period.common_end = '30/09/2014';
    X.paths.run_root = '';
    X.paths.meteo = fullfile('daily');
    X.paths.discharge = fullfile('daily','streamflow');
    % Meteorological/PET controls shown by SAGE-GUI.
    X.meteo.product.items = {'CAMELS-Chile [daily]'};
    X.meteo.product.default = 'CAMELS-Chile [daily]';
    X.meteo.product.enabled = false;
    X.meteo.precipitation.items = { ...
        '1 CR2MET', ...
        '2 CHIRPS', ...
        '3 MSWEP', ...
        '4 TMPA' ...
        };
    X.meteo.precipitation.default = '1 CR2MET';
    X.meteo.precipitation.enabled = true;
    X.meteo.temperature.items = { ...
        '1 CR2MET', ...
        '2 CR2MET (Tmin+Tmax)/2' ...
        };
    X.meteo.temperature.default = '1 CR2MET';
    X.meteo.temperature.enabled = true;
    X.meteo.pet.items = { ...
        '1 Hargreaves', ...
        '2 MODIS 8-day' ...
        };
    X.meteo.pet.default = '1 Hargreaves';
    X.meteo.pet.enabled = true;
    C = repmat(struct('name','','type','','path','','pattern','', ...
        'minimum_count',1,'required',true),0,1);
    C(1).name = 'Precipitation files';
    C(1).type = 'pattern';
    C(1).path = fullfile('daily','precipitation');
    C(1).pattern = '*.txt';
    C(1).minimum_count = 4;
    C(2).name = 'Temperature files';
    C(2).type = 'pattern';
    C(2).path = fullfile('daily','temperature');
    C(2).pattern = '*.txt';
    C(2).minimum_count = 3;
    C(3).name = 'PET files';
    C(3).type = 'pattern';
    C(3).path = fullfile('daily','pet');
    C(3).pattern = '*.txt';
    C(3).minimum_count = 2;
    C(4).name = 'Streamflow files';
    C(4).type = 'pattern';
    C(4).path = fullfile('daily','streamflow');
    C(4).pattern = '*.txt';
    C(4).minimum_count = 1;
    C(5).name = 'SWE files';
    C(5).type = 'pattern';
    C(5).path = fullfile('daily','swe');
    C(5).pattern = '*.txt';
    C(5).minimum_count = 1;
    X.checks = C;
    R.by_resolution.Daily = X;

end