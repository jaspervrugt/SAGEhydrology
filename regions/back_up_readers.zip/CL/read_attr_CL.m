function [A,id_gauge,gname,zone] = read_attr_CL(dirD,bas)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%READ_ATTR_CL Read catchment attributes of CAMELS-CL/CAMELS-Chile dataset.
%
% SYNOPSIS:
%   [A,id_gauge,gname,zone] = read_attr_CL(dirD,bas)
%
% INPUT:
%   dirD        Directory with CAMELS-CL attribute file
%   bas         OPTIONAL: structure with basin and attribute information
%    .id_gauge   OPTIONAL: vector/string/cell array of requested Chile
%                 gauge identifiers
%    .id_attr    rx1 vector of integer attribute IDs
%    .pr_attr    OPTIONAL: print attribute table [1/0]
%
% OUTPUT:
%   A           r x K matrix of standardized selected attributes
%   id_gauge    K x 1 string array with CAMELS-CL gauge identifiers
%   gname       K x 1 string array with standardized gauge names
%   zone        structure with CAMELS-CL basin classification
%    .id            K x 1 string array with zone labels per basin
%    .long          K x 1 string array with descriptive zone labels
%    .num           K x 1 numeric vector with integer zone identifiers
%    .codes         mx1 string array with unique compact zone codes
%    .names         mx1 string array with unique zone names
%    .lat           K x 1 vector with outlet latitude
%    .lon           K x 1 vector with outlet longitude
%    .area          K x 1 vector with catchment area [km^2], if present
%    .aridity       K x 1 vector with aridity index, if present
%    .frac_snow     K x 1 vector with snow fraction, if present
%
% DESCRIPTION:
%   This function reads the CAMELS-CL attribute file
%
%       1_CAMELScl_attributes.txt
%
%   The CAMELS-CL file is transposed relative to many CAMELS datasets:
%
%       rows    = attribute names
%       columns = basins/gauges
%
%   The reader converts this file to an internal table with one row per
%   basin and one variable per attribute. It then follows the same output
%   convention as read_attr_US, read_attr_GB, read_attr_BR, and
%   read_attr_AU.
%
% NOTES:
%   If bas is omitted, a small default attribute set is selected using
%   available basic location, basin-size, topographic, and climate fields.
%   The default selection avoids discharge-derived hydrologic signatures
%   when possible.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% © Written by Jasper A. Vrugt, May 2026                                  %
% University of California, Irvine                                        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    if nargin < 1 ...
            || isempty(dirD)
        error('read_attr_CL:missingDir', ...
            ['      Error:read_attr_CL: ' ...
            'dirD must be provided.']);
    end
    
    if ~isfolder(dirD)
        error('read_attr_CL:missingDir', ...
            ['      Error:read_attr_CL: ' ...
            'Attribute directory ' ...
            'does not exist: %s'],dirD);
    end
    
    if nargin < 2
        bas = struct();
    end
    
    if ~isstruct(bas)
        error('read_attr_CL:badBas', ...
            ['      Error:read_attr_CL: ' ...
            'bas must be a structure.']);
    end
    % =========================================
    % ZONE CONTROL PARAMETERS (GLOBAL DEFAULTS)
    % =========================================
    if ~isfield(bas,'min_per_zone') ...
            || isempty(bas.min_per_zone)
        min_per_zone = 5;
    else
        min_per_zone = bas.min_per_zone;
    end    
    if ~isfield(bas,'max_zones') ...
            || isempty(bas.max_zones)
        max_zones = 8;
    else
        max_zones = bas.max_zones;
    end
    
    pr_table = 1;
    if isfield(bas,'pr_attr') ...
            && ~isempty(bas.pr_attr)
        pr_table = bas.pr_attr;
    end
    
    f_attr = fullfile(dirD, ...
        '1_CAMELScl_attributes.txt');
    caller = mfilename;
    must_exist(f_attr, ...
        '1_CAMELScl_attributes.txt',caller);
    
    fprintf(['... Reading CAMELS-CL ' ...
        'basin attributes ']);
    
    AA = read_cl_transposed_attributes(f_attr);
    
    % -------------------------
    % Required metadata columns
    % -------------------------
    needVars = {'gauge_id','gauge_name', ...
        'gauge_lat','gauge_lon'};
    for j = 1:numel(needVars)
        if ~ismember(needVars{j}, ...
                AA.Properties.VariableNames)
            error('read_attr_CL:missingMetadata', ...
                ['      Error:read_attr_CL: ' ...
                'Attribute table is ' ...
                'missing required variable: %s'], ...
                needVars{j});
        end
    end
    
    id_all = normalize_cl_gauge_id( ...
        AA.gauge_id);
    AA.gauge_id = id_all;
    
    % Sort for reproducibility.
    [~,isrt] = sort(id_all);
    AA = AA(isrt,:);
    id_all = id_all(isrt);
    
    % --------------------------
    % Optional requested stations
    % --------------------------
    if isfield(bas,'id_gauge') ...
            && ~isempty(bas.id_gauge)
        id_req = normalize_cl_gauge_id( ...
            bas.id_gauge(:));
        [tf,locid] = ismember(id_req,id_all);
    
        if ~all(tf)
            missing = id_req(~tf);
            error('read_attr_CL:missingRequestedGauge', ...
                ['      Error:read_attr_CL: ' ...
                'Missing CAMELS-CL ' ...
                'attributes for %d requested ' ...
                'gauge IDs, e.g. %s.'], ...
                numel(missing),char(missing(1)));
        end
    
        AA = AA(locid,:);
        id_gauge = id_req(:);
    else
        id_gauge = id_all(:);
    end
    
    % -----------
    % Gauge names
    % -----------
    gname = string(AA.gauge_name);
    %gname = gname(:);
    gname = standardize_camels_gauge_names( ...
        gname(:),'CAMELS_CL',id_gauge);
    % 
    % try
    %     gname = standardize_camels_gauge_names( ...
    %         gname,'CAMELS_CL');
    % catch
    %     gname = local_standardize_cl_names( ...
    %         gname);
    % end
    
    ensure_cl_gauge_information(dirD,AA);
    
    % --------------------------
    % Zones
    % --------------------------
    
    region = erase(mfilename,'read_attr_');
    zone = classify_camels_all_zones(region,AA, ...
        min_per_zone,max_zones);
    
    % ------------------
    % Generic attributes
    % ------------------
    [A,labels] = build_attr_matrix(AA,bas, ...
        mfilename,pr_table);
    
    if pr_table == 1
        assignin('base', ...
            'SAGE_CL_attribute_labels', ...
            labels);
    end
    
    fprintf(' ... Done\n');

end

% ===============================================
function T = read_cl_transposed_attributes(fname)
% ===============================================
    
    C = readcell(fname, ...
        'FileType','text', ...
        'Delimiter','\t', ...
        'TextType','string');
    
    if isempty(C) ...
            || size(C,2) < 2 ...
            || size(C,1) < 2
        error('read_attr_CL:badFile', ...
            ['      Error:read_attr_CL: ' ...
            'Attribute file is empty ' ...
            'or has unexpected size: %s'],fname);
    end
    
    attr0 = string(C(:,1));
    attr0 = strip(attr0);
    attr0 = erase(attr0,'"');
    
    attrNames = matlab.lang.makeValidName(attr0, ...
        'ReplacementStyle','delete');
    
    % Guarantee unique variable names after makeValidName.
    attrNames = matlab.lang.makeUniqueStrings(attrNames);
    
    K = size(C,2) - 1;
    nA = numel(attrNames);
    
    T = table();
    
    for i = 1:nA
        raw = C(i,2:end).';
        s = string(raw);
        s = strip(s);
        s = erase(s,'"');
        s(ismissing(s)) = "";
    
        x = str2double(s);
    
        % Keep true metadata/date/text rows as strings. Convert rows to numeric
        % only if all nonempty entries are numeric.
        nonempty = strlength(s) > 0;
        if any(nonempty) ...
                && all(isfinite(x(nonempty)))
            T.(attrNames{i}) = x;
        else
            T.(attrNames{i}) = s;
        end
    end
    
    if height(T) ~= K
        error('read_attr_CL:internalSize', ...
            ['      Error:read_attr_CL: ' ...
            'Internal table height mismatch.']);
    end
    
    % Restore expected names if valid-name conversion changed them weirdly.
    T.Properties.VariableNames = attrNames;

end

% ===========================================
function ensure_cl_gauge_information(dirD,AA)
% ===========================================
    
    fout = fullfile(dirD,'gauge_information.txt');
    
    % Always refresh: CAMELS-CL source names are already in the attribute file.
    if isfile(fout)
        try
            delete(fout)
        catch
        end
    end
    
    id = normalize_cl_gauge_id(AA.gauge_id);
    name = string(AA.gauge_name);
    lat = get_numeric_column(AA,"gauge_lat");
    lon = get_numeric_column(AA,"gauge_lon");
    
    fid = fopen(fout,'w');
    if fid < 0
        warning('read_attr_CL:gaugeInformationWriteFailed', ...
            ['      Warning:read_attr_CL: ' ...
            'Could not write ' ...
            'gauge_information.txt to %s'],dirD);
        return
    end
    
    cleanup = onCleanup(@() fclose(fid));
    
    fprintf(fid,['gauge_id;gauge_name;' ...
        'gauge_lat;gauge_lon\n']);
    for k = 1:numel(id)
        fprintf(fid,'%s;%s;%.8f;%.8f\n', ...
            char(id(k)),char(name(k)), ...
            lat(k),lon(k));
    end

end

% ====================================
function id = normalize_cl_gauge_id(x)
% ====================================

    if isnumeric(x) || islogical(x)
        id = string(compose('%.0f', ...
            double(x(:))));
    else
        id = string(x(:));
        id = strip(id);
        id = erase(id,'"');
        id(ismissing(id)) = "";
        id = regexprep(id,'\.0+$','');
    end

end
