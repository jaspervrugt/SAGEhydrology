function [dat,aux] = read_meteo_CL(dirM,bas,split,meteo)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%READ_METEO_CL Read CAMELS-Chile daily meteorological data for SAGE.
%
% SYNOPSIS:
%   [dat,aux] = read_meteo_CL(dirM,bas,split,meteo)
%
% INPUT:
%   dirM        CAMELS-Chile data directory, normally .../Data/CAMELS_CL
%   bas         basin structure with fields
%    .K          number of selected basins
%    .id_gauge   Kx1 gauge identifiers in final basin order
%   split       SAGE split structure. Supports daily dt = 1 only.
%               Uses spin-up-aware requested window from ds/de or dts/dte.
%   meteo       options structure
%    .data       precipitation source:
%                 1 4_CAMELScl_precip_cr2met.txt [default]
%                 2 5_CAMELScl_precip_chirps.txt
%                 3 6_CAMELScl_precip_mswep.txt
%                 4 7_CAMELScl_precip_tmpa.txt
%    .pet        PET source:
%                 1 12_CAMELScl_pet_hargreaves.txt [default]
%                 2 11_CAMELScl_pet_8d_modis.txt
%    .temp       temperature source:
%                 1 10_CAMELScl_tmean_cr2met.txt [default]
%                 2 0.5*(8_CAMELScl_tmin_cr2met + 9_CAMELScl_tmax_cr2met)
%    .progressFcn OPTIONAL function handle called progressFcn(k)
%
% OUTPUT:
%   dat         Kx1 cell array.
%    {k}.meteo.P    nx1 precipitation vector [mm/day]
%    {k}.meteo.Ep   nx1 PET vector [mm/day]
%    {k}.meteo.T    nx1 mean air temperature vector [deg C]
%    {k}.meteo.bad  row vector of indices with invalid meteo values
%    {k}.gauge      gauge ID
%    {k}.fname      source/cache files
%   aux         Kx3 matrix [lat,elev,area_m2] if metadata are available.
%
% NOTES:
%   CAMELS-Chile stores all basins in one tab-delimited text file per
%   variable. The first row contains gauge_id & basin IDs. Subsequent rows
%   contain date in the first column and one value per basin.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% © Written by Jasper A. Vrugt / ChatGPT, May 2026                        %
% University of California, Irvine                                        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    if nargin < 1 ...
            || isempty(dirM)
        error('read_meteo_CL:missingDir', ...
            ['      Error:read_meteo_CL: ' ...
            'dirM must be provided.']);
    end
    if ~isfolder(dirM)
        error('read_meteo_CL:missingDir', ...
            ['      Error:read_meteo_CL: ' ...
            'Directory does not exist: %s'], ...
            dirM);
    end
    if nargin < 2 ...
            || ~isstruct(bas) ...
            || ~isfield(bas,'id_gauge')
        error('read_meteo_CL:missingBasins', ...
            ['      Error:read_meteo_CL: ' ...
            'bas.id_gauge must be provided.']);
    end
    if nargin < 3 ...
            || isempty(split)
        error('read_meteo_CL:missingSplit', ...
            ['      Error:read_meteo_CL: ' ...
            'split must be provided.']);
    end
    if nargin < 4 ...
        || isempty(meteo)
        meteo = struct();
    end
    
    split = prepare_split_CL(split);
    dt = double(split.dt);
    if dt ~= 1
        error('read_meteo_CL:dailyOnly', ...
            ['      Error:read_meteo_CL: ' ...
            'CAMELS-Chile currently ' ...
            'supports daily data only.']);
    end
    
    id_gauge = clean_station_id_CL( ...
        string(bas.id_gauge(:)));
    K = numel(id_gauge);
    if isfield(bas,'K') ...
            && ~isempty(bas.K)
        K = double(bas.K);
        id_gauge = id_gauge(1:K);
    end
    
    [p_file,~,~] = ...
        precipitation_source_CL(meteo);
    [pet_file,~,~] = ...
        pet_source_CL(meteo);
    [tempMode,tmean_file,tmin_file,tmax_file,~] = ...
        temperature_source_CL(meteo);
    
    req = build_requested_window_CL(split,true);
    
    precDir = fullfile(local_cl_daily_root(dirM),'precipitation');
    tempDir = fullfile(local_cl_daily_root(dirM),'temperature');
    petDir = fullfile(local_cl_daily_root(dirM),'pet');
    
    if ~isfolder(precDir)
        error('read_meteo_CL:missingPrecipDir', ...
            ['      Error:read_meteo_CL: ' ...
            'Missing folder: %s'],precDir);
    end
    if ~isfolder(tempDir)
        error('read_meteo_CL:missingTempDir', ...
            ['      Error:read_meteo_CL: ' ...
            'Missing folder: %s'],tempDir);
    end
    if ~isfolder(petDir)
        error('read_meteo_CL:missingPETDir', ...
            ['      Error:read_meteo_CL: ' ...
            'Missing folder: %s'],petDir);
    end
    
    fP = fullfile(precDir,p_file);
    fE = fullfile(petDir,pet_file);
    must_exist_CL(fP);
    must_exist_CL(fE);
    
    if tempMode == 1
        fT = fullfile(tempDir,tmean_file);
        must_exist_CL(fT);
    else
        fTmin = fullfile(tempDir,tmin_file);
        fTmax = fullfile(tempDir,tmax_file);
        must_exist_CL(fTmin);
        must_exist_CL(fTmax);
    end
    
    dailyCL = local_cl_daily_root(dirM);
    cacheDir = fullfile(dailyCL, ...
        'timeseries_cache');
    if ~isfolder(cacheDir)
        mkdir(cacheDir);
    end
    
    % fprintf(['... Reading CAMELS-Chile ' ...
    %     'daily meteorological data ' ...
    %     'P=%s, PET=%s, T=%s ... %3d%%'], ...
    %     p_label,pet_label,t_label,0);
    
    fprintf(['... Reading daily CAMELS-Chile ' ...
        'meteorological data files %3d%%'],0);
    flag_progress = true;
    
    CP = load_wide_cache_CL(fP, ...
        cacheDir,'P');
    CE = load_wide_cache_CL(fE, ...
        cacheDir,'Ep');
    if tempMode == 1
        CT = load_wide_cache_CL(fT, ...
            cacheDir,'Tmean');
    else
        CTn = load_wide_cache_CL(fTmin, ...
            cacheDir,'Tmin');
        CTx = load_wide_cache_CL(fTmax, ...
            cacheDir,'Tmax');
    end
    
    if tempMode == 1
        fileStartDT = max([CP.fileStartDT, ...
            CE.fileStartDT, ...
            CT.fileStartDT]);
        fileEndDT = min([CP.fileEndDT, ...
            CE.fileEndDT, ...
            CT.fileEndDT]);
    else
        fileStartDT = max([CP.fileStartDT, ...
            CE.fileStartDT, ...
            CTn.fileStartDT, ...
            CTx.fileStartDT]);
        fileEndDT = min([CP.fileEndDT, ...
            CE.fileEndDT, ...
            CTn.fileEndDT, ...
            CTx.fileEndDT]);
    end
    
    if fileEndDT < fileStartDT
        if flag_progress
            fprintf('\n');
        end
        error('read_meteo_CL:noOverlap', ...
            ['      Error:read_meteo_CL: ' ...
            'selected meteo files ' ...
            'do not overlap in time.']);
    end
    
    fileStartN = int64(datenum(fileStartDT)); %#ok<DATNM>
    fileEndN = int64(datenum(fileEndDT));     %#ok<DATNM>
    
    if req.read_start_N < fileStartN ...
            || req.read_end_N > fileEndN
        if flag_progress
            fprintf('\n');
        end
        error(['      Error:read_meteo_CL: ' ...
            'requested period outside ' ...
            'CAMELS-Chile meteo files.\nFile ' ...
            'overlap covers %s to %s.'], ...
            string(fileStartDT),string(fileEndDT));
    end
    
    idxP = local_row_index_CL(req,CP.fileStartN);
    idxE = local_row_index_CL(req,CE.fileStartN);
    if tempMode == 1
        idxT = local_row_index_CL(req,CT.fileStartN);
    else
        idxTn = local_row_index_CL( ...
            req,CTn.fileStartN);
        idxTx = local_row_index_CL( ...
            req,CTx.fileStartN);
    end
    
    [~,colP] = match_station_columns_CL( ...
        id_gauge,CP.ids,'precipitation');
    [~,colE] = match_station_columns_CL( ...
        id_gauge,CE.ids,'PET');
    if tempMode == 1
        [~,colT] = match_station_columns_CL( ...
            id_gauge,CT.ids, ...
            'temperature mean');
    else
        [~,colTn] = match_station_columns_CL( ...
            id_gauge,CTn.ids, ...
            'temperature minimum');
        [~,colTx] = match_station_columns_CL( ...
            id_gauge,CTx.ids, ...
            'temperature maximum');
    end
    
    dat = cell(K,1);
    aux = read_aux_CL(dirM,id_gauge);
    
    for k = 1:K
        P = single(CP.X(idxP,colP(k)));
        Ep = single(CE.X(idxE,colE(k)));
    
        if tempMode == 1
            T = single(CT.X(idxT,colT(k)));
            fnameList = {CP.cacheFile, ...
                CE.cacheFile,CT.cacheFile};
        else
            Tn = single(CTn.X(idxTn,colTn(k)));
            Tx = single(CTx.X(idxTx,colTx(k)));
            T = single(0.5*(double(Tn) + double(Tx)));
            fnameList = {CP.cacheFile,CE.cacheFile, ...
                CTn.cacheFile,CTx.cacheFile};
        end
    
        bad = find(~isfinite(P) ...
            | ~isfinite(Ep) ...
            | ~isfinite(T) ...
            | P < 0 ...
            | Ep < 0);
    
        dat{k}.meteo.P = P(:);
        dat{k}.meteo.Ep = Ep(:);
        dat{k}.meteo.T = T(:);
        dat{k}.meteo.bad = bad(:)';
        dat{k}.gauge = char(id_gauge(k));
        dat{k}.fname = fnameList;
    
        if mod(k,5) == 0 ...
                || k == K
            pct = floor(100*k/K);
            fprintf('\b\b\b\b%3d%%',pct);
            drawnow;
        end
    
        if nargin >= 4 ...
                && isstruct(meteo) ...
                && isfield(meteo,'progressFcn') ...
                && ~isempty(meteo.progressFcn)
            meteo.progressFcn(k);
        end
    end
    
    fprintf('\b\b\b\b%s\n','... Done');
    
    if isfield(split,'local') ...
            && split.local ...
            && isfield(split,'rainfall_block') ...
            && split.rainfall_block
        dat = rainfall_rank_split(dat,split);
    end

end

% =================================================
function C = load_wide_cache_CL(fname,cacheDir,tag)
% =================================================

    [~,base,~] = fileparts(fname);
    cacheFile = fullfile(cacheDir, ...
        sprintf('%s_%s_cache.mat', ...
        base,tag));
    
    srcInfo = dir(fname);
    srcBytes = srcInfo.bytes;
    srcDatenum = srcInfo.datenum;
    
    if isfile(cacheFile)
        try
            C = load(cacheFile,'X','ids','time', ...
                'fileStartDT','fileEndDT', ...
                'fileStartN','fileEndN', ...
                'sourceFile','sourceBytes', ...
                'sourceDatenum','cacheFile');
            if isfield(C,'sourceBytes') ...
                    && C.sourceBytes == srcBytes ...
                    && isfield(C,'sourceDatenum') ...
                    && abs(C.sourceDatenum - srcDatenum) < 1e-8
                C.cacheFile = cacheFile;
                return
            end
        catch
        end
    end
    
    fid = fopen(fname,'r');
    if fid < 0
        error('read_meteo_CL:cannotOpen', ...
            'Cannot open file: %s',fname);
    end
    cleaner = onCleanup(@() fclose(fid));
    
    hdr = fgetl(fid);
    if ~ischar(hdr)
        error('read_meteo_CL:emptyFile', ...
            'Empty file: %s',fname);
    end
    idsRaw = parse_tab_line_CL(hdr);
    if numel(idsRaw) < 2
        error('read_meteo_CL:badHeader', ...
            ['Header line in %s has ' ...
            'fewer than two columns.'],fname);
    end
    ids = clean_station_id_CL(idsRaw(2:end));
    
    % Preallocate approximately from line count if possible.
    D = dir(fname);
    roughN = max(1000, ...
        round(double(D.bytes)/ ...
        max(1,numel(hdr))/2));
    time = NaT(roughN,1);
    X = nan(roughN,numel(ids),'single');
    
    n = 0;
    while true
        ln = fgetl(fid);
        if ~ischar(ln)
            break
        end
        if isempty(strtrim(ln))
            continue
        end
    
        parts = parse_tab_line_CL(ln);
        if numel(parts) < 1
            continue
        end
    
        n = n + 1;
        if n > numel(time)
            time(end+roughN,1) = NaT; 
            X(end+roughN,size(X,2)) = single(NaN); 
        end
    
        time(n) = parse_date_CL(parts(1));
        vals = nan(1,numel(ids));
        nv = min(numel(ids),numel(parts)-1);
        if nv > 0
            vals(1:nv) = str2double( ...
                strtrim(parts(2:(nv+1))));
        end
        vals(vals <= -99 ...
            | abs(vals + 99.99) < 1e-8) = NaN;
        X(n,:) = single(vals);
    end
    
    time = time(1:n);
    X = X(1:n,:);
    
    if isempty(time) ...
            || all(isnat(time))
        error('read_meteo_CL:noDates', ...
            'No valid dates found in %s.',fname);
    end
    
    [time,ord] = sort(time);
    X = X(ord,:);
    
    fileStartDT = min(time);
    fileEndDT = max(time);
    fileStartN = int64(datenum(fileStartDT)); %#ok<DATNM>
    fileEndN = int64(datenum(fileEndDT));     %#ok<DATNM>
    sourceFile = fname;
    sourceBytes = srcBytes;
    sourceDatenum = srcDatenum;
    
    save(cacheFile,'X','ids','time', ...
        'fileStartDT','fileEndDT', ...
        'fileStartN','fileEndN', ...
        'sourceFile','sourceBytes', ...
        'sourceDatenum','cacheFile','-v7.3');
    
    C = struct();
    C.X = X;
    C.ids = ids;
    C.time = time;
    C.fileStartDT = fileStartDT;
    C.fileEndDT = fileEndDT;
    C.fileStartN = fileStartN;
    C.fileEndN = fileEndN;
    C.sourceFile = sourceFile;
    C.sourceBytes = sourceBytes;
    C.sourceDatenum = sourceDatenum;
    C.cacheFile = cacheFile;

end

% ===============================================
function idx = local_row_index_CL(req,fileStartN)
% ===============================================

    id0 = double(req.read_start_N - fileStartN) + 1;
    id1 = double(req.read_end_N - fileStartN) + 1;
    idx = id0:id1;

end

% ===============================================================
function [tf,loc] = match_station_columns_CL(reqIDs,fileIDs,kind)
% ===============================================================

    reqIDs = clean_station_id_CL(reqIDs(:));
    fileIDs = clean_station_id_CL(fileIDs(:));
    [tf,loc] = ismember(reqIDs,fileIDs);
    if ~all(tf)
        missing = reqIDs(~tf);
        error('read_meteo_CL:missingStation', ...
            ['      Error:read_meteo_CL: ' ...
            'Missing %s columns for %d ' ...
            'requested gauges, e.g. %s.'], ...
            kind,numel(missing),char(missing(1)));
    end

end

% =================================
function s = clean_station_id_CL(s)
% =================================

    s = string(s);
    s = strtrim(s);
    s = erase(s,'"');
    s = regexprep(s,'\.0+$','');
    s = regexprep(s,'\s+','');

end

% ===========================================================
function dailyCL = local_cl_daily_root(dirM)
    p = char(string(dirM));
    [parent,nm] = fileparts(p);
    if strcmpi(nm,'daily')
        dailyCL = p;
    elseif any(strcmpi(nm,{'streamflow','precipitation','temperature', ...
            'pet','swe'}))
        [~,nmParent] = fileparts(parent);
        if strcmpi(nmParent,'daily')
            dailyCL = parent;
        else
            dailyCL = fullfile(p,'daily');
        end
    else
        dailyCL = fullfile(p,'daily');
    end
end

function [fileName,id,label] = precipitation_source_CL(meteo)
% ===========================================================

    id = 1;
    if isfield(meteo,'data') ...
            && ~isempty(meteo.data)
        id = double(meteo.data);
    end
    
    switch id
        case 1
            fileName = '4_CAMELScl_precip_cr2met.txt';
            label = 'CR2MET';
        case 2
            fileName = '5_CAMELScl_precip_chirps.txt';
            label = 'CHIRPS';
        case 3
            fileName = '6_CAMELScl_precip_mswep.txt';
            label = 'MSWEP';
        case 4
            fileName = '7_CAMELScl_precip_tmpa.txt';
            label = 'TMPA';
        otherwise
            error('read_meteo_CL:badPrecipSource', ...
                ['      Error:read_meteo_CL: ' ...
                'meteo.data must be ' ...
                '1=CR2MET, 2=CHIRPS, ' ...
                '3=MSWEP, or 4=TMPA.']);
    end

end

% =================================================
function [fileName,id,label] = pet_source_CL(meteo)
% =================================================

    id = 1;
    if isfield(meteo,'pet') ...
            && ~isempty(meteo.pet)
        id = double(meteo.pet);
    end
    
    switch id
        case 1
            fileName = '12_CAMELScl_pet_hargreaves.txt';
            label = 'Hargreaves';
        case 2
            fileName = '11_CAMELScl_pet_8d_modis.txt';
            label = 'MODIS 8-day';
        otherwise
            error('read_meteo_CL:badPETSource', ...
                ['      Error:read_meteo_CL: ' ...
                'meteo.pet must be ' ...
                '1=Hargreaves or 2=MODIS 8-day.']);
    end

end

% =====================================================
function [mode,tmeanFile,tminFile,tmaxFile,label] = ...
    temperature_source_CL(meteo)
% =====================================================

    mode = 1;
    if isfield(meteo,'temp') ...
            && ~isempty(meteo.temp)
        mode = double(meteo.temp);
    end
    
    tmeanFile = '10_CAMELScl_tmean_cr2met.txt';
    tminFile = '8_CAMELScl_tmin_cr2met.txt';
    tmaxFile = '9_CAMELScl_tmax_cr2met.txt';
    
    switch mode
        case 1
            label = 'CR2MET mean temperature';
        case 2
            label = ['CR2MET mean of minimum ' ...
                'and maximum temperature'];
        otherwise
            error('read_meteo_CL:badTempSource', ...
                ['      Error:read_meteo_CL: ' ...
                'meteo.temp must be ' ...
                '1=Tmean or 2=0.5*(Tmin+Tmax).']);
    end

end

% ======================================
function split = prepare_split_CL(split)
% ======================================

    if ~isfield(split,'dt') ...
            || isempty(split.dt)
        split.dt = 1;
    end
    if ~isfield(split,'spinup') ...
            || isempty(split.spinup)
        split.spinup = 0;
    end

end

% ===========================================================
function req = build_requested_window_CL(split,includeSpinup)
% ===========================================================

    if nargin < 2
        includeSpinup = true;
    end
    
    spinup = max(0, ...
        round(double(split.spinup)));
    
    if isfield(split,'ds') ...
            && isfield(split,'de') ...
            && ~isempty(split.ds) ...
            && ~isempty(split.de)
        d0 = as_datetime_CL(split.ds);
        d1 = as_datetime_CL(split.de);
    
    elseif isfield(split,'dts') ...
            && isfield(split,'dte') ...
            && ~isempty(split.dts) ...
            && ~isempty(split.dte)
        d0 = as_datetime_CL(split.dts);
        d1 = as_datetime_CL(split.dte);
    
        if isfield(split,'des') ...
                && isfield(split,'dee') ...
                && ~isempty(split.des) ...
                && ~isempty(split.dee)
            d0 = min(d0,as_datetime_CL(split.des));
            d1 = max(d1,as_datetime_CL(split.dee));
        end
    
    elseif isfield(split,'d1') ...
            && isfield(split,'d2')
        d0 = as_datetime_CL(split.d1);
        d1 = as_datetime_CL(split.d2);
    
    else
        error('read_meteo_CL:badSplit', ...
            ['      Error:read_meteo_CL: ' ...
            'Could not determine ' ...
            'requested dates from split.']);
    end
    
    if includeSpinup
        d0 = d0 - days(spinup);
    end
    
    req.read_start_DT = d0;
    req.read_end_DT = d1;
    req.read_start_N = int64(datenum(d0)); %#ok<DATNM>
    req.read_end_N = int64(datenum(d1));   %#ok<DATNM>

end

% ============================
function d = as_datetime_CL(x)
% ============================

    if isdatetime(x)
        d = x(1);
    elseif isnumeric(x)
        x = double(x(:).');
        if numel(x) == 3
            if x(1) > 1800
                d = datetime(x(1),x(2),x(3));
            elseif x(3) > 1800
                d = datetime(x(3),x(2),x(1));
            else
                error('read_meteo_CL:badDate', ...
                    ['Cannot determine ' ...
                    'date-vector order.']);
            end
        elseif isscalar(x) ...
                && x > 1e7 ...
                && x < 1e8
            y = floor(x/10000);
            mo = floor((x - 10000*y)/100);
            da = x - 10000*y - 100*mo;
            d = datetime(y,mo,da);
        elseif isscalar(x)
            d = datetime(x, ...
                'ConvertFrom','datenum');
        else
            error('read_meteo_CL:badDate', ...
                ['Unsupported numeric ' ...
                'date format.']);
        end
    elseif ischar(x) ...
            || isstring(x)
        d = parse_date_CL(string(x));
    else
        error('read_meteo_CL:badDate', ...
            ['Unsupported date ' ...
            'input type.']);
    end

end

% ===========================
function d = parse_date_CL(s)
% ===========================

    s = strtrim(erase(string(s),'"'));
    try
        d = datetime(s, ...
            'InputFormat', ...
            'yyyy-MM-dd');
    catch
        try
            d = datetime(s, ...
                'InputFormat', ...
                'd/M/yyyy');
        catch
            try
                d = datetime(s, ...
                    'InputFormat', ...
                    'dd/MM/yyyy');
            catch
                d = datetime(s);
            end
        end
    end
    d = d(1);

end

% =======================================
function aux = read_aux_CL(dirM,id_gauge)
% =======================================

    K = numel(id_gauge);
    aux = nan(K,3);
    
    dirD = dirM;
    candidates = { ...
        fullfile(dirD, ...
        'gauge_information.txt'), ...
        fullfile(dirD, ...
        '1_CAMELScl_attributes.txt'), ...
        fullfile(fileparts(dirD), ...
        'CAMELS_CL','gauge_information.txt'), ...
        fullfile(fileparts(dirD), ...
        'CAMELS_CL','1_CAMELScl_attributes.txt')};
    
    fname = '';
    for i = 1:numel(candidates)
        if isfile(candidates{i})
            fname = candidates{i};
            break
        end
    end
    if isempty(fname)
        return
    end
    
    try
        if endsWith(lower(fname), ...
                '1_camelscl_attributes.txt')
            T = read_cl_attribute_table_for_aux(fname);
        else
            opts = detectImportOptions(fname, ...
                'FileType','text', ...
                'VariableNamingRule', ...
                'preserve');
            T = readtable(fname,opts);
            T.Properties.VariableNames = ...
                matlab.lang.makeValidName( ...
                T.Properties.VariableNames, ...
                'ReplacementStyle','delete');
        end
    
        valid = string(T.Properties.VariableNames);
        idVar = find_var_CL(valid, ...
            {'gauge_id','gaugeid','id'});
        latVar = find_var_CL(valid, ...
            {'gauge_lat','lat','latitude'});
        elevVar = find_var_CL(valid, ...
            {'elev_mean','elevation', ...
            'elev_gauge','elev'});
        areaVar = find_var_CL(valid, ...
            {'area','catchment_area', ...
            'area_km2','drainage_area'});
    
        if isempty(idVar)
            return
        end
    
        ids = clean_station_id_CL(string(T.(idVar)));
        req = clean_station_id_CL(id_gauge);
        [tf,loc] = ismember(req,ids);
    
        for k = 1:K
            if ~tf(k)
                continue
            end
            j = loc(k);
            if ~isempty(latVar)
                aux(k,1) = double(T.(latVar)(j));
            end
            if ~isempty(elevVar)
                aux(k,2) = double(T.(elevVar)(j));
            end
            if ~isempty(areaVar)
                area_km2 = double(T.(areaVar)(j));
                aux(k,3) = area_km2 * 1e6;
            end
        end
    catch
        aux = nan(K,3);
    end

end

% =================================================
function T = read_cl_attribute_table_for_aux(fname)
% =================================================

    L = readlines(fname);
    L = L(strlength(strtrim(L)) > 0);
    if isempty(L)
        T = table();
        return
    end
    
    H = parse_tab_line_CL(L(1));
    ids = clean_station_id_CL(H(2:end));
    K = numel(ids);
    T = table(ids(:),'VariableNames', ...
        {'gauge_id'});
    
    wanted = {'gauge_lat','gauge_lon', ...
        'elev_mean','elev_gauge','area'};
    for r = 2:numel(L)
        parts = parse_tab_line_CL(L(r));
        if isempty(parts)
            continue
        end
        nm = matlab.lang.makeValidName( ...
            char(strtrim(parts(1))), ...
            'ReplacementStyle','delete');
        if ~any(strcmp(nm,wanted))
            continue
        end
        vals = nan(K,1);
        nv = min(K,numel(parts)-1);
        if nv > 0
            vals(1:nv) = str2double( ...
                parts(2:(nv+1)));
        end
        T.(nm) = vals;
    end

end

% =============================================
function v = find_var_CL(validNames,candidates)
% =============================================

    v = '';
    validLower = lower(string(validNames));
    for i = 1:numel(candidates)
        c = lower(string(matlab.lang.makeValidName( ...
            candidates{i}, ...
            'ReplacementStyle', ...
            'delete')));
        j = find(validLower == c,1);
        if ~isempty(j)
            v = char(validNames(j));
            return
        end
    end

end

% ====================================
function parts = parse_tab_line_CL(ln)
% ====================================

    parts = string(strsplit( ...
        char(ln),sprintf('\t')));
    parts = strtrim(parts);
    parts = erase(parts,'"');

end

% ===========================
function must_exist_CL(fname)
% ===========================

    if ~isfile(fname)
        error('read_meteo_CL:missingFile', ...
            ['      Error:read_meteo_CL: ' ...
            'Required file ' ...
            'not found: %s'],fname);
    end

end
