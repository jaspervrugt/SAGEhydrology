function [dat,aux] = read_meteo_PL(dirM,bas,split,meteo)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%READ_METEO_PL Read CAMELS-PL daily hydrometeorological data for SAGE.
%
% Expected folder:
%   Data/CAMELS_PL/daily/timeseries/CAMELS_PL_hydromet_timeseries_<gauge_id>.csv
%
% Expected file columns:
%   date
%   discharge_vol_obs              [m3/s]
%   discharge_spec_obs             [mm/day]
%   water_level_obs                [cm]
%   precipitation_mean             [mm/day]
%   temperature_mean               [deg C]
%   maximum_temperature_mean       [deg C]
%   minimum_temperature_mean       [deg C]
%   wind_speed_mean                [m/s]
%   relative_humidity_mean         [%]
%   radiation_global_mean          [W/m2]
%
% Potential evapotranspiration is not distributed as a direct column in the
% CAMELS-PL hydromet files. This reader estimates daily Ep with the
% Hargreaves equation using Tmin, Tmax, Tmean, day of year, and gauge
% latitude. This mirrors the CAMELS-PL HBV benchmark description.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    if nargin < 4
        meteo = struct();
    end
    if nargin < 3
        error(['      Error:read_meteo_PL: ' ...
            'Expected input signature ' ...
            '[dat,aux] = read_meteo_PL(' ...
            'dirM,bas,split,meteo).']);
    end
    if nargin < 1 ...
            || isempty(dirM)
        error(['      Error:read_meteo_PL: ' ...
            'dirM must be provided.']);
    end

    split = local_prepare_split(split);

    if double(split.dt) ~= 1
        error(['      Error:read_meteo_PL: ' ...
            'CAMELS-PL ' ...
            'hydrometeorological ' ...
            'data are daily only.']);
    end

    K = bas.K;
    id_GAUGE = local_pl_id_strings(bas.id_gauge(:));

    dirTs = local_pl_timeseries_dir(dirM);
    dirPL = local_pl_root_from_timeseries(dirTs);

    dat = cell(K,1);
    aux = nan(K,3);

    try
        aux = local_aux_from_bas(bas,aux);
    catch
    end
    try
        aux = local_aux_from_gauge_information( ...
            dirPL,bas,aux);
    catch MEaux
        fprintf('\n');
        fprintf(['      Warning:read_meteo_PL: ' ...
            'could not read ' ...
            'Poland gauge information ' ...
            'for aux fields.\n']);
        fprintf('      Cause: %s\n', ...
            MEaux.message);
    end

    req = local_requested_daily_window(split);
    tReq = dateshift(datetime(req.time(:)),'start','day');
    nReq = numel(tReq);

    if nReq == 0
        error(['      Error:read_meteo_PL: ' ...
            'requested daily time ' ...
            'window is empty. Check ' ...
            'split dates and spin-up.']);
    end

    if isfield(split,'idx') ...
            && ~isempty(split.idx)
        idx_score = double(split.idx(:));
    else
        idx_score = (1:nReq).';
    end
    idx_score = idx_score(isfinite(idx_score) ...
        & idx_score >= 1 ...
        & idx_score <= nReq);
    idx_score = round(idx_score(:));

    if isempty(idx_score)
        error(['      Error:read_meteo_PL: ' ...
            'scored-period index ' ...
            'split.idx is empty or outside ' ...
            'the requested read window.']);
    end

    cache_dir = fullfile(dirTs,'_cache_PL_daily_meteo');
    if ~isfolder(cache_dir)
        mkdir(cache_dir);
    end

    fprintf(['... Reading daily CAMELS-PL ' ...
        'meteorological data files %3d%%'],0);
    flag_progress = true;

    for k = 1:K

        gid = id_GAUGE(k);
        fname = fullfile(dirTs, ...
            sprintf('CAMELS_PL_hydromet_timeseries_%s.csv',gid));

        if ~isfile(fname)
            fprintf('\n');
            error(['      Error:read_meteo_PL: ' ...
                'Missing hydrometeorological ' ...
                'file for basin %s: %s'],gid,fname);
        end

        win_key = sprintf('%s_%s', ...
            char(tReq(1),'yyyyMMdd'), ...
            char(tReq(end),'yyyyMMdd'));
        cache_file = fullfile(cache_dir, ...
            sprintf('%s_PL_daily_meteo_%s.mat', ...
            gid,win_key));

        use_cache = false;
        if isfile(cache_file)
            try
                S = load(cache_file, ...
                    'P','Ep','Tmean','Tmin','Tmax','Qmm', ...
                    'Qcms','badrows','src_datenum');
                info = dir(fname);
                if isfield(S,'src_datenum') ...
                        && S.src_datenum >= info.datenum
                    P = S.P;
                    Ep = S.Ep;
                    Tmean = S.Tmean;
                    Tmin = S.Tmin;
                    Tmax = S.Tmax;
                    Qmm = S.Qmm;
                    Qcms = S.Qcms;
                    badrows = S.badrows;
                    use_cache = true;
                end
            catch
                use_cache = false;
            end
        end

        if ~use_cache
            [tFile,Pfile,TmeanFile,TminFile, ...
                TmaxFile,QmmFile,QcmsFile] = ...
                local_read_pl_hydromet_file(fname);

            P = nan(nReq,1);
            Tmean = nan(nReq,1);
            Tmin = nan(nReq,1);
            Tmax = nan(nReq,1);
            Qmm = nan(nReq,1);
            Qcms = nan(nReq,1);

            [tf,loc] = ismember(tReq,tFile);
            P(tf) = Pfile(loc(tf));
            Tmean(tf) = TmeanFile(loc(tf));
            Tmin(tf) = TminFile(loc(tf));
            Tmax(tf) = TmaxFile(loc(tf));
            Qmm(tf) = QmmFile(loc(tf));
            Qcms(tf) = QcmsFile(loc(tf));

            if all(~isfinite(Tmean)) ...
                    && any(isfinite(Tmin) ...
                    & isfinite(Tmax))
                Tmean = 0.5*(Tmin + Tmax);
            end

            lat = aux(k,1);
            Ep = local_hargreaves_ep(tReq, ...
                Tmean,Tmin,Tmax,lat);
            Ep(~isfinite(Ep)) = 0;

            badmask = ~isfinite(P) ...
                | ~isfinite(Tmean) ...
                | ~isfinite(Ep);
            badrows = int64(find(badmask));

            try
                info = dir(fname);
                src_datenum = info.datenum;
                save(cache_file, ...
                    'P','Ep','Tmean','Tmin', ...
                    'Tmax','Qmm','Qcms', ...
                    'badrows','src_datenum','-v7.3');
            catch
            end
        end

        dat{k}.meteo.P = single(P);
        dat{k}.meteo.Ep = single(Ep);
        dat{k}.meteo.T = single(Tmean);
        dat{k}.meteo.Tmin = single(Tmin);
        dat{k}.meteo.Tmax = single(Tmax);
        dat{k}.meteo.bad = badrows(:)';

        Q = double(Qmm(idx_score));
        bad_q_all = ~isfinite(Qmm);

        dat{k}.y_n = single(Q);
        dat{k}.bad = bad_q_all(idx_score).';

        dat{k}.Q_cms_PL = single(Qcms);
        dat{k}.gauge = gid;
        dat{k}.fname{1} = fname;
        dat{k}.fname{2} = fname;

        if ~isempty(badrows)
            if flag_progress
                fprintf('\n');
            end
            fprintf(['      Warning:read_meteo_PL: ' ...
                'basin %s has %d ' ...
                'invalid/missing daily meteo ' ...
                'rows in requested window.\n'], ...
                gid,numel(badrows));
            pct = floor(100*k/K);
            fprintf(['... Reading daily CAMELS-PL ' ...
                'meteorological data files %3d%%'],pct);
            flag_progress = true;
        end

        if mod(k,20)==0 || k==K
            pct = floor(100*k/K);
            fprintf('\b\b\b\b%3d%%',pct);
            drawnow;
        end

        if isfield(meteo,'progressFcn') ...
                && ~isempty(meteo.progressFcn)
            try
                meteo.progressFcn(k);
            catch
            end
        end
    end

    if flag_progress
        fprintf('\b\b\b\b%s\n','... Done');
    end

    if isfield(split,'local') ...
            && split.local ...
            && isfield(split,'rainfall_block') ...
            && split.rainfall_block
        dat = rainfall_rank_split(dat,split);
    end
end

% =========================================
function split = local_prepare_split(split)
% =========================================
    if exist('prepare_split','file') == 2
        split = prepare_split(split);
        return
    end

    flds = {'dt_spin0','dt_train0', ...
        'dt_train1','dt_eval0','dt_eval1'};
    for i = 1:numel(flds)
        f = flds{i};
        if isfield(split,f) ...
                && ~isempty(split.(f))
            split.(f) = ...
                local_to_datetime(split.(f));
        end
    end
end

% ================================================
function req = local_requested_daily_window(split)
% ================================================
    if exist('build_requested_window','file') == 2
        try
            req0 = build_requested_window(split,true);
            if isfield(req0,'read_start_N') ...
                    && isfield(req0,'read_end_N')
                tRef = datetime(1950,10,1);
                t0 = tRef + days(double(req0.read_start_N));
                t1 = tRef + days(double(req0.read_end_N));
                req.time = (dateshift(t0, ...
                    'start','day'):days(1): ...
                    dateshift(t1,'start','day')).';
                return
            end
            if isfield(req0,'time') ...
                    && ~isempty(req0.time)
                req.time = dateshift( ...
                    datetime(req0.time(:)), ...
                    'start','day');
                return
            end
        catch
        end
    end

    spinup = 0;
    if isfield(split,'spinup') ...
            && ~isempty(split.spinup)
        spinup = max(0,round(double(split.spinup)));
    elseif isfield(split,'n_spin') ...
            && ~isempty(split.n_spin)
        spinup = max(0,round(double(split.n_spin)));
    end

    starts = NaT(0,1);
    ends = NaT(0,1);

    sfields = {'ds','dts','des','d1', ...
        'dt_train0','dt_eval0','dt_spin0'};
    efields = {'de','dte','dee','d2', ...
        'dt_train1','dt_eval1'};

    for i = 1:numel(sfields)
        f = sfields{i};
        if isfield(split,f) ...
                && ~isempty(split.(f))
            starts(end+1,1) = ...
                local_to_datetime(split.(f)); %#ok<AGROW>
        end
    end
    for i = 1:numel(efields)
        f = efields{i};
        if isfield(split,f) ...
                && ~isempty(split.(f))
            ends(end+1,1) = ...
                local_to_datetime(split.(f)); %#ok<AGROW>
        end
    end

    starts = starts(~isnat(starts));
    ends = ends(~isnat(ends));

    if isempty(starts) ...
            || isempty(ends)
        error(['      Error:read_meteo_PL: ' ...
            'could not determine ' ...
            'requested daily time ' ...
            'window from split.']);
    end

    t0 = dateshift(min(starts), ...
        'start','day') - days(spinup);
    t1 = dateshift(max(ends),'start','day');

    if t1 < t0
        error(['      Error:read_meteo_PL: ' ...
            'requested period is empty.']);
    end

    req.time = (t0:days(1):t1).';
end

% ============================================
function dirTs = local_pl_timeseries_dir(dirM)
% ============================================
    dirM = char(string(dirM));
    cands = { ...
        dirM, ...
        fullfile(dirM,'daily','timeseries'), ...
        fullfile(dirM,'timeseries'), ...
        fullfile(dirM,'CAMELS_PL','daily','timeseries'), ...
        fullfile(dirM,'CAMELS_PL','timeseries'), ...
        fullfile(dirM,'CAMELS-PL','daily','timeseries'), ...
        fullfile(dirM,'CAMELS-PL','timeseries'), ...
        fullfile(dirM,'Data','CAMELS_PL','daily','timeseries'), ...
        fullfile(dirM,'Data','CAMELS_PL','timeseries')};

    for i = 1:numel(cands)
        d = cands{i};
        if isfolder(d) ...
                && ~isempty(dir(fullfile(d, ...
                'CAMELS_PL_hydromet_timeseries_*.csv')))
            dirTs = d;
            return
        end
    end

    error(['      Error:read_meteo_PL: ' ...
        'Cannot resolve CAMELS_PL ' ...
        'timeseries directory from: %s'],dirM);
end

% ===================================================
function dirPL = local_pl_root_from_timeseries(dirTs)
% ===================================================
    dirPL = fileparts(dirTs);
    [~,nm] = fileparts(dirTs);
    if strcmpi(nm,'timeseries')
        [pDaily,nmDaily] = fileparts(dirPL);
        if strcmpi(nmDaily,'daily')
            dirPL = pDaily;
        end
        % parent already correct
    else
        dirPL = dirTs;
    end
end

% =========================================================================
function [t,P,Tmean,Tmin,Tmax,Qmm,Qcms] = local_read_pl_hydromet_file(fname)
% =========================================================================
    info = dir(fname);
    if isempty(info) ...
            || info.bytes == 0
        error(['      Error:read_meteo_PL: ' ...
            'Empty file: %s'],fname);
    end

    delim = local_detect_delimiter(fname);
    opts = detectImportOptions(char(fname), ...
        'FileType','text', ...
        'Delimiter',delim, ...
        'VariableNamingRule','preserve');
    opts = setvartype(opts, ...
        opts.VariableNames{1},'char');

    T = readtable(char(fname),opts);
    vn = string(T.Properties.VariableNames);

    jDate = local_find_var(vn, ...
        ["date","time"],1);
    jP = local_find_var(vn, ...
        ["precipitation_mean", ...
        "precipitation","prcp","pr"],5);
    jT = local_find_var(vn, ...
        ["temperature_mean", ...
        "tmean","temp"],9);
    jTmax = local_find_var(vn, ...
        ["maximum_temperature_mean", ...
        "tmax","maximumtemperature"],10);
    jTmin = local_find_var(vn, ...
        ["minimum_temperature_mean", ...
        "tmin","minimumtemperature"],11);
    jQmm = local_find_var(vn, ...
        ["discharge_spec_obs","q_mm", ...
        "runoff","streamflow_mm"],3);
    jQcms = local_find_var(vn, ...
        ["discharge_vol_obs","q_cms", ...
        "streamflow","discharge"],2);

    t = local_parse_pl_date(T{:,jDate});
    P = local_to_double(T{:,jP});
    Tmean = local_to_double(T{:,jT});
    Tmin = local_to_double(T{:,jTmin});
    Tmax = local_to_double(T{:,jTmax});
    Qmm = local_to_double(T{:,jQmm});
    Qcms = local_to_double(T{:,jQcms});

    t = t(:);
    P = P(:);
    Tmean = Tmean(:);
    Tmin = Tmin(:);
    Tmax = Tmax(:);
    Qmm = Qmm(:);
    Qcms = Qcms(:);

    good = ~isnat(t);
    t = t(good);
    P = P(good);
    Tmean = Tmean(good);
    Tmin = Tmin(good);
    Tmax = Tmax(good);
    Qmm = Qmm(good);
    Qcms = Qcms(good);

    if isempty(t)
        error(['      Error:read_meteo_PL: ' ...
            'No valid dates found in: %s'],fname);
    end

    [t,isrt] = sort(t);
    P = P(isrt);
    Tmean = Tmean(isrt);
    Tmin = Tmin(isrt);
    Tmax = Tmax(isrt);
    Qmm = Qmm(isrt);
    Qcms = Qcms(isrt);

    [t,ia] = unique(t,'stable');
    P = P(ia);
    Tmean = Tmean(ia);
    Tmin = Tmin(ia);
    Tmax = Tmax(ia);
    Qmm = Qmm(ia);
    Qcms = Qcms(ia);
end

% ======================================================
function Ep = local_hargreaves_ep(t,Tmean,Tmin,Tmax,lat)
% ======================================================
% Hargreaves-Samani PET [mm/day].
    if ~isfinite(lat)
        lat = 52; % central Poland fallback
    end

    lat = max(min(double(lat),89.9),-89.9);
    phi = lat*pi/180;
    J = day(t,'dayofyear');

    Gsc = 0.0820; % MJ m-2 min-1
    dr = 1 + 0.033*cos(2*pi*J/365);
    delta = 0.409*sin(2*pi*J/365 - 1.39);
    ws = acos(max(min(-tan(phi).*tan(delta),1),-1));

    Ra = (24*60/pi) * Gsc .* dr .* ...
        (ws.*sin(phi).*sin(delta) ...
        + cos(phi).*cos(delta).*sin(ws)); % MJ m-2 day-1
    Ra_mm = Ra / 2.45;

    dT = max(double(Tmax) - double(Tmin),0);
    Ep = 0.0023 .* Ra_mm(:) .* (double(Tmean(:)) + 17.8) ...
        .* sqrt(dT(:));
    Ep(Ep < 0) = 0;
end

% ============================================
function delim = local_detect_delimiter(fname)
% ============================================
    fid = fopen(char(fname),'r');
    if fid < 0
        error('Could not open %s',fname);
    end
    c = onCleanup(@() fclose(fid));
    line = fgetl(fid);
    if ~ischar(line)
        error('Empty file: %s',fname);
    end
    if count(string(line),"\t") ...
            >= count(string(line),";") ...
            && count(string(line),"\t") ...
            >= count(string(line),",")
        delim = '\t';
    elseif count(string(line),";") ...
            >= count(string(line),",")
        delim = ';';
    else
        delim = ',';
    end
end

% ============================================
function j = local_find_var(vn,cands,fallback)
% ============================================
    vnl = lower(regexprep(vn, ...
        '[^a-zA-Z0-9]',''));
    for i = 1:numel(cands)
        c = lower(regexprep(string(cands(i)), ...
            '[^a-zA-Z0-9]',''));
        jj = find(vnl == c,1,'first');
        if ~isempty(jj)
            j = jj;
            return
        end
    end
    for i = 1:numel(cands)
        c = lower(regexprep(string(cands(i)), ...
            '[^a-zA-Z0-9]',''));
        jj = find(contains(vnl,c),1,'first');
        if ~isempty(jj)
            j = jj;
            return
        end
    end
    j = fallback;
end

% =================================
function t = local_parse_pl_date(x)
% =================================
    if isdatetime(x)
        t = dateshift(x(:),'start','day');
        return
    end

    x = string(x(:));
    x = strip(x);
    x = erase(x,'"');

    fmts = {'yyyy-MM-dd','yyyy/MM/dd', ...
        'dd/MM/yyyy','d/M/yyyy', ...
        'dd-MM-yyyy','MM/dd/yyyy'};

    for i = 1:numel(fmts)
        try
            t = datetime(x,'InputFormat',fmts{i});
            if ~any(isnat(t))
                t = dateshift(t,'start','day');
                return
            end
        catch
        end
    end

    t = datetime(x);
    t = dateshift(t,'start','day');
end

% =============================
function x = local_to_double(x)
% =============================
    if isnumeric(x)
        x = double(x(:));
        return
    end
    if iscell(x)
        x = string(x);
    end
    if ischar(x)
        x = string(cellstr(x));
    end
    if isstring(x) ...
            || iscategorical(x)
        xs = string(x(:));
        xs = strip(xs);
        xs = erase(xs,'"');
        xs = strrep(xs,',','.');
        xs = regexprep(xs, ...
            '^(NA|NaN|null|NULL|nan|None|-9999)$', ...
            'NaN','ignorecase');
        xs(xs == "") = "NaN";
        x = str2double(xs);
        return
    end
    error(['      Error:read_meteo_PL: ' ...
        'Unable to convert column to double.']);
end

% ===================================
function id = local_pl_id_strings(x)
% ===================================
    x = string(x(:));
    x = strtrim(x);
    x = regexprep(x,'\.0+$','');
    x = regexprep(x,'[^0-9]','');
    if any(x == "")
        error(['      Error:read_meteo_PL: ' ...
            'Empty CAMELS-PL ' ...
            'basin ID after normalization.']);
    end
    id = x;
end

% ===============================
function t = local_to_datetime(x)
% ===============================
    if isdatetime(x)
        t = x(1);
    elseif isnumeric(x)
        if numel(x) >= 3
            t = datetime(x(1),x(2),x(3));
        else
            t = datetime(x(1), ...
                'ConvertFrom','datenum');
        end
    else
        x = string(x);
        t = datetime(x(1));
    end
    t = dateshift(t,'start','day');
end

% ----------------------------------------
function aux = local_aux_from_bas(bas,aux)
% ----------------------------------------
    K = bas.K;
    if isfield(bas,'lat')
        aux(1:K,1) = double(bas.lat(1:K));
    elseif isfield(bas,'gauge_lat')
        aux(1:K,1) = double(bas.gauge_lat(1:K));
    elseif isfield(bas,'gauge_lat_dd')
        aux(1:K,1) = double(bas.gauge_lat_dd(1:K));
    end

    if isfield(bas,'elev')
        aux(1:K,2) = double(bas.elev(1:K));
    elseif isfield(bas,'gauge_elev')
        aux(1:K,2) = double(bas.gauge_elev(1:K));
    elseif isfield(bas,'elev_mean')
        aux(1:K,2) = double(bas.elev_mean(1:K));
    end

    if isfield(bas,'area')
        a = double(bas.area(1:K));
        if median(a,'omitnan') < 1e7
            a = a * 1e6;
        end
        aux(1:K,3) = a;
    elseif isfield(bas,'area_km2')
        aux(1:K,3) = 1e6 * double(bas.area_km2(1:K));
    elseif isfield(bas,'area_metadata')
        aux(1:K,3) = 1e6 * double(bas.area_metadata(1:K));
    end
end

% ------------------------------------------------------------
function aux = local_aux_from_gauge_information(dirPL,bas,aux)
% ------------------------------------------------------------
    files = { ...
        fullfile(dirPL, ...
        'gauge_information_PL.csv'), ...
        fullfile(dirPL, ...
        'CAMELS_PL_topographic_attributes.csv'), ...
        fullfile(fileparts(dirPL), ...
        'CAMELS_PL_topographic_attributes.csv')};

    f = '';
    for i = 1:numel(files)
        if isfile(files{i})
            f = files{i};
            break
        end
    end
    if isempty(f)
        return
    end

    delim = local_detect_delimiter(f);
    T = readtable(f,'FileType','text', ...
        'Delimiter',delim, ...
        'VariableNamingRule','preserve', ...
        'Encoding','UTF-8');

    vn0 = string(T.Properties.VariableNames);
    vn = lower(regexprep(vn0, ...
        '[^a-zA-Z0-9]',''));

    iID = find(ismember(vn,["gaugeid", ...
        "gageid","id","stationid"]),1);
    if isempty(iID)
        iID = find(contains(vn,"gaugeid") ...
            | contains(vn,"gageid"),1);
    end
    if isempty(iID)
        return
    end

    idT = local_pl_id_strings(T{:,iID});
    idReq = local_pl_id_strings(bas.id_gauge(:));
    [tf,loc] = ismember(idReq,idT);

    if ~any(tf)
        fprintf('\n');
        fprintf(['      Warning:read_meteo_PL: ' ...
            'no selected basin IDs ' ...
            'matched gauge metadata file: %s\n'],f);
        return
    end

    iLatDD = find(ismember(vn,["gaugelatdd", ...
        "lat","latitude"]),1);
    iLonDD = find(ismember(vn,["gaugelondd", ...
        "lon","longitude"]),1);
    iLatRaw = find(ismember(vn,"gaugelat"),1);
    iLonRaw = find(ismember(vn,"gaugelon"),1);
    iElev = find(contains(vn,"elev"),1);
    iArea = find(contains(vn,"areakm2") ...
        | contains(vn,"areametadata") ...
        | strcmp(vn,"area"),1);

    if ~isempty(iLatDD) ...
            && ~isempty(iLonDD)
        lat = double(local_to_double(T{loc(tf),iLatDD}));
        % lon = double(local_to_double(T{loc(tf),iLonDD}));
    elseif ~isempty(iLatRaw) ...
            && ~isempty(iLonRaw)
        a = double(local_to_double(T{loc(tf),iLonRaw}));
        b = double(local_to_double(T{loc(tf),iLatRaw}));
        if median(a,'omitnan') > 40 ...
                && median(b,'omitnan') < 30
            lat = a;
            % lon = b;
        else
            lat = b;
            % lon = a;
        end
    else
        lat = [];
        % lon = [];
    end

    if ~isempty(lat)
        aux(tf,1) = lat;
    end
    
    if ~isempty(iElev)
        aux(tf,2) = double(local_to_double(T{loc(tf),iElev}));
    end
    if ~isempty(iArea)
        area = double(local_to_double(T{loc(tf),iArea}));
        if median(area,'omitnan') < 1e7
            area = area * 1e6;
        end
        aux(tf,3) = area;
    end
end
