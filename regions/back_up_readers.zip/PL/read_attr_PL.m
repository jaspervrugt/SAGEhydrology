function [A,id_gauge,gname,zone] = read_attr_PL(dirD,bas)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%READ_ATTR_PL Read catchment attributes of CAMELS-PL dataset.
%
% Expected files in Data/CAMELS_PL:
%   CAMELS_PL_BDOT10K_land_cover_catchments.csv
%   CAMELS_PL_climatic_attributes.csv
%   CAMELS_PL_hydrologic_attributes.csv
%   CAMELS_PL_landcover_attributes.csv
%   CAMELS_PL_simulation_benchmark.csv
%   CAMELS_PL_soil_attributes.csv
%   CAMELS_PL_topographic_attributes.csv
%
% Notes:
%   - CAMELS-PL topographic file labels gauge_lon/gauge_lat, but the
%     example files store latitude-like values in gauge_lon and
%     longitude-like values in gauge_lat. This reader writes corrected
%     fields gauge_lat_dd and gauge_lon_dd and uses those for maps.
%   - Hydrologic signatures and model benchmark scores are available in
%     the joined table, but omitted from the default predictor attributes.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    if nargin < 1 ...
            || isempty(dirD)
        error('read_attr_PL:missingDir', ...
            ['      Error:read_attr_PL: ' ...
            'dirD must be provided.']);
    end
    if ~isfolder(dirD)
        error('read_attr_PL:missingDir', ...
            ['      Error:read_attr_PL: ' ...
            'Attribute directory ' ...
             'does not exist: %s'],dirD);
    end
    if nargin < 2 ...
            || isempty(bas)
        bas = struct();
    end
    if ~isstruct(bas)
        error('read_attr_PL:badBas', ...
            ['      Error:read_attr_PL: ' ...
            'bas must be a structure.']);
    end
    % =========================================
    % ZONE CONTROL PARAMETERS (GLOBAL DEFAULTS)
    % =========================================
    if ~isfield(bas,'min_per_zone') ...
            || isempty(bas.min_per_zone)
        min_per_zone = 5;
    else
        min_per_zone = bas.min_per_zone;
    end    
    if ~isfield(bas,'max_zones') ...
            || isempty(bas.max_zones)
        max_zones = 8;
    else
        max_zones = bas.max_zones;
    end

    pr_table = 1;
    if isfield(bas,'pr_attr') ...
            && ~isempty(bas.pr_attr)
        pr_table = bas.pr_attr;
    end

    fprintf(['... Reading CAMELS-PL ' ...
        'basin attributes ']);

    AA = read_camels_pl_attribute_tables(dirD);

    needVars = {'gauge_id', ...
        'gauge_lat_dd','gauge_lon_dd','area_km2'};
    for j = 1:numel(needVars)
        if ~ismember(needVars{j}, ...
                AA.Properties.VariableNames)
            error('read_attr_PL:missingMetadata', ...
                ['      Error:read_attr_PL: ' ...
                'missing required ' ...
                 'variable: %s'],needVars{j});
        end
    end

    id_all = normalize_pl_gauge_id(AA.gauge_id);
    AA.gauge_id = id_all;

    [~,isrt] = sort(str2double(id_all));
    AA = AA(isrt,:);
    id_all = id_all(isrt);

    if isfield(bas,'id_gauge') ...
            && ~isempty(bas.id_gauge)
        id_req = normalize_pl_gauge_id(bas.id_gauge(:));
        [tf,locid] = ismember(id_req,id_all);
        if ~all(tf)
            missing = id_req(~tf);
            error('read_attr_PL:missingRequestedGauge', ...
                ['      Error:read_attr_PL: ' ...
                'Missing CAMELS-PL ' ...
                 'attributes for %d requested ' ...
                 'gauge IDs, e.g. %s.'], ...
                numel(missing),char(missing(1)));
        end
        AA = AA(locid,:);
        id_gauge = id_req(:);
    else
        id_gauge = id_all(:);
    end

    if ismember('gauge_name', ...
            AA.Properties.VariableNames)
        gname = string(AA.gauge_name);
    elseif ismember('water_body_name', ...
            AA.Properties.VariableNames)
        gname = string(AA.water_body_name);
    else
        gname = "PL_" + id_gauge;
    end

    gname = standardize_camels_gauge_names(gname, ...
        'CAMELS_PL',id_gauge);

    ensure_pl_gauge_information(dirD,AA,gname);
    region = erase(mfilename,'read_attr_');
    zone = classify_camels_all_zones(region,AA, ...
        min_per_zone,max_zones);
    
    % ------------------
    % Generic attributes
    % ------------------
    [A,labels] = build_attr_matrix(AA,bas, ...
        mfilename,pr_table);

    if pr_table == 1
        assignin('base', ...
            'SAGE_PL_attribute_labels',labels);
    end

    fprintf(' ... Done\n');
end

% =================================================
function AA = read_camels_pl_attribute_tables(dirD)
% =================================================

    f_topo = fullfile(dirD, ...
        'CAMELS_PL_topographic_attributes.csv');
    f_clim = fullfile(dirD, ...
        'CAMELS_PL_climatic_attributes.csv');
    f_hyd  = fullfile(dirD, ...
        'CAMELS_PL_hydrologic_attributes.csv');
    f_land = fullfile(dirD, ...
        'CAMELS_PL_landcover_attributes.csv');
    f_soil = fullfile(dirD, ...
        'CAMELS_PL_soil_attributes.csv');
    f_bdot = fullfile(dirD, ...
        'CAMELS_PL_BDOT10K_land_cover_catchments.csv');
    f_bench = fullfile(dirD, ...
        'CAMELS_PL_simulation_benchmark.csv');

    caller = mfilename;
    must_exist(f_topo, ...
        'CAMELS_PL_topographic_attributes.csv',caller);
    must_exist(f_clim, ...
        'CAMELS_PL_climatic_attributes.csv',caller);
    must_exist(f_hyd, ...
        'CAMELS_PL_hydrologic_attributes.csv',caller);
    must_exist(f_land, ...
        'CAMELS_PL_landcover_attributes.csv',caller);
    must_exist(f_soil, ...
        'CAMELS_PL_soil_attributes.csv',caller);
    must_exist(f_bench, ...
        'CAMELS_PL_simulation_benchmark.csv',caller);

    topo = read_pl_csv(f_topo,'topographic');
    clim = read_pl_csv(f_clim,'climate');
    hyd  = read_pl_csv(f_hyd,'hydrology');
    land = read_pl_csv(f_land,'landcover');
    soil = read_pl_csv(f_soil,'soil');
    bench = read_pl_csv(f_bench,'benchmark');

    AA = topo;
    AA = join_pl_attributes(AA,clim);
    AA = join_pl_attributes(AA,hyd);
    AA = join_pl_attributes(AA,land);
    AA = join_pl_attributes(AA,soil);
    AA = join_pl_attributes(AA,bench);

    if isfile(f_bdot)
        bdot = read_pl_csv(f_bdot,'bdot10k');
        AA = join_pl_attributes(AA,bdot);
    end

    AA = local_fix_pl_coordinates(AA);

    if ismember('area_metadata', ...
            AA.Properties.VariableNames)
        AA.area_km2 = double(AA.area_metadata);
    elseif ~ismember('area_km2', ...
            AA.Properties.VariableNames)
        AA.area_km2 = nan(height(AA),1);
    end
end

% ==================================
function T = read_pl_csv(fname,kind)
% ==================================
    delim = local_detect_delimiter(fname);
    opts = detectImportOptions(fname, ...
        'FileType','text', ...
        'Delimiter',delim, ...
        'Encoding','UTF-8');
    opts.VariableNamingRule = 'preserve';

    T = readtable(fname,opts);

    if height(T) > 0
        emptyRow = true(height(T),1);
        for j = 1:width(T)
            v = T{:,j};
            if isnumeric(v) ...
                    || islogical(v)
                emptyRow = emptyRow ...
                    & all(isnan(v),2);
            else
                s = string(v);
                emptyRow = emptyRow ...
                    & (ismissing(s) ...
                    | strlength(strtrim(s)) == 0);
            end
        end
        T(emptyRow,:) = [];
    end

    T.Properties.VariableNames = matlab.lang.makeUniqueStrings( ...
        matlab.lang.makeValidName(strtrim( ...
        string(T.Properties.VariableNames))));

    if ~ismember('gauge_id',T.Properties.VariableNames)
        error('read_attr_PL:missingGaugeID', ...
            ['      Error:read_attr_PL: ' ...
            '%s has no gauge_id column.'],fname);
    end

    T.gauge_id = normalize_pl_gauge_id(T.gauge_id);

    for j = 1:width(T)
        vn = T.Properties.VariableNames{j};
        if any(strcmp(vn,{'gauge_id','gauge_name', ...
                'water_body_name','high_prec_timing', ...
                'low_prec_timing','flow_period_start', ...
                'flow_period_end'}))
            continue
        end
        T.(vn) = local_to_double_or_keep(T.(vn));
    end

    % Prefix BDOT10K variables that overlap with ordinary land-cover names.
    if strcmpi(kind,'bdot10k')
        vars = T.Properties.VariableNames;
        for j = 1:numel(vars)
            if strcmp(vars{j},'gauge_id')
                continue
            end
            if ~startsWith(vars{j},'bdot_')
                T.Properties.VariableNames{j} = ...
                    ['bdot_' vars{j}];
            end
        end
    end
end

% ==================================
function T = join_pl_attributes(T,U)
% ==================================
    varsT = string(T.Properties.VariableNames);
    varsU = string(U.Properties.VariableNames);
    varsU = varsU(varsU ~= "gauge_id");

    for j = 1:numel(varsU)
        if any(varsT == varsU(j))
            old = char(varsU(j));
            new = char(varsU(j) + "_pl");
            U.Properties.VariableNames{strcmp( ...
                U.Properties.VariableNames,old)} = new;
        end
    end

    T = outerjoin(T,U, ...
        'Keys','gauge_id', ...
        'MergeKeys',true, ...
        'Type','left');
end

% ========================================
function AA = local_fix_pl_coordinates(AA)
% ========================================
    if ~all(ismember({'gauge_lon','gauge_lat'}, ...
            AA.Properties.VariableNames))
        return
    end

    a = double(AA.gauge_lon(:));
    b = double(AA.gauge_lat(:));

    % Poland: latitude approximately 49-55, longitude approximately 14-24.
    % The current CAMELS-PL topographic file has gauge_lon=latitude and
    % gauge_lat=longitude. Detect and correct this safely.
    if median(a,'omitnan') > 40 ...
            && median(b,'omitnan') < 30
        AA.gauge_lat_dd = a;
        AA.gauge_lon_dd = b;
    else
        AA.gauge_lat_dd = b;
        AA.gauge_lon_dd = a;
    end
end

% ====================================
function id = normalize_pl_gauge_id(x)
% ====================================
    x = string(x(:));
    x = strtrim(x);
    x = regexprep(x,'\.0+$','');
    x = regexprep(x,'[^0-9]','');
    if any(x == "")
        error('read_attr_PL:badGaugeID', ...
            ['      Error:read_attr_PL: ' ...
            'empty gauge_id after normalization.']);
    end
    id = x;
end

% =================================================
function ensure_pl_gauge_information(dirD,AA,gname)
% =================================================
    fname = fullfile(dirD, ...
        'gauge_information_PL.csv');
    if isfile(fname)
        return
    end

    T = table();
    T.gauge_id = normalize_pl_gauge_id(AA.gauge_id);
    T.gauge_name = string(gname(:));

    if ismember('water_body_name', ...
            AA.Properties.VariableNames)
        T.water_body_name = string( ...
            AA.water_body_name(:));
    end
    T.gauge_lat = double(AA.gauge_lat_dd(:));
    T.gauge_lon = double(AA.gauge_lon_dd(:));
    if ismember('gauge_elev', ...
            AA.Properties.VariableNames)
        T.gauge_elev = double(AA.gauge_elev(:));
    else
        T.gauge_elev = nan(height(AA),1);
    end
    T.area_km2 = double(AA.area_km2(:));

    try
        writetable(T,fname);
    catch
    end
end

% ============================================
function delim = local_detect_delimiter(fname)
% ============================================
    fid = fopen(fname,'r');
    if fid < 0
        error('read_attr_PL:openFailed', ...
            'Could not open %s',fname);
    end
    c = onCleanup(@() fclose(fid));
    line = fgetl(fid);
    if ~ischar(line)
        error('read_attr_PL:emptyFile', ...
            'Empty file: %s',fname);
    end
    if count(string(line),";") >= count(string(line),",")
        delim = ';';
    else
        delim = ',';
    end
end

% =====================================
function x = local_to_double_or_keep(x)
% =====================================
    if isnumeric(x) ...
            || islogical(x)
        return
    end
    if iscell(x)
        xs = string(x);
    elseif ischar(x)
        xs = string(cellstr(x));
    elseif isstring(x) ...
            || iscategorical(x)
        xs = string(x);
    else
        return
    end

    xs = strtrim(xs);
    xs = erase(xs,'"');
    xs = strrep(xs,',','.');
    xs = regexprep(xs,'^(NA|NaN|null|NULL|nan|None|-9999)$', ...
        'NaN','ignorecase');
    y = str2double(xs);
    good = ~(ismissing(xs) ...
        | xs == "");
    if ~any(good) ...
            || sum(isfinite(y(good)) ...
            | isnan(y(good))) ...
            >= 0.9*sum(good)
        x = y;
    end
end
