function R=region_config_AR()
%REGION_CONFIG_AR Defaults for Argentina GRDC-Caravan.
    R=region_config_GRDC('AR','Argentina',59,46,38,8, ...
        '01/10/1958','30/09/1978','01/10/1978','30/09/1998');
end
