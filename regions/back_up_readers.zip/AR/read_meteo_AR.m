function [dat,aux]=read_meteo_AR(dirM,bas,split,meteo)
%READ_METEO_AR Read daily Argentina GRDC-Caravan forcing and discharge.
    [dat,aux]=read_meteo_NA(dirM,bas,split,meteo,'Argentina');
end
