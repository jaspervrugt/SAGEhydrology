function dat=read_Q_AR(~,~,dat,~,~,~)
%READ_Q_AR No-op: GRDC-Caravan streamflow is read with meteorology.
end
