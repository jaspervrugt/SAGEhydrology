function [A,id_gauge,gname,zone]=read_attr_AR(dirD,bas)
%READ_ATTR_AR Read filtered Argentina GRDC-Caravan attributes.
    [A,id_gauge,gname,zone]=read_attr_NA(dirD,bas,'CAMELS_AR','AR');
end
